<?php $mts_options = get_option(MTS_THEME_NAME); ?>

<section class="featured-on clearfix" style="background: <?php echo $mts_options['mts_featured_on_background']; ?>">
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" style="fill:<?php echo $mts_options['mts_featured_on_background']; ?>">
		<path class="elementor-shape-fill" d="M761.9,40.6L643.1,24L333.9,93.8L0.1,1H0v99h1000V1"></path>
	</svg>
	<div class="container clearfix">
		<h2 class="section-title" style="color:<?php echo $mts_options['mts_featured_on_headline_color']; ?>"><span><?php echo $mts_options['mts_featured_on_heading']; ?></span></h2>

		<?php foreach( $mts_options['mts_featured_on_items'] as $featured_item ) : ?>
			<div class="featured-item">
				<img src="<?php echo $featured_item['mts_featured_on_item_logo']; ?>">
				<p style="color:<?php echo $featured_item['mts_featured_on_item_text_color']; ?>"><?php echo $featured_item['mts_featured_on_item_text']; ?></p>
			</div>
		<?php endforeach; ?>
	</div>
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" style="fill:<?php echo $mts_options['mts_featured_on_background']; ?>">
		<path class="elementor-shape-fill" d="M761.9,44.1L643.1,27.2L333.8,98L0,3.8V0l1000,0v3.9"></path>
	</svg>
</section>