<?php $mts_options = get_option(MTS_THEME_NAME); ?>

<section class="newsletter newsletter-2 clearfix" style="<?php echo mts_get_background_styles( 'mts_subscription_box_2_background' ); ?> color: <?php echo $mts_options['mts_subscription_box_2_text_color']; ?>">
	<div class="container clearfix">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar( 'homepage' ) ) : ?><?php endif; ?>
		<svg viewBox="0 0 128 128" xmlns="http://www.w3.org/2000/svg" style="position: absolute; top: -90px; right: 0; width: 500px;"><defs><style>.cls-1{fill:#000;}.cls-2{fill:#000;fill-opacity: .03;}.cls-3{fill:#000;fill-opacity: .05;}.cls-4{fill:#000;}</style></defs><title></title><g data-name="01 Web Analytics" id="_01_Web_Analytics" style="fill-opacity: 0.05;"><path class="cls-1" d="M112,64A48,48,0,1,1,64,16,48,48,0,0,1,112,64ZM64,46A18,18,0,1,0,82,64,18,18,0,0,0,64,46Z"></path><path class="cls-2" d="M64,46A18,18,0,0,1,82,64h30A48,48,0,0,0,64,16Z"></path><path class="cls-3" d="M76.73,76.72h0L97.94,97.94h0A47.85,47.85,0,0,0,112,64H82A17.94,17.94,0,0,1,76.73,76.72Z"></path><path class="cls-4" d="M97.94,98,76.73,76.77l18.78,23.47C96.34,99.52,97.15,98.78,97.94,98Z"></path></g></svg>
	</div>
</section>