<?php $mts_options = get_option(MTS_THEME_NAME); ?>

<section class="blog clearfix" style="<?php echo mts_get_background_styles( 'mts_blog_section_background' ); ?>">
	<div class="container clearfix">
		<?php if($mts_options['mts_blog_section_heading_url']) { ?><a href="<?php echo $mts_options['mts_blog_section_heading_url']; ?>"><?php } ?><h2 class="section-title" style="color:<?php echo $mts_options['mts_blog_section_headline_color']; ?>"><span><?php echo $mts_options['mts_blog_section_heading']; ?></span></h2><?php if($mts_options['mts_blog_section_heading_url']) { ?></a><?php } ?>
		<?php $j = 0;
		$blog_args = array( 'ignore_sticky_posts' => 1, 'post_status' => 'publish', 'posts_per_page' => 2 );
		$blog_query = new WP_Query( $blog_args );
		while ( $blog_query->have_posts() ) : $blog_query->the_post(); ?>
			<article class="latestPost excerpt <?php echo (++$j % 3 == 0) ? 'last' : ''; ?>">
				<?php mts_archive_post($layout = 'small-thumb'); ?>
			</article>
		<?php endwhile; wp_reset_postdata(); ?>
	</div>
</section>