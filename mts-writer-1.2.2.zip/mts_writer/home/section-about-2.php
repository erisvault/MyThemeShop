<?php $mts_options = get_option(MTS_THEME_NAME); ?>

<section class="about about-2 clearfix" style="<?php echo mts_get_background_styles( 'mts_about_2_background' ); ?>">
	<div class="container clearfix">
		<h2 class="section-title" style="color:<?php echo $mts_options['mts_about_2_headline_color']; ?>"><span><?php echo $mts_options['mts_about_2_heading']; ?></span></h2>
		<img src="<?php echo $mts_options['mts_about_2_img']; ?>" class="about-img">
		<div class="about-text" style="color:<?php echo $mts_options['mts_about_2_text_color']; ?>">
			<?php echo do_shortcode( $mts_options['mts_about_2_text'] ); ?>
		</div>
	</div>
</section>
