<?php $options = get_option('awake'); ?>
<?php get_header(); ?>
<div id="page">
	<div class="content">
		<article class="article">
			<div id="content_box">
				<?php if (is_home() && !is_paged()) { ?>
					<?php if($options['mts_featured_slider'] == '1') { ?>
						<div class="slider-container">
							<div class="flex-container">
								<div class="flexslider">
									<ul class="slides">
										<?php $my_query = new WP_Query('cat='.$options['mts_featured_slider_cat'].'&posts_per_page=4'); while ($my_query->have_posts()) : $my_query->the_post(); $image_id = get_post_thumbnail_id(); $image_url = wp_get_attachment_image_src($image_id,'slider'); $image_url = $image_url[0]; ?>
										<li data-thumb="<?php echo $image_url; ?>">
											<a href="<?php the_permalink() ?>">
												<?php the_post_thumbnail('slider',array('title' => '')); ?>
											</a>
											<p class="flex-caption">
												<span class="sliderCat"><?php $category = get_the_category(); if ($category) { echo '<a href="' . get_category_link( $category[0]->term_id ) . '" title="' . sprintf( __( "View all posts in %s" ), $category[0]->name ) . '" ' . '>' . $category[0]->name.'</a> '; } ?></span>
												<span class="title slidertitle"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></span>
												<span class="slidertext"><?php echo excerpt(24); ?> <a href="<?php the_permalink() ?>"><?php _e('...Continue Reading ','mythemeshop'); ?></a></span>	
											</p>
										</li>
										<?php endwhile; ?>
									</ul>
								</div>
							</div>
						</div>
					<?php } ?> 
				<?php } ?>
				<div class="leftBox">
					<div class="firstLeftBox">
						<?php $i = 1; $my_query = new wp_query( '&posts_per_page=4' ); ?>
						<h4 class="frontTitle"><?php _e('Latest News','mythemeshop'); ?></h4>
						<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
						<div class="frontPost excerpt">
							<h2 class="title front-view-title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
							<a id="featured-thumbnail" href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_post_thumbnail('featured',array('title' => '')); ?></a>
							<div class="post-content front-view-text">
								<?php echo excerpt(11);?>
								<div class="readMore">
									...<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Continue Reading','mythemeshop'); ?></a>
								</div>
							</div>
						</div>                   
						<?php $i++; endwhile; endif;?>
						<a class="green-button" href="<?php bloginfo('url'); ?>/latest"><?php _e('View More','mythemeshop'); ?></a>
					</div>
					<div class="secondLeftBox">
						<?php $i = 1; $my_query = new wp_query( 'cat='.$options['mts_left_second_cat'].'&posts_per_page=5' ); ?>
						<?php $categoryID = $options['mts_left_second_cat']; ?>						
						<h4 class="frontTitle"><?php if ($options['mts_left_second_cat']!='') { echo get_the_category_by_ID( $categoryID ); } ?></h4>
						<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
						<div class="frontPost excerpt <?php if($i == 3){echo 'last';} ?>">
							<h2 class="title front-view-title-italic"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
							<a id="featured-thumbnail" href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_post_thumbnail('widgetthumb',array('title' => '')); ?></a>
							<div class="post-info">
								<span class="postAuthor"><strong><?php _e('Posted By','mythemeshop'); ?>:</strong> <?php the_author_posts_link(); ?></span>
								<time><strong><?php _e('On','mythemeshop'); ?>:</strong> <?php the_time('j/m/Y'); ?></time>
							</div>
							<div class="readMore">
								<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Read Full Article','mythemeshop'); ?></a>
							</div>
						</div>                   
						<?php $i++; endwhile; endif;?> 
					</div>
				</div><!-- .leftBox -->
				<div class="rightBox">
					<div class="firstRightBox">
						<?php $i = 1; $my_query = new wp_query( 'cat='.$options['mts_right_first_cat'].'&posts_per_page=5' ); ?>
						<?php $categoryID = $options['mts_right_first_cat']; ?>
						<h4 class="frontTitle"><?php if ($options['mts_right_first_cat']!='') { echo get_the_category_by_ID( $categoryID ); } ?></h4>
						<ul>
							<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
								<li>
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
								</li>						
							<?php endwhile; endif;?>
						</ul>
					</div>
					<div class="secondRightBox">
						<?php $i = 1; $my_query = new wp_query( 'cat='.$options['mts_right_second_cat'].'&posts_per_page=3' ); ?>
						<?php $categoryID = $options['mts_right_second_cat']; ?>
						<h4 class="frontTitle"><?php if ($options['mts_right_second_cat']!='') { echo get_the_category_by_ID( $categoryID ); } ?></h4>
						<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
						<div class="frontPost excerpt <?php if($i == 2){echo 'last';} ?>">
							<h2 class="title front-view-title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
							<a id="featured-thumbnail" href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_post_thumbnail('featured',array('title' => '')); ?></a>
							<div class="post-content front-view-text">
								<?php echo excerpt(11);?>
								<div class="readMore">
									...<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Continue Reading','mythemeshop'); ?></a>
								</div>
							</div>
						</div>                   
						<?php $i++; endwhile; endif;?>
						<?php $categoryId = $options['mts_right_second_cat']; $category_link = get_category_link( $categoryId ); ?>						
						<a class="blue-button" href="<?php echo esc_url( $category_link ); ?>"><?php _e('View More','mythemeshop'); ?></a>
					</div>
					<div class="thirdRightBox">
						<?php $i = 1; $my_query = new wp_query( 'cat='.$options['mts_right_third_cat'].'&posts_per_page=3' ); ?>
						<?php $categoryID = $options['mts_right_third_cat']; ?>
						<h4 class="frontTitle"><?php if ($options['mts_right_third_cat']!='') { echo get_the_category_by_ID( $categoryID ); } ?></h4>
						<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
						<div class="frontPost excerpt <?php if($i == 2){echo 'last';} ?>">
							<h2 class="title front-view-title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
							<a id="featured-thumbnail" href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_post_thumbnail('featured',array('title' => '')); ?></a>
							<div class="post-content front-view-text">
								<?php echo excerpt(11);?>
							<div class="readMore">
								...<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Continue Reading','mythemeshop'); ?></a>
							</div>
							</div>
						</div>                   
						<?php $i++; endwhile; endif;?>
						<?php $categoryId = $options['mts_right_second_cat']; $category_link = get_category_link( $categoryId ); ?>						
						<a class="green-button" href="<?php echo esc_url( $category_link ); ?>"><?php _e('View More','mythemeshop'); ?></a>
					</div>
				</div><!-- .rightBox -->
				<div class="carousel-container">
					<?php if (is_home() && !is_paged()) { ?>
						<?php if($options['mts_carousel'] == '1') { ?>
						<div class="flex-container">
							<div class="carousel">
							<?php $f4cat=$options['mts_featured_carousel_cat'];  if ($options['mts_featured_carousel_cat']!='') { echo '<h4 class="frontTitle">'.get_the_category_by_id($f4cat).'</h4>'; } ?>
								<ul class="slides">
								<?php $my_query = new WP_Query('cat='.$options['mts_featured_carousel_cat'].'&posts_per_page=6'); while ($my_query->have_posts()) : $my_query->the_post(); $image_id = get_post_thumbnail_id(); $image_url = wp_get_attachment_image_src($image_id,'slider'); $image_url = $image_url[0]; ?>
									<li data-thumb="<?php echo $image_url; ?>">
										<div class="carousel-thumbnail">
											<a href="<?php the_permalink() ?>">
												<?php the_post_thumbnail('carousel',array('title' => '')); ?>	
											</a>									
										</div>
										<a class="carouseltitle" href="<?php the_permalink() ?>"><?php the_title(); ?></a>
									</li>
							   <?php endwhile; ?>
							   </ul>
							</div>
						</div>
						<?php } ?> 
					<?php } ?>
				</div><!--carousel-container-->
			</div>
		</article>
		<?php get_sidebar(); ?>
<?php get_footer(); ?>