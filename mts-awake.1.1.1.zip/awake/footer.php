<?php $options = get_option('awake'); ?>
		</div><!--#page-->
	</div><!--.container-->
</div>
<footer>
	<div class="container">
		<div class="footer-widgets">
			<?php widgetized_footer(); ?>			
			
			<?php if($options['mts_show_disclaimer'] == '1') { ?>
				<div class="disclaimer">
					<?php mts_disclaimer(); ?>
				</div>
			<?php } ?> 
			<div class="copyrights">
				<?php mts_copyrights_credit(); ?>
			</div> 
		</div><!--.footer-widgets-->
	</div><!--.container-->
</footer><!--footer-->
<?php mts_footer(); ?>
<?php wp_footer(); ?>
</body>
</html>