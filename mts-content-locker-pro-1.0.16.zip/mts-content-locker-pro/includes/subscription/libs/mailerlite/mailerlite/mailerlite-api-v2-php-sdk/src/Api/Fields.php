<?php

namespace MailerLiteApi\Api;

use MailerLiteApi\Common\ApiAbstract;

class Fields extends ApiAbstract {

    protected $endpoint = 'fields';

}