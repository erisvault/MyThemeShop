<h4><?php esc_html_e( 'What is the More Tag?', 'content-locker' ); ?></h4>
<img src="<?php echo cl()->plugin_url(); ?>/admin/assets/img/more-tag.png" alt="" style="position:relative;left:-7px;" />
<p>
	<?php echo wp_kses_post( __( 'Check out <a href="#" target="_blank">Splitting Content &gt; More Tag</a> to lean more.', 'content-locker' ) ); ?>
</p>
