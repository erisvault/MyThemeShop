<div class="cmb-row no-border cmb-half textright">
	<img src="<?php echo cl()->plugin_url(); ?>/admin/assets/img/lock-para.png" alt="" style="position:relative;left:-7px;">
</div>
