<div class="wrap mts-wrap wrap-cl-settings">

	<h1><?php esc_html_e( 'Settings', 'content-locker' ); ?></h1>

	<?php cl()->settings->display(); ?>

</div>
