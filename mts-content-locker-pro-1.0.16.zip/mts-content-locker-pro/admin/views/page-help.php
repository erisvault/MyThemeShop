<div class="wrap mts-wrap mts-wrap-help">

	<?php cl()->help_manager->display(); ?>

</div>
