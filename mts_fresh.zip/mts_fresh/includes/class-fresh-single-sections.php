<?php
/**
 * Sidebars
 *
 * @package Fresh
 */

defined( 'WPINC' ) || exit;

/**
 * Single sections
 */
class Fresh_Single_Sections extends Fresh_Base {

	public function render() {
		?>
		<article class="<?php fresh_article_class(); ?>">
			<?php
			if ( 'mts_nosidebar' !== mts_custom_sidebar() ) {
				$sidebar = fresh_custom_sidebar_layout();
			} else {
				$sidebar = 'nosidebar';
			}
			?>
			<div id="content_box" class="<?php echo $sidebar; ?>">
				<?php
				// Elementor 'single' location.
				if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'single' ) ) {
					if ( have_posts() ) :
						while ( have_posts() ) :
							the_post();
							$img_size = fresh_get_settings( 'featured_image_size' );
							?>
							<div id="post-<?php the_ID(); ?>" <?php post_class( 'g post' . isset( $img_size ) ? 'header-style-' . $img_size : '' ); ?>>
								<?php
								if ( fresh_get_settings( 'mts_breadcrumb' ) ) {
									fresh_breadcrumbs();
								}
								// Single post parts ordering.
								if ( ( null !== fresh_get_settings( 'mts_single_post_layout' ) ) && is_array( fresh_get_settings( 'mts_single_post_layout' ) ) && array_key_exists( 'enabled', fresh_get_settings( 'mts_single_post_layout' ) ) ) {
									$single_post_parts = fresh_get_settings( 'mts_single_post_layout' )['enabled'];
								} else {
									$single_post_parts = array(
										'content'   => 'content',
										'related'   => 'related',
										'author'    => 'author',
										'subscribe' => 'subscribe',
									);
								}

								foreach ( $single_post_parts as $part => $label ) {
									switch ( $part ) {
										// Content area.
										case 'content':
											fresh()->single_sections->single_post();
											break;

										// Post tags.
										case 'tags':
											fresh_post_tags( '<div class="tags"><span class="tagtext"></span>', '' );
											break;

										// Related Posts.
										case 'related':
											if ( 'default' === fresh_get_settings( 'related_posts_position' ) ) {
												fresh_related_posts();
											}
											break;

										// Author box.
										case 'author':
											fresh()->single_sections->single_author_section();
											break;

										// Subscribe box.
										case 'subscribe':
											fresh()->single_sections->single_subscribe_box();
											break;
									}
								}
								?>
							</div><!--.g post-->
							<?php
							// Comment area.
							comments_template( '', true );

						endwhile;
					endif; /* end loop */
				}
				?>
			</div>
		</article>
		<?php
	}

	public function single_post() {
		?>
		<div class="single_post <?php echo $sidebar; ?>">

			<?php fresh_action( 'single_post_header' ); ?>

			<div class="post-single-content box mark-links entry-content">

				<?php
				$this->single_post_ads( 'above' );

				$this->single_post_social_icons( 'above' );
				?>

				<div class="thecontent">
					<?php the_content(); ?>
				</div>

				<?php
				$this->single_post_pagination();

				$this->single_post_ads( 'below' );

				$this->single_post_social_icons( 'below' );
				?>

			</div><!--.post-single-content-->
		</div><!--.single_post-->
		<?php
	}

	public function single_post_pagination() {
		// Single Post Pagination.
		$args = array(
			'before'           => '<div class="pagination">',
			'after'            => '</div>',
			'link_before'      => '<span class="current"><span class="currenttext">',
			'link_after'       => '</span></span>',
			'next_or_number'   => 'next_and_number',
			'nextpagelink'     => '<i class="fa fa-chevron-right"></i>',
			'previouspagelink' => '<i class="fa fa-chevron-left"></i>',
			'pagelink'         => '%',
			'echo'             => 1,
		);
		wp_link_pages( $args );
	}

	public function single_author_section() {
	?>
		<div class="postauthor">

			<?php
			// Author box title.
			$author_title = fresh_get_settings( 'author_box_title' );
			if ( $author_title ) {
				echo '<h4>' . $author_title . '</h4>';
			}
			// Author gravatar.
			if ( function_exists( 'get_avatar' ) ) {
				echo get_avatar( get_the_author_meta( 'email' ), '90' ); // Gravatar size.
			}
			?>
			<h5 class="vcard author">
				<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" class="fn">
					<?php the_author_meta( 'display_name' ); ?>
				</a>
			</h5>
			<p><?php the_author_meta( 'description' ); ?></p>
		</div>
	<?php
	}

	public function single_subscribe_box() {
		if ( is_active_sidebar( 'single-subscribe' ) ) {
		?>
			<div class="single-subscribe clear">
				<?php dynamic_sidebar( 'single-subscribe' ); ?>
			</div>
		<?php
		}
	}

	public function single_post_ads( $location ) {
		// Above Content Ad Code.
		if ( ! empty( fresh_get_settings( 'mts_posttop_adcode' ) ) && 'above' == $location ) {
			$toptime = ! empty( fresh_get_settings( 'mts_posttop_adcode_time' ) ) ? fresh_get_settings( 'mts_posttop_adcode_time' ) : '0';
			if ( strcmp( date( 'Y-m-d', strtotime( -$toptime . ' day' ) ), get_the_time( 'Y-m-d' ) ) >= 0 ) {
				?>
				<div class="topad">
					<?php echo do_shortcode( fresh_get_settings( 'mts_posttop_adcode' ) ); ?>
				</div>
				<?php
			}
		}
		// Below Content Ad Code.
		if ( ! empty( fresh_get_settings( 'mts_postend_adcode' ) ) && 'below' == $location ) {
			$endtime = ! empty( fresh_get_settings( 'mts_postend_adcode_time' ) ) ? fresh_get_settings( 'mts_postend_adcode_time' ) : '0';
			if ( strcmp( date( 'Y-m-d', strtotime( -$endtime . ' day' ) ), get_the_time( 'Y-m-d' ) ) >= 0 ) {
				?>
				<div class="bottomad">
					<?php echo do_shortcode( fresh_get_settings( 'mts_postend_adcode' ) ); ?>
				</div>
				<?php
			}
		}
	}

	public function single_post_social_icons( $location ) {
		// Social Share icons above content.
		if ( null !== fresh_get_settings( 'mts_social_button_position' ) && 'top' === fresh_get_settings( 'mts_social_button_position' ) && 'above' == $location ) {
			fresh_social_buttons();
		}
		// Social Share icons below content and floating.
		if ( ( null !== fresh_get_settings( 'mts_social_button_position' ) ) && 'top' !== fresh_get_settings( 'mts_social_button_position' ) && 'below' == $location ) {
			fresh_social_buttons();
		}
	}

}
