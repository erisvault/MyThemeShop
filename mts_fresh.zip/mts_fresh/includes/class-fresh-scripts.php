<?php
/**
 * Script enqueueing manager.
 *
 * @package Fresh
 */

defined( 'WPINC' ) || exit;

/**
 * Script enqueueing manager.
 */
class Fresh_Scripts extends Fresh_Base {

	/**
	 * The Constructor
	 */
	public function __construct() {

		if ( ! is_admin() && ! in_array( $GLOBALS['pagenow'], array( 'wp-login.php', 'wp-register.php' ) ) ) {

			$this->add_action( 'wp_enqueue_scripts', 'enqueue_scripts' );

			if ( fresh_get_settings( 'optimize_wc' ) ) {

				$this->add_action( 'wp_enqueue_scripts', 'remove_woocommerce_scripts', 99 );

				// Remove WooCommerce generator tag.
				remove_action( 'wp_head', 'wc_generator_tag' );
			}

			if ( fresh_get_settings( 'async_js' ) ) {
				$this->add_filter( 'script_loader_tag', 'add_async', 10, 2 );
			}

			if ( fresh_get_settings( 'remove_ver_params' ) ) {
				$this->add_filter( 'script_loader_src', 'remove_version', 99 );
				$this->add_filter( 'style_loader_src', 'remove_version', 99 );
			}
		}
	}

	/**
	 * Takes care of enqueueing all our scripts.
	 */
	public function enqueue_scripts() {
		$this->styles();
		$this->scripts();
	}

	/**
	 * Enqueue CSS files
	 */
	private function styles() {
		$version            = fresh()->get_version();
		$template_directory = get_template_directory_uri();

		// style.css file.
		wp_enqueue_style( 'fresh-theme', get_stylesheet_uri(), array(), '0.9.4' );

		$deps = 'fresh-theme';

		// Font Awesome.
		$this->font_styles();
		wp_enqueue_style( 'fontawesome', $template_directory . '/css/font-awesome.min.css', $deps, '4.7.0' );

		// Slider.
		wp_register_style( 'owl-carousel', $template_directory . '/css/owl.carousel.css', $deps, $version );
		if ( is_page_template( 'page-home.php' ) ) {
			wp_enqueue_style( 'owl-carousel' );
		}

		// Responsive.
		if ( fresh_get_settings( 'mts_responsive', false ) ) {
			wp_enqueue_style( 'fresh-responsive', $template_directory . '/css/fresh-responsive.css', $deps, $version );
		}

		// WooCommerce.
		if ( fresh_is_woocommerce_active() ) {
			wp_enqueue_style( 'fresh-woocommerce', $template_directory . '/css/fresh-woocommerce.css', 'woocommerce', $version );
		}

		// Lightbox.
		if ( is_single() || is_page_template( 'page-about.php' ) ) {
			wp_enqueue_style( 'magnificPopup', $template_directory . '/css/magnific-popup.css', $deps, $version );
		}
	}

	/**
	 * Enqueue JS files
	 */
	private function scripts() {

		$version            = fresh()->get_version();
		$template_directory = get_template_directory_uri();
		$deps               = array( 'jquery' );

		// The comment-reply script.
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}

		// Ad Blocker Detector.
		if ( ! empty( fresh_get_settings( 'detect_adblocker' ) ) ) {
			wp_enqueue_script( 'AdBlockerDetector', get_template_directory_uri() . '/js/ads.js' );
		}

		// Main theme script.
		wp_register_script( 'fresh_customscript', $template_directory . '/js/fresh-customscripts.js', $deps, $version, true );

		// Localize for Responsive Menu.
		$nav_menu = 'none';
		if ( ! empty( fresh_get_settings( 'show_sliding_nav' ) ) ) {
			$nav_menu = 'both';
		} else {
			$nav_menu = 'secondary';
		}
		wp_localize_script( 'fresh_customscript', 'fresh_customscript', array(
			'nav_menu'   => $nav_menu,
			'responsive' => ( empty( fresh_get_settings( 'mts_responsive' ) ) ? false : true ),
			'layout'     => fresh_get_settings( 'header_styles' ),
			'show'       => fresh_get_settings( 'show_top_button' ),
			'icon'       => fresh_get_settings( 'top_button_icon' ),
		) );
		wp_enqueue_script( 'fresh_customscript' );

		// Slider.
		wp_register_script( 'owl-carousel', $template_directory . '/js/owl.carousel.min.js', $deps, $version, true );
		if ( is_page_template( 'page-home.php' ) ) {
			wp_enqueue_script( 'owl-carousel' );
		}

		// Animated Single Post or Page header.
		wp_register_script( 'fresh-parallax', $template_directory . '/js/fresh-parallax.js', $deps, $version, true );
		wp_register_script( 'fresh-zoomout', $template_directory . '/js/fresh-zoomout.js', $deps, $version, true );
		if ( is_singular() ) {
			$header_animation = fresh_get_post_header_effect();
			if ( 'parallax' === $header_animation ) {
				wp_enqueue_script( 'fresh-parallax' );
			} elseif ( 'zoomout' === $header_animation ) {
				wp_enqueue_script( 'fresh-zoomout' );
			}
		}

		// Lightbox.
		wp_register_script( 'magnificPopup', $template_directory . '/js/jquery.magnific-popup.min.js', $deps, $version, true );
		if ( is_single() || is_page_template( 'page-about.php' ) ) {
			wp_enqueue_script( 'magnificPopup' );
		}

		// Sticky Navigation.
		wp_register_script( 'StickyNav', $template_directory . '/js/sticky.js', $deps, $version, true );
		if ( ! empty( fresh_get_settings( 'mts_sticky_nav' ) ) ) {
			wp_enqueue_script( 'StickyNav' );
		}

		// Lazy Load.
		wp_register_script( 'layzr', $template_directory . '/js/layzr.min.js', $deps, $version, true );
		if ( ! empty( fresh_get_settings( 'mts_lazy_load' ) ) ) {
			if ( ! empty( fresh_get_settings( 'mts_lazy_load_thumbs' ) ) || ( ! empty( fresh_get_settings( 'mts_lazy_load_content' ) ) && is_singular() ) ) {
				wp_enqueue_script( 'layzr' );
			}
		}

		// Ajax Load More and Search Results.
		wp_register_script( 'fresh-ajax', get_template_directory_uri() . '/js/ajax.js', $deps, $version, true );
		wp_register_script( 'historyjs', get_template_directory_uri() . '/js/history.js', $deps, $version, true );
		if ( ! empty( fresh_get_settings( 'mts_pagenavigation_type' ) ) && fresh_get_settings( 'mts_pagenavigation_type' ) >= 2 && ! is_singular() ) {
			wp_enqueue_script( 'fresh-ajax' );
			wp_enqueue_script( 'historyjs' );

			// Add parameters for the JS.
			global $wp_query;
			$max      = $wp_query->max_num_pages;
			$paged    = ( get_query_var( 'paged' ) > 1 ) ? get_query_var( 'paged' ) : 1;
			$autoload = ( '3' === fresh_get_settings( 'mts_pagenavigation_type' ) );
			wp_localize_script( 'fresh-ajax', 'fresh_ajax_loadposts', array(
				'startPage'     => $paged,
				'maxPages'      => $max,
				'nextLink'      => next_posts( $max, false ),
				'autoLoad'      => $autoload,
				'i18n_loadmore' => __( 'Load More Posts', 'fresh' ),
				'i18n_loading'  => __( 'Loading...', 'fresh' ),
				'i18n_nomore'   => __( 'No more posts.', 'fresh' ),
			) );
		}
		if ( ! empty( fresh_get_settings( 'mts_ajax_search' ) ) ) {
			wp_enqueue_script( 'fresh-ajax' );
			wp_localize_script( 'fresh-ajax', 'fresh_ajax_search', array(
				'url'         => admin_url( 'admin-ajax.php' ),
				'ajax_search' => '1',
			));
		}
	}

	/**
	 * Generate needed font
	 *
	 * @return void
	 */
	public function font_styles() {

		$link = get_transient( 'fresh_dynamic_css_typography_link' );
		if ( false === $link ) {
			$fonts = $this->get_google_fonts();

			// If we don't have any fonts then we can exit.
			if ( empty( $fonts ) ) {
				return;
			}

			// Get font-family + subsets.
			$link_fonts = array();
			foreach ( $fonts as $font => $variants ) {

				$variants = implode( ',', $variants );

				$link_font = str_replace( ' ', '+', $font );
				if ( ! empty( $variants ) ) {
					$link_font .= ':' . $variants;
				}
				$link_fonts[] = $link_font;
			}

			$subsets = fresh_get_settings( 'typography-subsets', array() );
			$link    = add_query_arg( array(
				'family' => str_replace( '%2B', '+', urlencode( implode( '|', $link_fonts ) ) ),
				'subset' => urlencode( implode( ',', $subsets ) ),
			), 'https://fonts.googleapis.com/css' );

			set_transient( 'fresh_dynamic_css_typography_link', $link );
		}

		// Enqueue it.
		wp_enqueue_style( 'fresh_google_fonts', $link, array(), null );
	}

	/**
	 * Get typography from theme options
	 *
	 * @return array
	 */
	private function get_google_fonts() {

		$fonts      = array();
		$collection = (array) fresh_get_settings( 'typography-collections', array() );

		$opts = array(
			'fresh_logo',
			'secondary_navigation_font',
			'slider_text_font',
			'slider_big_title_font',
			'slider_title_font',
			'services_padding',
			'services_title_font',
			'featured_title_font',
			'featured_small_title_font',
			'featured_text_font',
			'services2_title_font',
			'testimonials_section_title_font',
			'testimonials_author_font',
			'testimonials_text_font',
			'instagram_title_font',
			'instagram_text_font',
			'cta_title_font',
			'home_title_font',
			'pagination_font',
			'breadcrumb_font',
			'single_title_font',
			'single_page_titles_font',
			'related_post_title_font',
			'single_subscribe_title_font',
			'single_subscribe_text_font',
			'single_subscribe_input_font',
			'single_subscribe_submit_font',
			'single_subscribe_small_text_font',
			'single_authorbox_title_font',
			'single_authorbox_author_name_font',
			'single_authorbox_text_font',
			'footer_nav_font',
			'content_font',
			'sidebar_title_font',
			'mts_widget_links',
			'default_widget_links',
			'sidebar_url_bigthumb',
			'sidebar_font',
			'sidebar_font_bigthumb',
			'sidebar_postinfo_font',
			'sidebar_postinfo_font_bigthumb',
			'tabs_title_font',
			'footer_fresh_logo',
			'top_footer_title_font',
			'top_footer_link_font',
			'top_footer_font',
			'copyrights_font',
			'h1_headline',
			'h2_headline',
			'h3_headline',
			'h4_headline',
			'h5_headline',
			'h6_headline',
			'mts_single_meta_info_font',
			'related_posts_font',
			'related_posts_meta_font',
		);

		// Dynamic Tab Fonts.
		$features = fresh_get_settings( 'mts_featured_categories' );
		foreach ( $features as $feature ) {
			if ( ! isset( $feature['unique_id'] ) ) {
				continue;
			}
			$opts[] = 'mts_featured_category_title_font_' . $feature['unique_id'];
			$opts[] = 'post_title_font_' . $feature['unique_id'];
		}

		foreach ( $opts as $key ) {
			$val = fresh_get_settings( $key, false );

			if ( $val ) {

				// Add to collection.
				$collection[] = $val;
			}
		}

		foreach ( (array) $collection as $font ) {

			$variant = '';

			if ( isset( $font['css-selectors'] ) && empty( trim( $font['css-selectors'] ) ) ) {
				continue;
			}

			if ( empty( $font['font-family'] ) ) {
				continue;
			}

			$variant = empty( $font['font-weight'] ) || 'normal' === $font['font-weight'] ? '400' : $font['font-weight'];

			// Add "i" to font-weight to make italics properly load.
			if ( isset( $font['font-style'] ) && 'italic' === $font['font-style'] ) {
				$variant .= 'i';
			}

			// Add the requested google-font.
			if ( ! isset( $fonts[ $font['font-family'] ] ) ) {
				$fonts[ $font['font-family'] ] = array();
			}
			if ( ! in_array( $variant, $fonts[ $font['font-family'] ], true ) ) {
				$fonts[ $font['font-family'] ][] = $variant;
			}
		}

		return $fonts;
	}

	/**
	 * Add async to fresh javascript file for performance
	 *
	 * @param string $tag    The script tag.
	 * @param string $handle The script handle.
	 */
	public function add_async( $tag, $handle ) {

		$to_match = array( 'fresh' );
		return in_array( $handle, $to_match ) ? str_replace( ' src', ' async src', $tag ) : $tag;
	}

	/**
	 * Remove version param from script or style source url
	 *
	 * @param  string $src Script loader source path.
	 */
	public function remove_version( $src ) {

		$parts = explode( '?ver', $src );
		return $parts[0];
	}

	/**
	 * Remove WooCommerce Scripts and Styles from unneeded pages.
	 */
	public function remove_woocommerce_scripts() {

		// First check that woo exists to prevent fatal errors.
		if ( function_exists( 'is_woocommerce' ) ) {

			// Dequeue scripts and styles.
			if ( ! is_woocommerce() && ! is_cart() && ! is_checkout() && ! is_account_page() ) {
				wp_dequeue_script( 'fresh-woocommerce' );
				wp_dequeue_style( 'woocommerce-layout' );
				wp_dequeue_style( 'woocommerce-smallscreen' );
				wp_dequeue_style( 'woocommerce-general' );
				wp_dequeue_style( 'wc-bto-styles' );
				wp_dequeue_script( 'wc-add-to-cart' );
				wp_dequeue_script( 'wc-cart-fragments' );
				wp_dequeue_script( 'woocommerce' );
				wp_dequeue_script( 'jquery-blockui' );
				wp_dequeue_script( 'jquery-placeholder' );
			}
		}
	}
}

/**
 * Init
 */
new Fresh_Scripts;
