<?php
/**
 * Fresh Child Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Fresh Child
 */

/**
 * Enqueue styles
 */
function fresh_child_enqueue_scripts() {
	wp_enqueue_style( 'fresh-theme-css', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'fresh-child-theme-css', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'fresh_child_enqueue_scripts', 15 );
