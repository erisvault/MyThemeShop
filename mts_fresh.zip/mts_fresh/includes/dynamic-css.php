<?php
/**
 * Dynamic CSS for the frontend.
 *
 * @package Fresh
 */

defined( 'WPINC' ) || exit;

/**
 * Helper function.
 * Merge and combine the CSS elements.
 *
 * @param  string|array $elements An array of our elements.
 *                                If we use a string then it is directly returned.
 * @return string
 */
function fresh_implode( $elements = array() ) {

	if ( ! is_array( $elements ) ) {
		return $elements;
	}

	// Make sure our values are unique.
	$elements = array_unique( $elements );

	// Sort elements alphabetically.
	// This way all duplicate items will be merged in the final CSS array.
	sort( $elements );

	// Implode items and return the value.
	return implode( ',', $elements );

}

/**
 * Maps elements from dynamic css to the selector.
 *
 * @param  array  $elements The elements.
 * @param  string $selector The selector.
 * @return array
 */
function fresh_map_selector( $elements, $selector ) {
	$array = array();

	foreach ( $elements as $element ) {
		$array[] = $element . $selector;
	}

	return $array;
}

/**
 * Map CSS selectors from values.
 *
 * @param array $css    Array of dynamic CSS.
 * @param array $values Array of values.
 */
function fresh_map_css_selectors( &$css, $values ) {
	if ( isset( $values['css-selectors'] ) ) {
		$elements = $values['css-selectors'];
		unset( $values['css-selectors'] );

		$css[ $elements ] = $values;
	}
}

/**
 * Merge CSS values.
 *
 * @param array $css    Array of dynamic CSS.
 * @param array $values Array of values.
 */
function fresh_merge_value( &$css, $values ) {
	foreach ( $values as $id => $val ) {
		$css[ $id ] = $val;
	}
}

/**
 * Format of the $css array:
 * $css['media-query']['element']['property'] = value
 *
 * If no media query is required then set it to 'global'
 *
 * If we want to add multiple values for the same property then we have to make it an array like this:
 * $css[media-query][element]['property'][] = value1
 * $css[media-query][element]['property'][] = value2
 *
 * Multiple values defined as an array above will be parsed separately.
 */
function fresh_dynamic_css_array() {

	global $wp_version;

	$css       = array();
	$c_page_id = fresh()->get_page_id();

	// Site Background.
	$css['global']['html body'] = Fresh_Sanitize::background( fresh_get_settings( 'mts_background' ) );

	// Top bar Background.
	$css['global']['.top-bar'] = Fresh_Sanitize::background( fresh_get_settings( 'top_bar_background' ) );

	// Nav Background.
	$css['global']['#header'] = Fresh_Sanitize::background( fresh_get_settings( 'header_background' ) );

	// Content Font.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'content_font' ) ) );
	// Logo Font.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'fresh_logo' ) ) );
	// Secondary Navigation font.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'secondary_navigation_font' ) ) );
	// Blog heading font.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'blog_heading_font' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'blog_subheading_font' ) ) );
	// Homepage post title font.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'home_title_font' ) ) );
	// Pagination.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'pagination_font' ) ) );
	// Breadcrumbs font.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'breadcrumb_font' ) ) );
	// Single post title font.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'single_title_font' ) ) );
	// Single Page titles font.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'single_page_titles_font' ) ) );
	// Related Posts Section title font.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'related_post_title_font' ) ) );
	// Single subscribe box.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'single_subscribe_title_font' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'single_subscribe_text_font' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'single_subscribe_input_font' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'single_subscribe_submit_font' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'single_subscribe_small_text_font' ) ) );
	// Author Box.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'single_authorbox_title_font' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'single_authorbox_author_name_font' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'single_authorbox_text_font' ) ) );
	// Footer Nav.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'footer_nav_font' ) ) );
	// Sidebar widget title font.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'sidebar_title_font' ) ) );
	// Sidebar widget font.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'mts_widget_links' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'default_widget_links' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'sidebar_url_bigthumb' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'sidebar_font' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'sidebar_font_bigthumb' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'sidebar_postinfo_font' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'sidebar_postinfo_font_bigthumb' ) ) );
	// Tab widget title font.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'tabs_title_font' ) ) );
	// Footer widget title font.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'footer_fresh_logo' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'top_footer_title_font' ) ) );
	// Footer link font.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'top_footer_link_font' ) ) );
	// Footer widget font.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'top_footer_font' ) ) );
	// Copyrights section font.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'copyrights_font' ) ) );
	// H1 title in the content.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'h1_headline' ) ) );
	// H2 title in the content.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'h2_headline' ) ) );
	// H3 title in the content.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'h3_headline' ) ) );
	// H4 title in the content.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'h4_headline' ) ) );
	// H5 title in the content.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'h5_headline' ) ) );
	// H6 title in the content.
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'h6_headline' ) ) );

	// Footer background.
	$css['global']['#site-footer'] = Fresh_Sanitize::background( fresh_get_settings( 'mts_footer_background' ) );
	// Copyrights background.
	$css['global']['.copyrights'] = Fresh_Sanitize::background( fresh_get_settings( 'mts_copyrights_background' ) );

	fresh_dynamic_css_skin( $css );
	fresh_sidebar_position( $css );
	fresh_header( $css );
	fresh_sidebar_styling( $css );
	fresh_home_sections( $css );
	fresh_post_layouts( $css );
	fresh_post_pagination( $css );
	fresh_footer( $css );
	fresh_copyrights( $css );
	fresh_single( $css );
	fresh_single_social_buttons( $css );
	fresh_misc_css( $css );

	return apply_filters( 'fresh_dynamic_css_array', $css );
}

/**
 * Skin CSS
 *
 * @param array $css Array of dynamic CSS.
 */
function fresh_dynamic_css_skin( &$css ) {

	// Primary Color.
	$primary_color_scheme = Fresh_Sanitize::color( fresh_get_settings( 'primary_color_scheme' ) );

	$dark_color = color_luminance( $primary_color_scheme, -0.2 );

	// Text Color.
	$elements = array(
		'a',
		'body a:hover',
		'.breadcrumb',
		'.rank-math-breadcrumb',
		'.single_post .thecontent a',
		'.reply a',
		'.featured-content a.title:hover',
		'.latestPost .title a:hover',
		'.related-posts .title a:hover',
		'.layout-default .latestPost .title a:hover',
		'.layout-2 .latestPost .title a:hover',
		'.layout-3 .latestPost .title a:hover',
		'.layout-4 .latestPost .title a:hover',
		'.woocommerce ul.products li.product .price',
		'.product_list_widget .amount',
		'.woocommerce div.product p.price, .woocommerce div.product span.price',
		'.shareit-circular.standard .fa:hover',
		'.textwidget a',
		'#wp-calendar td#today',
		'.pnavigation2 a',
		'#sidebar .widget li a:hover',
		'.title a:hover',
		'#tabber .inside li a:hover',
		'.fn a',
		'.widget .wp_review_tab_widget_content a',
		'.sidebar .wpt_widget_content a',
		'.related-posts .title a:hover',
		'.layout-subscribe .widget #wp-subscribe .title span',
		'.footer-nav li a:hover',
		'blockquote:after',
		'article ul li::before',
		'.single .pagination a .current:hover',
		'#secondary-navigation li:hover',
		'.readMore a',
		'blockquote::before',
		'.button.border:hover',
		'.single_post .post-single-content .cooked-left a',
	);

	$css['global'][ fresh_implode( $elements ) ]['color'] = $primary_color_scheme;
	$css['global']['#sidebar .widget a:hover']['color']   = $primary_color_scheme;

	// Text Color Important.
	$elements = array(
		'.social-profile-icons ul li a:hover',
		'.layout-1 .latestPost a:hover',
		'#sidebar .widget .wpt_widget_content .tab_title.selected a',
		'#sidebar .widget .wp_review_tab_widget_content .tab_title.selected a',
		'.widget .review_thumb_large .review-result',
		'.widget .review_thumb_large .review-total-only.large-thumb',
		'footer .widget .wpt_widget_content .tab_title.selected a',
		'footer .widget .wp_review_tab_widget_content .tab_title.selected a',
	);
	$css['global'][ fresh_implode( $elements ) ]['color'] = $primary_color_scheme . '!important';

	// Background Color.
	$elements = array(
		'.error404 .article .sbutton',
		'.search .article .sbutton',
		'.pace .pace-progress',
		'#mobile-menu-wrapper ul li a:hover',
		'.pagination a:hover',
		'.single .pagination a:hover .current',
		'a#pull',
		'#commentform input#submit',
		'#mtscontact_submit',
		'.navigation #wpmm-megamenu .wpmm-pagination a',
		'.wpmm-megamenu-showing.wpmm-light-scheme',
		'.mts-subscribe input[type="submit"]',
		'.f-widget .widget .wp-subscribe-wrap input.submit',
		'.widget_product_search button[type="submit"]',
		'#move-to-top:hover',
		'#tabber ul.tabs li a.selected',
		'.navigation ul .sfHover a',
		'.widget-slider .slide-caption',
		'.owl-prev:hover, .owl-next:hover',
		'.widget .wp-subscribe-wrap h4.title span.decor:after',
		'.woocommerce a.button',
		'.woocommerce-page a.button',
		'.woocommerce button.button',
		'.woocommerce-page button.button',
		'.woocommerce input.button',
		'.woocommerce-page input.button',
		'.woocommerce #respond input#submit',
		'.woocommerce-page #respond input#submit',
		'.woocommerce #content input.button',
		'.woocommerce-page #content input.button',
		'.woocommerce .bypostauthor:after',
		'.woocommerce nav.woocommerce-pagination ul li span.current',
		'.woocommerce-page nav.woocommerce-pagination ul li span.current',
		'.woocommerce #content nav.woocommerce-pagination ul li span.current',
		'.woocommerce-page #content nav.woocommerce-pagination ul li span.current',
		'.woocommerce nav.woocommerce-pagination ul li a:hover',
		'.woocommerce-page nav.woocommerce-pagination ul li a:hover',
		'.woocommerce #content nav.woocommerce-pagination ul li a:hover',
		'.woocommerce-page #content nav.woocommerce-pagination ul li a:hover',
		'.woocommerce nav.woocommerce-pagination ul li a:focus',
		'.woocommerce-page nav.woocommerce-pagination ul li a:focus',
		'.woocommerce #content nav.woocommerce-pagination ul li a:focus',
		'.woocommerce-page #content nav.woocommerce-pagination ul li a:focus',
		'.woocommerce a.button',
		'.woocommerce-page a.button',
		'.woocommerce button.button',
		'.woocommerce-page button.button',
		'.woocommerce input.button',
		'.woocommerce-page input.button',
		'.woocommerce #respond input#submit',
		'.woocommerce-page #respond input#submit',
		'.woocommerce #content input.button',
		'.woocommerce-page #content input.button',
		'.woocommerce #respond input#submit.alt.disabled',
		'.woocommerce #respond input#submit.alt.disabled:hover',
		'.woocommerce #respond input#submit.alt:disabled',
		'.woocommerce #respond input#submit.alt:disabled:hover',
		'.woocommerce #respond input#submit.alt:disabled[disabled]',
		'.woocommerce #respond input#submit.alt:disabled[disabled]:hover',
		'.woocommerce a.button.alt.disabled, .woocommerce a.button.alt.disabled:hover',
		'.woocommerce a.button.alt:disabled',
		'.woocommerce a.button.alt:disabled:hover',
		'.woocommerce a.button.alt:disabled[disabled]',
		'.woocommerce a.button.alt:disabled[disabled]:hover',
		'.woocommerce button.button.alt.disabled',
		'.woocommerce button.button.alt.disabled:hover',
		'.woocommerce button.button.alt:disabled',
		'.woocommerce button.button.alt:disabled:hover',
		'.woocommerce button.button.alt:disabled[disabled]',
		'.woocommerce button.button.alt:disabled[disabled]:hover',
		'.woocommerce input.button.alt.disabled',
		'.woocommerce input.button.alt.disabled:hover',
		'.woocommerce input.button.alt:disabled',
		'.woocommerce input.button.alt:disabled:hover',
		'.woocommerce input.button.alt:disabled[disabled]',
		'.woocommerce input.button.alt:disabled[disabled]:hover',
		'#wpmm-megamenu .review-total-only',
		'#searchsubmit',
		'#add_payment_method .wc-proceed-to-checkout a.checkout-button',
		'.woocommerce-cart .wc-proceed-to-checkout a.checkout-button',
		'.woocommerce-checkout .wc-proceed-to-checkout a.checkout-button',
		'.woocommerce #respond input#submit.alt',
		'.woocommerce a.button.alt',
		'.woocommerce button.button.alt',
		'.woocommerce input.button.alt',
		'.woocommerce-account .woocommerce-MyAccount-navigation li.is-active',
		'.widget #wp-subscribe form::after',
		'.button',
		'.instagram-button a',
		'.woocommerce .woocommerce-widget-layered-nav-dropdown__submit',
		'.layout-subscribe form:after',
		'.f-widget .widget #wp-subscribe form:after',
		'.widget .sbutton',
		'.owl-prev:hover, .owl-next:hover',
		'.woocommerce .widget_price_filter .ui-slider .ui-slider-handle',
		'.woocommerce .widget_price_filter .ui-slider .ui-slider-range',
		'.latestPost-review-wrapper',
		'.latestPost .review-type-circle.latestPost-review-wrapper',
		'.woocommerce span.onsale',
		'.widget .widget_wp_review_tab .review-total-only.large-thumb',
		'#sidebar .widget h3::before',
		'#sidebar .widget #wp-subscribe .title::before',
		'.f-widget .widget #wp-subscribe input.submit',
		'.prev-next .prev a:hover',
		'.prev-next .next a:hover',
		'.pagination .nav-previous a',
		'.pagination .nav-next a',
		'.tags a:hover',
		'.navigation ul ul',
		'.navigation ul li li',
		'.widget #wp-subscribe',
		'.cooked-recipe-search .cooked-browse-search-button',
		'.cooked-recipe-card-modern-centered:hover .cooked-recipe-card-sep',
	);

	$css['global'][ fresh_implode( $elements ) ]['background-color'] = $primary_color_scheme;

	// Background Color Important.
	$elements = array(
		'.tagcloud a:hover, #sidebar .widget .tagcloud a:hover',
		'.widget .wpt_widget_content #tags-tab-content ul li a:hover ',
	);
	$css['global'][ fresh_implode( $elements ) ]['background-color'] = $primary_color_scheme . '!important';

	// Border Color.
	$elements = array(
		'.flex-control-thumbs .flex-active',
		'#wrapper .cooked-recipe-ingredients .cooked-ingredient-checkbox',
	);

	$css['global'][ fresh_implode( $elements ) ]['border-color'] = $primary_color_scheme;

	$css['global']['.navigation ul ul::after']['border-bottom'] = '8px solid ' . $primary_color_scheme;

	// Dark Background Color.
	$elements = array(
		'.owl-controls .owl-dot.active span',
		'.navigation ul li li:hover',
	);

	$css['global'][ fresh_implode( $elements ) ]['background-color'] = $dark_color;

}

/**
 * Sidebar Position
 *
 * @param array $css Array of dynamic CSS.
 */
function fresh_sidebar_position( &$css ) {

	// Sidebar position.
	$sidebar_position = fresh_get_settings( 'mts_layout' );

	$sidebar_metabox_location = '';
	if ( is_page() || is_single() ) {
		$sidebar_metabox_location = get_post_meta( get_the_ID(), '_mts_sidebar_location', true );
	}

	if ( 'right' !== $sidebar_metabox_location && ( 'sclayout' === $sidebar_position || 'left' === $sidebar_metabox_location ) ) {

		$css['global']['.article']['float']                = 'right';
		$css['global']['.sidebar.c-4-12']['float']         = 'left';
		$css['global']['.sidebar.c-4-12']['padding-right'] = 0;

		if ( null !== fresh_get_settings( 'mts_social_button_position' ) && 'floating' === fresh_get_settings( 'mts_social_button_position' ) ) {
			$css['global']['.shareit.floating']['margin']                = '0 760px 0';
			$css['global']['.shareit.floating']['border-left']           = '0';
			$css['global']['.shareit.shareit-circular.floating']['left'] = '95%';

		}
	}
}

/**
 * Header
 *
 * @param array $css Array of dynamic CSS.
 */
function fresh_header( &$css ) {

	// Top Bar.
	$header_class = array(
		'.top-bar',
	);
	fresh_merge_value( $css['global'][ fresh_implode( $header_class ) ], Fresh_Sanitize::margin( fresh_get_settings( 'top_bar_margin' ) ) );
	fresh_merge_value( $css['global'][ fresh_implode( $header_class ) ], Fresh_Sanitize::padding( fresh_get_settings( 'top_bar_padding' ) ) );

	// Header.
	$header_class = array(
		'#header',
	);
	fresh_merge_value( $css['global'][ fresh_implode( $header_class ) ], Fresh_Sanitize::margin( fresh_get_settings( 'header_margin' ) ) );
	fresh_merge_value( $css['global'][ fresh_implode( $header_class ) ], Fresh_Sanitize::padding( fresh_get_settings( 'header_padding' ) ) );
	// Header Border.
	$header_border = Fresh_Sanitize::border( fresh_get_settings( 'mts_header_border' ) );
	$css['global'][ fresh_implode( $header_class ) ][ $header_border['direction'] ] = $header_border ['value'];

	// Main Nav.
	$main_nav_classes = array(
		'#secondary-navigation .navigation ul ul a',
		'#secondary-navigation .navigation ul ul a:link',
		'#secondary-navigation .navigation ul ul a:visited',
	);
	$css['global'][ fresh_implode( $main_nav_classes ) ]['color']              = Fresh_Sanitize::color( fresh_get_settings( 'main_navigation_dropdown_color' ) );
	$css['global']['#secondary-navigation .navigation ul ul a:hover']['color'] = Fresh_Sanitize::color( fresh_get_settings( 'main_navigation_dropdown_hover_color' ) );

	// Single color.
	$css['global']['.single_post .post-single-content a']['color'] = Fresh_Sanitize::color( fresh_get_settings( 'main_navigation_dropdown_hover_color' ) );

	// Social icons.
	if ( ! empty( fresh_get_settings( 'header_social_icons' ) ) && is_array( fresh_get_settings( 'header_social_icons' ) ) ) :
		$header_icons = fresh_get_settings( 'header_social_icons' );
		foreach ( $header_icons as $header_icon ) :

			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ]['background-color'] = Fresh_Sanitize::color( $header_icon['header_icon_bgcolor'] );

			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] . ':hover' ]['background-color'] = Fresh_Sanitize::color( $header_icon['header_icon_hover_bgcolor'] );

			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ]['color'] = Fresh_Sanitize::color( $header_icon['header_icon_color'] );

			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] . ':hover' ]['color'] = Fresh_Sanitize::color( $header_icon['header_icon_hover_color'] );

			fresh_merge_value( $css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ], Fresh_Sanitize::margin( $header_icon['header_icon_margin'] ) );

			fresh_merge_value( $css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ], Fresh_Sanitize::padding( $header_icon['header_icon_padding'] ) );

			$header_icon_border = Fresh_Sanitize::border( $header_icon['header_icon_border'] );
			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ][ $header_icon_border['direction'] ] = $header_icon_border ['value'];

			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ]['border-radius'] = Fresh_Sanitize::size( $header_icon['header_icon_border_radius'] . 'px' );

		endforeach;
	endif;

	// Header Ad.
	fresh_merge_value( $css['global']['.widget-header, .small-header .widget-header'], Fresh_Sanitize::margin( fresh_get_settings( 'mts_header_adcode_margin' ) ) );

	// Ad-Blocker.
	$css['global']['.navigation-banner']['background'] = Fresh_Sanitize::color( fresh_get_settings( 'navigation_ad_background' ) );
}

/**
 * Social Share Styling
 *
 * @param array $css Array of dynamic CSS.
 */
function fresh_single_social_buttons( &$css ) {

	$social_shadow = fresh_get_settings( 'social_styling_box_shadow' );

	// Social share.
	$css['global']['.shareit.floating'] = Fresh_Sanitize::background( fresh_get_settings( 'social_styling_background' ) );
	fresh_merge_value( $css['global']['.shareit.floating'], Fresh_Sanitize::margin( fresh_get_settings( 'social_styling_margin' ) ) );

	// Social share border.
	$social_border = Fresh_Sanitize::border( fresh_get_settings( 'social_styling_border' ) );
	$css['global']['.shareit.floating'][ $social_border ['direction'] ] = $social_border ['value'];

	if ( 0 === $social_shadow ) {
		$css['global']['.shareit.floating']['box-shadow'] = 'none';
	}
	$social_button_layout   = fresh_get_settings( 'social_button_layout' );
	$social_button_position = fresh_get_settings( 'social_floating_button_position' );
	if ( 'default' === $social_button_layout ) {
		$share_class = '.shareit.shareit-' . $social_button_layout . '.floating';
	} else {
		$share_class = '.shareit.' . $social_button_layout . '.floating';
	}
	if ( ! empty( $social_button_position ) && is_array( $social_button_position ) ) {
		foreach ( $social_button_position as $key => $position ) {
			$css['global'][ $share_class ][ $key ] = $position;
		}
	}
}

/**
 * Sidebar styling
 *
 * @param array $css Array of dynamic CSS.
 */
function fresh_sidebar_styling( &$css ) {

	// Sidebar.
	fresh_merge_value( $css['global']['#sidebar .widget'], Fresh_Sanitize::background( fresh_get_settings( 'mts_sidebar_styling_background' ) ) );
	fresh_merge_value( $css['global']['#sidebar .widget'], Fresh_Sanitize::margin( fresh_get_settings( 'mts_sidebar_styling_margin' ) ) );
	fresh_merge_value( $css['global']['#sidebar .widget'], Fresh_Sanitize::padding( fresh_get_settings( 'mts_sidebar_styling_padding' ) ) );
	// Sidebar border.
	$sidebar_border = Fresh_Sanitize::border( fresh_get_settings( 'sidebar_styling_border' ) );
	$css['global']['#sidebar .widget'][ $sidebar_border['direction'] ] = $sidebar_border['value'];

	// Sidebar title.
	$sidebar_title                   = '#sidebar .widget h3, #sidebar .widget #wp-subscribe .title';
	$css['global'][ $sidebar_title ] = Fresh_Sanitize::background( fresh_get_settings( 'mts_sidebar_title_styling_background' ) );
	fresh_merge_value( $css['global'][ $sidebar_title ], Fresh_Sanitize::padding( fresh_get_settings( 'mts_sidebar_title_styling_padding' ) ) );
	fresh_merge_value( $css['global'][ $sidebar_title ], Fresh_Sanitize::margin( fresh_get_settings( 'mts_sidebar_title_styling_margin' ) ) );
	// Sidebar Title border.
	$sidebar_title_border = Fresh_Sanitize::border( fresh_get_settings( 'widget_title_border' ) );
	$css['global'][ $sidebar_title ][ $sidebar_title_border['direction'] ] = $sidebar_title_border['value'];
}

/**
 * HomePage sections CSS
 *
 * @param array $css Array of dynamic CSS.
 */
function fresh_home_sections( &$css ) {

	/**
	 * Slider Section.
	 */
	$slider = fresh_get_settings( 'home_slider' );
	$i      = 0;
	if ( ! empty( $slider ) && is_array( $slider ) ) {
		foreach ( $slider as $slide ) {

			++$i;
			$css['global'][ '.slider-item.item-' . $i ]['background-image'] = 'url(' . $slide['slider_background'] . ')';

			$css['global'][ '.slider-item.item-' . $i . ' p.slider-text' ]['color']      = Fresh_Sanitize::color( $slide['slider_text_color'] );
			$css['global'][ '.slider-item.item-' . $i . ' h2' ]['color']                 = Fresh_Sanitize::color( $slide['slider_big_title_color'] );
			$css['global'][ '.slider-item.item-' . $i . ' h3' ]['color']                 = Fresh_Sanitize::color( $slide['slider_title_color'] );
			$css['global'][ '.slider-item.item-' . $i . ' .button' ]['color']            = Fresh_Sanitize::color( $slide['slider_button_text_color'] );
			$css['global'][ '.slider-item.item-' . $i . ' .button' ]['background-color'] = Fresh_Sanitize::color( $slide['slider_button_bg_color'] );

			$alignment = $slide['slider_alignment'];
			if ( 'right' === $alignment ) {
				$css['global'][ '.slider-item.item-' . $i . ' .slider-caption' ]['float'] = 'right';
			}
		}
	}

	fresh_merge_value( $css['global']['.slider-item'], Fresh_Sanitize::padding( fresh_get_settings( 'slider_padding' ) ) );

	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'slider_text_font' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'slider_big_title_font' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'slider_title_font' ) ) );

	/**
	 * Services Section.
	 */
	$services = fresh_get_settings( 'home_services' );
	$i        = 0;
	if ( ! empty( $services ) && is_array( $services ) ) {
		foreach ( $services as $service ) {
			++$i;
			$css['global'][ '.service-item.item-' . $i ]['background-image'] = 'url(' . $service['services_bg_image'] . ')';

		}
	}
	// Border.
	$services_image_border = Fresh_Sanitize::border( fresh_get_settings( 'services_image_border' ) );
	$css['global']['.services-section .service-item img'][ $services_image_border['direction'] ] = $services_image_border['value'];

	fresh_merge_value( $css['global']['.services-section'], Fresh_Sanitize::padding( fresh_get_settings( 'services_padding' ) ) );

	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'services_title_font' ) ) );

	/**
	 * Featured Section.
	 */
	fresh_merge_value( $css['global']['.featured-section'], Fresh_Sanitize::background( fresh_get_settings( 'featured_background' ) ) );

	$css['global']['.featured-section .button']['color']            = Fresh_Sanitize::color( fresh_get_settings( 'featured_button_text_color' ) );
	$css['global']['.featured-section .button']['background-color'] = Fresh_Sanitize::color( fresh_get_settings( 'featured_button_bg_color' ) );

	fresh_merge_value( $css['global']['.featured-section'], Fresh_Sanitize::padding( fresh_get_settings( 'featured_padding' ) ) );

	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'featured_title_font' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'featured_small_title_font' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'featured_text_font' ) ) );

	/**
	 * Services 2 Section.
	 */
	$services = fresh_get_settings( 'home_services2' );
	$i        = 0;
	if ( ! empty( $services ) && is_array( $services ) ) {
		foreach ( $services as $service ) {
			++$i;
			$css['global'][ '.service2-item.item-' . $i ]['background-image'] = 'url(' . $service['services2_bg_image'] . ')';

		}
	}
	fresh_merge_value( $css['global']['.services2-section'], Fresh_Sanitize::padding( fresh_get_settings( 'services2_padding' ) ) );

	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'services2_title_font' ) ) );

	/**
	 * Testimonials Section.
	 */
	fresh_merge_value( $css['global']['.testimonials-section'], Fresh_Sanitize::padding( fresh_get_settings( 'testimonials_padding' ) ) );

	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'testimonials_section_title_font' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'testimonials_author_font' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'testimonials_text_font' ) ) );

	// Background Image and Position.
	$css['global']['.testimonials-section::before']['background-image'] = 'url(' . fresh_get_settings( 'testimonials_left_bg_image' ) . ')';
	$css['global']['.testimonials-section::after']['background-image']  = 'url(' . fresh_get_settings( 'testimonials_right_bg_image' ) . ')';

	$left_position  = Fresh_Sanitize::padding( fresh_get_settings( 'testimonials_left_bg_position' ) );
	$right_position = Fresh_Sanitize::padding( fresh_get_settings( 'testimonials_right_bg_position' ) );

	$css['global']['.testimonials-section::before']['top']  = $left_position['padding-top'];
	$css['global']['.testimonials-section::before']['left'] = $left_position['padding-left'];

	$css['global']['.testimonials-section::after']['right']  = $right_position['padding-right'];
	$css['global']['.testimonials-section::after']['bottom'] = $right_position['padding-bottom'];

	/**
	 * Instagram Section.
	 */
	$css['global']['.instagram-section .button']['color']            = Fresh_Sanitize::color( fresh_get_settings( 'instagram_button_text_color' ) );
	$css['global']['.instagram-section .button']['background-color'] = Fresh_Sanitize::color( fresh_get_settings( 'instagram_button_bg_color' ) );

	fresh_merge_value( $css['global']['.instagram-section'], Fresh_Sanitize::background( fresh_get_settings( 'instagram_background' ) ) );
	fresh_merge_value( $css['global']['.instagram-section'], Fresh_Sanitize::padding( fresh_get_settings( 'instagram_padding' ) ) );

	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'instagram_title_font' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'instagram_text_font' ) ) );

	/**
	 * CTA Section.
	 *
	 */
	$css['global']['.cta-section'] = Fresh_Sanitize::background( fresh_get_settings( 'cta_background' ) );

	$css['global']['.cta-section .button']['color']            = Fresh_Sanitize::color( fresh_get_settings( 'cta_button_text_color' ) );
	$css['global']['.cta-section .button']['background-color'] = Fresh_Sanitize::color( fresh_get_settings( 'cta_button_bg_color' ) );

	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'cta_title_font' ) ) );

	fresh_merge_value( $css['global']['.cta-section'], Fresh_Sanitize::padding( fresh_get_settings( 'cta_padding' ) ) );

	// Background image and Position.
	$css['global']['.cta-section::before']['background-image'] = 'url(' . fresh_get_settings( 'cta_left_bg_image' ) . ')';
	$img_position = Fresh_Sanitize::padding( fresh_get_settings( 'cta_left_bg_position' ) );

	$css['global']['.cta-section::before']['top']  = $img_position['padding-top'];
	$css['global']['.cta-section::before']['left'] = $img_position['padding-left'];
}

/**
 * Layout CSS
 *
 * @param array $css Array of dynamic CSS.
 */
function fresh_post_layouts( &$css ) {

	// Post Layouts.
	$features = fresh_get_settings( 'mts_featured_categories' );
	foreach ( $features as $feature ) :

		if ( ! isset( $feature['unique_id'] ) ) {
			continue;
		}

		$category     = $feature['mts_featured_category'];
		$posts_layout = isset( $feature['blog_layout'] ) ? $feature['blog_layout'] : 'layout-default';
		$unique_id    = $feature['unique_id'];

		if ( 'layout-default' === $posts_layout ) :
			$posts_layout = 'default';
		endif;

		// Container Class.
		if ( ! in_array( $posts_layout, array( 'default' ) ) ) :
			$container_class                                    = array(
				'.layout-' . $unique_id,
			);
			$css['global'][ fresh_implode( $container_class ) ] = array(
				'width'    => '100%',
				'float'    => 'none',
				'overflow' => 'visible',
				'position' => 'relative',
			);
		endif;
		if ( ! in_array( $posts_layout, array( 'default' ) ) ) :
			$all_class                                    = array(
				'.layout-' . $unique_id . ' .latestPost .title',
			);
			$css['global'][ fresh_implode( $all_class ) ] = array(
				'line-height' => '1',
				'font-size'   => 'inherit',
			);
		endif;

		// Section title align.
		$post_title_align = fresh_get_settings( 'mts_post_title_alignment_' . $unique_id );

		// Post area.
		$cat_class = 'cat-latest';
		if ( 'latest' !== $category ) {
			$category  = get_term_by( 'slug', $category, 'category' );
			$cat_class = sanitize_key( $category->name );
		}

		$title_class = '.title-container.title-id-' . $unique_id . ' h3';

		$css['global'][ $title_class ] = Fresh_Sanitize::background( fresh_get_settings( 'mts_featured_category_title_background_' . $unique_id ) );
		fresh_merge_value( $css['global'][ $title_class ], Fresh_Sanitize::margin( fresh_get_settings( 'mts_featured_category_title_margin_' . $unique_id ) ) );
		fresh_merge_value( $css['global'][ $title_class ], Fresh_Sanitize::padding( fresh_get_settings( 'mts_featured_category_title_padding_' . $unique_id ) ) );
		// Section title border.
		$post_title_border = Fresh_Sanitize::border( fresh_get_settings( 'post_title_border_' . $unique_id ) );
		$css['global'][ $title_class ][ $post_title_border['direction'] ] = $post_title_border['value'];

		// Title alignment.
		$align_class = '.title-container.title-id-' . $unique_id;
		if ( 'center' === $post_title_align ) :
			$css['global'][ $align_class ]['text-align'] = 'center';
		elseif ( 'right' === $post_title_align ) :
			$css['global'][ $align_class ]['text-align']              = 'right';
			$css['global'][ $align_class . ' + .view-more' ]['left']  = '0';
			$css['global'][ $align_class . ' + .view-more' ]['right'] = 'auto';
		endif;

		fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'mts_featured_category_title_font_' . $unique_id ) ) );

		if ( 'layout-featured' !== $posts_layout ) {
			$post_class = '.layout-' . $unique_id . '.default-container';
		} else {
			$post_class = '.layout-' . $unique_id;
		}

		// Post border.
		$post_border = Fresh_Sanitize::border( fresh_get_settings( 'post_border_' . $unique_id ) );
		$css['global'][ $post_class ][ $post_border['direction'] ] = $post_border['value'];

		fresh_merge_value( $css['global'][ $post_class ], Fresh_Sanitize::margin( fresh_get_settings( 'post_margin_' . $unique_id ) ) );
		fresh_merge_value( $css['global'][ $post_class ], Fresh_Sanitize::padding( fresh_get_settings( 'post_padding_' . $unique_id ) ) );

		/**
		 * Meta info
		 */

		if ( 'layout-featured' === $posts_layout ) {
			$css['global'][ '.layout-' . $unique_id . ' .latestPost .wrapper' ]['background-color'] = Fresh_Sanitize::color( fresh_get_settings( 'wrapper_bgcolor_' . $unique_id ) );
		}

		fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'meta_info_font_' . $unique_id ) ) );

		fresh_merge_value( $css['global'][ '.layout-' . $unique_id . ' .latestPost .post-info' ], Fresh_Sanitize::margin( fresh_get_settings( 'mts_meta_info_margin_' . $unique_id ) ) );

		fresh_merge_value( $css['global'][ '.layout-' . $unique_id . ' .latestPost .post-info' ], Fresh_Sanitize::padding( fresh_get_settings( 'mts_meta_info_padding_' . $unique_id ) ) );

		fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'post_title_font_' . $unique_id ) ) );

		if ( 'layout-featured' !== $posts_layout ) {
			fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'post_excerpt_font_' . $unique_id ) ) );
		}

		// Border.
		$meta_info_border = Fresh_Sanitize::border( fresh_get_settings( 'meta_info_border_' . $unique_id ) );
		$css['global'][ '.layout-' . $unique_id . ' .latestPost .post-info' ][ $meta_info_border['direction'] ] = $meta_info_border['value'];

	endforeach;
}

/**
 * Pagination
 *
 * @param array $css Array of dynamic CSS.
 */
function fresh_post_pagination( &$css ) {

	// Pagination Active class.
	$pagination_class_active = array(
		'.pace .pace-progress',
		'.page-numbers.current',
		'#mobile-menu-wrapper ul li a:hover',
		'.pagination a:hover',
	);
	$pagination_class        = array(
		'.pagination a',
		'.single .pagination > .current .currenttext',
		'.pagination .page-numbers.dots',
	);
	fresh_merge_value( $css['global'][ fresh_implode( array_merge( $pagination_class_active, $pagination_class ) ) ], Fresh_Sanitize::margin( fresh_get_settings( 'mts_pagenavigation_margin' ) ) );
	if ( '2' !== fresh_get_settings( 'mts_pagenavigation_type' ) ) {
		$css['global'][ fresh_implode( $pagination_class ) ]['background-color'] = Fresh_Sanitize::color( fresh_get_settings( 'mts_pagenavigation_bgcolor' ) );

		$css['global'][ fresh_implode( $pagination_class_active ) ]['background-color'] = Fresh_Sanitize::color( fresh_get_settings( 'mts_pagenavigation_hover_bgcolor' ) );

		$css['global'][ fresh_implode( $pagination_class ) ]['color'] = Fresh_Sanitize::color( fresh_get_settings( 'mts_pagenavigation_color' ) );

		$css['global'][ fresh_implode( $pagination_class_active ) ]['color'] = Fresh_Sanitize::color( fresh_get_settings( 'mts_pagenavigation_hover_color' ) );

		fresh_merge_value( $css['global'][ fresh_implode( array_merge( $pagination_class_active, $pagination_class ) ) ], Fresh_Sanitize::padding( fresh_get_settings( 'mts_pagenavigation_padding' ) ) );
	} else {
		$css['global']['#load-posts a']['background-color'] = Fresh_Sanitize::color( fresh_get_settings( 'load_more_bgcolor' ) );

		$css['global']['#load-posts a:hover']['background-color'] = Fresh_Sanitize::color( fresh_get_settings( 'load_more_hover_bgcolor' ) );

		$css['global']['#load-posts a']['color'] = Fresh_Sanitize::color( fresh_get_settings( 'load_more_color' ) );

		$css['global']['#load-posts a:hover']['color'] = Fresh_Sanitize::color( fresh_get_settings( 'load_more_hover_color' ) );

		fresh_merge_value( $css['global']['#load-posts a'], Fresh_Sanitize::padding( fresh_get_settings( 'load_more_padding' ) ) );
	}
	$css['global'][ fresh_implode( $pagination_class ) ]['border-radius']        = Fresh_Sanitize::size( fresh_get_settings( 'mts_pagenavigation_border_radius' ) . 'px' );
	$css['global'][ fresh_implode( $pagination_class_active ) ]['border-radius'] = Fresh_Sanitize::size( fresh_get_settings( 'mts_pagenavigation_border_radius' ) . 'px' );

	// Pagination border.
	$pagination_border = Fresh_Sanitize::border( fresh_get_settings( 'pagenavigation_border' ) );
	$css['global'][ fresh_implode( $pagination_class ) ][ $pagination_border ['direction'] ] = $pagination_border ['value'];

	// Pagination Alignment.
	$pagenavigation_align = fresh_get_settings( 'pagenavigation_alignment' );
	if ( 'left' === $pagenavigation_align ) :
		$css['global']['.pagination']['text-align'] = 'left';
	elseif ( 'right' === $pagenavigation_align ) :
		$css['global']['.pagination']['text-align'] = 'right';
	endif;

	// Load more Alignment.
	$load_more_align = fresh_get_settings( 'load_more_alignment' );
	if ( 'left' === $load_more_align ) :
		$css['global']['#load-posts']['text-align'] = 'left';
	elseif ( 'right' === $load_more_align ) :
		$css['global']['#load-posts']['text-align'] = 'right';
	elseif ( 'full' === $load_more_align ) :
		$css['global']['#load-posts a']['width'] = '100%';
	endif;
}

/**
 * Single
 *
 * @param array $css Array of dynamic CSS.
 */
function fresh_single( &$css ) {

	// Single, Page, Archive, Search, Category and 404 Page Background.
	$page_classes = array(
		'.single .article',
		'.page .article',
		'.search .article',
		'.archive .article',
		'.error404 .article',
	);

	$css['global'][ fresh_implode( $page_classes ) ] = Fresh_Sanitize::background( fresh_get_settings( 'single_background' ) );

	// Margin, Padding, Border and Box Shadow.
	fresh_merge_value( $css['global'][ fresh_implode( $page_classes ) ], Fresh_Sanitize::margin( fresh_get_settings( 'mts_single_styling_margin' ) ) );
	fresh_merge_value( $css['global'][ fresh_implode( $page_classes ) ], Fresh_Sanitize::padding( fresh_get_settings( 'mts_single_styling_padding' ) ) );

	// Single border.
	$single_border = Fresh_Sanitize::border( fresh_get_settings( 'single_styling_border' ) );
	$css['global']['.article'][ $single_border ['direction'] ] = $single_border ['value'];

	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'mts_single_meta_info_font' ) ) );

	// Tags.
	$css['global']['.tags a, .tagcloud a, .widget .wpt_widget_content #tags-tab-content ul li a']['background-color'] = Fresh_Sanitize::color( fresh_get_settings( 'tags_bgcolor' ) );

	// Related Posts.
	$css['global']['.related-posts'] = Fresh_Sanitize::background( fresh_get_settings( 'related_posts_background' ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'related_posts_font' ) ) );
	fresh_map_css_selectors( $css['global'], Fresh_Sanitize::typography( fresh_get_settings( 'related_posts_meta_font' ) ) );
	fresh_merge_value( $css['global']['.related-posts'], Fresh_Sanitize::margin( fresh_get_settings( 'related_posts_margin' ) ) );
	fresh_merge_value( $css['global']['.related-posts'], Fresh_Sanitize::padding( fresh_get_settings( 'related_posts_padding' ) ) );

	$related_posts_border = Fresh_Sanitize::border( fresh_get_settings( 'related_posts_border' ) );
	$css['global']['.related-posts'][ $related_posts_border ['direction'] ] = $related_posts_border ['value'];

	// Related Posts articles.
	$css['global']['.related-posts article'] = Fresh_Sanitize::background( fresh_get_settings( 'related_article_background' ) );
	fresh_merge_value( $css['global']['.related-posts article'], Fresh_Sanitize::padding( fresh_get_settings( 'related_article_padding' ) ) );
	fresh_merge_value( $css['global']['.related-posts article header'], Fresh_Sanitize::padding( fresh_get_settings( 'related_article_text_padding' ) ) );

	// Subscribe Box.
	$css['global']['.single-subscribe .widget #wp-subscribe'] = Fresh_Sanitize::background( fresh_get_settings( 'single_subscribe_background' ) );
	fresh_merge_value( $css['global']['.single-subscribe .widget #wp-subscribe'], Fresh_Sanitize::margin( fresh_get_settings( 'single_subscribe_margin' ) ) );
	fresh_merge_value( $css['global']['.single-subscribe .widget #wp-subscribe'], Fresh_Sanitize::padding( fresh_get_settings( 'single_subscribe_padding' ) ) );
	$css['global']['.single-subscribe .widget #wp-subscribe']['border-radius'] = Fresh_Sanitize::size( fresh_get_settings( 'single_subscribe_border_radius' ) . 'px' );

	// Subscribe Box Input fields.
	$subscribe_input_class = array(
		'.single-subscribe #wp-subscribe input.email-field',
		'.single-subscribe #wp-subscribe input.name-field',
	);
	$css['global'][ fresh_implode( $subscribe_input_class ) ]['background-color'] = Fresh_Sanitize::color( fresh_get_settings( 'single_subscribe_input_background' ) );

	$css['global'][ fresh_implode( $subscribe_input_class ) ]['height'] = Fresh_Sanitize::size( fresh_get_settings( 'single_subscribe_input_height' ) . 'px' );

	$css['global']['.single-subscribe .widget #wp-subscribe input.submit']['height'] = Fresh_Sanitize::size( fresh_get_settings( 'single_subscribe_input_height' ) . 'px' );

	$css['global'][ fresh_implode( $subscribe_input_class ) ]['border-radius'] = Fresh_Sanitize::size( fresh_get_settings( 'single_subscribe_input_border_radius' ) . 'px' );

	// Subscribe Box Input border.
	$subscribe_box_input_border = Fresh_Sanitize::border( fresh_get_settings( 'single_subscribe_input_border' ) );
	$css['global'][ fresh_implode( $subscribe_input_class ) ][ $subscribe_box_input_border ['direction'] ] = $subscribe_box_input_border ['value'];

	// Subscribe Box Submit button.
	$css['global']['.single-subscribe .widget #wp-subscribe input.submit']['background']    = Fresh_Sanitize::color( fresh_get_settings( 'single_subscribe_submit_backgroud' ) );
	$css['global']['.single-subscribe .widget #wp-subscribe input.submit']['border-radius'] = Fresh_Sanitize::size( fresh_get_settings( 'single_subscribe_submit_border_radius' ) . 'px' );

	// Subscribe Box Submit border.
	$subscribe_box_submit_border = Fresh_Sanitize::border( fresh_get_settings( 'single_subscribe_submit_border' ) );
	$css['global']['.single-subscribe .widget #wp-subscribe input.submit'][ $subscribe_box_submit_border ['direction'] ] = $subscribe_box_submit_border ['value'];

	fresh_merge_value( $css['global']['.single-subscribe .widget #wp-subscribe input.submit'], Fresh_Sanitize::padding( fresh_get_settings( 'single_subscribe_submit_padding' ) ) );

	// Author Box.
	$css['global']['.postauthor'] = Fresh_Sanitize::background( fresh_get_settings( 'single_authorbox_background' ) );

	fresh_merge_value( $css['global']['.postauthor'], Fresh_Sanitize::margin( fresh_get_settings( 'single_authorbox_margin' ) ) );

	fresh_merge_value( $css['global']['.postauthor'], Fresh_Sanitize::padding( fresh_get_settings( 'single_authorbox_padding' ) ) );

	$css['global']['.postauthor']['border-radius'] = Fresh_Sanitize::size( fresh_get_settings( 'single_authorbox_border_radius' ) . 'px' );

	$single_authorbox_border = Fresh_Sanitize::border( fresh_get_settings( 'single_authorbox_border' ) );
	$css['global']['.postauthor'][ $single_authorbox_border ['direction'] ] = $single_authorbox_border ['value'];

	// Author image.
	fresh_merge_value( $css['global']['.postauthor img'], Fresh_Sanitize::margin( fresh_get_settings( 'single_author_image_margin' ) ) );

	$css['global']['.postauthor img']['border-radius'] = Fresh_Sanitize::size( fresh_get_settings( 'single_author_image_border_radius' ) . 'px' );

	// Single Page titles Styling.
	$titles_align = fresh_get_settings( 'single_title_alignment' );

	$titles_align_class = array(
		'.comment-title',
		'#respond',
		'.related-posts-title',
	);
	$titles_class       = array(
		'#respond h4',
		'.total-comments',
		'.related-posts h4',
	);

	$css['global'][ fresh_implode( $titles_class ) ] = Fresh_Sanitize::background( fresh_get_settings( 'single_title_background' ) );
	fresh_merge_value( $css['global'][ fresh_implode( $titles_class ) ], Fresh_Sanitize::padding( fresh_get_settings( 'single_title_padding' ) ) );
	// Single title border.
	$single_titles_border = Fresh_Sanitize::border( fresh_get_settings( 'single_title_border' ) );
	$css['global'][ fresh_implode( $titles_class ) ][ $single_titles_border ['direction'] ] = $single_titles_border ['value'];

	if ( 'left' === $titles_align ) :
		$css['global'][ fresh_implode( $titles_class ) ]['display'] = 'inline-block';
	elseif ( 'center' === $titles_align ) :
		$css['global'][ fresh_implode( $titles_align_class ) ]['text-align'] = 'center';
		$css['global'][ fresh_implode( $titles_class ) ]['display']          = 'inline-block';
	elseif ( 'right' === $titles_align ) :
		$css['global'][ fresh_implode( $titles_align_class ) ]['text-align'] = 'right';
		$css['global'][ fresh_implode( $titles_class ) ]['display']          = 'inline-block';
	endif;

}

/**
 * Copyrights
 *
 * @param array $css Array of dynamic CSS.
 */
function fresh_copyrights( &$css ) {

	// copyrights border.
	$copyrights_border = Fresh_Sanitize::border( fresh_get_settings( 'copyrights_border' ) );
	$css['global']['.copyrights'][ $copyrights_border ['direction'] ] = $copyrights_border ['value'];

}

/**
 * Footer
 *
 * @param array $css Array of dynamic CSS.
 */
function fresh_footer( &$css ) {

	// Footer.
	fresh_merge_value( $css['global']['#site-footer'], Fresh_Sanitize::margin( fresh_get_settings( 'mts_top_footer_margin' ) ) );
	fresh_merge_value( $css['global']['#site-footer'], Fresh_Sanitize::padding( fresh_get_settings( 'mts_top_footer_padding' ) ) );

	// Footer widgets.
	if ( 1 === fresh_get_settings( 'mts_top_footer' ) && 1 === fresh_get_settings( 'mts_top_footer_num' ) ) :
		$css['global']['.footer-widgets']['display']                = 'flex';
		$css['global']['.footer-widgets']['justify-content']        = 'center';
		$css['global']['.footer-widgets .f-widget']['width']        = '38.7387388%';
		$css['global']['.footer-widgets .f-widget']['text-align']   = 'center';
		$css['global']['.footer-widgets .f-widget']['margin-right'] = '0px';
	endif;

	// Footer Navigation Section.
	fresh_merge_value( $css['global']['.footer-nav-section'], Fresh_Sanitize::margin( fresh_get_settings( 'footer_nav_margin' ) ) );
	fresh_merge_value( $css['global']['.footer-nav-section'], Fresh_Sanitize::padding( fresh_get_settings( 'footer_nav_padding' ) ) );

	// footer Nav border.
	$footer_nav_border = Fresh_Sanitize::border( fresh_get_settings( 'footer_nav_border' ) );
	$css['global']['.footer-nav-section'][ $footer_nav_border ['direction'] ] = $footer_nav_border ['value'];

	// footer Nav alignment.
	$footer_nav_align = fresh_get_settings( 'footer_nav_alignment' );
	if ( 'left' === $footer_nav_align ) :
		$css['global']['.footer-nav-section']['text-align'] = 'left';
	elseif ( 'center' === $footer_nav_align ) :
		$css['global']['.footer-nav-section']['text-align'] = 'center';
	elseif ( 'right' === $footer_nav_align ) :
		$css['global']['.footer-nav-section']['text-align'] = 'right';
	endif;

	// footer Nav menu item.
	fresh_merge_value( $css['global']['.footer-nav-container li a'], Fresh_Sanitize::margin( fresh_get_settings( 'footer_menu_item_margin' ) ) );

	// footer Nav separator.
	fresh_merge_value( $css['global']['.footer-nav-container .footer-separator'], Fresh_Sanitize::margin( fresh_get_settings( 'footer_nav_separator_margin' ) ) );
	$css['global']['.footer-nav-container .footer-separator']['color'] = Fresh_Sanitize::color( fresh_get_settings( 'footer_nav_separator_color' ) );

	// Footer Logo Social icons.
	if ( 1 === fresh_get_settings( 'footer_logo_social_icons' ) && ! empty( fresh_get_settings( 'footer_logo_social' ) ) && is_array( fresh_get_settings( 'footer_logo_social' ) ) ) :
		$footer_nav_icons = fresh_get_settings( 'footer_logo_social' );
		foreach ( $footer_nav_icons as $footer_nav_icon ) :
			$footer_icons[]               = $footer_nav_icon['footer_logo_social_icon'];
			$footer_nav_icon_border_size  = $footer_nav_icon['footer_logo_social_border_size'];
			$footer_nav_icon_border_style = $footer_nav_icon['footer_logo_social_border_style'];
			$footer_nav_icon_border_color = $footer_nav_icon['footer_logo_social_border_color'];
			$footer_nav_icon_border       = $footer_nav_icon_border_size . 'px ' . $footer_nav_icon_border_style . ' ' . $footer_nav_icon_border_color;
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ]['background-color']            = Fresh_Sanitize::color( $footer_nav_icon['footer_logo_social_bgcolor'] );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] . ':hover' ]['background-color'] = Fresh_Sanitize::color( $footer_nav_icon['footer_logo_social_hover_bgcolor'] );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ]['color']                       = Fresh_Sanitize::color( $footer_nav_icon['footer_logo_social_color'] );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] . ':hover' ]['color']            = Fresh_Sanitize::color( $footer_nav_icon['footer_logo_social_hover_color'] );
			fresh_merge_value( $css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ], Fresh_Sanitize::margin( $footer_nav_icon['footer_logo_social_margin'] ) );
			fresh_merge_value( $css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ], Fresh_Sanitize::padding( $footer_nav_icon['footer_logo_social_padding'] ) );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ]['border-radius'] = Fresh_Sanitize::size( $footer_nav_icon['footer_logo_social_border_radius'] . 'px' );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ]['border']        = $footer_nav_icon_border;
		endforeach;
	endif;

	// Footer Nav Social icons font size.
	if ( ! empty( $footer_icons ) && is_array( $footer_icons ) ) :
		foreach ( $footer_icons as $footer_icon ) :
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_icon ]['font-size'] = Fresh_Sanitize::size( fresh_get_settings( 'footer_logo_social_font_size' ) . 'px' );
		endforeach;
	endif;

	// Footer Brands Sections.
	$brands_border = Fresh_Sanitize::border( fresh_get_settings( 'brands_border' ) );
	$css['global']['.brands-container'][ $brands_border ['direction'] ] = $brands_border ['value'];

	// footer brands alignment.
	$footer_brands_align = fresh_get_settings( 'footer_brands_alignment' );
	if ( 'center' === $footer_brands_align ) :
		$css['global']['.brands-container']['justify-content'] = 'center';
	elseif ( 'right' === $footer_brands_align ) :
		$css['global']['.brands-container']['justify-content'] = 'flex-end';
	endif;

	// brand container.
	fresh_merge_value( $css['global']['.brands-container'], Fresh_Sanitize::margin( fresh_get_settings( 'brands_margin' ) ) );
	fresh_merge_value( $css['global']['.brands-container'], Fresh_Sanitize::padding( fresh_get_settings( 'brands_padding' ) ) );

}

/**
 * Misc
 *
 * @param array $css Array of dynamic CSS.
 */
function fresh_misc_css( &$css ) {

	// Show Logo.
	$show_logo = fresh_get_settings( 'mts_header_section2' );

	if ( 0 === $show_logo ) {
		$css['global']['.logo-wrap']['display'] = 'none';
	}

	// Back to top.
	// Border.
	$top_button_border = Fresh_Sanitize::border( fresh_get_settings( 'top_button_border' ) );
	$css['global']['#move-to-top'][ $top_button_border ['direction'] ] = $top_button_border ['value'];
	// Font-size, Padding and Position.
	$css['global']['#move-to-top .fa']['font-size'] = Fresh_Sanitize::size( fresh_get_settings( 'top_button_font_size' ) . 'px' );
	fresh_merge_value( $css['global']['#move-to-top'], Fresh_Sanitize::padding( fresh_get_settings( 'top_button_padding' ) ) );
	$top_button_position = fresh_get_settings( 'top_button_position' );
	foreach ( $top_button_position as $key => $position ) {
		$css['global']['#move-to-top'][ $key ] = $position;
	}
	// Border-radius.
	$css['global']['#move-to-top']['border-radius'] = Fresh_Sanitize::size( fresh_get_settings( 'top_button_border_radius' ) . 'px' );
	// Colors.
	$css['global']['#move-to-top']['color']            = Fresh_Sanitize::color( fresh_get_settings( 'top_button_color' ) );
	$css['global']['#move-to-top:hover']['color']      = Fresh_Sanitize::color( fresh_get_settings( 'top_button_color_hover' ) );
	$css['global']['#move-to-top']['background']       = Fresh_Sanitize::color( fresh_get_settings( 'top_button_background' ) );
	$css['global']['#move-to-top:hover']['background'] = Fresh_Sanitize::color( fresh_get_settings( 'top_button_background_hover' ) );
}
