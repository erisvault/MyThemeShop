<?php
/**
 * Back to top
 *
 * @package Fresh
 */

$menus['footer']['child']['footer-styling'] = array(
	'title' => esc_html__( 'Styling', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control the styling of footer section.', 'fresh' ),
);

$sections['footer-styling'] = array(
	array(
		'id'         => 'mts_top_footer_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Footer Margin', 'fresh' ),
		'sub_desc'   => esc_html__( 'Footer margin.', 'fresh' ),
		'std'        => array(
			'top'    => '30px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_top_footer',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_top_footer_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Footer Padding', 'fresh' ),
		'sub_desc'   => esc_html__( 'Footer padding.', 'fresh' ),
		'std'        => array(
			'top'    => '83px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_top_footer',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'mts_footer_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Footer Background', 'fresh' ),
		'sub_desc'   => esc_html__( 'Set footer background color, pattern and image from here.', 'fresh' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '#78ae31',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_top_footer',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'    => 'copyrights_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Copyrights Styling', 'fresh' ),
	),

	array(
		'id'       => 'mts_copyrights_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Copyrights Background', 'fresh' ),
		'sub_desc' => esc_html__( 'Set copyrights background color, pattern and image from here.', 'fresh' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#f8faf4',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'copyrights_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'fresh' ),
		'sub_desc' => esc_html__( 'Select border', 'fresh' ),
	),

);
