<?php
/**
 * Footer Tab
 *
 * @package Fresh
 */

$menus['footer'] = array(
	'icon'  => 'fa-table',
	'title' => esc_html__( 'Footer', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control the elements of footer section.', 'fresh' ),
);

$menus['footer']['child']['footer-general'] = array(
	'title' => esc_html__( 'General', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control the elements of footer section.', 'fresh' ),
);

$mts_patterns = array(
	'nobg' => array( 'img' => $uri . 'bg-patterns/nobg.png' ),
);
for ( $i = 1; $i <= 29; $i++ ) {
	$mts_patterns[ 'hbg' . $i ] = array( 'img' => $uri . 'bg-patterns/hbg' . $i . '.png' );
}

$sections['footer-general'] = array(

	array(
		'id'       => 'mts_top_footer',
		'type'     => 'switch',
		'title'    => esc_html__( 'Footer', 'fresh' ),
		'sub_desc' => esc_html__( 'Enable or disable footer with this option.', 'fresh' ),
		'std'      => '0',
	),

	array(
		'id'         => 'mts_top_footer_num',
		'type'       => 'button_set',
		'class'      => 'green',
		'title'      => esc_html__( 'Footer Layout', 'fresh' ),
		'sub_desc'   => wp_kses( __( 'Choose the number of widget areas in the <strong>footer</strong>', 'fresh' ), array( 'strong' => '' ) ),
		'options'    => array(
			'1' => esc_html__( '1 Widget', 'fresh' ),
			'2' => esc_html__( '2 Widgets', 'fresh' ),
			'3' => esc_html__( '3 Widgets', 'fresh' ),
			'4' => esc_html__( '4 Widgets', 'fresh' ),
		),
		'std'        => '4',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_top_footer',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_copyrights',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Copyrights Text', 'fresh' ),
		'sub_desc' => esc_html__( 'You can change or remove our link from footer and use your own custom text.', 'fresh' ) . ( MTS_THEME_WHITE_LABEL ? '' : wp_kses( __( '(You can also use your affiliate link to <strong>earn 55% of sales</strong>. Ex: <a href="https://mythemeshop.com/go/aff/aff" target="_blank">https://mythemeshop.com/?ref=username</a>)', 'fresh' ), array( 'strong' => '', 'a' => array( 'href' => array(), 'target' => array() ) ) ) ),
		// translators: Default value.
		'std'      => MTS_THEME_WHITE_LABEL ? null : sprintf( __( 'Theme by %s', 'fresh' ), '<a href="https://mythemeshop.com/" rel="nofollow">MyThemeShop</a>' ),
	),

);
