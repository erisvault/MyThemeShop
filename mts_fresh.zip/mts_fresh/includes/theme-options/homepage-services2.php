<?php
/**
 * HomePage Services 2 Section
 *
 * @package Fresh
 */

$menus['homepage']['child']['homepage-services2'] = array(
	'title' => esc_html__( 'Services 2', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the services 2 section.', 'fresh' ),
);

$sections['homepage-services2'] = array(

	array(
		'id'        => 'home_services2',
		'type'      => 'group',
		'title'     => esc_html__( 'Services 2', 'fresh' ),
		'sub_desc'  => esc_html__( 'Add services 2 appearing on the homepage.', 'fresh' ),
		'groupname' => esc_html__( 'Service', 'fresh' ),
		'subfields' => array(
			array(
				'id'    => 'services2_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'fresh' ),
			),
			array(
				'id'    => 'services2_button_text',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'fresh' ),
			),
			array(
				'id'    => 'services2_button_url',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'fresh' ),
			),
			array(
				'id'       => 'services2_bg_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Uplaod Service Background Image', 'fresh' ),
				'sub_desc' => esc_html__( 'Recommended size: 538 x 331 in px.', 'fresh' ),
				'return'   => 'url',
			),
		),
		'std'       => array(
			'1' => array(
				'group_sort'            => '1',
				'services2_title'       => 'Health & Diet Recipes',
				'services2_button_text' => 'Visit Blog',
				'services2_button_url'  => '#',
				'services2_bg_image'    => get_template_directory_uri() . '/images/service2-1-bg.png',
			),
			'2' => array(
				'group_sort'            => '2',
				'services2_title'       => 'Order Farm Diary Products',
				'services2_button_text' => 'Order Online',
				'services2_button_url'  => '#',
				'services2_bg_image'    => get_template_directory_uri() . '/images/service2-2-bg.png',
			),
		),
	),

	array(
		'id'       => 'services2_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'fresh' ),
		'sub_desc' => esc_html__( 'Set services 2 section padding from here.', 'fresh' ),
		'std'      => array(
			'top'    => '124px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),

	array(
		'id'    => 'services2_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'fresh' ),
		'std'   => array(
			'preview-text'  => 'Title',
			'preview-color' => 'dark',
			'font-family'   => 'Open Sans',
			'font-weight'   => '700',
			'color'         => '#ffffff',
			'font-size'     => '30px',
			'line-height'   => '46px',
			'css-selectors' => '.services2-section h2',
		),
	),

);
