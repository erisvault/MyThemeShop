<?php
/**
 * Single Styling
 *
 * @package Fresh
 */

$menus['single-styling'] = array(
	'title' => esc_html__( 'Single Styling', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of your single posts page.', 'fresh' ),
);

$sections['single-styling'] = array(

	array(
		'id'    => 'single_title_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Single Titles Styling', 'fresh' ),
	),

	array(
		'id'       => 'single_title_alignment',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Single Page Title Alignment', 'fresh' ),
		'sub_desc' => esc_html__( 'Choose the single page title alignment', 'fresh' ),
		'options'  => array(
			'left'   => esc_html__( 'Left', 'fresh' ),
			'center' => esc_html__( 'Center', 'fresh' ),
			'right'  => esc_html__( 'Right', 'fresh' ),
		),
		'std'      => 'left',
	),

	array(
		'id'       => 'single_title_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Single Page Title Background Color', 'fresh' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'fresh' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'single_title_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Page Title Padding', 'fresh' ),
		'sub_desc' => esc_html__( 'Set single page title padding from here.', 'fresh' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_title_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'fresh' ),
		'sub_desc' => esc_html__( 'Select border', 'fresh' ),
	),
	array(
		'id'    => 'single_page_titles_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Comment Section Title', 'fresh' ),
		'std'   => array(
			'preview-text'   => 'Title Font',
			'preview-color'  => 'light',
			'font-family'    => 'Open Sans',
			'font-weight'    => '700',
			'font-size'      => '22px',
			'line-height'    => '1',
			'color'          => color_luminance( fresh_get_settings( 'primary_color_scheme' ), -0.2 ),
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '#respond h4, .total-comments',
		),
	),

	array(
		'id'    => 'mts_single_styling_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Single Styling', 'fresh' ),
	),

	array(
		'id'       => 'single_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Background', 'fresh' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image of Single, Page, Archive, Search, Category and 404 Page from here.', 'fresh' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'mts_single_styling_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Margin', 'fresh' ),
		'sub_desc' => esc_html__( 'Set single post margin from here.', 'fresh' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '35px',
		),
	),
	array(
		'id'       => 'mts_single_styling_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Padding', 'fresh' ),
		'sub_desc' => esc_html__( 'Set single post padding from here.', 'fresh' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_styling_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'fresh' ),
		'sub_desc' => esc_html__( 'Select border', 'fresh' ),
	),
	array(
		'id'    => 'single_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Single Post Title', 'fresh' ),
		'std'   => array(
			'preview-text'  => 'Single Article Title',
			'preview-color' => 'light',
			'font-family'   => 'Open Sans',
			'font-weight'   => '600',
			'font-size'     => '40px',
			'line-height'   => '46px',
			'color'         => '#383b34',
			'css-selectors' => '.single-title',
		),
	),
	array(
		'id'    => 'mts_single_meta_info_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Single Meta Info Font', 'fresh' ),
		'std'   => array(
			'preview-text'  => 'Post Meta Info Font',
			'preview-color' => 'light',
			'font-family'   => 'Open Sans',
			'font-weight'   => '400',
			'font-size'     => '15px',
			'color'         => '#8e8c8c',
			'css-selectors' => '.single_post .post-info',
		),
	),

);
