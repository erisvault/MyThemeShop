<?php
/**
 * Brands
 *
 * @package Fresh
 */

$menus['footer']['child']['footer-brands'] = array(
	'title' => esc_html__( 'Brands Section', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control the Brands Section.', 'fresh' ),
);

$sections['footer-brands'] = array(

	array(
		'id'       => 'footer_brands_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Brands Section', 'fresh' ),
		'sub_desc' => esc_html__( 'Enable or disable Brands Section with this option.', 'fresh' ),
		'std'      => '0',
	),

	array(
		'id'         => 'footer_brands_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Brands Section Alignment', 'fresh' ),
		'sub_desc'   => esc_html__( 'Choose alignment of Brands Section.', 'fresh' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'fresh' ),
			'center' => esc_html__( 'Center', 'fresh' ),
			'right'  => esc_html__( 'Right', 'fresh' ),
		),
		'std'        => 'center',
		'class'      => 'green',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'brands_section_title',
		'type'       => 'text',
		'title'      => esc_html__( 'Brands Title', 'fresh' ),
		'sub_desc'   => esc_html__( 'Enter brands title here.', 'fresh' ),
		'std'        => esc_html__( 'Our Brands:', 'fresh' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),

	),

	array(
		'id'         => 'footer_brands_items',
		'type'       => 'group',
		'title'      => esc_html__( 'Brands', 'fresh' ),
		'groupname'  => esc_html__( 'Brand', 'fresh' ), // Group name.
		'subfields'  => array(
			array(
				'id'       => 'brand_title',
				'type'     => 'text',
				'title'    => esc_html__( 'Title', 'fresh' ),
				'sub_desc' => esc_html__( 'The title will not be shown.', 'fresh' ),
			),
			array(
				'id'       => 'brand_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Image', 'fresh' ),
				'sub_desc' => esc_html__( 'Upload or select an image for brand', 'fresh' ),
			),
			array(
				'id'       => 'brand_url',
				'type'     => 'text',
				'title'    => esc_html__( 'Link', 'fresh' ),
				'sub_desc' => esc_html__( 'Insert a link URL of brand', 'fresh' ),
				'std'      => '#',
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'brands_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'fresh' ),
		'sub_desc'   => esc_html__( 'Brands Section margin.', 'fresh' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'brands_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'fresh' ),
		'sub_desc'   => esc_html__( 'Brands Section padding.', 'fresh' ),
		'std'        => array(
			'top'    => '40px',
			'right'  => '0',
			'bottom' => '27px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'brands_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'fresh' ),
		'sub_desc'   => esc_html__( 'Select border', 'fresh' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
);
