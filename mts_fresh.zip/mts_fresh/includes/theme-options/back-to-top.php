<?php
/**
 * Back to top
 *
 * @package Fresh
 */

$menus['footer']['child']['footer-back-to-top'] = array(
	'title' => esc_html__( 'Back to Top', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control the back to top button.', 'fresh' ),
);

// Dependency check that back to top option is enable.
$top_button_dependency = array(
	'relation' => 'and',
	array(
		'field'      => 'show_top_button',
		'value'      => '1',
		'comparison' => '==',
	),
);

$sections['footer-back-to-top'] = array(

	array(
		'id'       => 'show_top_button',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Top Button', 'fresh' ),
		'sub_desc' => esc_html__( 'Enable or disable back to top button with this option.', 'fresh' ),
		'std'      => '1',
	),

	array(
		'id'         => 'top_button_icon',
		'type'       => 'icon_select',
		'title'      => esc_html__( 'Top Button Icon', 'fresh' ),
		'sub_desc'   => esc_html__( 'Set icon for top button icon with this option.', 'fresh' ),
		'std'        => 'angle-up',
		'dependency' => $top_button_dependency,
	),

	array(
		'id'         => 'top_button_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Top Button Icon Color', 'fresh' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'fresh' ),
		'std'        => '#ffffff',
		'dependency' => $top_button_dependency,
	),
	array(
		'id'         => 'top_button_color_hover',
		'type'       => 'color',
		'title'      => esc_html__( 'Top Button Icon Hover Color', 'fresh' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'fresh' ),
		'std'        => '#ffffff',
		'dependency' => $top_button_dependency,
	),

	array(
		'id'         => 'top_button_background',
		'type'       => 'color',
		'title'      => esc_html__( 'Top Button Background', 'fresh' ),
		'sub_desc'   => esc_html__( 'Set top button background color, pattern and image from here.', 'fresh' ),
		'std'        => fresh_get_settings( 'primary_color_scheme' ),
		'dependency' => $top_button_dependency,
	),
	array(
		'id'         => 'top_button_background_hover',
		'type'       => 'color',
		'title'      => esc_html__( 'Top Button Hover Background', 'fresh' ),
		'sub_desc'   => esc_html__( 'Set top button background color, pattern and image from here.', 'fresh' ),
		'std'        => '#444444',
		'dependency' => $top_button_dependency,
	),

	array(
		'id'         => 'top_button_font_size',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Font Size', 'fresh' ),
		'sub_desc'   => esc_html__( 'Set font size of top button in px.', 'fresh' ),
		'std'        => '50',
		'args'       => array( 'type' => 'number' ),
		'dependency' => $top_button_dependency,
	),

	array(
		'id'         => 'top_button_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'fresh' ),
		'sub_desc'   => esc_html__( 'Set Top button padding from here.', 'fresh' ),
		'std'        => array(
			'top'    => '1px',
			'right'  => '10.5px',
			'bottom' => '6px',
			'left'   => '10.5px',
		),
		'dependency' => $top_button_dependency,
	),
	array(
		'id'         => 'top_button_position',
		'type'       => 'margin',
		'title'      => esc_html__( 'Top Button Position', 'fresh' ),
		'sub_desc'   => esc_html__( 'Set top button position from here.', 'fresh' ),
		'std'        => array(
			'top'    => 'auto',
			'right'  => '30px',
			'bottom' => '100px',
			'left'   => 'auto',
		),
		'dependency' => $top_button_dependency,
	),

	array(
		'id'         => 'top_button_border_radius',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Border Radius', 'fresh' ),
		'sub_desc'   => esc_html__( 'Set border radius of top button in px.', 'fresh' ),
		'std'        => '75',
		'args'       => array( 'type' => 'number' ),
		'dependency' => $top_button_dependency,
	),

	array(
		'id'         => 'top_button_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'fresh' ),
		'sub_desc'   => esc_html__( 'Select border', 'fresh' ),
		'dependency' => $top_button_dependency,
	),

);
