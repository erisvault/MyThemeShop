<?php
/**
 * HomePage Instagram Section
 *
 * @package Fresh
 */

$menus['homepage']['child']['homepage-instagram'] = array(
	'title' => esc_html__( 'Instagram', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the instagram section.', 'fresh' ),
);

$sections['homepage-instagram'] = array(

	array(
		'id'       => 'instagram_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Instagram Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'upload',
			'image_pattern' => 'nobg',
			'image_upload'  => get_template_directory_uri() . '/images/instagram-bg.png',
			'repeat'        => 'no-repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'instagram_title',
		'type'     => 'text',
		'title'    => esc_html__( 'Title', 'fresh' ),
		'sub_desc' => esc_html__( 'Set instagram section title from here.', 'fresh' ),
		'std'      => 'We are on Instagram',
	),

	array(
		'id'       => 'instagram_text',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Text', 'fresh' ),
		'sub_desc' => esc_html__( 'Set instagram section sub-heading from here.', 'fresh' ),
		'std'      => 'Follow Us',
	),

	array(
		'id'       => 'instagram_username',
		'type'     => 'text',
		'title'    => esc_html__( 'Username', 'fresh' ),
		'sub_desc' => esc_html__( 'Set instagram username from here.', 'fresh' ),
		'std'      => 'habitburgergrill',
	),

	array(
		'id'       => 'instagram_num_post',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Number of feeds', 'fresh' ),
		'sub_desc' => esc_html__( 'Enter the number of feeds to show in the instagram section.', 'fresh' ),
		'std'      => '4',
		'args'     => array(
			'type' => 'number',
		),
	),

	array(
		'id'       => 'instagram_button_text',
		'type'     => 'text',
		'title'    => esc_html__( 'Button Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button text.', 'lawyer' ),
		'std'      => 'Follow Us',
	),

	array(
		'id'       => 'instagram_button_url',
		'type'     => 'text',
		'title'    => esc_html__( 'Button URL', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button URL.', 'lawyer' ),
		'std'      => '#',
	),
	array(
		'id'       => 'instagram_button_text_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Button Text Color', 'fresh' ),
		'sub_desc' => esc_html__( 'Enter button text color.', 'lawyer' ),
		'std'      => '#ffffff',
	),
	array(
		'id'       => 'instagram_button_bg_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Button Background Color', 'fresh' ),
		'sub_desc' => esc_html__( 'Enter button background color.', 'lawyer' ),
		'std'      => fresh_get_settings( 'primary_color_scheme' ),
	),

	array(
		'id'       => 'instagram_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'fresh' ),
		'sub_desc' => esc_html__( 'Set instagram section padding from here.', 'fresh' ),
		'std'      => array(
			'top'    => '168px',
			'right'  => '0',
			'bottom' => '94px',
			'left'   => '0',
		),
	),

	array(
		'id'    => 'instagram_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'fresh' ),
		'std'   => array(
			'preview-text'  => 'Title',
			'preview-color' => 'light',
			'font-family'   => 'Open Sans',
			'color'         => color_luminance( fresh_get_settings( 'primary_color_scheme' ), -0.2 ),
			'font-weight'   => '700',
			'font-size'     => '48px',
			'line-height'   => '1',
			'css-selectors' => '.instagram-section h2',
		),
	),
	array(
		'id'    => 'instagram_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sub heading Font', 'fresh' ),
		'std'   => array(
			'preview-text'   => 'Sub heading',
			'preview-color'  => 'light',
			'font-family'    => 'Open Sans',
			'color'          => '#444444',
			'font-weight'    => '400',
			'font-size'      => '19px',
			'line-height'    => '1',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.instagram-section p',
		),
	),

);
