<?php
/**
 * Navigation
 *
 * @package Fresh
 */

$menus['footer']['child']['footer-logo'] = array(
	'title' => esc_html__( 'Footer Logo Section', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control footer logo and social icons.', 'fresh' ),
);

$sections['footer-logo'] = array(

	array(
		'id'       => 'footer_logo_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Footer Logo and Social icons', 'fresh' ),
		'sub_desc' => esc_html__( 'Enable or disable Footer Logo and Social icons with this option.', 'fresh' ),
		'std'      => '0',
	),

	array(
		'id'         => 'footer_logo',
		'type'       => 'upload',
		'title'      => esc_html__( 'Footer Logo', 'fresh' ),
		'sub_desc'   => esc_html__( 'Select an image file for your footer logo.', 'fresh' ),
		'return'     => 'id',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_fresh_logo',
		'type'       => 'typography',
		'title'      => esc_html__( 'Logo Font', 'fresh' ),
		'std'        => array(
			'preview-text'  => 'Logo',
			'preview-color' => 'dark',
			'font-family'   => 'Caveat Brush',
			'font-weight'   => '400',
			'font-size'     => '54px',
			'color'         => '#ffffff',
			'css-selectors' => '.footer #logo a',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_social_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Social Icons', 'fresh' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_logo_social_icons',
		'type'       => 'switch',
		'title'      => esc_html__( 'Social Icons', 'fresh' ),
		'sub_desc'   => esc_html__( 'Enable or disable social icons with this option.', 'fresh' ),
		'std'        => '1',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_logo_social',
		'title'      => esc_html__( 'Footer Social Icons', 'fresh' ),
		'sub_desc'   => esc_html__( 'Add Social Media icons in footer logo section.', 'fresh' ),
		'type'       => 'group',
		'groupname'  => esc_html__( 'Social Icons', 'fresh' ), // Group name.
		'subfields'  => array(
			array(
				'id'    => 'footer_logo_social_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'fresh' ),
			),
			array(
				'id'    => 'footer_logo_social_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Icon', 'fresh' ),
			),
			array(
				'id'    => 'footer_logo_social_link',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'fresh' ),
			),
			array(
				'id'    => 'footer_logo_social_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Background color', 'fresh' ),
			),
			array(
				'id'    => 'footer_logo_social_hover_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Background hover color', 'fresh' ),
			),
			array(
				'id'    => 'footer_logo_social_color',
				'type'  => 'color',
				'title' => esc_html__( 'Icon color', 'fresh' ),
			),
			array(
				'id'    => 'footer_logo_social_hover_color',
				'type'  => 'color',
				'title' => esc_html__( 'Icon hover color', 'fresh' ),
			),
			array(
				'id'    => 'footer_logo_social_margin',
				'type'  => 'margin',
				'title' => esc_html__( 'Margin', 'fresh' ),
			),
			array(
				'id'    => 'footer_logo_social_padding',
				'type'  => 'margin',
				'title' => esc_html__( 'Padding', 'fresh' ),
			),
			array(
				'id'    => 'footer_logo_social_border_radius',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Border radius', 'fresh' ),
				'args'  => array( 'type' => 'number' ),
			),
			array(
				'id'    => 'footer_logo_social_border_size',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Border Size', 'fresh' ),
				'args'  => array( 'type' => 'number' ),
			),
			array(
				'id'      => 'footer_logo_social_border_style',
				'type'    => 'select',
				'title'   => esc_html__( 'Border Style', 'fresh' ),
				'options' => array(
					'none'   => esc_html__( 'None', 'fresh' ),
					'solid'  => esc_html__( 'Solid', 'fresh' ),
					'dotted' => esc_html__( 'Dotted', 'fresh' ),
					'dashed' => esc_html__( 'Dashed', 'fresh' ),
					'double' => esc_html__( 'Double', 'fresh' ),
					'groove' => esc_html__( 'Groove', 'fresh' ),
					'ridge'  => esc_html__( 'Ridge', 'fresh' ),
					'inset'  => esc_html__( 'Inset', 'fresh' ),
					'outset' => esc_html__( 'Outset', 'fresh' ),
				),
			),
			array(
				'id'    => 'footer_logo_social_border_color',
				'type'  => 'color',
				'title' => esc_html__( 'Border Color', 'fresh' ),
			),
		),
		'std'        => array(
			'facebook'  => array(
				'group_title'                      => 'Facebook',
				'group_sort'                       => '1',
				'footer_logo_social_title'         => 'Facebook',
				'footer_logo_social_icon'          => 'facebook-square',
				'footer_logo_social_link'          => '#',
				'footer_logo_social_bgcolor'       => '',
				'footer_logo_social_hover_bgcolor' => '',
				'footer_logo_social_color'         => '#ffffff',
				'footer_logo_social_hover_color'   => '#444444',
				'footer_logo_social_margin'        => array(
					'top'    => '0',
					'right'  => '22px',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_border_radius' => '0',
				'footer_logo_social_border_size'   => '1',
				'footer_logo_social_border_style'  => 'none',
				'footer_logo_social_border_color'  => '#dddddd',
			),
			'twitter'   => array(
				'group_title'                      => 'Twitter',
				'group_sort'                       => '2',
				'footer_logo_social_title'         => 'Twitter',
				'footer_logo_social_icon'          => 'twitter',
				'footer_logo_social_link'          => '#',
				'footer_logo_social_bgcolor'       => '',
				'footer_logo_social_hover_bgcolor' => '',
				'footer_logo_social_color'         => '#ffffff',
				'footer_logo_social_hover_color'   => '#444444',
				'footer_logo_social_margin'        => array(
					'top'    => '0',
					'right'  => '22px',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_border_radius' => '0',
				'footer_logo_social_border_size'   => '1',
				'footer_logo_social_border_style'  => 'none',
				'footer_logo_social_border_color'  => '#dddddd',
			),
			'instagram' => array(
				'group_title'                      => 'Instagram',
				'group_sort'                       => '3',
				'footer_logo_social_title'         => 'Instagram',
				'footer_logo_social_icon'          => 'instagram',
				'footer_logo_social_link'          => '#',
				'footer_logo_social_bgcolor'       => '',
				'footer_logo_social_hover_bgcolor' => '',
				'footer_logo_social_color'         => '#ffffff',
				'footer_logo_social_hover_color'   => '#444444',
				'footer_logo_social_margin'        => array(
					'top'    => '0',
					'right'  => '22px',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_border_radius' => '0',
				'footer_logo_social_border_size'   => '1',
				'footer_logo_social_border_style'  => 'none',
				'footer_logo_social_border_color'  => '#dddddd',
			),
			'youtube'   => array(
				'group_title'                      => 'Youtube',
				'group_sort'                       => '4',
				'footer_logo_social_title'         => 'Youtube',
				'footer_logo_social_icon'          => 'youtube',
				'footer_logo_social_link'          => '#',
				'footer_logo_social_bgcolor'       => '',
				'footer_logo_social_hover_bgcolor' => '',
				'footer_logo_social_color'         => '#ffffff',
				'footer_logo_social_hover_color'   => '#444444',
				'footer_logo_social_margin'        => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_border_radius' => '0',
				'footer_logo_social_border_size'   => '1',
				'footer_logo_social_border_style'  => 'none',
				'footer_logo_social_border_color'  => '#dddddd',
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_social_icons',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'footer_logo_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_logo_social_font_size',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Font Size', 'fresh' ),
		'sub_desc'   => esc_html__( 'Set font size of footer nav social icons in px.', 'fresh' ),
		'std'        => '22',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_social_icons',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'footer_logo_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

);
