<?php
/**
 * HomePage Pagination
 *
 * @package Fresh
 */

$menus['blog']['child']['blog-pagination'] = array(
	'title' => esc_html__( 'Pagination', 'fresh' ),
	'desc'  => esc_html__( 'From here, you can control the elements of pagination.', 'fresh' ),
);

// Dependency check - Default and Numbered pagination.
$default_pagination_dependency = array(
	'relation' => 'and',
	array(
		'field'      => 'mts_pagenavigation_type',
		'value'      => '2',
		'comparison' => '!=',
	),
);

// Dependency check the load more button.
$loadmore_button_dependency = array(
	'relation' => 'and',
	array(
		'field'      => 'mts_pagenavigation_type',
		'value'      => '2',
		'comparison' => '==',
	),
);

$sections['blog-pagination'] = array(

	array(
		'id'       => 'mts_pagenavigation_type',
		'type'     => 'radio',
		'title'    => esc_html__( 'Pagination Type', 'fresh' ),
		'sub_desc' => esc_html__( 'Select pagination type.', 'fresh' ),
		'options'  => array(
			'0' => esc_html__( 'Default (Next / Previous)', 'fresh' ),
			'1' => esc_html__( 'Numbered (1 2 3 4...)', 'fresh' ),
			'2' => esc_html__( 'AJAX (Load More Button)', 'fresh' ),
			'3' => esc_html__( 'AJAX (Auto Infinite Scroll)', 'fresh' ),
		),
		'std'      => '1',
	),

	array(
		'id'         => 'pagenavigation_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Pagination Alignment', 'fresh' ),
		'sub_desc'   => esc_html__( 'Choose pagination alignment from here.', 'fresh' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'fresh' ),
			'center' => esc_html__( 'Center', 'fresh' ),
			'right'  => esc_html__( 'Right', 'fresh' ),
		),
		'std'        => 'right',
		'dependency' => $default_pagination_dependency,
	),

	array(
		'id'         => 'load_more_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Load More Alignment', 'fresh' ),
		'sub_desc'   => esc_html__( 'Choose the load more alignment from here.', 'fresh' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'fresh' ),
			'center' => esc_html__( 'Center', 'fresh' ),
			'right'  => esc_html__( 'Right', 'fresh' ),
			'full'   => esc_html__( 'Full Width', 'fresh' ),
		),
		'std'        => 'right',
		'dependency' => $loadmore_button_dependency,
	),

	array(
		'id'         => 'mts_pagenavigation_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination background color', 'fresh' ),
		'sub_desc'   => esc_html__( 'Select pagination background color.', 'fresh' ),
		'std'        => '#f8faf4',
		'dependency' => $default_pagination_dependency,
	),
	array(
		'id'         => 'load_more_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More background color', 'fresh' ),
		'sub_desc'   => esc_html__( 'Select background color for load more button.', 'fresh' ),
		'std'        => fresh_get_settings( 'primary_color_scheme' ),
		'dependency' => $loadmore_button_dependency,
	),
	array(
		'id'         => 'mts_pagenavigation_hover_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination background hover color', 'fresh' ),
		'sub_desc'   => esc_html__( 'Select pagination background hover color.', 'fresh' ),
		'std'        => color_luminance( fresh_get_settings( 'primary_color_scheme' ), -0.2 ),
		'dependency' => $default_pagination_dependency,
	),
	array(
		'id'         => 'load_more_hover_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More background hover color', 'fresh' ),
		'sub_desc'   => esc_html__( 'Select background hover color for load more button.', 'fresh' ),
		'std'        => '#444444',
		'dependency' => $loadmore_button_dependency,
	),
	array(
		'id'         => 'mts_pagenavigation_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination color', 'fresh' ),
		'sub_desc'   => esc_html__( 'Select pagination color.', 'fresh' ),
		'std'        => '#444444',
		'dependency' => $default_pagination_dependency,
	),
	array(
		'id'         => 'load_more_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More color', 'fresh' ),
		'sub_desc'   => esc_html__( 'Select color for load more button.', 'fresh' ),
		'std'        => '#ffffff',
		'dependency' => $loadmore_button_dependency,
	),
	array(
		'id'         => 'mts_pagenavigation_hover_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination hover color', 'fresh' ),
		'sub_desc'   => esc_html__( 'Select pagination hover color.', 'fresh' ),
		'std'        => '#deebcd',
		'dependency' => $default_pagination_dependency,
	),
	array(
		'id'         => 'load_more_hover_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More hover color', 'fresh' ),
		'sub_desc'   => esc_html__( 'Select hover color for load more button.', 'fresh' ),
		'std'        => '#ffffff',
		'dependency' => $loadmore_button_dependency,
	),
	array(
		'id'       => 'mts_pagenavigation_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Pagination Margin', 'fresh' ),
		'sub_desc' => esc_html__( 'Update pagination margin from here.', 'fresh' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '8px',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'         => 'mts_pagenavigation_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Pagination Padding', 'fresh' ),
		'sub_desc'   => esc_html__( 'Update pagination padding from here.', 'fresh' ),
		'std'        => array(
			'top'    => '10px',
			'right'  => '13px',
			'bottom' => '9px',
			'left'   => '13px',
		),
		'dependency' => $default_pagination_dependency,
	),
	array(
		'id'         => 'load_more_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Load More Padding', 'fresh' ),
		'sub_desc'   => esc_html__( 'Update padding for load more button from here.', 'fresh' ),
		'std'        => array(
			'top'    => '20px',
			'right'  => '30px',
			'bottom' => '17px',
			'left'   => '30px',
		),
		'dependency' => $loadmore_button_dependency,
	),
	array(
		'id'       => 'mts_pagenavigation_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Pagination border radius', 'fresh' ),
		'sub_desc' => esc_html__( 'Update pagination border radius in px.', 'fresh' ),
		'std'      => '5',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'pagenavigation_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'fresh' ),
		'sub_desc' => esc_html__( 'Select border', 'fresh' ),
		'std'      => array(
			'color'     => '#e7f1db',
			'direction' => 'all',
			'size'      => '1',
			'style'     => 'solid',
		),
	),
	array(
		'id'    => 'pagination_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Pagination', 'fresh' ),
		'color' => false,
		'std'   => array(
			'preview-text'  => 'Pagination',
			'preview-color' => 'light',
			'font-family'   => 'Open Sans',
			'font-weight'   => '400',
			'font-size'     => '17px',
			'css-selectors' => '.pagination, #load-posts a',
		),
	),

);
