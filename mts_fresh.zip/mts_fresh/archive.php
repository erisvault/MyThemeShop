<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Fresh
 */

get_header(); ?>

	<div id="wrapper">

		<div class="container">

			<div class="<?php fresh_article_class(); ?>">

				<?php
				// Elementor 'archive' location.
				if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'archive' ) ) {

					fresh_action( 'before_content' );
					?>

					<div id="content_box">
						<section id="latest-posts" class="layout-default clearfix">
							<?php
							the_archive_title( '<h1 class="page-title">', '</h1>' );
							the_archive_description( '<div class="taxonomy-description">', '</div>' );

							$j = 0;
							if ( have_posts() ) {
								while ( have_posts() ) {
									the_post();
									fresh_blog_articles();
								}
							}

							if ( 0 !== ++$j ) {
								fresh_pagination( fresh_get_settings( 'mts_pagenavigation_type' ) );
							}
							?>
						</section>
					</div>

					<?php
					fresh_action( 'after_content' );
				}
				?>

			</div>

			<?php get_sidebar(); ?>

		</div>

<?php
get_footer();
