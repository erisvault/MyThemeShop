<?php
/**
 * Template Name: HomePage
 *
 * @package Fresh
 */

get_header();

?>

<div id="wrapper" class="clearfix">

	<?php

	fresh_homepage_sections();

	get_footer();
