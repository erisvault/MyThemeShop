<?php
/**
 * Homepage Section - Services 2
 *
 * @package Fresh
 */

$services = fresh_get_settings( 'home_services2' );

if ( empty( $services ) && ! is_array( $services ) ) {
	return;
}
?>

<section class="services2-section clearfix">

	<div class="container clearfix">

		<?php
		$i = 0;
		echo '<ul>';

		foreach ( $services as $service ) {
			printf(
				'<li class="service2-item item-' . ++$i . '"><h2>%1$s</h2><a class="button border" href="%2$s">%3$s</a></li>',
				$service['services2_title'],
				$service['services2_button_url'],
				$service['services2_button_text']
			);
		}

		echo '</ul>';
		?>

	</div><!-- .container -->

</section>
