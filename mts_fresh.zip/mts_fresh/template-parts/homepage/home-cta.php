<?php
/**
 * Homepage Section - CTA
 *
 * @package Lawyer
 */

$title       = fresh_get_settings( 'cta_title' );
$button_text = fresh_get_settings( 'cta_button_text' );
$button_url  = fresh_get_settings( 'cta_button_url' );

if ( empty( $title ) && empty( $button_text ) && empty( $button_url ) ) {
	return;
}
?>

<section class="cta-section clearfix">

	<div class="container">

		<?php
		if ( $title ) {
			echo '<h2>' . $title . '</h2>';
		}
		if ( ! empty( $button_text ) && ! empty( $button_url ) ) {
			printf(
				'<a class="button" href="%1$s">%2$s</a>',
				$button_url,
				$button_text
			);
		}
		?>

	</div><!-- .container -->

</section>
