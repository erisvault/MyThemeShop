<?php
/**
 * Homepage Section - Featured
 *
 * @package Fresh
 */

$title       = fresh_get_settings( 'featured_title' );
$small_title = fresh_get_settings( 'featured_small_title' );
$text        = fresh_get_settings( 'featured_text' );
$button_text = fresh_get_settings( 'featured_button_text' );
$button_url  = fresh_get_settings( 'featured_button_url' );

if ( ! $title && ! $small_title && ! $text && ! $button_text && ! $button_url ) {
	return;
}
?>

<section class="featured-section clearfix">

	<div class="container">

		<div class="caption">

			<?php
			if ( $title ) {
				echo '<h2>' . $title . '</h2>';
			}
			if ( $small_title ) {
				echo '<h3>' . $small_title . '</h3>';
			}
			if ( $text ) {
				echo '<p>' . $text . '</p>';
			}
			if ( ! empty( $button_text ) && ! empty( $button_url ) ) {
				printf( '<a class="button" href="%1$s">%2$s</a>', $button_url, $button_text );
			}
			?>

		</div><!-- .caption -->

	</div><!-- .container -->

</section>
