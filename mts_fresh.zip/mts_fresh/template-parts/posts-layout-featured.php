<?php
/**
 * Posts Layout - Featured
 *
 * @package Fresh
 */
$featured = fresh()->featured_layouts;
?>
<div class="<?php fresh_article_class(); ?> <?php $featured->get_post_container_class(); ?>">

	<div id="content_box">

		<?php fresh_action( 'start_content_box' ); ?>

		<div class="container">

			<?php $featured->get_section_title(); ?>

			<?php $featured->get_view_more_button(); ?>

			<section id="latest-posts" class="<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">
				<?php
				while ( have_posts() ) :
					the_post();
				?>
				<article class="latestPost excerpt">

					<?php $featured->get_post_thumbnail(); ?>

					<div class="wrapper">

						<?php $featured->get_post_title(); ?>

					</div>

				</article>
				<?php
				endwhile;

				$featured->get_post_pagination();
				?>
			</section><!--#latest-posts-->

		</div>

	</div>

</div>
