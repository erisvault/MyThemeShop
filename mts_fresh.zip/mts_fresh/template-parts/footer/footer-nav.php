<?php
/**
 * Footer Nav Section
 *
 * @package Fresh
 */
if ( fresh_get_settings( 'footer_nav_section' ) ) :
?>
	<div class="footer-nav-section">
		<?php
		// Nav Section
		$footer_nav_position = fresh_get_settings( 'footer_nav_position' );
		$footer_separator    = fresh_get_settings( 'footer_nav_separator_content' );
		$separator           = ( fresh_get_settings( 'footer_nav_separator' ) ? '<span class="footer-separator">' . $footer_separator . '</span>' : '' );
		?>
		<div class="footer-nav-container nav-<?php echo $footer_nav_position; ?>">
			<nav class="footer-nav clearfix">
			<?php
			// Pirmary Navigation.
			if ( has_nav_menu( 'footer-menu' ) ) {
				wp_nav_menu( array(
					'theme_location' => 'footer-menu',
					'menu_class'     => 'footer-menu clearfix',
					'container'      => '',
					'after'          => $separator,
					'walker'         => new fresh_menu_walker(),
				));
			}
			?>
			</nav>
		</div>
	</div>
<?php
endif;
?>
