<?php
/**
 * Header Layout 3
 *
 * @package Fresh
 */
?>

<header id="site-header" class="main-header <?php echo esc_attr( fresh_get_settings( 'header_styles' ) ); ?> clearfix" role="banner" itemscope itemtype="http://schema.org/WPHeader">
<?php
if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'header' ) ) {
	if ( fresh_get_settings( 'mts_sticky_nav' ) ) {
		?>
	<div class="clear" id="catcher"></div>
	<div id="header" class="sticky-navigation clearfix">
	<?php } else { ?>
	<div id="header" class="clearfix">
	<?php } ?>
		<div class="container">

			<div class="logo-wrap">
				<?php fresh_logo(); ?>
			</div>

			<div id="secondary-navigation" class="secondary-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
				<a href="#" id="pull" class="toggle-mobile-menu"><?php _e( 'Menu', 'fresh' ); ?></a>
				<?php if ( has_nav_menu( 'mobile' ) ) { ?>

					<nav class="navigation clearfix">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu(
								array(
									'theme_location' => 'secondary-menu',
									'menu_class'     => 'menu clearfix',
									'container'      => '',
									'walker'         => new fresh_menu_walker(),
								)
							);
						}
						?>
					</nav>
					<nav class="navigation mobile-only clearfix mobile-menu-wrapper">
						<?php
						// Mobile Menu.
						if ( has_nav_menu( 'mobile' ) ) {
							wp_nav_menu(
								array(
									'theme_location' => 'mobile',
									'menu_class'     => 'menu clearfix',
									'container'      => '',
									'walker'         => new fresh_menu_walker(),
								)
							);
						}
						?>
					</nav>

				<?php } else { ?>

					<nav class="navigation clearfix mobile-menu-wrapper">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu(
								array(
									'theme_location' => 'secondary-menu',
									'menu_class'     => 'menu clearfix',
									'container'      => '',
									'walker'         => new fresh_menu_walker(),
								)
							);
						}
						?>
					</nav>

				<?php } ?>
			</div>

		</div><!--.container-->

	</div><!--#header-->

	<?php get_template_part( 'template-parts/header/header', 'nav-adcode' ); ?>

	<?php } ?>

</header>

<?php get_template_part( 'template-parts/header/header', 'adcode' ); ?>
