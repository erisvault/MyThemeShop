<?php $options = get_option('daynight'); ?>
<?php get_header(); ?>
<div id="page">
	<div class="content">
		<article class="article">
			<div id="content_box">
				<?php if (is_home() && !is_paged()) { ?>
					<?php if($options['mts_featured_slider'] == '1') { ?>
						<div class="slider-container">
							<div class="flex-container">
								<div class="flexslider">
									<ul class="slides">
										<?php $my_query = new WP_Query('cat='.$options['mts_featured_slider_cat'].'&posts_per_page=4'); while ($my_query->have_posts()) : $my_query->the_post(); $image_id = get_post_thumbnail_id(); $image_url = wp_get_attachment_image_src($image_id,'slider'); $image_url = $image_url[0]; ?>
										<li data-thumb="<?php echo $image_url; ?>">
											<a href="<?php the_permalink() ?>">
												<?php the_post_thumbnail('slider',array('title' => '')); ?>
												<p class="flex-caption">
													<span class="sliderLeftBg sliderHeight">
														<span class="sliderleft">
															<span class="title slidertitle"><?php the_title(); ?></span>
														</span>
													</span>
													<span class="sliderRightBg sliderHeight">
														<span class="sliderRight">
															<span class="sliderDate"><?php the_time('F j, Y'); ?></span>
															<span class="slidertext"><?php echo excerpt(14); ?></span>
														</span>
													</span>
												</p>
											</a>
										</li>
										<?php endwhile; ?>
										<?php wp_reset_query(); ?>
									</ul>
								</div>
							</div>
						</div>
					<?php } ?> 
				<?php } ?>
				<?php if (is_home() & !is_paged()) { ?>
					<div class="cat-posts">
						<?php $i = 1; $my_query = new wp_query( 'cat='.$options['mts_first_section_cat'].'&posts_per_page=6' ); ?>
						<?php $categoryID = $options['mts_first_section_cat']; ?>
						<h4 class="frontTitle"><span><?php if ($options['mts_first_section_cat']!='') { echo get_the_category_by_ID( $categoryID ); } ?></span></h4>
						<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
						<div class="frontPost excerpt <?php if($i % 3 == 0){echo 'last';} ?>">
							<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" id="featured-thumbnail">
								<div class="post-comments"><?php comments_number( '0', '1', '%' ); ?></div>
								<?php if ( has_post_thumbnail() ) { ?> 
									<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('featured-cat',array('title' => '')); echo '</div>'; ?>
								<?php } else { ?>
									<div class="featured-thumbnail">
										<img width="200" height="130" src="<?php echo get_template_directory_uri(); ?>/images/nothumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
									</div>
								<?php } ?>
							</a>
							<?php if($options['mts_headline_meta'] == '1') { ?>
								<div class="post-info-home">
									<time><?php the_time('j F, Y'); ?></time>
								</div>
							<?php } ?>
							<h2 class="title front-view-title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
							<div class="front-view-content">
								<?php echo excerpt(8); ?>
							</div>
						</div>                   
						<?php $i++; endwhile; endif;?>
					</div><!-- end .cat-posts -->
				<?php } ?>
				<h4 class="frontTitle"><span><?php _e('Latest Posts','mythemeshop'); ?></span></h4>
				<?php $j=0; if (have_posts()) : while (have_posts()) : the_post(); ?>
					<div class="post excerpt <?php echo (++$j % 2 == 0) ? 'last' : ''; ?>">
						<header>	
							<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" id="featured-thumbnail">
								<div class="post-comments"><?php comments_number( '0', '1', '%' ); ?></div>
								<?php if ( has_post_thumbnail() ) { ?> 
									<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('featured',array('title' => '')); echo '</div>'; ?>
								<?php } ?>
							</a>					
							<h2 class="title">
								<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
							</h2>
						</header><!--.header-->
						<?php if($options['mts_headline_meta'] == '1') { ?>
							<div class="post-info"><span class="theauthor"><?php _e('By: ','mythemeshop'); the_author_posts_link(); ?></span> / <span class="thecategory"><?php _e(' Category: ','mythemeshop'); the_category(', ') ?></span> / <span class="thetime"><?php the_time('j F Y'); ?></span></div>
						<?php } ?>
						<div class="post-content image-caption-format-1">
							<?php echo excerpt(25);?>
						</div>
						<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Read More','mythemeshop'); ?></a></div>
					</div><!--.post excerpt-->
				<?php endwhile; endif; ?>	
				<?php if ($options['mts_pagenavigation'] == '1') { ?>
					<?php pagination();?>
				<?php } else { ?>
					<div class="pnavigation2">
						<div class="nav-previous"><?php next_posts_link( __( '&larr; '.'Older posts', 'mythemeshop' ) ); ?></div>
						<div class="nav-next"><?php previous_posts_link( __( 'Newer posts'.' &rarr;', 'mythemeshop' ) ); ?></div>
					</div>
				<?php } ?>
			</div>
		</article>
		<?php get_sidebar(); ?>
<?php get_footer(); ?>