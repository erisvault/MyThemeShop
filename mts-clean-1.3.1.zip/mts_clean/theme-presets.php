<?php
// make sure to not include translations
$args['presets']['default'] = array(
	'title' => 'Default',
	'demo' => 'http://demo.mythemeshop.com/clean/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/default/thumb.jpg',
	'menus' => array( 'primary' => 'Top', 'secondary' => 'Menu' ), // menu location slug => Demo menu name
	'options' => array( 'show_on_front' => 'posts', 'posts_per_page' => 10 ),
);

// make sure to not include translations
$args['presets']['portfolio'] = array(
	'title' => 'Portfolio',
	'demo' => 'http://demo.mythemeshop.com/clean-portfolio/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/portfolio/thumb.jpg',
	'menus' => array( 'primary' => 'Top' ), // menu location slug => Demo menu name
	'options' => array( 'show_on_front' => 'posts', 'posts_per_page' => 10 ),
);

// make sure to not include translations
$args['presets']['journal'] = array(
	'title' => 'Journal',
	'demo' => 'http://demo.mythemeshop.com/clean-journal/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/journal/thumb.jpg',
	'menus' => array( 'secondary' => 'Menu' ), // menu location slug => Demo menu name
	'options' => array( 'show_on_front' => 'posts', 'posts_per_page' => 10 ),
);

// make sure to not include translations
$args['presets']['landing-page'] = array(
	'title' => 'Landing Page',
	'demo' => 'http://demo.mythemeshop.com/clean-landing-page/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/landing-page/thumb.jpg',
	'menus' => array(), // menu location slug => Demo menu name
	'options' => array( 'show_on_front' => 'page', 'page_on_front' => '4'),
);

global $mts_presets;
$mts_presets = $args['presets'];
