<?php
/**
 * The template for displaying the search form.
 */
$mts_options = get_option(MTS_THEME_NAME); ?>

<form method="get" id="searchform" class="search-form" action="<?php echo esc_attr( home_url() ); ?>" _lpchecked="1">
	<fieldset>
		<input type="search" name="s" id="s" value="<?php the_search_query(); ?>" placeholder="<?php _e('Search', 'clean' ); ?>" <?php if (!empty($mts_options['mts_ajax_search'])) echo ' autocomplete="off"'; ?> />
		<button id="search-image" class="sbutton" type="submit" value="">
				<img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz48c3ZnIHZlcnNpb249IjEuMSIgaWQ9IkxheWVyXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IiB3aWR0aD0iMjEuOHB4IiBoZWlnaHQ9IjIxLjhweCIgdmlld0JveD0iMCAwIDIxLjggMjEuOCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMjEuOCAyMS44OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+PHN0eWxlIHR5cGU9InRleHQvY3NzIj4uc3Qwe2ZpbGw6IzIwMzAzQzt9PC9zdHlsZT48cGF0aCBjbGFzcz0ic3QwIiBkPSJNMTcuNiwxNi4yYzEuMy0xLjcsMi4xLTMuOCwyLjEtNi4xYzAtNS4zLTQuMy05LjYtOS42LTkuNmMtNS4zLDAtOS42LDQuMy05LjYsOS42czQuMyw5LjYsOS42LDkuNmMyLjMsMCw0LjQtMC44LDYuMS0yLjFsNC4yLDQuMmwxLjQtMS40TDE3LjYsMTYuMnogTTEwLjEsMTcuN2MtNC4yLDAtNy42LTMuNC03LjYtNy42czMuNC03LjYsNy42LTcuNmM0LjIsMCw3LjYsMy40LDcuNiw3LjZTMTQuMywxNy43LDEwLjEsMTcuN3oiLz48L3N2Zz4=">
			</button>
	</fieldset>
</form>
