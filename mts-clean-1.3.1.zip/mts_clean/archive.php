<?php
/**
 * The template for displaying archive pages.
 *
 * Used for displaying archive-type pages. These views can be further customized by
 * creating a separate template for each one.
 *
 * - author.php (Author archive)
 * - category.php (Category archive)
 * - date.php (Date archive)
 * - tag.php (Tag archive)
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 */
$mts_options = get_option(MTS_THEME_NAME);

get_header();

$mts_home_layout = $mts_options['mts_home_layout'];
$sidebar1 = '';
$sidebar2 = ''; ?>

<div id="page">
	<div id="content_box">
		<?php if ( '3-col-grid' == $mts_home_layout && is_active_sidebar( 'home-sidebar-1' ) ) {
			$sidebar1 = "sidebar1";
		} 
		if( '3-col-grid' == $mts_home_layout && is_active_sidebar( 'home-sidebar-2' ) ) {
			$sidebar2 = "sidebar2";
		} ?>
		<h1 class="postsby">
			<span><?php the_archive_title(); ?></span>
		</h1>
		<p><?php the_archive_description(); ?></p>

		<?php if( '2-col-grid' == $mts_home_layout ) { ?>
			<div class="page-2-col-grid">
		<?php }
		if( 'traditional-grid' == $mts_home_layout ) { ?>
			<div class="page-traditional-grid">
		<?php } ?>
		
		<div class="post-wrap <?php echo $sidebar1; ?> <?php echo $sidebar2; ?>">
			<?php $j = 0; if (have_posts()) : while (have_posts()) : the_post(); $j++; ?>
				<article class="latestPost excerpt" data-aos="fade-up">
					<?php mts_archive_post(); ?>
				</article>

				<?php if ( $j == 5 && is_active_sidebar( 'home-sidebar-1' ) && ('3-col-grid' == $mts_home_layout) ) { ?>
                   	<aside class="latestPost sidebar c-4-12 home-sidebar-1" data-aos="fade-up">
                   		<?php dynamic_sidebar('home-sidebar-1'); ?>
                   	</aside>	 
                <?php } ?>

                <?php if ( $j == 10 && is_active_sidebar( 'home-sidebar-2' ) && ('3-col-grid' == $mts_home_layout) ) { ?>
                   	<aside class="latestPost sidebar c-4-12 home-sidebar-2" data-aos="fade-up">
                   		<?php dynamic_sidebar('home-sidebar-2'); ?>
                   	</aside>	 
                <?php } ?>
			<?php endwhile; endif; ?>
		</div>

		<?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
			<?php mts_pagination(); ?>
		<?php }

		if( '2-col-grid' == $mts_home_layout ) { ?></div><?php }

		if( 'traditional-grid' == $mts_home_layout ) { ?></div><?php } ?>
	
		<?php if( '2-col-grid' == $mts_home_layout || 'traditional-grid' == $mts_home_layout ) get_sidebar(); ?>
	</div>
<?php get_footer(); ?>