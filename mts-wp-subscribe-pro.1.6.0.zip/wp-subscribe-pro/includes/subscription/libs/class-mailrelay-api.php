<?php
/**
 * Mailrelay API class
 *
 * @package WP_Subscribe_Pro
 */

class Mailrelay_API {

	/**
	 * API Key.
	 *
	 * @var string
	 */
	protected $api_key;

	/**
	 * Based endpoint.
	 *
	 * @var string
	 */
	protected $based_endpoint = 'https://[YOUR-ACCOUNT].ipzmarketing.com/api/v1/';

	/**
	 * Mailrelay_API constructor.
	 *
	 * @param string $api_key  API Key.
	 * @param string $username Username.
	 */
	public function __construct( $api_key, $username ) {
		$this->api_key        = $api_key;
		$this->based_endpoint = str_replace( '[YOUR-ACCOUNT]', $this->clean_username( $username ), $this->based_endpoint );
	}

	/**
	 * Makes a request.
	 *
	 * @param string       $endpoint Endpoint.
	 * @param string       $method   Request method.
	 * @param string|array $data     Request data.
	 * @param array        $headers  Request headers.
	 * @param array        $args     Custom arguments.
	 * @return mixed
	 */
	public function make_request( $endpoint, $method = 'GET', $data = '', $headers = array(), $args = array() ) {
		$endpoint = $this->based_endpoint . $endpoint;
		if ( ! in_array( strtoupper( $method ), array( 'GET', 'POST', 'PUT', 'PATCH', 'HEAD', 'DELETE' ), true ) ) {
			$method = 'GET';
		}

		$headers['X-AUTH-TOKEN'] = $this->api_key;

		if ( is_array( $data ) ) {
			$data = wp_json_encode( $data );
			$headers['Content-Type'] = 'application/json';
		}

		$request_data = array(
			'method'  => $method,
			'headers' => $headers,
			'body'    => $data,
		);

		$response = wp_remote_request( $endpoint, $request_data + $args );
		return json_decode( wp_remote_retrieve_body( $response ), true );
	}

	/**
	 * Gets the list of groups.
	 *
	 * @return array
	 */
	public function getGroups() {
		return $this->make_request( 'groups' );
	}

	/**
	 * Adds subscriber.
	 *
	 * @param array $data Subscriber data.
	 */
	public function addSubscriber( $data ) {
		$data = wp_parse_args(
			$data,
			array(
				'name'   => '',
				'email'  => '',
				'groups' => array(),
			)
		);

		return $this->make_request(
			'subscribers',
			'POST',
			array(
				'name'      => $data['name'],
				'email'     => $data['email'],
				'group_ids' => $data['groups'],
				'status'    => 'active',
			)
		);
	}

	/**
	 * Cleans username.
	 *
	 * @param  string $username Username filled in the setting.
	 * @return string           Clean username.
	 */
	protected function clean_username( $username ) {
		$replace = array( 'http://', 'https://', '.ip-zone.com', '.ipzmarketing.com', '/' );
		return str_replace( $replace, '', $username );
	}
}
