<?php
namespace GuzzleHttp\Ring\Exception;

/**
 * Occurs when the connection failed.
 */
class ConnectException extends RingException {}
