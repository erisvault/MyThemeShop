<?php

if( ! class_exists('AC_Subscriber') ) :
class AC_Subscriber extends AC_Contact {
}
endif;
