<?php
/**
 * About Page Section - Services Grid
 *
 * @package Lawyer
 */

$services_grids = lawyer_get_settings( 'about_services_group' );

if ( empty( $services_grids ) && ! is_array( $services_grids ) ) {
	return;
}
?>

<section class="about-services-grid-section clearfix">

	<div class="container">

		<?php

		// Services grids.
		if ( ! empty( $services_grids ) && is_array( $services_grids ) ) {

			if ( empty( $services_grids ) ) {
				return;
			}

			echo '<ul class="about-services-grid-container">';
			foreach ( $services_grids as $services_grid ) {
				printf(
					'<li><a href="%1$s"><div class="img"><img src="%2$s"></div><div class="text-wrapper"><span><i class="fa fa-%3$s"></i></span><h3>%4$s</h3><p>%5$s</p></div></a></li>',
					$services_grid['about_services_group_url'],
					$services_grid['about_services_group_image'],
					$services_grid['about_services_group_icon'],
					$services_grid['about_services_group_title'],
					$services_grid['about_services_group_text']
				);
			}

			echo '</ul>';

		}
		?>

	</div><!-- .container -->

</section>
