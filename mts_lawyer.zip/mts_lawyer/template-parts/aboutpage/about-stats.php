<?php
/**
 * About Page Section - Stats
 *
 * @package Lawyer
 */

$icon          = lawyer_get_settings( 'about_stats_icon' );
$title         = lawyer_get_settings( 'about_stats_title' );
$text          = lawyer_get_settings( 'about_stats_text' );
$progress_bars = lawyer_get_settings( 'about_stats_group' );
$button_text   = lawyer_get_settings( 'about_stats_button_text' );
$button_url    = lawyer_get_settings( 'about_stats_button_url' );

if ( empty( $icon ) && empty( $title ) && empty( $text ) && empty( $progress_bars ) && ! is_array( $progress_bars ) && empty( $button_text ) && empty( $button_url ) ) {
	return;
}
?>

<section class="about-stats-section clearfix">

	<div class="container">

		<div class="small-container">

			<?php

			if ( $icon ) {
				echo '<i class="icon fa fa-' . $icon . '"></i>';
			}
			if ( $title ) {
				echo '<h2>' . $title . '</h2>';
			}
			if ( $text ) {
				echo '<p>' . $text . '</p>';
			}

			// Services grids.
			if ( ! empty( $progress_bars ) && is_array( $progress_bars ) ) {

				if ( empty( $progress_bars ) ) {
					return;
				}

				echo '<ul class="about-stats-container">';

				foreach ( $progress_bars as $progress_bar ) {
					printf(
						'<li><div class="left">%1$s</div><div class="right"><div class="bar"><div class="bar-fill" style="width:%2$s%%;">%2$s %3$s</div></div></div></li>',
						$progress_bar['about_stats_group_title'],
						$progress_bar['about_stats_group_percentage'],
						__( 'Percent', 'lawyer' )
					);
				}

				echo '</ul>';

			}
			if ( ! empty( $button_text ) && ! empty( $button_url ) ) {
				printf(
					'<a class="button border" href="%1$s">%2$s</a>',
					$button_url,
					$button_text
				);
			}
			?>

		</div>

	</div><!-- .container -->

</section>
