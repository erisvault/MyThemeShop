<?php
/**
 * Footer Sections
 *
 * @package Lawyer
 */

if ( lawyer_get_settings( 'footer_logo_section' ) ) {
	?>
	<div class="footer-logo-section">

		<div class="footer logo-wrap">
			<?php lawyer_logo( array(), 'footer' ); ?>
		</div>

	<?php
	// Footer Nav Icons
	if ( lawyer_get_settings( 'footer_logo_social_icons' ) && ! empty( lawyer_get_settings( 'footer_logo_social' ) ) && is_array( lawyer_get_settings( 'footer_logo_social' ) ) ) {
		$footer_logo_icons = lawyer_get_settings( 'footer_logo_social' );
		echo '<div class="footer-logo-social-icons">';

		foreach ( $footer_logo_icons as $item ) {
			printf(
				'<a href="%1$s" title="%2$s" class="footer-logo-%3$s" target="_blank"><span class="fa fa-%3$s"></span></a>',
				$item['footer_logo_social_link'],
				$item['footer_logo_social_title'],
				$item['footer_logo_social_icon']
			);
		}

		echo '</div>';
	}
	echo '</div>';
}
