<?php
/**
 * Footer Nav Section
 *
 * @package Lawyer
 */
if ( lawyer_get_settings( 'footer_nav_section' ) ) :
?>
	<div class="footer-nav-section">
		<?php
		// Nav Section
		if ( 1 === lawyer_get_settings( 'footer_nav_section' ) ) {
			$footer_nav_position = lawyer_get_settings( 'footer_nav_position' );
			$footer_separator    = lawyer_get_settings( 'footer_nav_separator_content' );
			$separator           = ( 1 === lawyer_get_settings( 'footer_nav_separator' ) ? '<span class="footer-separator">' . $footer_separator . '</span>' : '' );
			?>
			<div class="footer-nav-container nav-<?php echo $footer_nav_position; ?>">
				<nav class="footer-nav clearfix">
				<?php
				// Pirmary Navigation.
				if ( has_nav_menu( 'footer-menu' ) ) {
					wp_nav_menu( array(
						'theme_location' => 'footer-menu',
						'menu_class'     => 'footer-menu clearfix',
						'container'      => '',
						'after'          => $separator,
						'walker'         => new lawyer_menu_walker(),
					));
				}
				?>
				</nav>
			</div>
		<?php
		}
		?>
	</div>
<?php
endif;
?>
