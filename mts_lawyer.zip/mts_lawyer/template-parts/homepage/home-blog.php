<?php
/**
 * Homepage Section - Blog Grid
 *
 * @package Lawyer
 */

$title        = lawyer_get_settings( 'blog_section_title' );
$text         = lawyer_get_settings( 'blog_section_text' );
$button_text  = lawyer_get_settings( 'blog_section_button_text' );
$button_url   = lawyer_get_settings( 'blog_section_button_url' );
$social_icons = lawyer_get_settings( 'blog_social_icons' );

$blog_post_num = ! empty( lawyer_get_settings( 'blog_section_postnum' ) ) ? lawyer_get_settings( 'blog_section_postnum' ) : '3';
?>

<section class="blog-section clearfix">

	<div class="container">

		<?php
		echo '<div class="left">';
		if ( ! empty( $title ) ) {
			printf( '<h2>%s</h2>', $title );
		}
		if ( ! empty( $text ) ) {
			printf( '<p>%s</p>', $text );
		}
		if ( $button_text && $button_url ) {
			printf( '<a class="button border" href="%1$s">%2$s</a>', $button_url, $button_text );
		}

		// Blog social icons.
		if ( ! empty( $social_icons ) && is_array( $social_icons ) ) {

			if ( empty( $social_icons ) ) {
				return;
			}

			echo '<ul class="blog-social-icons">';
			foreach ( $social_icons as $social_icon ) {
				printf(
					'<a href="%1$s" title="%2$s" class="blog-social-%3$s" target="_blank"><span class="fa fa-%3$s"></span></a>',
					$social_icon['blog_social_link'],
					$social_icon['blog_social_title'],
					$social_icon['blog_social_icon']
				);
			}

			echo '</ul>';

		}
		echo '</div>';

		echo '<div class="right">';

		echo '<ul class="post-wrapper">';

		global $wp_query;
		$wp_query = new WP_Query( array( 'posts_per_page' => $blog_post_num ) );

		while ( have_posts() ) :
			the_post();

			printf(
				'<li><a href="%1$s"><h2>%2$s</h2></a><div class="post-meta">%3$s - %4$s</div><span class="arrow fa fa-angle-right"></span></li>',
				get_permalink(),
				get_the_title(),
				get_the_time( get_option( 'date_format' ) ),
				lawyer_get_the_category( ', ' )
			);

		endwhile;

		echo '</ul>';

		echo '</div>';
		?>

	</div><!-- .container -->

</section>
