<?php
/**
 * Homepage Section - Services Grid
 *
 * @package Lawyer
 */

$icon           = lawyer_get_settings( 'services_grid_icon' );
$title          = lawyer_get_settings( 'services_grid_title' );
$text           = lawyer_get_settings( 'services_grid_text' );
$services_grids = lawyer_get_settings( 'services_group' );

if ( ! $icon && empty( $title ) && empty( $text ) && empty( $services_grids ) && ! is_array( $services_grids ) ) {
	return;
}
?>

<section class="services-grid-section clearfix">

	<div class="container">

		<?php
		if ( $icon ) {
			echo '<i class="icon fa fa-' . $icon . '"></i>';
		}
		if ( $title ) {
			echo '<h2>' . $title . '</h2>';
		}
		if ( $text ) {
			echo '<p>' . $text . '</p>';
		}

		// Services grids.
		if ( ! empty( $services_grids ) && is_array( $services_grids ) ) {

			if ( empty( $services_grids ) ) {
				return;
			}

			echo '<ul class="services-grid-container">';
			foreach ( $services_grids as $services_grid ) {
				printf(
					'<li><a href="%1$s"><div class="img"><img src="%2$s"></div><div class="text-wrapper"><span><i class="fa fa-%3$s"></i></span><h3>%4$s</h3><p>%5$s</p></div></a></li>',
					$services_grid['services_group_url'],
					$services_grid['services_group_image'],
					$services_grid['services_group_icon'],
					$services_grid['services_group_title'],
					$services_grid['services_group_text']
				);
			}

			echo '</ul>';

		}
		?>

	</div><!-- .container -->

</section>
