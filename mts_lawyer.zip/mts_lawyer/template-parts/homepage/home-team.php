<?php
/**
 * Homepage Section - Team
 *
 * @package Lawyer
 */

$icon       = lawyer_get_settings( 'team_icon' );
$title      = lawyer_get_settings( 'team_title' );
$text       = lawyer_get_settings( 'team_text' );
$team_grids = lawyer_get_settings( 'team_group' );

if ( ! $icon && empty( $title ) && empty( $text ) && empty( $team_grids ) && ! is_array( $team_grids ) ) {
	return;
}
?>

<section class="team-section clearfix">

	<div class="container">

		<?php
		if ( $icon ) {
			echo '<i class="icon fa fa-' . $icon . '"></i>';
		}
		if ( $title ) {
			echo '<h2>' . $title . '</h2>';
		}
		if ( $text ) {
			echo '<p>' . $text . '</p>';
		}

		// Services grids.
		if ( $team_grids && is_array( $team_grids ) ) {

			if ( empty( $team_grids ) ) {
				return;
			}

			echo '<ul class="team-container">';
			foreach ( $team_grids as $team_grid ) {
				printf(
					'<li><a href="%1$s"><div class="img"><div class="hover-text"><span class="arrow fa fa-angle-right"></span>%2$s</div><img src="%3$s"></div><div class="text-wrapper"><h3>%4$s</h3><p>%5$s</p></div></a></li>',
					$team_grid['team_group_url'],
					$team_grid['team_group_hover_text'],
					$team_grid['team_group_image'],
					$team_grid['team_group_title'],
					$team_grid['team_group_text']
				);
			}

			echo '</ul>';

		}
		?>

	</div><!-- .container -->

</section>
