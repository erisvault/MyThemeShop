<?php
/**
 * Homepage Section - Featured 1
 *
 * @package Lawyer
 */

$title       = lawyer_get_settings( 'featured1_title' );
$text        = lawyer_get_settings( 'featured1_text' );
$button_text = lawyer_get_settings( 'featured1_button_text' );
$button_url  = lawyer_get_settings( 'featured1_button_url' );

if ( empty( $title ) && empty( $text ) && empty( $button_text ) && empty( $button_url ) ) {
	return;
}
?>

<section class="featured1-section clearfix">

	<div class="container">

		<div class="small-container">

			<?php
			if ( ! empty( $title ) ) {
				printf( '<h2>%s</h2>', $title );
			}
			if ( ! empty( $text ) ) {
				printf( '<p>%s</p>', $text );
			}
			if ( ! empty( $button_text ) && ! empty( $button_url ) ) {
				printf( '<a class="button border" href="%1$s">%2$s</a>', $button_url, $button_text );
			}
			?>

		</div>

	</div><!-- .container -->

</section>
