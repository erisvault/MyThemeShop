<?php
/**
 * Homepage Section - Services List
 *
 * @package Lawyer
 */

$title1     = lawyer_get_settings( 'services_list_title1' );
$list_text1 = lawyer_get_settings( 'services_list_text1' );

$title2     = lawyer_get_settings( 'services_list_title2' );
$list_text2 = lawyer_get_settings( 'services_list_text2' );

$title3     = lawyer_get_settings( 'services_list_title3' );
$list_text3 = lawyer_get_settings( 'services_list_text3' );

$title4     = lawyer_get_settings( 'services_list_title4' );
$list_text4 = lawyer_get_settings( 'services_list_text4' );

if ( empty( $title1 ) && empty( $list_text1 ) && empty( $title2 ) && empty( $list_text2 ) && empty( $title3 ) && empty( $list_text3 ) && empty( $title4 ) && empty( $list_text4 ) ) {
	return;
}
?>

<section class="services-list-section clearfix">

	<div class="container">

		<?php
		echo '<div class="services-list-container clearfix">';

		for ( $i = 1; $i < 5; $i++ ) {
			if ( ! empty( lawyer_get_settings( 'services_list_title' . $i ) ) && ! empty( lawyer_get_settings( 'services_list_text' . $i ) ) ) {
				printf(
					'<div class="list-wrap"><h2>%1$s</h2><div class="list">%2$s</div></div>',
					lawyer_get_settings( 'services_list_title' . $i ),
					wpautop( lawyer_get_settings( 'services_list_text' . $i ) )
				);
			}
		}

		echo '</div>';
		?>

	</div><!-- .container -->

</section>
