<?php
/**
 * Set lawyer layout according to options
 *
 * @package Lawyer
 */

defined( 'WPINC' ) || exit;

/**
 * Layout manager.
 */
class Lawyer_Layout extends Lawyer_Base {

	/**
	 * The Construct
	 */
	public function __construct() {
		$this->add_action( 'lawyer_before_wrapper', 'add_header' );
		$this->add_action( 'lawyer_before_content', 'single_heading_secton' );
		$this->add_action( 'lawyer_single_post_header', 'single_post_header' );
	}

	/**
	 * Add header
	 */
	public function add_header() {
		$hash   = array(
			'header-default' => 'default',
			'header-layout2' => 'layout2',
			'header-layout3' => 'layout3',
		);
		$layout = lawyer_get_settings( 'header_styles' );
		get_template_part( 'template-parts/header/header', isset( $hash[ $layout ] ) ? $hash[ $layout ] : $layout );
	}

	/**
	 * Single post heading section
	 */
	public function single_heading_secton() {

		if ( ! is_front_page() && ! is_single() ) {
			return;
		}

		$heading        = lawyer_get_settings( 'blog_heading' );
		$subheading     = lawyer_get_settings( 'blog_subheading' );
		$breadcrumb_url = lawyer_get_settings( 'blog_breadcrumb_url' );
		$arrow          = lawyer_get_settings( 'breadcrumb_icon' );

		if ( ! empty( $heading ) || ! empty( $subheading ) || lawyer_get_settings( 'mts_breadcrumb' ) ) {
		?>
		<div class="blog-heading-section clearfix">
			<div class="container">
				<?php
				if ( ! empty( $heading ) || ! empty( $subheading ) ) {
					printf( '<div class="left"><h2 class="heading">%1$s</h2><p class="subheading">%2$s</p></div>', $heading, $subheading );
				}
				if ( is_front_page() && ! empty( $breadcrumb_url ) ) {
					printf(
						'<div class="right">
							<div class="breadcrumb" xmlns:v="http://rdf.data-vocabulary.org/#">
								<div typeof="v:Breadcrumb" class="root">
									<a rel="v:url" property="v:title" href="%1$s">%2$s</a>
								</div>
								<div><i class="fa fa-' . $arrow . '"></i></div>
								<div><span>%3$s</span></div>
							</div>
						</div>',
						esc_url( trailingslashit( home_url() ) ),
						get_bloginfo( 'name' ),
						$breadcrumb_url
					);
				} elseif ( is_single() && lawyer_get_settings( 'mts_breadcrumb' ) ) {
					echo '<div class="right">';
					if ( function_exists( 'rank_math' ) && rank_math()->breadcrumbs ) {
						rank_math_the_breadcrumbs();
					} else {
						lawyer_breadcrumbs();
					}
					echo '</div>';
				}
				?>
			</div>
		</div>
		<?php
		}
	}

	/**
	 * Single post header layout
	 */
	public function single_post_header() {
		?>
		<header class="single-full-header clearfix">

			<?php
			if ( lawyer_get_settings( 'show_single_featured' ) ) {
				the_post_thumbnail( 'lawyer-featured', array( 'class' => 'single-featured-image' ) );
			}
			?>
			<h1 class="title single-title entry-title"><?php the_title(); ?></h1>
			<?php lawyer_the_post_meta( 'single' ); ?>

		</header><!--.headline_area-->
		<?php
	}
}

// Init.
new Lawyer_Layout;
