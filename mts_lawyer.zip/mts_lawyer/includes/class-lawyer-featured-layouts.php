<?php
/**
 * The featured layouts
 *
 * @package Lawyer
 */

defined( 'WPINC' ) || exit;

/**
 * Class for featured layouts.
 */
class Lawyer_Featured_Layouts extends Lawyer_Base {

	/**
	 * Current layout.
	 *
	 * @var string
	 */
	public $current = null;

	/**
	 * Hold sections.
	 *
	 * @var array
	 */
	private $sections = null;

	/**
	 * The Construct
	 */
	public function __construct() {
		$this->sections = lawyer_get_settings( 'mts_featured_categories' );
	}

	/**
	 * Render layout
	 */
	public function render() {

		if ( empty( $this->sections ) || ( is_paged() && 'latest' !== $category ) ) {
			$this->current = array(
				'layout'         => 'default',
				'posts_layout'   => 'layout-default',
				'excerpt_length' => 45,
				'unique_id'      => 'nothing',
				'is_latest'      => true,
			);

			get_template_part( 'template-parts/posts', 'default' );
			return;
		}

		foreach ( $this->sections as $section ) :

			$section = wp_parse_args( array_filter( $section ), array(
				'mts_featured_category_postsnum'   => 6,
				'mts_featured_category_excerpt'    => 45,
				'mts_featured_category_background' => '',
				'mts_featured_category_margin'     => '',
				'mts_featured_category_padding'    => '',
				'unique_id'                        => '',
			) );

			$category = $section['mts_featured_category'];

			if ( 'latest' !== $category ) {
				$this->category_posts( $category, $section['mts_featured_category_postsnum'] );
			}

			$layout = 'default';

			$this->current = array(
				'layout'           => $layout,
				'category'         => $category,
				'unique_id'        => $section['unique_id'],
				'is_latest'        => 'latest' !== $category,
				'posts_layout'     => $layout,
				'posts_count'      => $section['mts_featured_category_postsnum'],
				'excerpt_length'   => $section['mts_featured_category_excerpt'],
				'posts_background' => $section['mts_featured_category_background'],
				'posts_margin'     => $section['mts_featured_category_margin'],
				'posts_padding'    => $section['mts_featured_category_padding'],
			);

			if ( have_posts() ) {
				get_template_part( 'template-parts/posts', $layout );
			}

		endforeach;
	}

	/**
	 * Genrate post_container classes
	 */
	public function get_post_container_class() {
		$classes   = array();
		$classes[] = 'layout-' . $this->current['unique_id'];
		$classes[] = $this->current['layout'] . '-container';
		$classes[] = 'clearfix';

		echo join( ' ', $classes );
	}

	/**
	 * Set category in main query
	 *
	 * @param  int $category    Category ID.
	 * @param  int $posts_count Number of posts.
	 */
	public function category_posts( $category, $posts_count ) {
		global $wp_query;

		$wp_query = new WP_Query( 'ignore_sticky_posts=1&category_name=' . $category . '&posts_per_page=' . $posts_count );
	}

	/**
	 * Set blog heading and breadcrumb
	 *
	 * @param  int $category    Category ID.
	 */
	public function blog_heading() {

		$heading        = lawyer_get_settings( 'blog_heading' );
		$subheading     = lawyer_get_settings( 'blog_subheading' );
		$breadcrumb_url = lawyer_get_settings( 'blog_breadcrumb_url' );
		$arrow          = lawyer_get_settings( 'breadcrumb_icon' );

		if ( ! empty( $heading ) || ! empty( $subheading ) || ! empty( $breadcrumb_url ) ) {
		?>
		<div class="blog-heading-section clearfix">
			<div class="container">
				<?php
				if ( ! empty( $heading ) || ! empty( $subheading ) ) {
					printf( '<div class="left"><h2 class="heading">%1$s</h2><p class="subheading">%2$s</p></div>', $heading, $subheading );
				}
				if ( ! empty( $breadcrumb_url ) ) {
					printf(
						'<div class="right">
							<div class="breadcrumb" xmlns:v="http://rdf.data-vocabulary.org/#">
								<div typeof="v:Breadcrumb" class="root">
									<a rel="v:url" property="v:title" href="%1$s">%2$s</a>
								</div>
								<div><i class="fa fa-' . $arrow . '"></i></div>
								<div><span>%3$s</span></div>
							</div>
						</div>',
						esc_url( trailingslashit( home_url() ) ),
						get_bloginfo( 'name' ),
						$breadcrumb_url
					);
				}
				?>
			</div>
		</div>
		<?php
		}

	}

	/**
	 * Get section title.
	 *
	 * @param int $category Category id or name.
	 */
	public function get_section_title( $category = false ) {
		if ( lawyer_get_settings( 'mts_featured_category_title_' . $this->current['unique_id'] ) ) :
			$category = ! $category ? $this->current['category'] : $category;
		?>
		<div class="title-container title-id-<?php echo $this->current['unique_id']; ?>">
			<?php
			if ( ! $this->current['is_latest'] && 'latest' === $category ) {
				echo '<h3 class="featured-category-title">';
				_e( 'Latest', 'lawyer' );
				echo '</h3>';
				return;
			}
			$category_name = lawyer_get_cat_name( $category );
			$category_id   = get_cat_ID( $category_name );
			?>
			<h3 class="featured-category-title"><a href="<?php echo esc_url( get_category_link( $category_id ) ); ?>" title="<?php echo esc_attr( $category_name ); ?>"><?php echo esc_html( $category_name ); ?></a></h3>
		</div>
		<?php
		endif;
	}

	/**
	 * Get post title
	 *
	 * @param  boolean $meta     Display meta.
	 */
	public function get_post_title( $meta = true ) {
		?>
		<header>
			<?php
			if ( $meta ) {
				lawyer_the_post_meta( 'home', $this->current['unique_id'] );
			}
			?>
			<h2 class="title front-view-title">
				<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php the_title_attribute(); ?>"><?php echo the_title(); ?></a>
			</h2>
		</header>
		<?php
	}

	/**
	 * Get post thumbnail according to layout
	 *
	 * @param  boolean $avatar Display avatar.
	 */
	public function get_post_thumbnail() {
		?>
		<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php the_title_attribute(); ?>" id="featured-thumbnail" class="post-image post-image-left lawyer-featured">
			<div class="featured-thumbnail">
				<?php
				if ( has_post_thumbnail() ) {
					the_post_thumbnail( 'lawyer-featured', array( 'title' => '' ) );
				} else {
					echo '<img src="' . get_template_directory_uri() . '/images/nothumb-lawyer-featured.png" alt="' . __( 'No Preview', 'lawyer' ) . '"  class="wp-post-image" />';
				}
				?>
			</div>
			<?php
			if ( function_exists( 'wp_review_show_total' ) ) {
				wp_review_show_total( true, 'latestPost-review-wrapper' );
			}
			?>
		</a>
		<?php
	}

	/**
	 * Get post content
	 *
	 */
	public function get_post_content() {
		?>

		<div class="front-view-content">
			<?php
			if ( empty( lawyer_excerpt() ) ) {
				echo lawyer_truncate( get_the_content(), $this->current['excerpt_length'], 'words' );
			} else {
				echo lawyer_excerpt( $this->current['excerpt_length'] );
			}
			if ( lawyer_get_settings( 'readmore_' . $this->current['unique_id'] ) ) :
				lawyer_readmore();
			endif;
			?>
		</div>

		<?php
	}


	/**
	 * Get sidebar
	 */
	public function get_sidebar() {
		$cat_name = __( 'Latest ', 'lawyer' );
		if ( 'latest' !== $this->current['category'] ) {
			$cat_name = ucwords( lawyer_get_cat_name( $this->current['category'] ) );
		}
		if ( 'default' == $this->current['layout'] ) {
			$this->current['layout'] = 'layout-default';
		}
		?>
		<aside id="sidebar" class="sidebar c-4-12 post-<?php echo $this->current['layout']; ?>" role="complementary" itemscope itemtype="http://schema.org/WPSideBar">
			<?php
			dynamic_sidebar( sanitize_title( strtolower( 'post-' . $this->current['layout'] . $cat_name ) ) );
			?>
		</aside>
		<?php
	}

	/**
	 * Get post pagination
	 */
	public function get_post_pagination() {
		if ( ! $this->current['is_latest'] ) {
			lawyer_pagination( lawyer_get_settings( 'mts_pagenavigation_type' ) );
		}
		wp_reset_query();
	}
}
