/**
 * lawyer Metaboxes
 */
;(function( $ ) {

	'use strict';

	// Dom Ready
	$(function() {

		// Metabox tabs
		$( 'a', '.lawyer_metabox_tabs' ).on( 'click', function() {

			var $this = $( this ),
				target = $( '#lawyer_tab_' + $this.attr( 'href' ) );

			$( '.lawyer_metabox_tab.active' ).removeClass( 'active' );

			$this.parent().siblings().removeClass( 'active' );
			$this.parent().addClass( 'active' );
			target.addClass( 'active' );
			target.fadeIn( 800 );

			return false;
		});

		// Select
		$( '.lawyer_field select' ).select2({
			minimumResultsForSearch: 10,
			dropdownCssClass: 'lawyer-select2'
		});

		// Upload file
		var uploads = $( '.lawyer_upload_button' ),
			frame;
		if ( uploads.length ) {
			uploads.on( 'click', function( event ) {
				event.preventDefault();

				var $this = $( this );

				// If the media frame already exists, reopen it.
				if ( frame ) {
					frame.open();
					return;
				}

				// Create the media frame.
				frame = wp.media({
					multiple: false
				});

				// When an image is selected, run a callback.
				frame.on( 'select', function() {

					// Grab the selected attachment.
					var attachment = frame.state().get( 'selection' ).first();
					frame.close();

					$this.prev().val( attachment.attributes.url );
				});

				// Finally, open the modal.
				frame.open();
			});
		}

		// Buttonset
		$( '.lawyer_field.lawyer-buttonset a' ).on( 'click', function( event ) {
			event.preventDefault();

			var $radiosetcontainer = $( this ).closest( '.lawyer-buttonset' );
			$radiosetcontainer.find( '.buttonset-state-active' ).removeClass( 'buttonset-state-active' );

			$( this ).addClass( 'buttonset-state-active' );
			$radiosetcontainer.find( '.button-set-value' ).val( $radiosetcontainer.find( '.buttonset-state-active' ).data( 'value' ) ).trigger( 'change' );
		});

		// Dependency
		function lawyerCheckDependency( $currentValue, $desiredValue, $comparison ) {
			var $passed = false;
			if ( '==' === $comparison ) {
				if ( $currentValue == $desiredValue ) {
					$passed = true;
				}
			}
			if ( '=' === $comparison ) {
				if ( $currentValue = $desiredValue ) {
					$passed = true;
				}
			}
			if ( '>=' === $comparison ) {
				if ( $currentValue >= $desiredValue ) {
					$passed = true;
				}
			}
			if ( '<=' === $comparison ) {
				if ( $currentValue <= $desiredValue ) {
					$passed = true;
				}
			}
			if ( '>' === $comparison ) {
				if ( $currentValue > $desiredValue ) {
					$passed = true;
				}
			}
			if ( '<' === $comparison ) {
				if ( $currentValue < $desiredValue ) {
					$passed = true;
				}
			}
			if ( '!=' === $comparison ) {
				if ( $currentValue != $desiredValue ) {
					$passed = true;
				}
			}

			return $passed;
		}

		function lawyerLoopDependencies( $container ) {
			var $passed = false;
			$container.find( 'span' ).each( function() {

				var $value = $( this ).data( 'value' ),
					$comparison = $( this ).data( 'comparison' ),
					$field = $( this ).data( 'field' );

				$passed = lawyerCheckDependency( $( '#lawyer_' + $field ).val(), $value, $comparison );
				return $passed;
			});

			if ( $passed ) {
				 $container.parents( '.lawyer_metabox_field' ).fadeIn( 300 );
			} else {
				 $container.parents( '.lawyer_metabox_field' ).hide();
			}
		}

		$( '.lawyer-dependency' ).each( function() {
			lawyerLoopDependencies( $( this ) );
		});

		$( '[id*="lawyer"]' ).on( 'change', function() {
			var $id = $( this ).attr( 'id' ),
				$field = $id.replace( 'lawyer_', '' );
			$( 'span[data-field="' + $field + '"]' ).each( function() {
				lawyerLoopDependencies( $( this ).parents( '.lawyer-dependency' ) );
			});
		});
	});

})( jQuery );
