<?php
/**
 * HomePage CTA Section
 *
 * @package Lawyer
 */

$menus['homepage']['child']['homepage-cta'] = array(
	'title' => esc_html__( 'Call to Action', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the call to action section.', 'lawyer' ),
);

$sections['homepage-cta'] = array(

	array(
		'id'       => 'cta_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Call to Action Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'gradient',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#cfa755',
				'to'        => '#b88d37',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'cta_title',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Title', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter title for call to action section.', 'lawyer' ),
		'std'      => 'Our lawyers will also represent you in civil litigation cases such as <a href="#">divorce</a>.',
	),
	array(
		'id'    => 'cta_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Title',
			'preview-color' => 'dark',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '32px',
			'line-height'   => '42px',
			'color'         => '#ffffff',
			'css-selectors' => '.cta-section h2, .cta-section h2 a',
		),
	),

	array(
		'id'       => 'cta_button_text',
		'type'     => 'text',
		'title'    => esc_html__( 'Button Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button text.', 'lawyer' ),
		'std'      => 'See & learn more',
	),

	array(
		'id'       => 'cta_button_url',
		'type'     => 'text',
		'title'    => esc_html__( 'Button URL', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button URL.', 'lawyer' ),
		'std'      => '#',
	),

	array(
		'id'       => 'cta_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set call to action section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '57px',
			'right'  => '0',
			'bottom' => '55px',
			'left'   => '0',
		),
	),

);
