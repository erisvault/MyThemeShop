<?php
/**
 * Navigation
 *
 * @package Lawyer
 */

$menus['footer']['child']['footer-nav'] = array(
	'title' => esc_html__( 'Navigation Section', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the Navigation Section.', 'lawyer' ),
);

$sections['footer-nav'] = array(

	array(
		'id'       => 'footer_nav_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Navigation Section', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enable or disable Navigation Section with this option.', 'lawyer' ),
		'std'      => '1',
	),

	array(
		'id'         => 'footer_nav_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Navigation Section margin.', 'lawyer' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Navigation Section padding.', 'lawyer' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Select border', 'lawyer' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_nav_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Footer Navigation', 'lawyer' ),
		'std'        => array(
			'preview-text'   => 'Footer Navigation Font',
			'preview-color'  => 'dark',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '14px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.footer-nav li a',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_menu_item_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Nav Menu items', 'lawyer' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_menu_item_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Menu Items Margin', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Navigation Section menu item margin.', 'lawyer' ),
		'top'        => false,
		'bottom'     => false,
		'std'        => array(
			'right' => '44px',
			'left'  => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_separator',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Nav Separator', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Enable or disable nav separator with this option.', 'lawyer' ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_separator_content',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Separator', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Use any separator, ex: "-" "/" "|" "." ">"', 'lawyer' ),
		'std'        => '|',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_separator',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_separator_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Separator Color', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Set nav separator color from here.', 'lawyer' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_separator',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_separator_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Separator Margin', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Nav Separator margin.', 'lawyer' ),
		'top'        => false,
		'bottom'     => false,
		'std'        => array(
			'right' => '25px',
			'left'  => '25px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_separator',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

);
