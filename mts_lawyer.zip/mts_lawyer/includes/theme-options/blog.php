<?php
/**
 * HomePage Tab
 *
 * @package Lawyer
 */

$menus['blog'] = array(
	'icon'  => 'fa-list-alt',
	'title' => esc_html__( 'Blog', 'lawyer' ),
);

$menus['blog']['child']['blog-general'] = array(
	'title' => esc_html__( 'General', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the Blog page.', 'lawyer' ),
);

$sections['blog-general'] = array(

	array(
		'id'                => 'mts_featured_categories',
		'type'              => 'group',
		'title'             => esc_html__( 'Blog Sections', 'lawyer' ),
		'sub_desc'          => esc_html__( 'Select categories appearing on the homepage.', 'lawyer' ),
		'groupname'         => esc_html__( 'Section', 'lawyer' ),
		'subfields'         => array(
			array(
				'id'    => 'mts_featured_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'lawyer' ),
			),
			array(
				'id'   => 'unique_id',
				'type' => 'text',
				'args' => array(
					'type'  => 'hidden',
					'class' => 'hidden',
				),
				'std'  => uniqid(),
			),
			array(
				'id'       => 'mts_featured_category',
				'type'     => 'select',
				'title'    => esc_html__( 'Category', 'lawyer' ),
				'sub_desc' => esc_html__( 'Select a category or the latest posts for this section', 'lawyer' ),
				'std'      => 'latest',
				'data'     => 'category_slug',
				'args'     => array(
					'include_latest' => 1,
					'hide_empty'     => 0,
				),
			),
			array(
				'id'       => 'mts_featured_category_postsnum',
				'type'     => 'text',
				'class'    => 'small-text',
				'title'    => esc_html__( 'Number of posts', 'lawyer' ),
				// translators: Description.
				'sub_desc' => sprintf( wp_kses_post( __( 'Enter the number of posts to show in this section.<br/><strong>For Latest Posts</strong>, this setting will be ignored, and number set in <a href="%s" target="_blank">Settings&nbsp;&gt;&nbsp;Reading</a> will be used instead.', 'lawyer' ) ), admin_url( 'options-reading.php' ) ),
				'args'     => array( 'type' => 'number' ),
			),

			array(
				'id'       => 'mts_featured_category_excerpt',
				'type'     => 'text',
				'class'    => 'small-text',
				'title'    => esc_html__( 'Excerpt Length', 'magnus' ),
				'sub_desc' => esc_html__( 'Max lenght is 55 Words.', 'magnus' ),
				'args'     => array( 'type' => 'number' ),
			),

		),
		'std'               => array(
			'1' => array(
				'group_title'                    => '',
				'group_sort'                     => '1',
				'mts_featured_title'             => 'Latest',
				'mts_featured_category'          => 'latest',
				'mts_featured_category_postsnum' => get_option( 'posts_per_page' ),
				'mts_featured_category_excerpt'  => '45',
			),
		),

		'validate_callback' => 'validate_featured_categories',
	),

);
