<?php
/**
 * Header Tab
 *
 * @package Lawyer
 */

$menus['header'] = array(
	'icon'  => 'fa-header',
	'title' => esc_html__( 'Header', 'lawyer' ),
);

$menus['header']['child']['header-general'] = array(
	'title' => esc_html__( 'General', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of header section.', 'lawyer' ),
);

$sections['header-general'] = array(

	array(
		'id'       => 'header_styles',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Header Styling', 'lawyer' ),
		'sub_desc' => wp_kses( __( 'Choose the <strong>Header design</strong> for your site.', 'lawyer' ), array( 'strong' => '' ) ),
		'options'  => array(
			'header-default' => array( 'img' => $uri . 'headers/header-default.jpg' ),
			'header-layout2' => array( 'img' => $uri . 'headers/header-layout2.jpg' ),
			'header-layout3' => array( 'img' => $uri . 'headers/header-layout3.jpg' ),
		),
		'std'      => 'header-default',
	),

	array(
		'id'         => 'top_bar_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Top Bar', 'lawyer' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'         => 'contact_info',
		'title'      => esc_html__( 'Contact Info', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Add Time/Date and Contact Info into header.', 'lawyer' ),
		'type'       => 'group',
		'groupname'  => esc_html__( 'Contact Info', 'lawyer' ), // Group name.
		'subfields'  => array(
			array(
				'id'    => 'contact_info_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'lawyer' ),
			),
			array(
				'id'    => 'contact_info_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Icon', 'lawyer' ),
				'std'   => '#cfa755',
			),
			array(
				'id'    => 'contact_info_icon_color',
				'type'  => 'color',
				'title' => esc_html__( 'Icon color', 'lawyer' ),
			),
			array(
				'id'    => 'contact_info_small_text',
				'type'  => 'text',
				'title' => esc_html__( 'Small Text', 'lawyer' ),
			),
			array(
				'id'    => 'contact_info_text',
				'type'  => 'text',
				'title' => esc_html__( 'Large Text', 'lawyer' ),
			),
			array(
				'id'    => 'contact_info_small_text_color',
				'type'  => 'color',
				'title' => esc_html__( 'Small text color', 'lawyer' ),
			),
			array(
				'id'    => 'contact_info_text_color',
				'type'  => 'color',
				'title' => esc_html__( 'Large text color', 'lawyer' ),
			),
			array(
				'id'       => 'contact_info_border',
				'type'     => 'border',
				'title'    => esc_html__( 'Border', 'lawyer' ),
				'sub_desc' => esc_html__( 'Select border.', 'lawyer' ),
			),
			array(
				'id'    => 'contact_info_margin',
				'type'  => 'margin',
				'title' => esc_html__( 'Margin', 'lawyer' ),
			),
			array(
				'id'    => 'contact_info_padding',
				'type'  => 'margin',
				'title' => esc_html__( 'Padding', 'lawyer' ),
			),
		),
		'std'        => array(
			'time'    => array(
				'group_title'                   => 'Time and Date',
				'group_sort'                    => '1',
				'contact_info_title'            => 'Time and Date',
				'contact_info_icon'             => 'clock-o',
				'contact_info_icon_color'       => '#cfa755',
				'contact_info_small_text'       => 'Open on Mon. - Fri.',
				'contact_info_text'             => '8:00 - 19:00',
				'contact_info_small_text_color' => '#6f747d',
				'contact_info_text_color'       => '#ffffff',
				'contact_info_border'           => array(
					'direction' => 'right',
					'size'      => '1',
					'style'     => 'solid',
					'color'     => '#4c5664',
				),
				'contact_info_margin'           => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'contact_info_padding'          => array(
					'top'    => '0',
					'right'  => '27px',
					'bottom' => '0',
					'left'   => '0',
				),
			),
			'contact' => array(
				'group_title'                   => 'Contact',
				'group_sort'                    => '2',
				'contact_info_title'            => 'Contact',
				'contact_info_icon'             => 'headphones',
				'contact_info_icon_color'       => '#cfa755',
				'contact_info_small_text'       => 'Call for consultation',
				'contact_info_text'             => '123.456.789',
				'contact_info_small_text_color' => '#6f747d',
				'contact_info_text_color'       => '#ffffff',
				'contact_info_border'           => array(
					'direction' => 'right',
					'size'      => '1',
					'style'     => 'solid',
					'color'     => '#4c5664',
				),
				'contact_info_margin'           => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'contact_info_padding'          => array(
					'top'    => '0',
					'right'  => '24px',
					'bottom' => '0',
					'left'   => '24px',
				),
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'         => 'header_social_icons',
		'title'      => esc_html__( 'Header Social Icons', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Add Social Media icons in header.', 'lawyer' ),
		'type'       => 'group',
		'groupname'  => esc_html__( 'Header Icons', 'lawyer' ), // Group name.
		'subfields'  => array(
			array(
				'id'    => 'header_icon_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'lawyer' ),
			),
			array(
				'id'    => 'header_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Icon', 'lawyer' ),
			),
			array(
				'id'    => 'header_icon_link',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'lawyer' ),
			),
			array(
				'id'    => 'header_icon_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background color', 'lawyer' ),
			),
			array(
				'id'    => 'header_icon_hover_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background hover color', 'lawyer' ),
			),
			array(
				'id'    => 'header_icon_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon color', 'lawyer' ),
			),
			array(
				'id'    => 'header_icon_hover_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon hover color', 'lawyer' ),
			),
			array(
				'id'    => 'header_icon_margin',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Margin', 'lawyer' ),
			),
			array(
				'id'    => 'header_icon_padding',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Padding', 'lawyer' ),
			),
			array(
				'id'       => 'header_icon_border',
				'type'     => 'border',
				'title'    => esc_html__( 'Border', 'lawyer' ),
				'sub_desc' => esc_html__( 'Select border.', 'lawyer' ),
			),
			array(
				'id'    => 'header_icon_border_radius',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Header icon border radius', 'lawyer' ),
				'args'  => array( 'type' => 'number' ),
			),
		),
		'std'        => array(
			'facebook' => array(
				'group_title'               => 'Facebook',
				'group_sort'                => '1',
				'header_icon_title'         => 'Facebook',
				'header_icon'               => 'facebook-official',
				'header_icon_link'          => '#',
				'header_icon_bgcolor'       => '',
				'header_icon_hover_bgcolor' => '',
				'header_icon_color'         => '#ffffff',
				'header_icon_hover_color'   => '#ffffff',
				'header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'header_icon_padding'       => array(
					'top'    => '6px',
					'right'  => '24px',
					'bottom' => '6px',
					'left'   => '24px',
				),
				'header_icon_border_radius' => '0',
				'header_icon_border'        => array(
					'direction' => 'right',
					'size'      => '1',
					'style'     => 'solid',
					'color'     => '#4c5664',
				),
			),
			'twitter'  => array(
				'group_title'               => 'Twitter',
				'group_sort'                => '2',
				'header_icon_title'         => 'Twitter',
				'header_icon'               => 'twitter',
				'header_icon_link'          => '#',
				'header_icon_bgcolor'       => '',
				'header_icon_hover_bgcolor' => '',
				'header_icon_color'         => '#ffffff',
				'header_icon_hover_color'   => '#ffffff',
				'header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'header_icon_padding'       => array(
					'top'    => '6px',
					'right'  => '24px',
					'bottom' => '6px',
					'left'   => '24px',
				),
				'header_icon_border_radius' => '0',
				'header_icon_border'        => array(
					'direction' => 'right',
					'size'      => '1',
					'style'     => 'solid',
					'color'     => '#4c5664',
				),
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'         => 'header_search_box',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Header Search Form', 'lawyer' ),
		'sub_desc'   => wp_kses( __( 'Use this button to Show or Hide the <strong>Header Search Form</strong> completely.', 'lawyer' ), array( 'strong' => '' ) ),
		'std'        => '1',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'         => 'top_bar_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Top Bar Margin', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Set top bar margin from here.', 'lawyer' ),
		'left'       => false,
		'right'      => false,
		'std'        => array(
			'top'    => '0',
			'bottom' => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'top_bar_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Top Bar Padding', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Set top bar padding from here.', 'lawyer' ),
		'left'       => false,
		'right'      => false,
		'std'        => array(
			'top'    => '26px',
			'bottom' => '26px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'         => 'top_bar_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Header Background', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '#2d3849',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'    => 'header_nav_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Header Nav Settings', 'lawyer' ),
	),

	array(
		'id'         => 'nav_button',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Nav Button', 'lawyer' ),
		'sub_desc'   => wp_kses( __( 'Use this button to Show or Hide the <strong>Nav Button</strong> completely.', 'lawyer' ), array( 'strong' => '' ) ),
		'std'        => '1',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'         => 'nav_button_text',
		'type'       => 'text',
		'title'      => esc_html__( 'Button Text', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Enter button text.', 'lawyer' ),
		'std'        => 'Free Evalution',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'nav_button',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'         => 'nav_button_url',
		'type'       => 'text',
		'title'      => esc_html__( 'Button URL', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Enter button URL.', 'lawyer' ),
		'std'        => '#',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'nav_button',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout3',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'       => 'main_nav_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Main Nav Margin', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set main nav margin from here.', 'lawyer' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '0',
		),
	),
	array(
		'id'       => 'main_nav_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Main Nav Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set main nav padding from here.', 'lawyer' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '0',
		),
	),

	array(
		'id'       => 'mts_header_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select border.', 'lawyer' ),
	),

	array(
		'id'       => 'nav_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Main Navigation Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#3a475d',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'    => 'header_general_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Header General Settings', 'lawyer' ),
	),

	array(
		'id'       => 'mts_sticky_nav',
		'type'     => 'switch',
		'title'    => esc_html__( 'Floating Navigation Menu', 'lawyer' ),
		// translators: Floating Navigation Menu with strong tag.
		'sub_desc' => sprintf( esc_html__( 'Use this button to enable %s.', 'lawyer' ), '<strong>' . esc_html__( 'Floating Navigation Menu', 'lawyer' ) . '</strong>' ),
		'std'      => '0',
	),

	array(
		'id'       => 'mts_header_section2',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Logo', 'lawyer' ),
		'sub_desc' => wp_kses( __( 'Use this button to Show or Hide the <strong>Logo</strong> completely.', 'lawyer' ), array( 'strong' => '' ) ),
		'std'      => '1',
	),

	array(
		'id'       => 'main_navigation_dropdown_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Color', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'lawyer' ),
		'std'      => '#ffffff',
	),
	array(
		'id'       => 'main_navigation_dropdown_hover_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Hover Color', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'lawyer' ),
		'std'      => lawyer_get_settings( 'primary_color_scheme' ),
	),

);
