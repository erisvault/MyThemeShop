<?php
/**
 * About Page Video Section
 *
 * @package Lawyer
 */

$menus['aboutpage']['child']['aboutpage-video'] = array(
	'title' => esc_html__( 'Video', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the video section.', 'lawyer' ),
);

$sections['aboutpage-video'] = array(

	array(
		'id'       => 'about_video_image',
		'type'     => 'upload',
		'title'    => esc_html__( 'Section Background Image', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select an image file for your video section.', 'lawyer' ),
		'return'   => 'url',
		'std'      => get_template_directory_uri() . '/images/about-video-bg.jpg',
	),

	array(
		'id'       => 'about_video_youtube_id',
		'type'     => 'text',
		'title'    => esc_html__( 'YouTube Video ID', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter YouTube video ID to appear on the Stats section', 'lawyer' ),
		'std'      => 'hcZGS9SUkeY',
	),

	array(
		'id'       => 'about_video_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set video section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),

);
