<?php
/**
 * Search Tab
 *
 * @package Lawyer
 */

$menus['search'] = array(
	'icon'  => 'fa fa-search',
	'title' => esc_html__( 'Search', 'lawyer' ),
	'desc'  => esc_html__( 'Setting here apply to search pages.', 'lawyer' ),
);

$sections['search'] = array(

	array(
		'id'       => 'search_content',
		'type'     => 'select',
		'title'    => esc_html__( 'Search Results Content', 'lawyer' ),
		'sub_desc' => esc_html__( 'Controls the type of content that displays in search results.', 'lawyer' ),
		'options'  => array(
			'all'          => esc_html__( 'All Post Types and Pages', 'lawyer' ),
			'all-no-pages' => esc_html__( 'All Post Types without Pages', 'lawyer' ),
			'pages'        => esc_html__( 'Only Pages', 'lawyer' ),
			'posts'        => esc_html__( 'Only Blog Posts', 'lawyer' ),
			'woocommerce'  => esc_html__( 'Only WooCommerce Products', 'lawyer' ),
		),
		'std'      => 'posts_pages',
	),

	array(
		'id'       => 'search_results_per_page',
		'type'     => 'text',
		'title'    => esc_html__( 'Number of Search Results Per Page', 'lawyer' ),
		'sub_desc' => esc_html__( 'Controls the number of search results per page.', 'lawyer' ),
		'validate' => 'numeric',
		'std'      => '9',
		'class'    => 'small-text',
	),

	array(
		'id'       => 'search_position',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Search Form Position', 'lawyer' ),
		'sub_desc' => esc_html__( 'Controls the position of the search bar on the search results page.', 'lawyer' ),
		'options'  => array(
			'above' => esc_html__( 'Above Results', 'lawyer' ),
			'below' => esc_html__( 'Below Results', 'lawyer' ),
			'hide'  => esc_html__( 'Hide', 'lawyer' ),
		),
		'std'      => 'above',
	),
);
