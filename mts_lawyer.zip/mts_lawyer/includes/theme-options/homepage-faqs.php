<?php
/**
 * HomePage Faqs Section
 *
 * @package Lawyer
 */

$menus['homepage']['child']['homepage-faqs'] = array(
	'title' => esc_html__( 'FAQs', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the FAQs section.', 'lawyer' ),
);

$faq_answer = 'Maecenas viverra sapien felis, elementum semper ante interdum et. Sed condimentum vel lorem id tempor. Sed convallis eu eros at vulputate. Nam non quam nulla. Donec lobortis, turpis id imperdiet vulputate, ante sem aliquam enim, id dignissim enim est eu erat. Mauris vulputate facilisis nisl, eu varius magna ullamcorper ut. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.';

$sections['homepage-faqs'] = array(

	array(
		'id'       => 'faqs_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'        => 'faqs_items',
		'type'      => 'group',
		'title'     => esc_html__( 'FAQs', 'lawyer' ),
		'sub_desc'  => esc_html__( 'Add faq appearing on the FAQs section.', 'lawyer' ),
		'groupname' => esc_html__( 'Faq', 'lawyer' ),
		'subfields' => array(
			array(
				'id'    => 'faqs_question',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'lawyer' ),
			),
			array(
				'id'    => 'faqs_answer',
				'type'  => 'textarea',
				'title' => esc_html__( 'Text', 'lawyer' ),
			),
		),
		'std'       => array(
			'1' => array(
				'group_sort'    => '1',
				'faqs_question' => 'How do I choose Lawyer?',
				'faqs_answer'   => $faq_answer,
			),
			'2' => array(
				'group_sort'    => '2',
				'faqs_question' => 'How do I sponsor my company updates on Linked In?',
				'faqs_answer'   => $faq_answer,
			),
			'3' => array(
				'group_sort'    => '3',
				'faqs_question' => 'Can I get a divorce without a Lawyer?',
				'faqs_answer'   => $faq_answer,
			),
			'4' => array(
				'group_sort'    => '4',
				'faqs_question' => 'Can I get a divorce Lawyer to help me if I cant afford to Pay?',
				'faqs_answer'   => $faq_answer,
			),
			'5' => array(
				'group_sort'    => '5',
				'faqs_question' => 'What is domestic violence?',
				'faqs_answer'   => $faq_answer,
			),
		),
	),

	array(
		'id'    => 'faqs_question_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Question Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Question',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '16px',
			'color'          => '#2d3349',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.faqs-section .question',
		),
	),
	array(
		'id'    => 'faqs_answer_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Answer Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Answer',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '26px',
			'color'         => '#2d3349',
			'css-selectors' => '.faqs-section .answer',
		),
	),

	array(
		'id'       => 'faqs_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set why us section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '94px',
			'left'   => '0',
		),
	),

);
