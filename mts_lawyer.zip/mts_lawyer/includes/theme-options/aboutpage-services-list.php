<?php
/**
 * About Page Services List Section
 *
 * @package Lawyer
 */

$menus['aboutpage']['child']['aboutpage-services-list'] = array(
	'title' => esc_html__( 'Services List', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the services list section.', 'lawyer' ),
);

$sections['aboutpage-services-list'] = array(

	array(
		'id'       => 'about_services_list_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#2d3849',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'        => 'about_services_list_group',
		'type'      => 'group',
		'title'     => esc_html__( 'Services List', 'lawyer' ),
		'sub_desc'  => esc_html__( 'Add services appearing on the Services List section.', 'lawyer' ),
		'groupname' => esc_html__( 'Services', 'lawyer' ),
		'subfields' => array(
			array(
				'id'    => 'about_services_list_group_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'lawyer' ),
			),
			array(
				'id'    => 'about_services_list_group_text',
				'type'  => 'textarea',
				'title' => esc_html__( 'Text', 'lawyer' ),
			),
			array(
				'id'    => 'about_services_list_group_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Select Icon', 'lawyer' ),
			),
			array(
				'id'    => 'about_services_list_group_button_text',
				'type'  => 'text',
				'title' => esc_html__( 'Button Text', 'lawyer' ),
			),
			array(
				'id'    => 'about_services_list_group_button_url',
				'type'  => 'text',
				'title' => esc_html__( 'Button URL', 'lawyer' ),
			),
		),
		'std'       => array(
			'1' => array(
				'group_sort'                            => '1',
				'about_services_list_group_title'       => 'Family Law',
				'about_services_list_group_text'        => 'In conjunction with his vast know-how, we leverage the robust legal expertise of working in different courts.',
				'about_services_list_group_icon'        => 'adjust',
				'about_services_list_group_button_text' => 'Contact us now',
				'about_services_list_group_button_url'  => '#',
			),
			'2' => array(
				'group_sort'                            => '2',
				'about_services_list_group_title'       => 'Finance Marketing',
				'about_services_list_group_text'        => 'In conjunction with his vast know-how, we leverage the robust legal expertise of working in different courts.',
				'about_services_list_group_icon'        => 'bitcoin',
				'about_services_list_group_button_text' => 'Contact us now',
				'about_services_list_group_button_url'  => '#',
			),
			'3' => array(
				'group_sort'                            => '3',
				'about_services_list_group_title'       => 'Intellectual Property',
				'about_services_list_group_text'        => 'In conjunction with his vast know-how, we leverage the robust legal expertise of working in different courts.',
				'about_services_list_group_icon'        => 'houzz',
				'about_services_list_group_button_text' => 'Contact us now',
				'about_services_list_group_button_url'  => '#',
			),
		),
	),

	array(
		'id'    => 'about_services_list_group_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Title',
			'preview-color'  => 'dark',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '20px',
			'line-height'    => '35px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.about-services-list-container h3',
		),
	),
	array(
		'id'    => 'about_services_list_group_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Text',
			'preview-color' => 'dark',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '26px',
			'color'         => '#ffffff',
			'css-selectors' => '.about-services-list-container p',
		),
	),

	array(
		'id'       => 'about_services_list_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Margin', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set services list section margin from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '-30px',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'about_services_list_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set services list section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '97px',
			'right'  => '0',
			'bottom' => '69px',
			'left'   => '0',
		),
	),

);
