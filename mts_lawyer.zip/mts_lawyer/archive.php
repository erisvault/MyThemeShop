<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Lawyer
 */

get_header(); ?>

	<div id="wrapper">

		<div class="container">

			<div class="<?php lawyer_article_class(); ?>">

				<?php lawyer_action( 'before_content' ); ?>

				<div id="content_box">
					<section id="latest-posts" class="layout-default clearfix">
						<?php
						the_archive_title( '<h1 class="page-title">', '</h1>' );
						the_archive_description( '<div class="taxonomy-description">', '</div>' );

						$j = 0;
						if ( have_posts() ) {
							while ( have_posts() ) {
								the_post();
								lawyer_blog_articles();
							}
						}

						if ( 0 !== ++$j ) {
							lawyer_pagination( lawyer_get_settings( 'mts_pagenavigation_type' ) );
						}
						?>
					</section>
				</div>

				<?php lawyer_action( 'after_content' ); ?>

			</div>

			<?php get_sidebar(); ?>

		</div>

<?php
get_footer();
