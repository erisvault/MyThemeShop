<?php
/**
 * The template for displaying search results pages.
 *
 * @package Lawyer
 */

get_header(); ?>

	<div id="wrapper">

		<div class="container">

			<div class="article">

				<?php lawyer_action( 'before_content' ); ?>

				<div id="content_box">

					<?php if ( have_posts() ) : ?>

						<h1 class="page-title">
							<?php
							// translators: search query.
							printf( esc_html__( 'Search Results for: %s', 'lawyer' ), '<span>' . get_search_query() . '</span>' );
							?>
						</h1>
					<?php else : ?>
						<h1 class="page-title"><?php esc_html_e( 'Nothing Found', 'lawyer' ); ?></h1>
					<?php endif; ?>

					<?php
					if ( 'above' === lawyer_get_settings( 'search_position' ) ) {
						get_search_form();
					}

					$j = 0;
					if ( have_posts() ) {
						while ( have_posts() ) {
							the_post();
							lawyer_blog_articles( 'default' );
						}
					} else {
						get_template_part( 'template-parts/no', 'results' );
					}

					if ( 0 !== $j ) {
						lawyer_pagination( lawyer_get_settings( 'mts_pagenavigation_type' ) );
					}

					if ( 'below' === lawyer_get_settings( 'search_position' ) ) {
						get_search_form();
					}
					?>
				</div>

				<?php lawyer_action( 'after_content' ); ?>

			</div>

			<?php get_sidebar(); ?>

		</div>

<?php
get_footer();
