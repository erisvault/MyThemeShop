<?php
// make sure to not include translations
$args['presets']['default'] = array(
	'title' => 'Default',
	'demo' => 'http://demo.mythemeshop.com/sensational/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/default/thumb.jpg',
	'menus' => array( 'primary-menu' => 'Menu' ), // menu location slug => Demo menu name
	'options' => array( 'show_on_front' => 'posts' ),
);

$args['presets']['travel'] = array(
	'title' => 'Travel',
	'demo' => 'http://demo.mythemeshop.com/sensational-travel/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/travel/thumb.jpg',
	'menus' => array( 'primary-menu' => 'Menu' ), // menu location slug => Demo menu name
	//'options' => array( 'show_on_front' => 'page', 'page_on_front' => '4' ), // To set static front page
);

$args['presets']['fashion'] = array(
	'title' => 'Fashion',
	'demo' => 'http://demo.mythemeshop.com/sensational-fashion/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/fashion/thumb.jpg',
	'menus' => array( 'primary-menu' => 'Menu' ), // menu location slug => Demo menu name
	'options' => array( 'show_on_front' => 'posts' ),
);

$args['presets']['political'] = array(
	'title' => 'Political',
	'demo' => 'http://demo.mythemeshop.com/sensational-political/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/political/thumb.jpg',
	'menus' => array( 'primary-menu' => 'Menu' ), // menu location slug => Demo menu name
	//'options' => array( 'show_on_front' => 'page', 'page_on_front' => '4' ), // To set static front page
);

$args['presets']['writer'] = array(
	'title' => 'Writer',
	'demo' => 'http://demo.mythemeshop.com/sensational-writer/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/writer/thumb.jpg',
	'menus' => array( 'primary-menu' => 'Menu' ), // menu location slug => Demo menu name
	//'options' => array( 'show_on_front' => 'page', 'page_on_front' => '4' ), // To set static front page
);

global $mts_presets;
$mts_presets = $args['presets'];
