<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Magnus
 */

get_template_part( 'template-parts/footer/footer', 'ad' );
?>
	</div><!--#wrapper-->

	<footer<?php magnus_attr( 'footer' ); ?>>

		<div class="container">
			<?php

			get_template_part( 'template-parts/footer/footer', 'logo' );

			if ( 'bottom' !== magnus_get_settings( 'footer_sections_position' ) ) {
				get_template_part( 'template-parts/footer/footer', 'sections' );
			}

			if ( magnus_get_settings( 'mts_top_footer' ) ) {
				magnus_footer_widget_columns();
			}

			if ( 'bottom' === magnus_get_settings( 'footer_sections_position' ) ) {
				get_template_part( 'template-parts/footer/footer', 'sections' );
			}
			?>
		</div>

		<?php magnus_footer_copyrights(); ?>

	</footer><!--#site-footer-->

</div><!--.main-container-->

<?php get_template_part( 'template-parts/footer/footer', 'detect-adblocker' ); ?>

<?php wp_footer(); ?>

</body>
</html>
