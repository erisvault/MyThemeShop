<?php
/**
 * Magnus Child Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Magnus Child
 */

/**
 * Enqueue styles
 */
function magnus_child_enqueue_scripts() {
	wp_enqueue_style( 'magnus-child-theme', get_stylesheet_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'magnus_child_enqueue_scripts', 15 );
