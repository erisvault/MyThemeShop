<?php
/**
 * Typography tab
 *
 * @package Magnus
 */

$menus['typography-collection'] = array(
	'icon'       => 'fa-text-width',
	'title'      => esc_html__( 'Typography', 'magnus' ),
	'hide_title' => true,
);

$sections['typography-collection'] = array(

	array(
		'id'    => 'typography-collections',
		'type'  => 'typography_collections',
		'title' => esc_html__( 'Theme Typography', 'magnus' ),
		'desc'  => esc_html__( 'From here, you can control the fonts used on your site. You can choose from 17 standard font sets, or from the Google Fonts Library containing 800+ fonts.', 'magnus' ),
	),

	array(
		'id'    => 'magnus_logo',
		'type'  => 'typography',
		'title' => esc_html__( 'Logo Font', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'Logo',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '700',
			'font-size'     => '38px',
			'color'         => magnus_get_settings( 'mts_color_scheme' ),
			'css-selectors' => '#logo a',
		),
	),

	array(
		'id'    => 'secondary_navigation_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Secondary Navigation', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'Secondary Navigation Font',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => 'normal',
			'font-size'     => '15px',
			'color'         => '#1c2534',
			'css-selectors' => '#secondary-navigation a, .header-layout3 .navigation .toggle-caret',
		),
	),

	array(
		'id'    => 'home_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Archive Post Titles', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'Archive Article Title',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '500',
			'font-size'     => '40px',
			'line-height'   => '46px',
			'color'         => '#1c2534',
			'css-selectors' => '.latestPost .title a',
		),
	),

	array(
		'id'    => 'single_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Single Post Title', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'Single Article Title',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '500',
			'font-size'     => '36px',
			'line-height'   => '44px',
			'color'         => '#1c2534',
			'css-selectors' => '.single-title',
		),
	),

	array(
		'id'    => 'content_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Content Font', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'Content Font',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '300',
			'font-size'     => '20px',
			'line-height'   => '36px',
			'color'         => '#1c2534',
			'css-selectors' => 'body',
		),
	),

	array(
		'id'    => 'sidebar_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Widget Title', 'magnus' ),
		'std'   => array(
			'preview-text'   => 'Sidebar Title Font',
			'preview-color'  => 'light',
			'font-family'    => 'Rubik',
			'font-weight'    => '500',
			'font-size'      => '24px',
			'line-height'    => '32px',
			'color'          => '#a7a9ad',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '#sidebar .widget h3.widget-title, .widget #wp-subscribe .title',
		),
	),

	array(
		'id'    => 'sidebar_url',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Links', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Links',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '500',
			'font-size'     => '18px',
			'line-height'   => '24px',
			'color'         => '#1c2534',
			'css-selectors' => '#sidebar .widget a, #sidebar .widget li',
		),
	),
	array(
		'id'    => 'sidebar_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Font', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Font',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '300',
			'font-size'     => '16px',
			'line-height'   => '25px',
			'color'         => '#70747a',
			'css-selectors' => '#sidebar .widget p, #sidebar .widget .post-excerpt',
		),
	),

	array(
		'id'    => 'top_footer_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Widget Title', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'Footer Title Font',
			'preview-color' => 'dark',
			'font-family'   => 'Rubik',
			'font-weight'   => '500',
			'font-size'     => '24px',
			'color'         => '#ffffff',
			'css-selectors' => '.footer-widgets h3, #site-footer .widget #wp-subscribe .title, .brands-title',
		),
	),

	array(
		'id'    => 'top_footer_link_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Link', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'Footer Links',
			'preview-color' => 'dark',
			'font-family'   => 'Rubik',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'color'         => '#d7d7d9',
			'css-selectors' => '.f-widget a, footer .wpt_widget_content a, footer .wp_review_tab_widget_content a, footer .wpt_tab_widget_content a, footer .widget .wp_review_tab_widget_content a',
		),
	),

	array(
		'id'    => 'top_footer_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer font', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'Footer Font',
			'preview-color' => 'dark',
			'font-family'   => 'Rubik',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '28px',
			'color'         => '#a8aaae',
			'css-selectors' => '.footer-widgets, .f-widget .top-posts .comment_num, footer .meta, footer .twitter_time, footer .widget .wpt_widget_content .wpt-postmeta, footer .widget .wpt_comment_content, footer .widget .wpt_excerpt, footer .wp_review_tab_widget_content .wp-review-tab-postmeta, footer .advanced-recent-posts p, footer .popular-posts p, footer .category-posts p, footer .widget .post-info',
		),
	),

	array(
		'id'    => 'copyrights_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Copyrights Section', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'Copyrights Font',
			'preview-color' => 'dark',
			'font-family'   => 'Rubik',
			'font-weight'   => '400',
			'font-size'     => '15px',
			'color'         => '#a8aaae',
			'css-selectors' => '#copyright-note, #copyright-note a',
		),
	),

	array(
		'id'    => 'h1_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H1 Heading in Content', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'H1 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '500',
			'font-size'     => '28px',
			'color'         => '#1c2534',
			'css-selectors' => 'h1',
		),
	),

	array(
		'id'    => 'h2_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H2 Heading in Content', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'H2 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '500',
			'font-size'     => '24px',
			'color'         => '#1c2534',
			'css-selectors' => 'h2',
		),
	),

	array(
		'id'    => 'h3_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H3 Heading in Content', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'H3 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '500',
			'font-size'     => '22px',
			'color'         => '#1c2534',
			'css-selectors' => 'h3',
		),
	),

	array(
		'id'    => 'h4_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H4 Heading in Content', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'H4 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '500',
			'font-size'     => '20px',
			'color'         => '#1c2534',
			'css-selectors' => 'h4',
		),
	),

	array(
		'id'    => 'h5_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H5 Heading in Content', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'H5 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '500',
			'font-size'     => '18px',
			'color'         => '#1c2534',
			'css-selectors' => 'h5',
		),
	),

	array(
		'id'    => 'h6_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H6 Heading in Content', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'H6 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '500',
			'font-size'     => '16px',
			'color'         => '#1c2534',
			'css-selectors' => 'h6',
		),
	),

	array(
		'id'       => 'typography-subsets',
		'type'     => 'multi_checkbox',
		'title'    => esc_html__( 'Character sets', 'magnus' ),
		'sub_desc' => esc_html__( 'Choose the character sets you wish to include. Please note that not all sets are available for all fonts.', 'magnus' ),
		'options'  => array(
			'latin'        => esc_html__( 'Latin', 'magnus' ),
			'latin-ext'    => esc_html__( 'Latin Extended', 'magnus' ),
			'cyrillic'     => esc_html__( 'Cyrillic', 'magnus' ),
			'cyrillic-ext' => esc_html__( 'Cyrillic Extended', 'magnus' ),
			'greek'        => esc_html__( 'Greek', 'magnus' ),
			'greek-ext'    => esc_html__( 'Greek Extended', 'magnus' ),
			'vietnamese'   => esc_html__( 'Vietnamese', 'magnus' ),
			'khmer'        => esc_html__( 'Khmer', 'magnus' ),
			'devanagari'   => esc_html__( 'Devanagari', 'magnus' ),
		),
		'std'      => array( 'latin' ),
	),
);
