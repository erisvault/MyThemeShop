<?php
/**
 * Brands
 *
 * @package Magnus
 */

$menus['footer']['child']['footer-brands'] = array(
	'title' => esc_html__( 'Brands Section', 'magnus' ),
	'desc'  => esc_html__( 'From here, you can control the Brands Section.', 'magnus' ),
);

$sections['footer-brands'] = array(

	array(
		'id'       => 'footer_brands_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Brands Section', 'magnus' ),
		'sub_desc' => esc_html__( 'Enable or disable Brands Section with this option.', 'magnus' ),
		'std'      => '0',
	),

	array(
		'id'         => 'footer_brands_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Brands Section Alignment', 'magnus' ),
		'sub_desc'   => esc_html__( 'Choose alignment of Brands Section.', 'magnus' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'magnus' ),
			'center' => esc_html__( 'Center', 'magnus' ),
			'right'  => esc_html__( 'Right', 'magnus' ),
		),
		'std'        => 'center',
		'class'      => 'green',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'brands_section_title',
		'type'       => 'text',
		'title'      => esc_html__( 'Brands Title', 'magnus' ),
		'sub_desc'   => esc_html__( 'Enter brands title here.', 'magnus' ),
		'std'        => esc_html__( 'Our Brands:', 'magnus' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),

	),

	array(
		'id'         => 'footer_brands_items',
		'type'       => 'group',
		'title'      => esc_html__( 'Brands', 'magnus' ),
		'groupname'  => esc_html__( 'Brand', 'magnus' ), // Group name.
		'subfields'  => array(
			array(
				'id'       => 'brand_title',
				'type'     => 'text',
				'title'    => esc_html__( 'Title', 'magnus' ),
				'sub_desc' => esc_html__( 'The title will not be shown.', 'magnus' ),
			),
			array(
				'id'       => 'brand_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Image', 'magnus' ),
				'sub_desc' => esc_html__( 'Upload or select an image for brand', 'magnus' ),
			),
			array(
				'id'       => 'brand_url',
				'type'     => 'text',
				'title'    => esc_html__( 'Link', 'magnus' ),
				'sub_desc' => esc_html__( 'Insert a link URL of brand', 'magnus' ),
				'std'      => '#',
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'brands_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'magnus' ),
		'sub_desc'   => esc_html__( 'Brands Section margin.', 'magnus' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'brands_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'magnus' ),
		'sub_desc'   => esc_html__( 'Brands Section padding.', 'magnus' ),
		'std'        => array(
			'top'    => '40px',
			'right'  => '0',
			'bottom' => '27px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'brands_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'magnus' ),
		'sub_desc'   => esc_html__( 'Select border', 'magnus' ),
		'std'        => array(
			'direction' => 'top',
			'size'      => '1',
			'style'     => 'solid',
			'color'     => '#008b3e',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
);
