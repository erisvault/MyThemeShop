<?php
/**
 * Navigation
 *
 * @package Magnus
 */

$menus['footer']['child']['footer-nav'] = array(
	'title' => esc_html__( 'Navigation Section', 'magnus' ),
	'desc'  => esc_html__( 'From here, you can control the Navigation Section.', 'magnus' ),
);

$sections['footer-nav'] = array(

	array(
		'id'       => 'footer_nav_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Navigation Section', 'magnus' ),
		'sub_desc' => esc_html__( 'Enable or disable Navigation Section with this option.', 'magnus' ),
		'std'      => '0',
	),

	array(
		'id'         => 'footer_nav_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Navigation Section Alignment', 'magnus' ),
		'sub_desc'   => esc_html__( 'Choose alignment of Navigation Section.', 'magnus' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'magnus' ),
			'center' => esc_html__( 'Center', 'magnus' ),
			'right'  => esc_html__( 'Right', 'magnus' ),
		),
		'std'        => 'left',
		'class'      => 'green',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_nav_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'magnus' ),
		'sub_desc'   => esc_html__( 'Navigation Section margin.', 'magnus' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'magnus' ),
		'sub_desc'   => esc_html__( 'Navigation Section padding.', 'magnus' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'magnus' ),
		'sub_desc'   => esc_html__( 'Select border', 'magnus' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_nav_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Footer Navigation', 'magnus' ),
		'std'        => array(
			'preview-text'  => 'Footer Navigation Font',
			'preview-color' => 'dark',
			'font-family'   => 'Rubik',
			'font-weight'   => '400',
			'font-size'     => '15px',
			'color'         => '#d7d7d9',
			'css-selectors' => '.footer-nav li a',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_menu_item_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Nav Menu items', 'magnus' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_menu_item_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Menu Items Margin', 'magnus' ),
		'sub_desc'   => esc_html__( 'Navigation Section menu item margin.', 'magnus' ),
		'top'        => false,
		'bottom'     => false,
		'std'        => array(
			'right' => '19px',
			'left'  => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_separator',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Nav Separator', 'magnus' ),
		'sub_desc'   => esc_html__( 'Enable or disable nav separator with this option.', 'magnus' ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_separator_content',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Separator', 'magnus' ),
		'sub_desc'   => esc_html__( 'Use any separator, ex: "-" "/" "|" "." ">"', 'magnus' ),
		'std'        => '|',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_separator',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_separator_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Separator Color', 'magnus' ),
		'sub_desc'   => esc_html__( 'Set nav separator color from here.', 'magnus' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_separator',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_separator_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Separator Margin', 'magnus' ),
		'sub_desc'   => esc_html__( 'Nav Separator margin.', 'magnus' ),
		'top'        => false,
		'bottom'     => false,
		'std'        => array(
			'right' => '25px',
			'left'  => '25px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_separator',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

);
