<?php
/**
 * Single Related Posts
 *
 * @package Magnus
 */

$menus['single-related'] = array(
	'title' => esc_html__( 'Related Posts', 'magnus' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of related posts in single posts page.', 'magnus' ),
);

$sections['single-related'] = array(

	array(
		'id'       => 'related_posts_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Related Posts Background', 'magnus' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'magnus' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'related_posts_layouts',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Related Posts Layouts', 'magnus' ),
		'sub_desc' => esc_html__( 'Choose the Related Posts layouts for your site.', 'magnus' ),
		'options'  => array(
			'default'  => array( 'img' => $uri . 'related/r1.jpg' ),
			'related2' => array( 'img' => $uri . 'related/r2.jpg' ),
			'related3' => array( 'img' => $uri . 'related/r3.jpg' ),
			'related4' => array( 'img' => $uri . 'related/r4.jpg' ),
			'related5' => array( 'img' => $uri . 'related/r5.jpg' ),
			'related6' => array( 'img' => $uri . 'related/r6.jpg' ),
		),
		'std'      => 'default',
	),

	array(
		'id'         => 'related_posts_grid',
		'type'       => 'select',
		'class'      => 'small',
		'title'      => esc_html__( 'Grid', 'magnus' ),
		'sub_desc'   => esc_html__( 'Select the number of grid for Related Posts.', 'magnus' ),
		'options'    => array(
			'grid2' => esc_html__( '2', 'magnus' ),
			'grid3' => esc_html__( '3', 'magnus' ),
			'grid4' => esc_html__( '4', 'magnus' ),
			'grid5' => esc_html__( '5', 'magnus' ),
			'grid6' => esc_html__( '6', 'magnus' ),
		),
		'std'        => 'grid3',
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'default',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_related_postsnum',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Number of related posts', 'magnus' ),
		'sub_desc' => esc_html__( 'Enter the number of posts to show in the related posts section.', 'magnus' ),
		'std'      => '3',
		'args'     => array(
			'type' => 'number',
		),
	),

	array(
		'id'         => 'related_posts_excerpt_length',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Excerpt Length', 'magnus' ),
		'sub_desc'   => esc_html__( 'Enter excerpt length for big post here.', 'magnus' ),
		'std'        => '15',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'related4',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'related_posts_image_position',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Image Position from Top', 'magnus' ),
		'sub_desc'   => esc_html__( 'Enter image position from top in px.', 'magnus' ),
		'std'        => '95',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'related4',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'related_posts_adcode',
		'type'       => 'ace_editor',
		'mode'       => 'html',
		'title'      => esc_html__( 'Related Posts Ad', 'magnus' ),
		'sub_desc'   => esc_html__( 'Paste your Adsense, BSA or other ad code here to show ads in Related Posts Area.', 'magnus' ),
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'related5',
				'comparison' => '==',
			),
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'related6',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'related_posts_position',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Related Posts Position', 'magnus' ),
		'sub_desc' => esc_html__( 'Choose the position for related posts, below content will be Full width', 'magnus' ),
		'options'  => array(
			'default' => esc_html__( 'Default', 'magnus' ),
			'full'    => esc_html__( 'Below Content', 'magnus' ),
		),
		'std'      => 'default',
	),

	array(
		'id'       => 'related_post_meta_info',
		'type'     => 'multi_checkbox',
		'title'    => esc_html__( 'Post Meta Info', 'magnus' ),
		'sub_desc' => esc_html__( 'Show or hide post meta info.', 'magnus' ),
		'options'  => array(
			'author'   => esc_html__( 'Author Name', 'magnus' ),
			'time'     => esc_html__( 'Time/Date', 'magnus' ),
			'category' => esc_html__( 'Category', 'magnus' ),
			'comment'  => esc_html__( 'Comments', 'magnus' ),
		),
		'std'      => array(),
	),

	array(
		'id'       => 'related_posts_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Margin', 'magnus' ),
		'sub_desc' => esc_html__( 'Set related posts margin from here.', 'magnus' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'related_posts_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'magnus' ),
		'sub_desc' => esc_html__( 'Set related posts padding from here.', 'magnus' ),
		'std'      => array(
			'top'    => '49px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),

	array(
		'id'    => 'related_post_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Related Post Section Title Typography', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'Related Post Section Title Typography',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '500',
			'font-size'     => '28px',
			'color'         => '#1c2534',
			'css-selectors' => '.related-posts h4',
		),
	),

	array(
		'id'         => 'related_big_posts_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Big Related Posts Title', 'magnus' ),
		'std'        => array(
			'preview-text'  => 'Big Related Posts Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '500',
			'font-size'     => '28px',
			'line-height'   => '38px',
			'color'         => '#1c2534',
			'css-selectors' => '.related-posts.related4 .latestPost.big .title a',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'related4',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'related_posts_excerpt_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Related Posts Excerpt', 'magnus' ),
		'std'        => array(
			'preview-text'  => 'Related Posts Excerpt Font',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '300',
			'font-size'     => '16px',
			'line-height'   => '25px',
			'color'         => '#70747a',
			'css-selectors' => '.related-posts .front-view-content',
		),
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'default',
				'comparison' => '==',
			),
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'related4',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'    => 'related_posts_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Related Posts Title', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'Related Posts Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '500',
			'font-size'     => '18px',
			'line-height'   => '25px',
			'color'         => '#1c2534',
			'css-selectors' => '.related-posts .title a',
		),
	),
	array(
		'id'    => 'related_posts_meta_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Related Posts Meta Info', 'magnus' ),
		'std'   => array(
			'preview-text'  => 'Related Posts Meta Info Font',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '300',
			'font-size'     => '13px',
			'color'         => '#70747a',
			'css-selectors' => '.related-posts .post-info, .related-posts .post-info a',
		),
	),

	array(
		'id'    => 'related_posts_article_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Related Posts Articles', 'magnus' ),
	),

	array(
		'id'       => 'related_article_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Related Posts Background', 'magnus' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'magnus' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'related_article_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Articles Padding', 'magnus' ),
		'sub_desc' => esc_html__( 'Set related posts articles padding from here.', 'magnus' ),
		'std'      => array(
			'left'   => '0',
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
		),
	),

	array(
		'id'       => 'related_article_text_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Articles Text Padding', 'magnus' ),
		'sub_desc' => esc_html__( 'Set related posts articles text padding from here.', 'magnus' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),

);
