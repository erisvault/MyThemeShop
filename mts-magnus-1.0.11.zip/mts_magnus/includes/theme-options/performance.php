<?php
/**
 * Performance Tab
 *
 * @package Magnus
 */

$menus['performance'] = array(
	'icon'  => 'fa-bolt',
	'title' => esc_html__( 'Performance', 'magnus' ),
	'desc'  => esc_html__( 'This tab contains optimization options which can help make your site run faster.', 'magnus' ),
);

$sections['performance'] = array(

	array(
		'id'       => 'async_js',
		'type'     => 'switch',
		'title'    => esc_html__( 'Async JavaScript', 'magnus' ),
		// translators: Using code tag in description.
		'sub_desc' => sprintf( esc_html__( 'Add %s attribute to script tags to improve page download speed.', 'magnus' ), '<code>async</code>' ),
		'std'      => '1',
	),

	array(
		'id'       => 'remove_ver_params',
		'type'     => 'switch',
		'title'    => esc_html__( 'Remove ver parameters', 'magnus' ),
		// translators: Using code tag in description.
		'sub_desc' => sprintf( esc_html__( 'Remove %s parameter from CSS and JS file calls. It may improve speed in some browsers which do not cache files having the parameter.', 'magnus' ), '<code>ver</code>' ),
		'std'      => '1',
	),

	array(
		'id'       => 'disable_emojis',
		'type'     => 'switch',
		'title'    => esc_html__( 'Disable Emojis', 'magnus' ),
		'sub_desc' => esc_html__( 'Disables the new WordPress emoji functionality.', 'magnus' ),
		'std'      => '0',
	),

	array(
		'id'       => 'prefetching',
		'type'     => 'switch',
		'title'    => esc_html__( 'Prefetching', 'magnus' ),
		'sub_desc' => esc_html__( 'Enable or disable prefetching. If user is on homepage, then single page will load faster and if user is on single page, homepage will load faster in modern browsers.', 'magnus' ),
		'std'      => '0',
	),
);

if ( magnus_is_woocommerce_active() ) {
	$sections['performance'][] = array(
		'id'       => 'optimize_wc',
		'type'     => 'switch',
		'title'    => esc_html__( 'Optimize WooCommerce scripts', 'magnus' ),
		'sub_desc' => esc_html__( 'Load WooCommerce scripts and styles only on WooCommerce pages.', 'magnus' ),
		'std'      => '1',
	);
}
