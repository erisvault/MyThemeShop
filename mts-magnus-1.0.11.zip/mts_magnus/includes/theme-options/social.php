<?php
/**
 * Social Tab
 *
 * @package Magnus
 */

$menus['social'] = array(
	'icon'  => 'fa-users',
	'title' => esc_html__( 'Social Share', 'magnus' ),
	'desc'  => esc_html__( 'Enable or disable social sharing buttons on single posts using these buttons.', 'magnus' ),
);

$menus['social']['child']['social-general'] = array(
	'title' => esc_html__( 'General', 'magnus' ),
	'desc'  => esc_html__( 'From here, you can control the elements of social sharing buttons.', 'magnus' ),
);

$sections['social-general'] = array(

	array(
		'id'       => 'social_button_layout',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Social Sharing Buttons Layout', 'magnus' ),
		'sub_desc' => wp_kses( __( 'Choose default <strong>social sharing buttons</strong> layout or modern <strong>social sharing buttons</strong> layout for your site. ', 'magnus' ), array( 'strong' => array() ) ),
		'options'  => array(
			'default'       => array( 'img' => $uri . 'social/default.jpg' ),
			'rectwithname'  => array( 'img' => $uri . 'social/modern.jpg' ),
			'circwithname'  => array( 'img' => $uri . 'social/circwithname.jpg' ),
			'rectwithcount' => array( 'img' => $uri . 'social/rectwithcount.jpg' ),
			'standard'      => array( 'img' => $uri . 'social/standard.jpg' ),
			'circular'      => array( 'img' => $uri . 'social/circular.jpg' ),
		),
		'std'      => 'standard',
	),

	array(
		'id'       => 'mts_social_button_position',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Social Sharing Buttons Position', 'magnus' ),
		'options'  => array(
			'top'      => esc_html__( 'Above Content', 'magnus' ),
			'bottom'   => esc_html__( 'Below Content', 'magnus' ),
			'floating' => esc_html__( 'Floating', 'magnus' ),
		),
		'sub_desc' => esc_html__( 'Choose position for Social Sharing Buttons.', 'magnus' ),
		'std'      => 'top',
		'class'    => 'green',
	),

	array(
		'id'       => 'mts_social_buttons_on_pages',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Social Sharing Buttons on Pages', 'magnus' ),
		'options'  => array(
			'0' => esc_html__( 'Off', 'magnus' ),
			'1' => esc_html__( 'On', 'magnus' ),
		),
		'sub_desc' => esc_html__( 'Enable the sharing buttons for pages too, not just posts.', 'magnus' ),
		'std'      => '0',
	),

	array(
		'id'       => 'mts_social_buttons',
		'type'     => 'layout',
		'title'    => esc_html__( 'Social Media Buttons', 'magnus' ),
		'sub_desc' => esc_html__( 'Organize how you want the social sharing buttons to appear on single posts', 'magnus' ),
		'options'  => array(
			'enabled'  => array(
				'facebookshare' => esc_html__( 'Facebook Share', 'magnus' ),
				'twitter'       => esc_html__( 'Twitter', 'magnus' ),
				'pinterest'     => esc_html__( 'Pinterest', 'magnus' ),
				'gplus'         => esc_html__( 'Google Plus', 'magnus' ),
			),
			'disabled' => array(
				'facebook' => esc_html__( 'Facebook Like', 'magnus' ),
				'linkedin' => esc_html__( 'LinkedIn', 'magnus' ),
				'stumble'  => esc_html__( 'StumbleUpon', 'magnus' ),
				'reddit'   => esc_html__( 'Reddit', 'magnus' ),
			),
		),
		'std'      => array(
			'enabled'  => array(
				'facebookshare' => esc_html__( 'Facebook Share', 'magnus' ),
				'twitter'       => esc_html__( 'Twitter', 'magnus' ),
				'pinterest'     => esc_html__( 'Pinterest', 'magnus' ),
				'gplus'         => esc_html__( 'Google Plus', 'magnus' ),
			),
			'disabled' => array(
				'facebook' => esc_html__( 'Facebook Like', 'magnus' ),
				'linkedin' => esc_html__( 'LinkedIn', 'magnus' ),
				'stumble'  => esc_html__( 'StumbleUpon', 'magnus' ),
				'reddit'   => esc_html__( 'Reddit', 'magnus' ),
			),
		),
	),

);
