<?php
/**
 * Single Subscribe
 *
 * @package Magnus
 */

$menus['single-subscribe'] = array(
	'title' => esc_html__( 'Subscribe Box', 'magnus' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of Subscribe box in single posts page.', 'magnus' ),
);

$sections['single-subscribe'] = array(

	array(
		'id'       => 'single_subscribe_box',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Subscribe box', 'magnus' ),
		'sub_desc' => esc_html__( 'Enable/Disable Subscribe box in the single post.', 'magnus' ),
		'std'      => '0',
	),
	array(
		'id'         => 'single_subscribe_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Subscribe box Settings', 'magnus' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Subscribe box Background', 'magnus' ),
		'sub_desc'   => esc_html__( 'Set background color, pattern and image for subscribe box from here.', 'magnus' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'magnus' ),
		'sub_desc'   => esc_html__( 'Set Subscribe box margin from here.', 'magnus' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'magnus' ),
		'sub_desc'   => esc_html__( 'Set Subscribe box padding from here.', 'magnus' ),
		'std'        => array(
			'top'    => '59px',
			'right'  => '0',
			'bottom' => '24px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_border_radius',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Border Radius', 'magnus' ),
		'sub_desc'   => esc_html__( 'Subscribe box border radius.', 'magnus' ),
		'std'        => '0',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'magnus' ),
		'sub_desc'   => esc_html__( 'Select border', 'magnus' ),
		'std'        => array(
			'direction' => 'top',
			'size'      => '1',
			'style'     => 'solid',
			'color'     => '#c7c9cd',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'single_subscribe_title_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Subscribe box Title Settings', 'magnus' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_title_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Subscribe Title Font', 'magnus' ),
		'std'        => array(
			'preview-text'  => 'Subscribe Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '500',
			'font-size'     => '28px',
			'color'         => magnus_get_settings( 'mts_color_scheme' ),
			'css-selectors' => '.single-subscribe .widget #wp-subscribe .title',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_text_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Subscribe box Text Settings', 'magnus' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_text_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Subscribe Text Font', 'magnus' ),
		'std'        => array(
			'preview-text'  => 'Subscribe Text Font',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '300',
			'font-size'     => '20px',
			'color'         => '#1c2534',
			'css-selectors' => '.single-subscribe .widget #wp-subscribe p.text, .single-subscribe .widget .wp-subscribe .wps-consent-wrapper label, .single-subscribe .widget .wp-subscribe-wrap .error, .single-subscribe .widget .wp-subscribe-wrap .thanks',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_input_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Subscribe box Input Settings', 'magnus' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_input_background',
		'type'       => 'color',
		'title'      => esc_html__( 'Background Color', 'magnus' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'magnus' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_input_height',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Height', 'magnus' ),
		'sub_desc'   => esc_html__( 'Subscribe box input fields height.', 'magnus' ),
		'std'        => '64',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_input_border_radius',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Border Radius', 'magnus' ),
		'sub_desc'   => esc_html__( 'Subscribe box input fields border radius.', 'magnus' ),
		'std'        => '0',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_input_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'magnus' ),
		'sub_desc'   => esc_html__( 'Select border', 'magnus' ),
		'std'        => array(
			'direction' => 'all',
			'size'      => '1',
			'style'     => 'solid',
			'color'     => '#dddfe1',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_input_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Subscribe Input Fields Font', 'magnus' ),
		'std'        => array(
			'preview-text'  => 'Subscribe Input Fields',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '400',
			'font-size'     => '20px',
			'color'         => '#a7a9ad',
			'css-selectors' => '.single-subscribe .widget #wp-subscribe input.email-field, .single-subscribe .widget #wp-subscribe input.name-field',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_submit_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Subscribe box Submit Settings', 'magnus' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_submit_backgroud',
		'type'       => 'color',
		'title'      => esc_html__( 'Background Color', 'magnus' ),
		'sub_desc'   => esc_html__( 'Submit button background color', 'magnus' ),
		'std'        => magnus_get_settings( 'mts_color_scheme' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_submit_border_radius',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Border Radius', 'magnus' ),
		'sub_desc'   => esc_html__( 'Subscribe box submit button border radius.', 'magnus' ),
		'std'        => '0',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_submit_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'magnus' ),
		'sub_desc'   => esc_html__( 'Select border', 'magnus' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_submit_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'magnus' ),
		'sub_desc'   => esc_html__( 'Set subscribe submit button padding from here.', 'magnus' ),
		'std'        => array(
			'top'    => '10px',
			'right'  => '0',
			'bottom' => '10px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_submit_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Subscribe Submit Button Font', 'magnus' ),
		'std'        => array(
			'preview-text'  => 'Subscribe Submit Button',
			'preview-color' => 'dark',
			'font-family'   => 'Rubik',
			'font-weight'   => '500',
			'font-size'     => '18px',
			'color'         => '#ffffff',
			'css-selectors' => '.single-subscribe .widget #wp-subscribe input.submit',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_small_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Subscribe box small text Settings', 'magnus' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_small_text_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Subscribe Small Text Font', 'magnus' ),
		'std'        => array(
			'preview-text'  => 'Subscribe Small Text',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '400',
			'font-size'     => '13px',
			'line-height'   => '20px',
			'color'         => '#bec2c7',
			'css-selectors' => '.single-subscribe .widget .wp-subscribe-wrap p.footer-text',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
);
