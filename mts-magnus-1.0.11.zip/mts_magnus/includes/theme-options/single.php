<?php
/**
 * Single Tab
 *
 * @package Magnus
 */

$menus['single-general'] = array(
	'title' => esc_html__( 'General', 'magnus' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of your single posts page.', 'magnus' ),
);

$sections['single-general'] = array(

	array(
		'id'       => 'mts_show_featured',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Featured image', 'magnus' ),
		'sub_desc' => esc_html__( 'Enable/Disable the Featured images in the single post.', 'magnus' ),
		'std'      => '1',
	),
	array(
		'id'       => 'featured_image_size',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Header Size', 'magnus' ),
		'sub_desc' => esc_html__( 'Choose the featured image size', 'magnus' ),
		'options'  => array(
			'default' => esc_html__( 'Content Size', 'magnus' ),
			'full'    => esc_html__( 'Full Width', 'magnus' ),
		),
		'std'      => 'full',
	),
	array(
		'id'         => 'featured_image_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Header Image Margin', 'magnus' ),
		'sub_desc'   => esc_html__( 'Set header image margin from here.', 'magnus' ),
		'std'        => array(
			'top'    => '-35px',
			'right'  => '0',
			'bottom' => '83px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'featured_text_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Alignment', 'magnus' ),
		'sub_desc'   => esc_html__( 'Choose the featured image text alignment', 'magnus' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'magnus' ),
			'center' => esc_html__( 'Center', 'magnus' ),
			'right'  => esc_html__( 'Right', 'magnus' ),
		),
		'std'        => 'left',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'author_image_on_full',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Author Image', 'magnus' ),
		'sub_desc'   => esc_html__( 'Enable or disable author image with this option', 'magnus' ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'show_prev_next',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show preview and next article buttons', 'magnus' ),
		'sub_desc'   => esc_html__( 'Use this button to show or hide preview and next article buttons.', 'magnus' ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_single_post_layout',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Post Layout', 'magnus' ),
		'sub_desc' => esc_html__( 'Customize the look of single posts', 'magnus' ),
		'options'  => array(
			'enabled'  => array(
				'content'   => array(
					'label'     => esc_html__( 'Post Content', 'magnus' ),
					'subfields' => array(),
				),
				'author'    => array(
					'label'     => esc_html__( 'Author Box', 'magnus' ),
					'subfields' => array(),
				),
				'related'   => array(
					'label'     => esc_html__( 'Related Posts', 'magnus' ),
					'subfields' => array(
						array(
							'id'       => 'related_post_title',
							'type'     => 'text',
							'title'    => esc_html__( 'Related Posts Title', 'magnus' ),
							'sub_desc' => esc_html__( 'Enter the title text to show in the related posts section.', 'magnus' ),
							'std'      => 'Related Posts',

						),
						array(
							'id'       => 'mts_related_posts_taxonomy',
							'type'     => 'switch',
							'title'    => esc_html__( 'Related Posts Taxonomy', 'magnus' ),
							'options'  => array(
								'tags'       => esc_html__( 'Tags', 'magnus' ),
								'categories' => esc_html__( 'Categories', 'magnus' ),
							),
							'class'    => 'green',
							'sub_desc' => esc_html__( 'Related Posts based on tags or categories.', 'magnus' ),
							'std'      => 'categories',
						),
					),
				),
			),
			'disabled' => array(
				'subscribe' => array(
					'label'     => esc_html__( 'Subscribe Box', 'magnus' ),
					'subfields' => array(),
				),
				'tags'      => array(
					'label'     => esc_html__( 'Tags', 'magnus' ),
					'subfields' => array(),
				),
			),
		),
	),

	array(
		'id'       => 'single_meta_info_background',
		'type'     => 'color',
		'title'    => esc_html__( 'Single Meta Info Background Color', 'magnus' ),
		'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'magnus' ),
		'std'      => '#ffffff',
	),

	array(
		'id'       => 'mts_single_headline_meta_info',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Meta Info', 'magnus' ),
		'sub_desc' => esc_html__( 'Organize how you want the post meta info to appear on single page', 'magnus' ),
		'options'  => array(
			'enabled'  => array(
				'author' => array(
					'label'     => esc_html__( 'Author Name', 'magnus' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_author_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'magnus' ),
						),
					),
				),
				'date'   => array(
					'label'     => esc_html__( 'Date', 'magnus' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_date_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'magnus' ),
						),
					),
				),
			),
			'disabled' => array(
				'category' => array(
					'label'     => esc_html__( 'Categories', 'magnus' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_category_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'magnus' ),
						),
					),
				),
				'comment'  => array(
					'label'     => esc_html__( 'Comment Count', 'magnus' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_comment_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'magnus' ),
						),
					),
				),
			),
		),
	),

	array(
		'id'       => 'mts_breadcrumb',
		'type'     => 'switch',
		'title'    => esc_html__( 'Breadcrumbs', 'magnus' ),
		'sub_desc' => esc_html__( 'Breadcrumbs are a great way to make your site more user-friendly. You can enable them by checking this box.', 'magnus' ),
		'std'      => '0',
	),

	array(
		'id'         => 'breadcrumb_icon',
		'type'       => 'icon_select',
		'title'      => esc_html__( 'Icon', 'magnus' ),
		'sub_desc'   => esc_html__( 'Select divider icons from here.', 'magnus' ),
		'std'        => 'angle-right',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'breadcrumb_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Breadcrumbs Font', 'magnus' ),
		'std'        => array(
			'preview-text'  => 'Breadcrumbs',
			'preview-color' => 'light',
			'font-family'   => 'Rubik',
			'font-weight'   => '500',
			'font-size'     => '18px',
			'color'         => '#1c2534',
			'css-selectors' => '.breadcrumb, .rank-math-breadcrumb',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_author_comment',
		'type'     => 'switch',
		'title'    => esc_html__( 'Highlight Author Comment', 'magnus' ),
		'sub_desc' => esc_html__( 'Use this button to highlight author comments.', 'magnus' ),
		'std'      => '1',
	),

	array(
		'id'       => 'mts_comment_date',
		'type'     => 'switch',
		'title'    => esc_html__( 'Date in Comments', 'magnus' ),
		'sub_desc' => esc_html__( 'Use this button to show the date for comments.', 'magnus' ),
		'std'      => '1',
	),
);
