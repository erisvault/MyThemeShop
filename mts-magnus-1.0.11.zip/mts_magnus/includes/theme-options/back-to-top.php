<?php
/**
 * Back to top
 *
 * @package Magnus
 */

$menus['footer']['child']['footer-back-to-top'] = array(
	'title' => esc_html__( 'Back to Top', 'magnus' ),
	'desc'  => esc_html__( 'From here, you can control the back to top button.', 'magnus' ),
);

$sections['footer-back-to-top'] = array(

	array(
		'id'       => 'show_top_button',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Top Button', 'magnus' ),
		'sub_desc' => esc_html__( 'Enable or disable back to top button with this option.', 'magnus' ),
		'std'      => '1',
	),

	array(
		'id'         => 'top_button_icon',
		'type'       => 'icon_select',
		'title'      => esc_html__( 'Top Button Icon', 'magnus' ),
		'sub_desc'   => esc_html__( 'Set icon for top button icon with this option.', 'magnus' ),
		'std'        => 'angle-up',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_text',
		'type'       => 'text',
		'title'      => esc_html__( 'Top Button Text', 'magnus' ),
		'sub_desc'   => esc_html__( 'Set Top button text from here.', 'magnus' ),
		'std'        => 'Top',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Top Button Icon Color', 'magnus' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'magnus' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'top_button_color_hover',
		'type'       => 'color',
		'title'      => esc_html__( 'Top Button Icon Hover Color', 'magnus' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'magnus' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_background',
		'type'       => 'color',
		'title'      => esc_html__( 'Top Button Background', 'magnus' ),
		'sub_desc'   => esc_html__( 'Set top button background color, pattern and image from here.', 'magnus' ),
		'std'        => magnus_get_settings( 'mts_color_scheme' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'top_button_background_hover',
		'type'       => 'color',
		'title'      => esc_html__( 'Top Button Hover Background', 'magnus' ),
		'sub_desc'   => esc_html__( 'Set top button background color, pattern and image from here.', 'magnus' ),
		'std'        => '#1c2534',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_font_size',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Font Size', 'magnus' ),
		'sub_desc'   => esc_html__( 'Set font size of top button in px.', 'magnus' ),
		'std'        => '32',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'magnus' ),
		'sub_desc'   => esc_html__( 'Set Top button padding from here.', 'magnus' ),
		'std'        => array(
			'top'    => '9px',
			'right'  => '21px',
			'bottom' => '16px',
			'left'   => '21px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'top_button_position',
		'type'       => 'margin',
		'title'      => esc_html__( 'Top Button Position', 'magnus' ),
		'sub_desc'   => esc_html__( 'Set top button position from here.', 'magnus' ),
		'std'        => array(
			'top'    => 'auto',
			'right'  => '30px',
			'bottom' => '100px',
			'left'   => 'auto',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_border_radius',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Border Radius', 'magnus' ),
		'sub_desc'   => esc_html__( 'Set border radius of top button in px.', 'magnus' ),
		'std'        => '0',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'magnus' ),
		'sub_desc'   => esc_html__( 'Select border', 'magnus' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

);
