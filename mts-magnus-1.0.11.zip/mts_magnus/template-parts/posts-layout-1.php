<?php
/**
 * Posts Layout - layout 1
 *
 * @package Magnus
 */
$featured = magnus()->featured_layouts;
?>
<div class="clearfix">

	<div class="<?php magnus_article_class(); ?> <?php $featured->get_post_container_class(); ?>">

		<div id="content_box">

			<?php magnus_action( 'start_content_box' ); ?>

			<?php $featured->get_section_title(); ?>

			<section id="latest-posts" class="<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">
				<?php
				$j = 0;
				while ( have_posts() ) :
					the_post();

					$featured_image = array();
					if ( has_post_thumbnail() ) :
						$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
					endif;
				?>
				<article class="latestPost excerpt" style="background: url('<?php echo isset( $featured_image[0] ) ? $featured_image[0] : ''; ?>') center center no-repeat; background-size: cover;">

						<div class="wrapper <?php echo ( 1 === ++$j ) ? 'first' : 'last'; ?>">

							<?php $featured->get_post_title( true ); ?>

						</div>

					</article>
					<?php
					endwhile;

					$featured->get_post_pagination();
					?>

			</section><!--#latest-posts-->

		</div>

	</div>

</div><!--.clearfix-->
