<?php
/**
 * Posts Layout - layout 3
 *
 * @package Magnus
 */
$featured = magnus()->featured_layouts;
?>
<div class="<?php magnus_article_class(); ?> <?php $featured->get_post_container_class(); ?>">

	<div class="container clearfix">

		<?php $featured->get_section_title(); ?>

	</div>

	<div id="content_box">

		<?php magnus_action( 'start_content_box' ); ?>

		<div class="container clearfix">

			<section id="latest-posts" class="<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">
				<?php
				$j = 0;
				while ( have_posts() ) :
					the_post();
				?>
				<article class="latestPost excerpt <?php echo ( 0 === ++$j % 4 ) ? 'last' : ''; ?>">

					<?php $featured->get_post_thumbnail(); ?>

					<div class="wrapper">

						<?php $featured->get_post_title(); ?>

						<?php $featured->get_post_content( true ); ?>

					</div>

				</article>
				<?php
				endwhile;

				$featured->get_post_pagination();
				?>
			</section><!--#latest-posts-->

		</div>

	</div>

</div>
