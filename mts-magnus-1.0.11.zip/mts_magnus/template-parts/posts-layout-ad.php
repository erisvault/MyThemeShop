<?php
/**
 * Posts Layout - layout ad
 *
 * @package Magnus
 */
$featured = magnus()->featured_layouts;
?>
<div class="<?php magnus_article_class(); ?> <?php $featured->get_post_container_class(); ?>">
	<section class="<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">
		<?php if ( ! empty( magnus_get_settings( 'adcode_' . $featured->current['unique_id'] ) ) ) { ?>
			<div class="container">
				<div class="widget-ad"><?php echo magnus_get_settings( 'adcode_' . $featured->current['unique_id'] ); ?></div>
			</div>
		<?php } ?>
	</section><!--#latest-posts-->
</div>
