<?php if ( magnus_get_settings( 'navigation_ad' ) && magnus_get_settings( 'navigation_adcode' ) ) { ?>
	<div class="navigation-banner">
		<div class="container">
			<div style="<?php ad_size_value( magnus_get_settings( 'navigation_ad_size' ) ); ?>">
				<?php echo magnus_get_settings( 'navigation_adcode' ); ?>
			</div>
		</div>
	</div>
<?php } ?>
