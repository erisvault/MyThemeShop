<?php
/**
 * Clickable Background
 *
 */

if ( magnus_get_settings( 'background_clickable' ) && magnus_get_settings( 'background_link' ) ) {
	$target = ( 1 === magnus_get_settings( 'background_link_new_tab' ) ) ? 'target="_blank"' : '';
	printf( '<a href="%1$s" rel="nofollow" class="clickable-background" %2$s>', magnus_get_settings( 'background_link' ), $target );
}
