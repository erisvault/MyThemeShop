<?php
/**
 * Before footer detect ad blocker notice.
 *
 */

if ( magnus_get_settings( 'detect_adblocker' ) && ( 'popup' === magnus_get_settings( 'detect_adblocker_type' ) || 'floating' === magnus_get_settings( 'detect_adblocker_type' ) ) ) { ?>
	<?php if ( 'popup' === magnus_get_settings( 'detect_adblocker_type' ) ) { ?>
		<div class="blocker-overlay"></div>
	<?php } ?>
	<?php echo detect_adblocker_notice(); ?>
<?php } ?>
