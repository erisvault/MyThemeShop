<?php
/**
 * The template for displaying all single posts.
 *
 * @package Magnus
 */

get_header(); ?>

	<div id="wrapper" class="<?php magnus_single_page_class(); ?>">

		<?php magnus_action( 'single_top' ); ?>

		<div class="container clearfix">

			<?php
			magnus_single_featured_image_effect();

			magnus_action( 'before_content' );

			magnus_single_sections();

			magnus_action( 'after_content' );

			get_sidebar();
			?>

		</div>

		<?php
		if ( 'full' === magnus_get_settings( 'related_posts_position' ) ) {
			magnus_related_posts();
		}
		?>

<?php
get_footer();
