<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="page">
 *
 * @package Magnus
 */

?><!doctype html>
<html<?php magnus_attr( 'html' ); ?>>
<head<?php magnus_attr( 'head' ); ?>>
	<?php wp_head(); ?>
</head>

<body<?php magnus_attr( 'body' ); ?>>

	<?php get_template_part( 'template-parts/header/clickable', 'background' ); ?>

	<div<?php magnus_attr( 'main' ); ?>>

		<?php magnus_action( 'before_wrapper' ); ?>
