<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<?php mts_related_posts(); ?>