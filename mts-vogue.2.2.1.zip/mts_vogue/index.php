<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<?php get_header(); ?>
<?php if (is_home() && !is_paged()) { ?>
    <?php if($mts_options['mts_featured_slider'] == '1') { ?>
    <div class="primary-slider-container clearfix loading">
        <div id="slider" class="primary-slider">
            <?php if (empty($mts_options['mts_custom_slider'])) { ?>
            <?php
                                // prevent implode error
            if (empty($mts_options['mts_featured_slider_cat']) || !is_array($mts_options['mts_featured_slider_cat'])) {
                $mts_options['mts_featured_slider_cat'] = array('0');
            }

            $slider_cat = implode(",", $mts_options['mts_featured_slider_cat']);
            $my_query = new WP_Query('cat='.$slider_cat.'&posts_per_page='.$mts_options['mts_featured_slider_num']);
            while ($my_query->have_posts()) : $my_query->the_post();
            ?>
            <div> 
                <a href="<?php the_permalink() ?>">
                    <?php the_post_thumbnail('slider',array('title' => '')); ?>
                    <div class="slide-caption">
                        <h2 class="slide-title"><?php the_title(); ?></h2>
                        <p><?php echo mts_excerpt(20); ?></p>
                    </div>
                </a> 
            </div>
        <?php endwhile; wp_reset_query(); ?>
        <?php } else { ?>
        <?php foreach($mts_options['mts_custom_slider'] as $slide) : ?>
            <div>
                <a href="<?php echo $slide['mts_custom_slider_link']; ?>">
                    <?php echo wp_get_attachment_image($slide['mts_custom_slider_image'], 'slider', false, array('title' => '')); ?>
                    <div class="slide-caption">
                        <h2 class="slide-title"><?php echo $slide['mts_custom_slider_title']; ?></h2>
                        <p class="slide-text"><?php echo $slide['mts_custom_slider_text']; ?></p>
                    </div>
                </a>
            </div>
        <?php endforeach; ?>
        <?php } ?>
    </div>
    </div>
    <!-- slider-container -->
    <?php } ?>
<?php } ?>
<div id="page" class="clearfix">
    <div class="article">
        <div id="content_box">
            
            <?php
            if ( !is_paged() ) {

                $featured_categories = array();
                if (!empty($mts_options['mts_featured_categories'])) {
                    foreach ($mts_options['mts_featured_categories'] as $section) {
                        $category_id = $section['mts_featured_category'];
                        $featured_categories[] = $category_id;
                        $posts_num = $section['mts_featured_category_postsnum'];
                        if ($category_id == 'latest') { ?>
                        
                            <h3 class="featured-category-title"><?php _e('Latest Posts','mythemeshop'); ?></h3>
                            <?php $post_count = 1; $j = 0; if (have_posts()) : while (have_posts()) : the_post(); 
                                //if(!get_query_var('paged')){
                                    if($post_count == 1){
                                        $post_count_class = 'first-post';
                                    }elseif($post_count == 2){
                                        $post_count_class = 'second-post';
                                    }else{
                                        $post_count_class = 'normal-post';
                                    }
                                //}
                            ?>
                                <article class="latestPost excerpt <?php echo $post_count_class; echo (++$j % 2 == 0) ? ' last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
                                    <?php get_template_part( 'templates/archive-post-content' ); ?>
                                </article>

                                <?php if ($post_count == 2 && is_home()) : ?>
                                    <?php if($mts_options['mts_featured_gallery'] == '1') { ?>
                                        <div class="featured-gallery">
                                            <div class="leftCol">
                                                <h3 class="front-title-featured"><?php $second_cat = $section['mts_featured_gallery_cat']; echo get_cat_name( $second_cat ); ?></h3>
                                                <p><?php echo category_description( $second_cat ); ?></p>
                                            </div>
                                            <div class="rightCol">
                                                <ul>
                                                    <?php $my_query = new WP_Query('cat='.$section['mts_featured_gallery_cat'].'&posts_per_page=3'); if (have_posts()) : while ($my_query->have_posts()) : $my_query->the_post();  ?>
                                                        <li>
                                                            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php 
                                                                if(has_post_thumbnail()){
                                                            the_post_thumbnail('featured-small',array('title' => '')); 
                                                        }else{
                                                            echo '<img src="'. get_template_directory_uri() .'/images/nothumb.png" alt="">';
                                                        }
                                                        ?></a>
                                                        </li>
                                                    <?php endwhile; endif; ?>
                                                </ul>
                                            </div>
                                        </div><!-- .featured-gallery -->
                                    <?php } ?>
                                <?php endif; 

                                $post_count++;
                             endwhile; endif; ?>
                            
                            <?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
                                <?php get_template_part( 'templates/archive-pagination' ); ?>
                            <?php } ?>
                            
                        <?php } else { // if $category_id != 'latest': ?>
                            <h3 class="featured-category-title"><a href="<?php echo esc_url( get_category_link($category_id) ); ?>" title="<?php echo esc_attr( get_cat_name($category_id) ); ?>"><?php echo get_cat_name($category_id); ?></a></h3>
                            <?php
                            $post_count = 1;
                            $j = 0;
                            
                            $cat_query = new WP_Query('cat='.$category_id.'&posts_per_page='.$posts_num);
                            if ($cat_query->have_posts()) : while ($cat_query->have_posts()) : $cat_query->the_post(); 

                            if($post_count == 1){
                                $post_count_class = 'first-post';
                            }elseif($post_count == 2){
                                $post_count_class = 'second-post';
                            }else{
                                $post_count_class = 'normal-post';
                            }
                            ?>
                                <article class="latestPost excerpt <?php echo $post_count_class; echo (++$j % 2 == 0) ? ' last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
                                    <?php get_template_part( 'templates/archive-post-content' ); ?>
                                </article>
                                <?php if ($post_count == 2 && is_home()) : ?>
                                    <?php if($mts_options['mts_featured_gallery'] == '1') { ?>
                                        <div class="featured-gallery">
                                            <div class="leftCol">
                                                <h3 class="front-title-featured"><?php $second_cat = $section['mts_featured_gallery_cat']; echo get_cat_name( $second_cat ); ?></h3>
                                                <p><?php echo category_description( $second_cat ); ?></p>
                                            </div>
                                            <div class="rightCol">
                                                <ul>
                                                    <?php $my_query = new WP_Query('cat='.$section['mts_featured_gallery_cat'].'&posts_per_page=3'); if (have_posts()) : while ($my_query->have_posts()) : $my_query->the_post();  ?>
                                                        <li>
                                                            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php 
                                                                if(has_post_thumbnail()){
                                                            the_post_thumbnail('featured-small',array('title' => '')); 
                                                        }else{
                                                            echo '<img src="'. get_template_directory_uri() .'/images/nothumb.png" alt="">';
                                                        }
                                                        ?></a>
                                                        </li>
                                                    <?php endwhile; endif; ?>
                                                </ul>
                                            </div>
                                        </div><!-- .featured-gallery -->
                                    <?php } 
                                    endif; ?>
                            <?php
                                $post_count++;
                            endwhile; endif; wp_reset_query();
                        }
                    }
                }

            } else { //Paged ?>

                <?php $post_count = 1; $j = 0; if (have_posts()) : while (have_posts()) : the_post(); 
                    if($post_count == 1){
                        $post_count_class = 'first-post';
                    }elseif($post_count == 2){
                        $post_count_class = 'second-post';
                    }else{
                        $post_count_class = 'normal-post';
                    }
                ?>
                <article class="latestPost excerpt <?php echo $post_count_class; echo (++$j % 2 == 0) ? ' last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
                    <?php get_template_part( 'templates/archive-post-content' ); ?>
                </article>
                <?php $post_count++; endwhile; endif; ?>
            
                <?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
                    <?php get_template_part( 'templates/archive-pagination' ); ?>
                <?php } ?>

            <?php
            }
            ?>
        </div>
    </div>
    <?php get_sidebar(); ?>
<?php get_footer(); ?>