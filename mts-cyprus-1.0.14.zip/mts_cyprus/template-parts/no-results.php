<div class="no-results">
	<p>
		<?php esc_html_e( 'We apologize for any inconvenience, please hit back on your browser or use the search form.', 'cyprus' ); ?>
	</p>
</div><!--noResults-->
