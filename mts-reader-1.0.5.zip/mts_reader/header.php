<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="page">
 *
 * @package Reader
 */

?><!doctype html>
<html<?php reader_attr( 'html' ); ?>>
<head<?php reader_attr( 'head' ); ?>>
	<?php wp_head(); ?>
</head>

<body<?php reader_attr( 'body' ); ?>>

	<?php get_template_part( 'template-parts/header/clickable', 'background' ); ?>

	<div<?php reader_attr( 'main' ); ?>>

		<?php reader_action( 'before_wrapper' ); ?>
