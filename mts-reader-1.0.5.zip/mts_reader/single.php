<?php
/**
 * The template for displaying all single posts.
 *
 * @package Reader
 */

get_header(); ?>

	<div id="wrapper" class="<?php reader_single_page_class(); ?>">

		<div class="container clearfix">

			<?php
			reader_single_featured_image_effect();

			reader_action( 'before_content' );

			reader_single_sections();

			reader_action( 'after_content' );

			get_sidebar();
			?>

		</div>

		<?php
		if ( 'full' === reader_get_settings( 'related_posts_position' ) ) {
			reader_related_posts();
		}
		?>

<?php
get_footer();
