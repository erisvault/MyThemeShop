<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package Reader
 */

get_header(); ?>

	<div id="wrapper" class="<?php reader_single_page_class(); ?>">

		<?php reader_single_featured_image_effect(); ?>

		<div class="container clearfix">

			<?php
			if ( reader_get_settings( 'mts_breadcrumb' ) ) {
			?>

			<div class="breadcrumb-wrapper">
				<div class="left">
					<i class="fa fa-angle-right"></i>
					<a href="<?php esc_url( trailingslashit( home_url() ) ); ?>"><?php _e( 'Back to all posts', 'reader' ); ?></a>
				</div>

				<div class="right">
					<?php reader_breadcrumbs(); ?>
				</div>
			</div>

			<?php
			}
			?>

			<article class="<?php reader_article_class(); ?>">

				<?php reader_action( 'before_content' ); ?>

				<div id="content_box" >

				<?php
				// Elementor 'single' location.
				if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'single' ) ) {
					if ( have_posts() ) :
						while ( have_posts() ) :
							the_post();
							?>
						<div id="post-<?php the_ID(); ?>" <?php post_class( 'g post' ); ?>>

							<div class="single_page">

								<header>
									<h1 class="title entry-title"><?php the_title(); ?></h1>
								</header>

								<div class="post-content box mark-links entry-content">
									<?php
									if ( ! empty( reader_get_settings( 'mts_social_buttons_on_pages' ) ) && null !== reader_get_settings( 'mts_social_button_position' ) && 'top' === reader_get_settings( 'mts_social_button_position' ) ) {
										reader_social_buttons();
									}

									the_content();

									// Single Page Pagination.
									$args = array(
										'before'           => '<div class="pagination">',
										'after'            => '</div>',
										'link_before'      => '<span class="current"><span class="currenttext">',
										'link_after'       => '</span></span>',
										'next_or_number'   => 'next_and_number',
										'nextpagelink'     => __( 'Next', 'reader' ),
										'previouspagelink' => __( 'Previous', 'reader' ),
										'pagelink'         => '%',
										'echo'             => 1,
									);
									wp_link_pages( $args );

									if ( ( ! empty( reader_get_settings( 'mts_social_buttons_on_pages' ) ) && null !== reader_get_settings( 'mts_social_button_position' ) ) && 'top' !== reader_get_settings( 'mts_social_button_position' ) ) {
										reader_social_buttons();
									}
									?>

								</div><!--.post-content box mark-links-->

							</div>

						</div>
							<?php
							// Comment area.
							comments_template( '', true );

					endwhile;

				endif;
				}
				?>

				</div>

			</article>

		<?php get_sidebar(); ?>

	</div>

<?php
get_footer();
