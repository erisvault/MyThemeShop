<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Reader
 */

get_template_part( 'template-parts/footer/footer', 'ad' );

get_template_part( 'template-parts/footer/footer', 'subscribe' );

?>
	</div><!--#wrapper-->

	<footer<?php reader_attr( 'footer' ); ?>>

	<?php
		// Elementor 'footer' location.
	if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'footer' ) ) {
		?>

		<div class="container">
			<?php

			get_template_part( 'template-parts/footer/footer', 'logo' );

			get_template_part( 'template-parts/footer/footer', 'nav' );

			get_template_part( 'template-parts/footer/footer', 'brands' );

			if ( reader_get_settings( 'mts_top_footer' ) ) {
				reader_footer_widget_columns();
			}

			?>
		</div>

		<?php reader_footer_copyrights(); ?>

		<?php
	}
	?>

	</footer><!--#site-footer-->

</div><!--.main-container-->

<?php get_template_part( 'template-parts/footer/footer', 'detect-adblocker' ); ?>

<?php wp_footer(); ?>

</body>
</html>
