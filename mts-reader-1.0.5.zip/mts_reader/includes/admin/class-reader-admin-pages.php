<?php
/**
 * Theme administration pages.
 *
 * @package Reader
 */

defined( 'WPINC' ) || exit;

/**
 * Admin pages
 */
class Reader_Admin_Pages extends Reader_Base {

	/**
	 * The Constructor
	 */
	public function __construct() {

		$this->add_action( 'admin_init', 'admin_init' );
	}

	/**
	 * Init
	 */
	public function admin_init() {

		if ( ! current_user_can( 'edit_theme_options' ) ) {
			return;
		}

		// Activate Plugin.
		if (
			isset( $_GET['reader-activate'] ) &&
			'activate-plugin' === $_GET['reader-activate'] &&
			isset( $_GET['plugin'] )
		) {
			check_admin_referer( 'reader-activate', 'reader-activate-nonce' );

			$plugins = TGM_Plugin_Activation::$instance->plugins;

			foreach ( $plugins as $plugin ) {
				if ( $plugin['slug'] === $_GET['plugin'] ) {
					activate_plugin( $plugin['file_path'] );

					wp_redirect( admin_url( 'admin.php?page=install-required-plugins' ) );
					exit;
				}
			}
		}

		// Deactivate Plugin.
		if (
			isset( $_GET['reader-deactivate'] ) &&
			'deactivate-plugin' === $_GET['reader-deactivate'] &&
			isset( $_GET['plugin'] )
		) {

			check_admin_referer( 'reader-deactivate', 'reader-deactivate-nonce' );

			$plugins = TGM_Plugin_Activation::$instance->plugins;

			foreach ( $plugins as $plugin ) {
				if ( $plugin['slug'] == $_GET['plugin'] ) {
					deactivate_plugins( $plugin['file_path'] );
				}
			}
		}
	}

	/**
	 * Get the plugin link.
	 *
	 * @param  array $item         The plugin in question.
	 * @param  array $registration Is registration done.
	 * @return array
	 */
	public function plugin_link( $item, $registration ) {
		$actions                  = array();
		$installed_plugins        = get_plugins();
		$item['sanitized_plugin'] = $item['name'];

		// We have a repo plugin.
		if ( ! $item['version'] ) {
			$item['version'] = TGM_Plugin_Activation::$instance->does_plugin_have_update( $item['slug'] );
		}

		$disable_class = '';
		$data_version  = '';
		if ( ( 'LayerSlider' == $item['slug'] || 'revslider' == $item['slug'] ) && empty( $registration ) ) {
			$disable_class = ' disabled reader-no-token';
		}

		// We need to display the 'Install' hover link.
		if ( ! isset( $installed_plugins[ $item['file_path'] ] ) ) {
			if ( ! $disable_class ) {
				$url = esc_url( wp_nonce_url(
					add_query_arg(
						array(
							'page'          => urlencode( TGM_Plugin_Activation::$instance->menu ),
							'plugin'        => urlencode( $item['slug'] ),
							'plugin_name'   => urlencode( $item['sanitized_plugin'] ),
							'tgmpa-install' => 'install-plugin',
							'return_url'    => 'reader-plugins',
						),
						TGM_Plugin_Activation::$instance->get_tgmpa_url()
					),
					'tgmpa-install',
					'tgmpa-nonce'
				) );
			} else {
				$url = '#';
			}
			$actions = array(
				/* translators: plugin name */
				'install' => '<a href="' . $url . '" class="button button-primary' . $disable_class . '"' . $data_version . ' title="' . sprintf( esc_attr__( 'Install %s', 'reader' ), $item['sanitized_plugin'] ) . '">' . esc_attr__( 'Install', 'reader' ) . '</a>',
			);
		} elseif ( is_plugin_inactive( $item['file_path'] ) ) {
			// We need to display the 'Activate' hover link.
			if ( ! $disable_class ) {
				$url = esc_url( add_query_arg(
					array(
						'plugin'                => urlencode( $item['slug'] ),
						'plugin_name'           => urlencode( $item['sanitized_plugin'] ),
						'reader-activate'       => 'activate-plugin',
						'reader-activate-nonce' => wp_create_nonce( 'reader-activate' ),
					),
					admin_url( 'admin.php?page=reader-plugins' )
				) );
			} else {
				$url = '#';
			}

			$actions = array(
				/* translators: plugin name */
				'activate' => '<a href="' . $url . '" class="button button-primary' . $disable_class . '"' . $data_version . ' title="' . sprintf( esc_attr__( 'Activate %s', 'reader' ), $item['sanitized_plugin'] ) . '">' . esc_attr__( 'Activate', 'reader' ) . '</a>',
			);
		} elseif ( version_compare( $installed_plugins[ $item['file_path'] ]['Version'], $item['version'], '<' ) ) {
			$disable_class = '';
			// We need to display the 'Update' hover link.
			$url = wp_nonce_url(
				add_query_arg(
					array(
						'page'         => urlencode( TGM_Plugin_Activation::$instance->menu ),
						'plugin'       => urlencode( $item['slug'] ),
						'tgmpa-update' => 'update-plugin',
						'version'      => urlencode( $item['version'] ),
						'return_url'   => 'reader-plugins',
					),
					TGM_Plugin_Activation::$instance->get_tgmpa_url()
				),
				'tgmpa-update',
				'tgmpa-nonce'
			);
			if ( ( 'LayerSlider' == $item['slug'] || 'revslider' == $item['slug'] ) && empty( $registration ) ) {
				$disable_class = ' disabled reader-no-token';
			}
			$actions = array(
				/* translators: plugin name */
				'update' => '<a href="' . $url . '" class="button button-primary' . $disable_class . '" title="' . sprintf( esc_attr__( 'Update %s', 'reader' ), $item['sanitized_plugin'] ) . '">' . esc_attr__( 'Update', 'reader' ) . '</a>',
			);
		} elseif ( is_plugin_active( $item['file_path'] ) ) {
			$url     = esc_url( add_query_arg(
				array(
					'plugin'                  => urlencode( $item['slug'] ),
					'plugin_name'             => urlencode( $item['sanitized_plugin'] ),
					'reader-deactivate'       => 'deactivate-plugin',
					'reader-deactivate-nonce' => wp_create_nonce( 'reader-deactivate' ),
				),
				admin_url( 'admin.php?page=reader-plugins' )
			) );
			$actions = array(
				/* translators: plugin name */
				'deactivate' => '<a href="' . $url . '" class="button button-primary" title="' . sprintf( esc_attr__( 'Deactivate %s', 'reader' ), $item['sanitized_plugin'] ) . '">' . esc_attr__( 'Deactivate', 'reader' ) . '</a>',
			);
		}

		return $actions;
	}
}

new Reader_Admin_Pages;
