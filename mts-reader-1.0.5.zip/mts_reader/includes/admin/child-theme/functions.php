<?php
/**
 * Reader Child Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Reader Child
 */

/**
 * Enqueue styles
 */
function reader_child_enqueue_scripts() {
	wp_enqueue_style( 'reader-child-theme', get_stylesheet_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'reader_child_enqueue_scripts', 15 );
