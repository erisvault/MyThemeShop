/**
Theme Name: <?php echo $child_name . "\n"; ?>
Author: MyThemeShop
Author URI: https://mythemeshop.com/
Description: Reader is a fast loading, ultra-SEO friendly WordPress theme that features rich snippets in order to help search engines identify all parts of your site and rank you higher.
Version: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: reader-child
Template: <?php echo $parent_stylesheet . "\n"; ?>
*/
