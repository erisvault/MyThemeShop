<?php
/**
 * Set reader layout according to options
 *
 * @package Reader
 */

defined( 'WPINC' ) || exit;

/**
 * Layout manager.
 */
class Reader_Layout extends Reader_Base {

	/**
	 * The Construct
	 */
	public function __construct() {
		$this->add_action( 'reader_before_wrapper', 'add_header' );
		$this->add_action( 'reader_single_post_header_thumb', 'single_post_header_thumb' );
	}

	/**
	 * Add header
	 */
	public function add_header() {
		$hash   = array(
			'header-default' => 'default',
			'header-layout2' => 'layout2',
			'header-layout3' => 'layout3',
		);
		$layout = reader_get_settings( 'header_styles' );
		get_template_part( 'template-parts/header/header', isset( $hash[ $layout ] ) ? $hash[ $layout ] : $layout );
	}

	/**
	 * Single post header thumbnail
	 */
	public function single_post_header_thumb() {

		if ( reader_get_settings( 'show_single_featured' ) ) {
			the_post_thumbnail( 'reader-featured', array( 'class' => 'single-featured-image' ) );
		}

	}
}

// Init.
new Reader_Layout;
