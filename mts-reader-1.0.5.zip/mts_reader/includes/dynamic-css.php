<?php
/**
 * Dynamic CSS for the frontend.
 *
 * @package Reader
 */

defined( 'WPINC' ) || exit;

/**
 * Helper function.
 * Merge and combine the CSS elements.
 *
 * @param  string|array $elements An array of our elements.
 *                                If we use a string then it is directly returned.
 * @return string
 */
function reader_implode( $elements = array() ) {

	if ( ! is_array( $elements ) ) {
		return $elements;
	}

	// Make sure our values are unique.
	$elements = array_unique( $elements );

	// Sort elements alphabetically.
	// This way all duplicate items will be merged in the final CSS array.
	sort( $elements );

	// Implode items and return the value.
	return implode( ',', $elements );

}

/**
 * Maps elements from dynamic css to the selector.
 *
 * @param  array  $elements The elements.
 * @param  string $selector The selector.
 * @return array
 */
function reader_map_selector( $elements, $selector ) {
	$array = array();

	foreach ( $elements as $element ) {
		$array[] = $element . $selector;
	}

	return $array;
}

/**
 * Map CSS selectors from values.
 *
 * @param array $css    Array of dynamic CSS.
 * @param array $values Array of values.
 */
function reader_map_css_selectors( &$css, $values ) {
	if ( isset( $values['css-selectors'] ) ) {
		$elements = $values['css-selectors'];
		unset( $values['css-selectors'] );

		$css[ $elements ] = $values;
	}
}

/**
 * Merge CSS values.
 *
 * @param array $css    Array of dynamic CSS.
 * @param array $values Array of values.
 */
function reader_merge_value( &$css, $values ) {
	foreach ( $values as $id => $val ) {
		$css[ $id ] = $val;
	}
}

/**
 * Format of the $css array:
 * $css['media-query']['element']['property'] = value
 *
 * If no media query is required then set it to 'global'
 *
 * If we want to add multiple values for the same property then we have to make it an array like this:
 * $css[media-query][element]['property'][] = value1
 * $css[media-query][element]['property'][] = value2
 *
 * Multiple values defined as an array above will be parsed separately.
 */
function reader_dynamic_css_array() {

	global $wp_version;

	$css       = array();
	$c_page_id = reader()->get_page_id();

	// Site Background.
	$css['global']['html body'] = Reader_Sanitize::background( reader_get_settings( 'mts_background' ) );

	// Top bar Background.
	$css['global']['.top-bar'] = Reader_Sanitize::background( reader_get_settings( 'top_bar_background' ) );

	// Header Background.
	$css['global']['.main-header.bg-on, #header.sticky-navigation-active'] = Reader_Sanitize::background( reader_get_settings( 'header_background' ) );

	// Content Font.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'content_font' ) ) );
	// Logo Font.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'reader_logo' ) ) );
	// Primary Navigation font.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'primary_navigation_font' ) ) );
	// Homepage post title font.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'home_title_font' ) ) );
	// Header Featured font.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'header_featured_title_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'header_featured_text_font' ) ) );
	// Pagination.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'pagination_font' ) ) );
	// Breadcrumbs font.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'breadcrumb_font' ) ) );
	// Single post title font.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'single_title_font' ) ) );
	// Single Page titles font.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'single_page_titles_font' ) ) );
	// Related Posts Section title font.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'related_post_title_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'related_posts_text_font' ) ) );
	// Single subscribe box.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'single_subscribe_title_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'single_subscribe_text_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'single_subscribe_input_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'single_subscribe_submit_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'single_subscribe_small_text_font' ) ) );
	// Author Box.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'single_authorbox_title_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'single_authorbox_author_name_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'single_authorbox_text_font' ) ) );
	// Thanks Section.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'thanks_title_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'thanks_text_font' ) ) );
	// Next Post Section.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'nextpost_title_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'nextpost_text_font' ) ) );
	// Footer Nav.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'footer_nav_font' ) ) );
	// Sidebar widget title font.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'sidebar_title_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'sidebar_buttons_font' ) ) );
	// Sidebar widget font.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'mts_widget_links' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'default_widget_links' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'sidebar_url_bigthumb' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'sidebar_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'sidebar_font_bigthumb' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'sidebar_postinfo_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'sidebar_postinfo_font_bigthumb' ) ) );
	// Tab widget title font.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'tabs_title_font' ) ) );
	// Footer widget title font.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'footer_reader_logo' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'top_footer_title_font' ) ) );
	// Footer link font.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'top_footer_link_font' ) ) );
	// Footer widget font.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'top_footer_font' ) ) );
	// Copyrights section font.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'copyrights_font' ) ) );
	// Fields font.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'fields_font' ) ) );
	// H1 title in the content.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'h1_headline' ) ) );
	// H2 title in the content.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'h2_headline' ) ) );
	// H3 title in the content.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'h3_headline' ) ) );
	// H4 title in the content.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'h4_headline' ) ) );
	// H5 title in the content.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'h5_headline' ) ) );
	// H6 title in the content.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'h6_headline' ) ) );

	// Footer background.
	$css['global']['#site-footer'] = Reader_Sanitize::background( reader_get_settings( 'mts_footer_background' ) );
	// Copyrights background.
	$css['global']['.copyrights'] = Reader_Sanitize::background( reader_get_settings( 'mts_copyrights_background' ) );

	reader_dynamic_css_skin( $css );
	reader_sidebar_position( $css );
	reader_header( $css );
	reader_sidebar_styling( $css );
	reader_post_layouts( $css );
	reader_post_pagination( $css );
	reader_footer_subscribe( $css );
	reader_footer( $css );
	reader_copyrights( $css );
	reader_single( $css );
	reader_single_social_buttons( $css );
	reader_misc_css( $css );

	return apply_filters( 'reader_dynamic_css_array', $css );
}

/**
 * Skin CSS
 *
 * @param array $css Array of dynamic CSS.
 */
function reader_dynamic_css_skin( &$css ) {

	// Primary Color.
	$primary_color_scheme = Reader_Sanitize::color( reader_get_settings( 'primary_color_scheme' ) );

	// Text Color.
	$elements = array(
		'a',
		'body a:hover',
		'.reply a',
		'.latestPost .title a:hover',
		'.related-posts .title a:hover',
		'.layout-default .latestPost .title a:hover',
		'.woocommerce ul.products li.product .price',
		'.product_list_widget .amount',
		'.woocommerce div.product p.price, .woocommerce div.product span.price',
		'.shareit-circular.standard .fa:hover',
		'.textwidget a',
		'#wp-calendar td#today',
		'.pnavigation2 a',
		'#sidebar .widget li a:hover',
		'.title a:hover',
		'#tabber .inside li a:hover',
		'.fn a',
		'.widget .wp_review_tab_widget_content a',
		'.sidebar .wpt_widget_content a',
		'.related-posts .title a:hover',
		'.layout-subscribe .widget #wp-subscribe .title span',
		'.footer-nav li a:hover',
		'blockquote:after',
		'article ul li::before',
		'.single .pagination a .current:hover',
		'#primary-navigation li:hover',
		'.readMore a:hover',
		'blockquote::before',
		'.layout-default .latestPost .post-info a',
		'.breadcrumb .separator',
		'.rank-math-breadcrumb .separator',
		'.breadcrumb-wrapper .left .fa',
		'.single_post .post-info .thecategory a',
		'.postauthor h5 a:hover',
	);

	$css['global'][ reader_implode( $elements ) ]['color'] = $primary_color_scheme;
	$css['global']['#sidebar .widget a:hover']['color']    = $primary_color_scheme;

	// Text Color Important.
	$elements = array(
		'.layout-1 .latestPost a:hover',
		'.widget .review_thumb_large .review-result',
		'.widget .review_thumb_large .review-total-only.large-thumb',
		'.review-total-only.small-thumb .review-result-wrapper i',
	);
	$css['global'][ reader_implode( $elements ) ]['color'] = $primary_color_scheme . '!important';

	// Background Color.
	$elements = array(
		'.error404 .article .sbutton',
		'.search .article .sbutton',
		'.pace .pace-progress',
		'#mobile-menu-wrapper ul li a:hover',
		'.pagination a:hover',
		'.single .pagination a:hover .current',
		'a#pull',
		'#commentform input#submit',
		'#mtscontact_submit',
		'.navigation #wpmm-megamenu .wpmm-pagination a',
		'.wpmm-megamenu-showing.wpmm-light-scheme',
		'.mts-subscribe input[type="submit"]',
		'.widget_product_search button[type="submit"]',
		'#move-to-top:hover',
		'#tabber ul.tabs li a.selected',
		'.navigation ul .sfHover a',
		'.widget-slider .slide-caption',
		'.owl-prev:hover, .owl-next:hover',
		'.widget .wp-subscribe-wrap h4.title span.decor:after',
		'.woocommerce a.button',
		'.woocommerce-page a.button',
		'.woocommerce button.button',
		'.woocommerce-page button.button',
		'.woocommerce input.button',
		'.woocommerce-page input.button',
		'.woocommerce #respond input#submit',
		'.woocommerce-page #respond input#submit',
		'.woocommerce #content input.button',
		'.woocommerce-page #content input.button',
		'.woocommerce .bypostauthor:after',
		'.woocommerce nav.woocommerce-pagination ul li span.current',
		'.woocommerce-page nav.woocommerce-pagination ul li span.current',
		'.woocommerce #content nav.woocommerce-pagination ul li span.current',
		'.woocommerce-page #content nav.woocommerce-pagination ul li span.current',
		'.woocommerce nav.woocommerce-pagination ul li a:hover',
		'.woocommerce-page nav.woocommerce-pagination ul li a:hover',
		'.woocommerce #content nav.woocommerce-pagination ul li a:hover',
		'.woocommerce-page #content nav.woocommerce-pagination ul li a:hover',
		'.woocommerce nav.woocommerce-pagination ul li a:focus',
		'.woocommerce-page nav.woocommerce-pagination ul li a:focus',
		'.woocommerce #content nav.woocommerce-pagination ul li a:focus',
		'.woocommerce-page #content nav.woocommerce-pagination ul li a:focus',
		'.woocommerce a.button',
		'.woocommerce-page a.button',
		'.woocommerce button.button',
		'.woocommerce-page button.button',
		'.woocommerce input.button',
		'.woocommerce-page input.button',
		'.woocommerce #respond input#submit',
		'.woocommerce-page #respond input#submit',
		'.woocommerce #content input.button',
		'.woocommerce-page #content input.button',
		'.woocommerce #respond input#submit.alt.disabled',
		'.woocommerce #respond input#submit.alt.disabled:hover',
		'.woocommerce #respond input#submit.alt:disabled',
		'.woocommerce #respond input#submit.alt:disabled:hover',
		'.woocommerce #respond input#submit.alt:disabled[disabled]',
		'.woocommerce #respond input#submit.alt:disabled[disabled]:hover',
		'.woocommerce a.button.alt.disabled, .woocommerce a.button.alt.disabled:hover',
		'.woocommerce a.button.alt:disabled',
		'.woocommerce a.button.alt:disabled:hover',
		'.woocommerce a.button.alt:disabled[disabled]',
		'.woocommerce a.button.alt:disabled[disabled]:hover',
		'.woocommerce button.button.alt.disabled',
		'.woocommerce button.button.alt.disabled:hover',
		'.woocommerce button.button.alt:disabled',
		'.woocommerce button.button.alt:disabled:hover',
		'.woocommerce button.button.alt:disabled[disabled]',
		'.woocommerce button.button.alt:disabled[disabled]:hover',
		'.woocommerce input.button.alt.disabled',
		'.woocommerce input.button.alt.disabled:hover',
		'.woocommerce input.button.alt:disabled',
		'.woocommerce input.button.alt:disabled:hover',
		'.woocommerce input.button.alt:disabled[disabled]',
		'.woocommerce input.button.alt:disabled[disabled]:hover',
		'#wpmm-megamenu .review-total-only',
		'#searchsubmit',
		'#add_payment_method .wc-proceed-to-checkout a.checkout-button',
		'.woocommerce-cart .wc-proceed-to-checkout a.checkout-button',
		'.woocommerce-checkout .wc-proceed-to-checkout a.checkout-button',
		'.woocommerce #respond input#submit.alt',
		'.woocommerce a.button.alt',
		'.woocommerce button.button.alt',
		'.woocommerce input.button.alt',
		'.woocommerce-account .woocommerce-MyAccount-navigation li.is-active',
		'.button',
		'.instagram-button a',
		'.woocommerce .woocommerce-widget-layered-nav-dropdown__submit',
		'.layout-subscribe form:after',
		'.widget .sbutton',
		'.owl-prev:hover, .owl-next:hover',
		'.woocommerce .widget_price_filter .ui-slider .ui-slider-handle',
		'.woocommerce .widget_price_filter .ui-slider .ui-slider-range',
		'.latestPost-review-wrapper',
		'.latestPost .review-type-circle.latestPost-review-wrapper',
		'.woocommerce span.onsale',
		'.widget .widget_wp_review_tab .review-total-only.large-thumb',
		'#sidebar .widget h3::before',
		'.prev-next .prev a:hover',
		'.prev-next .next a:hover',
		'.pagination .nav-previous a',
		'.pagination .nav-next a',
		'.tags a:hover',
		'.header-featured h1::before',
		'.footer-subscribe .widget #wp-subscribe input.submit',
	);

	$css['global'][ reader_implode( $elements ) ]['background-color'] = $primary_color_scheme;

	$css['@media screen and (max-width: 865px)']['.navigation.mobile-menu-wrapper']['background-color'] = $primary_color_scheme;

	// Background Color Important.
	$elements = array(
		'.tagcloud a:hover, #sidebar .widget .tagcloud a:hover',
		'.widget .wpt_widget_content #tags-tab-content ul li a:hover ',
	);
	$css['global'][ reader_implode( $elements ) ]['background-color'] = $primary_color_scheme . '!important';

	// Border Color.
	$elements = array(
		'.flex-control-thumbs .flex-active',
		'#wrapper .cooked-recipe-ingredients .cooked-ingredient-checkbox',
		'#primary-navigation li a:hover',
	);

	$css['global'][ reader_implode( $elements ) ]['border-color'] = $primary_color_scheme;

	// Box Shadow Color.
	$elements = array(
		'#secondary-navigation li:hover a',
		'#secondary-navigation li.current-menu-item a',
	);

	$css['global'][ reader_implode( $elements ) ]['box-shadow'] = '0 4px ' . $primary_color_scheme;

	// Box Shadow inset.
	$elements = array(
		'#sidebar .widget .wp_review_tab_widget_content .tab_title.selected a',
		'#sidebar .widget .wpt_widget_content .tab_title.selected a',
		'footer .widget .wpt_widget_content .tab_title.selected a',
		'footer .widget .wp_review_tab_widget_content .tab_title.selected a',
	);

	$css['global'][ reader_implode( $elements ) ]['box-shadow'] = 'inset 0 -4px ' . $primary_color_scheme;

	// Light color.
	$css['global']['blockquote::after']['background-color'] = $primary_color_scheme;
	$css['global']['blockquote::after']['opacity']          = '0.1';

}

/**
 * Sidebar Position
 *
 * @param array $css Array of dynamic CSS.
 */
function reader_sidebar_position( &$css ) {

	// Sidebar position.
	$sidebar_position = reader_get_settings( 'mts_layout' );

	$sidebar_metabox_location = '';
	if ( is_page() || is_single() ) {
		$sidebar_metabox_location = get_post_meta( get_the_ID(), '_mts_sidebar_location', true );
	}

	if ( 'right' !== $sidebar_metabox_location && ( 'sclayout' === $sidebar_position || 'left' === $sidebar_metabox_location ) ) {
		$css['global']['.article']['float']                = 'right';
		$css['global']['.sidebar.c-4-12']['float']         = 'left';
		$css['global']['.sidebar.c-4-12']['padding-right'] = 0;

		if ( null !== reader_get_settings( 'mts_social_button_position' ) && 'floating' === reader_get_settings( 'mts_social_button_position' ) ) {

			$shareit_class = array(
				'.right .shareit.shareit-default.floating',
				'.right .shareit.standard.floating',
				'.right .shareit.shareit-circular.floating',
			);

			$css['global'][ reader_implode( $shareit_class ) ]['left']  = 'auto';
			$css['global'][ reader_implode( $shareit_class ) ]['right'] = '0px';

			$css['global'][ reader_implode( $shareit_class ) ]['margin-left']  = '0px';
			$css['global'][ reader_implode( $shareit_class ) ]['margin-right'] = '50px';
		}
	}
	if ( 'mts_nosidebar' == mts_custom_sidebar() ) {
		$css['global']['.single-full-header']['width'] = '100%';
	}
}

/**
 * Header
 *
 * @param array $css Array of dynamic CSS.
 */
function reader_header( &$css ) {

	// Header.
	$header_class = array(
		'#header',
	);
	reader_merge_value( $css['global'][ reader_implode( $header_class ) ], Reader_Sanitize::margin( reader_get_settings( 'header_margin' ) ) );
	reader_merge_value( $css['global'][ reader_implode( $header_class ) ], Reader_Sanitize::padding( reader_get_settings( 'header_padding' ) ) );
	// Header Border.
	$header_border = Reader_Sanitize::border( reader_get_settings( 'header_border' ) );
	$css['global'][ reader_implode( $header_class ) ][ $header_border['direction'] ] = $header_border ['value'];

	// Primary Nav.
	$main_nav_classes = array(
		'#primary-navigation .navigation ul ul a',
		'#primary-navigation .navigation a:hover',
		'#primary-navigation .navigation ul ul a:link',
		'#primary-navigation .navigation ul ul a:visited',
	);
	$css['global'][ reader_implode( $main_nav_classes ) ]['color'] = Reader_Sanitize::color( reader_get_settings( 'main_navigation_dropdown_color' ) );

	$css['global']['#primary-navigation .navigation ul ul a:hover, #secondary-navigation ul ul a:hover']['color'] = Reader_Sanitize::color( reader_get_settings( 'main_navigation_dropdown_hover_color' ) );

	$css['global']['#primary-navigation .navigation ul ul a:hover']['border-color'] = Reader_Sanitize::color( reader_get_settings( 'main_navigation_dropdown_hover_color' ) );

	// Featured Area.
	reader_merge_value( $css['global']['.header-featured'], Reader_Sanitize::padding( reader_get_settings( 'featured_padding' ) ) );

	// Secondary Nav.
	reader_merge_value( $css['global']['#secondary-navigation'], Reader_Sanitize::padding( reader_get_settings( 'secondary_nav_padding' ) ) );

	$secondary_nav_border = Reader_Sanitize::border( reader_get_settings( 'secondary_nav_border' ) );
	$css['global']['#secondary-navigation'][ $secondary_nav_border['direction'] ] = $secondary_nav_border ['value'];

	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'secondary_navigation_font' ) ) );

	// Social icons.
	if ( 'header-layout2' === reader_get_settings( 'header_styles' ) && ! empty( reader_get_settings( 'header_social_icons' ) ) && is_array( reader_get_settings( 'header_social_icons' ) ) ) :
		$header_icons = reader_get_settings( 'header_social_icons' );
		foreach ( $header_icons as $header_icon ) :

			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ]['background-color'] = Reader_Sanitize::color( $header_icon['header_icon_bgcolor'] );

			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] . ':hover' ]['background-color'] = Reader_Sanitize::color( $header_icon['header_icon_hover_bgcolor'] );

			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ]['color'] = Reader_Sanitize::color( $header_icon['header_icon_color'] );

			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] . ':hover' ]['color'] = Reader_Sanitize::color( $header_icon['header_icon_hover_color'] );

			reader_merge_value( $css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ], Reader_Sanitize::margin( $header_icon['header_icon_margin'] ) );

			reader_merge_value( $css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ], Reader_Sanitize::padding( $header_icon['header_icon_padding'] ) );

			$header_icon_border = Reader_Sanitize::border( $header_icon['header_icon_border'] );
			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ][ $header_icon_border['direction'] ] = $header_icon_border ['value'];

			$css['global'][ '.header-social-icons a.header-' . $header_icon['header_icon'] ]['border-radius'] = Reader_Sanitize::size( $header_icon['header_icon_border_radius'] . 'px' );

		endforeach;
	endif;

	// Header Ad.
	reader_merge_value( $css['global']['.widget-header, .small-header .widget-header'], Reader_Sanitize::margin( reader_get_settings( 'mts_header_adcode_margin' ) ) );

	// Ad-Blocker.
	$css['global']['.navigation-banner']['background'] = Reader_Sanitize::color( reader_get_settings( 'navigation_ad_background' ) );
}

/**
 * Social Share Styling
 *
 * @param array $css Array of dynamic CSS.
 */
function reader_single_social_buttons( &$css ) {

	$social_shadow = reader_get_settings( 'social_styling_box_shadow' );

	// Social share.
	$css['global']['.shareit.floating'] = Reader_Sanitize::background( reader_get_settings( 'social_styling_background' ) );
	reader_merge_value( $css['global']['.shareit.floating'], Reader_Sanitize::margin( reader_get_settings( 'social_styling_margin' ) ) );

	// Social share border.
	$social_border = Reader_Sanitize::border( reader_get_settings( 'social_styling_border' ) );
	$css['global']['.shareit.floating'][ $social_border ['direction'] ] = $social_border ['value'];

	if ( 0 === $social_shadow ) {
		$css['global']['.shareit.floating']['box-shadow'] = 'none';
	}
	$social_button_layout   = reader_get_settings( 'social_button_layout' );
	$social_button_position = reader_get_settings( 'social_floating_button_position' );
	if ( 'default' === $social_button_layout ) {
		$share_class = '.shareit.shareit-' . $social_button_layout . '.floating';
	} else {
		$share_class = '.shareit.' . $social_button_layout . '.floating';
	}
	if ( ! empty( $social_button_position ) && is_array( $social_button_position ) ) {
		foreach ( $social_button_position as $key => $position ) {
			$css['global'][ $share_class ][ $key ] = $position;
		}
	}
}

/**
 * Sidebar styling
 *
 * @param array $css Array of dynamic CSS.
 */
function reader_sidebar_styling( &$css ) {

	// Sidebar.
	reader_merge_value( $css['global']['#sidebar .widget'], Reader_Sanitize::background( reader_get_settings( 'mts_sidebar_styling_background' ) ) );
	reader_merge_value( $css['global']['#sidebar .widget'], Reader_Sanitize::margin( reader_get_settings( 'mts_sidebar_styling_margin' ) ) );
	reader_merge_value( $css['global']['#sidebar .widget'], Reader_Sanitize::padding( reader_get_settings( 'mts_sidebar_styling_padding' ) ) );
	// Sidebar border.
	$sidebar_border = Reader_Sanitize::border( reader_get_settings( 'sidebar_styling_border' ) );
	$css['global']['#sidebar .widget'][ $sidebar_border['direction'] ] = $sidebar_border['value'];

	// Sidebar title.
	$sidebar_title                   = '#sidebar .widget h3, #sidebar .widget #wp-subscribe .title';
	$css['global'][ $sidebar_title ] = Reader_Sanitize::background( reader_get_settings( 'mts_sidebar_title_styling_background' ) );
	reader_merge_value( $css['global'][ $sidebar_title ], Reader_Sanitize::padding( reader_get_settings( 'mts_sidebar_title_styling_padding' ) ) );
	reader_merge_value( $css['global'][ $sidebar_title ], Reader_Sanitize::margin( reader_get_settings( 'mts_sidebar_title_styling_margin' ) ) );
	// Sidebar Title border.
	$sidebar_title_border = Reader_Sanitize::border( reader_get_settings( 'widget_title_border' ) );
	$css['global'][ $sidebar_title ][ $sidebar_title_border['direction'] ] = $sidebar_title_border['value'];

	// Subscribe widget styling.
	$css['global']['.widget #wp-subscribe, .f-widget #wp-subscribe']['background'] = Reader_Sanitize::color( reader_get_settings( 'subscribe_widget_background' ) );

	reader_merge_value( $css['global']['.widget #wp-subscribe'], Reader_Sanitize::padding( reader_get_settings( 'subscribe_widget_padding' ) ) );

	$css['global']['.widget #wp-subscribe']['border-radius'] = Reader_Sanitize::size( reader_get_settings( 'subscribe_widget_border_radius' ) . 'px' );

	$css['global']['.widget #wp-subscribe input.submit']['background'] = Reader_Sanitize::color( reader_get_settings( 'subscribe_widget_button_background' ) );

	// Search widget and Social icons widget styling.
	$widget_classes = array(
		'#sidebar .widget.widget_search',
		'#sidebar .widget.social-profile-icons',
		'#site-footer .f-widget .widget.widget_search',
		'#sidebar .widget.woocommerce.widget_product_search',
	);

	$css['global'][ reader_implode( $widget_classes ) ]['background'] = Reader_Sanitize::color( reader_get_settings( 'search_widget_background' ) );

	reader_merge_value( $css['global'][ reader_implode( $widget_classes ) ], Reader_Sanitize::padding( reader_get_settings( 'search_widget_padding' ) ) );

	$css['global'][ reader_implode( $widget_classes ) ]['border-radius'] = Reader_Sanitize::size( reader_get_settings( 'search_widget_border_radius' ) . 'px' );

	$css['global']['#sidebar .widget .sbutton, .widget_product_search button[type="submit"]']['background'] = Reader_Sanitize::color( reader_get_settings( 'search_widget_button_background' ) );

	// Instagram widget styling.
	$insta_padding = Reader_Sanitize::padding( reader_get_settings( 'instagram_widget_padding' ) );

	$css['global']['.widget.instagram-widget-wrapper']['background'] = Reader_Sanitize::color( reader_get_settings( 'instagram_widget_background' ) );

	reader_merge_value( $css['global']['#sidebar .widget.instagram-widget-wrapper, footer .widget.instagram-widget-wrapper'], $insta_padding );

	$css['global']['.widget.instagram-widget-wrapper']['border-radius'] = Reader_Sanitize::size( reader_get_settings( 'instagram_widget_border_radius' ) . 'px' );

	$css['global']['.widget.instagram-widget-wrapper .instagram-button a']['background'] = Reader_Sanitize::color( reader_get_settings( 'instagram_widget_button_background' ) );

	$css['global']['.widget.instagram-widget-wrapper .instagram-posts']['margin-left'] = '-' . $insta_padding['padding-left'];

	$css['global']['.widget.instagram-widget-wrapper .instagram-posts']['margin-right'] = '-' . $insta_padding['padding-right'];

}

/**
 * Layout CSS
 *
 * @param array $css Array of dynamic CSS.
 */
function reader_post_layouts( &$css ) {

	// Post Layouts.
	$features = reader_get_settings( 'mts_featured_categories' );
	foreach ( $features as $feature ) :

		if ( ! isset( $feature['unique_id'] ) ) {
			continue;
		}

		$category     = $feature['mts_featured_category'];
		$posts_layout = isset( $feature['blog_layout'] ) ? $feature['blog_layout'] : 'layout-default';
		$unique_id    = $feature['unique_id'];

		if ( 'layout-default' === $posts_layout ) :
			$posts_layout = 'default';
		endif;

		// Section title align.
		$post_title_align = reader_get_settings( 'mts_post_title_alignment_' . $unique_id );

		// Post area.
		$cat_class = 'cat-latest';
		if ( 'latest' !== $category ) {
			$category  = get_term_by( 'slug', $category, 'category' );
			$cat_class = sanitize_key( $category->name );
		}

		$title_class = '.title-container.title-id-' . $unique_id . ' h3';

		$css['global'][ $title_class ] = Reader_Sanitize::background( reader_get_settings( 'mts_featured_category_title_background_' . $unique_id ) );
		reader_merge_value( $css['global'][ $title_class ], Reader_Sanitize::margin( reader_get_settings( 'mts_featured_category_title_margin_' . $unique_id ) ) );
		reader_merge_value( $css['global'][ $title_class ], Reader_Sanitize::padding( reader_get_settings( 'mts_featured_category_title_padding_' . $unique_id ) ) );
		// Section title border.
		$post_title_border = Reader_Sanitize::border( reader_get_settings( 'post_title_border_' . $unique_id ) );
		$css['global'][ $title_class ][ $post_title_border['direction'] ] = $post_title_border['value'];

		// Title alignment.
		$align_class = '.title-container.title-id-' . $unique_id;
		if ( 'center' === $post_title_align ) :
			$css['global'][ $align_class ]['text-align'] = 'center';
		elseif ( 'right' === $post_title_align ) :
			$css['global'][ $align_class ]['text-align']              = 'right';
			$css['global'][ $align_class . ' + .view-more' ]['left']  = '0';
			$css['global'][ $align_class . ' + .view-more' ]['right'] = 'auto';
		endif;

		reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'mts_featured_category_title_font_' . $unique_id ) ) );

		if ( 'layout-default' === $posts_layout ) {
			$post_class = '.layout-' . $unique_id . '.default-container';
		} else {
			$post_class = '.layout-' . $unique_id;
		}

		// Post border.
		$post_border = Reader_Sanitize::border( reader_get_settings( 'post_border_' . $unique_id ) );
		$css['global'][ $post_class ][ $post_border['direction'] ] = $post_border['value'];

		/**
		 * Meta info
		 */
		reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'meta_info_font_' . $unique_id ) ) );

		reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'post_title_font_' . $unique_id ) ) );

		if ( 'layout-subscribe' !== $posts_layout ) {
			reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'post_excerpt_font_' . $unique_id ) ) );
		}

		// Border.
		$meta_info_border = Reader_Sanitize::border( reader_get_settings( 'meta_info_border_' . $unique_id ) );
		$css['global'][ '.layout-' . $unique_id . ' .latestPost .post-info' ][ $meta_info_border['direction'] ] = $meta_info_border['value'];

		// All Posts Margin and Padding.
		reader_merge_value( $css['global'][ $post_class ], Reader_Sanitize::margin( reader_get_settings( 'post_margin_' . $unique_id ) ) );
		reader_merge_value( $css['global'][ $post_class ], Reader_Sanitize::padding( reader_get_settings( 'post_padding_' . $unique_id ) ) );

	endforeach;
}

/**
 * Pagination
 *
 * @param array $css Array of dynamic CSS.
 */
function reader_post_pagination( &$css ) {

	// Pagination Active class.
	$pagination_class_active = array(
		'.pace .pace-progress',
		'.page-numbers.current',
		'#mobile-menu-wrapper ul li a:hover',
		'.pagination a:hover',
	);
	$pagination_class        = array(
		'.pagination a',
		'.single .pagination > .current .currenttext',
		'.pagination .page-numbers.dots',
	);
	reader_merge_value( $css['global'][ reader_implode( array_merge( $pagination_class_active, $pagination_class ) ) ], Reader_Sanitize::margin( reader_get_settings( 'mts_pagenavigation_margin' ) ) );
	if ( '2' !== reader_get_settings( 'mts_pagenavigation_type' ) ) {
		$css['global'][ reader_implode( $pagination_class ) ]['background-color'] = Reader_Sanitize::color( reader_get_settings( 'mts_pagenavigation_bgcolor' ) );

		$css['global'][ reader_implode( $pagination_class_active ) ]['background-color'] = Reader_Sanitize::color( reader_get_settings( 'mts_pagenavigation_hover_bgcolor' ) );

		$css['global'][ reader_implode( $pagination_class ) ]['color'] = Reader_Sanitize::color( reader_get_settings( 'mts_pagenavigation_color' ) );

		$css['global'][ reader_implode( $pagination_class_active ) ]['color'] = Reader_Sanitize::color( reader_get_settings( 'mts_pagenavigation_hover_color' ) );

		reader_merge_value( $css['global'][ reader_implode( array_merge( $pagination_class_active, $pagination_class ) ) ], Reader_Sanitize::padding( reader_get_settings( 'mts_pagenavigation_padding' ) ) );
	} else {
		$css['global']['#load-posts a']['background-color'] = Reader_Sanitize::color( reader_get_settings( 'load_more_bgcolor' ) );

		$css['global']['#load-posts a:hover']['background-color'] = Reader_Sanitize::color( reader_get_settings( 'load_more_hover_bgcolor' ) );

		$css['global']['#load-posts a']['color'] = Reader_Sanitize::color( reader_get_settings( 'load_more_color' ) );

		$css['global']['#load-posts a:hover']['color'] = Reader_Sanitize::color( reader_get_settings( 'load_more_hover_color' ) );

		reader_merge_value( $css['global']['#load-posts a'], Reader_Sanitize::padding( reader_get_settings( 'load_more_padding' ) ) );
	}
	$css['global'][ reader_implode( $pagination_class ) ]['border-radius']        = Reader_Sanitize::size( reader_get_settings( 'mts_pagenavigation_border_radius' ) . 'px' );
	$css['global'][ reader_implode( $pagination_class_active ) ]['border-radius'] = Reader_Sanitize::size( reader_get_settings( 'mts_pagenavigation_border_radius' ) . 'px' );

	// Pagination border.
	$pagination_border = Reader_Sanitize::border( reader_get_settings( 'pagenavigation_border' ) );
	$css['global'][ reader_implode( $pagination_class ) ][ $pagination_border ['direction'] ] = $pagination_border ['value'];

	// Pagination Alignment.
	$pagenavigation_align = reader_get_settings( 'pagenavigation_alignment' );
	if ( 'left' === $pagenavigation_align ) :
		$css['global']['.pagination']['text-align'] = 'left';
	elseif ( 'right' === $pagenavigation_align ) :
		$css['global']['.pagination']['text-align'] = 'right';
	endif;

	// Load more Alignment.
	$load_more_align = reader_get_settings( 'load_more_alignment' );
	if ( 'left' === $load_more_align ) :
		$css['global']['#load-posts']['text-align'] = 'left';
	elseif ( 'right' === $load_more_align ) :
		$css['global']['#load-posts']['text-align'] = 'right';
	elseif ( 'full' === $load_more_align ) :
		$css['global']['#load-posts a']['width'] = '100%';
	endif;
}

/**
 * Single
 *
 * @param array $css Array of dynamic CSS.
 */
function reader_single( &$css ) {

	// Single, Page, Archive, Search, Category and 404 Page Background.
	$page_classes = array(
		'.single .article',
		'.page .article',
		'.search .article',
		'.archive .article',
		'.error404 .article',
	);

	$css['global'][ reader_implode( $page_classes ) ] = Reader_Sanitize::background( reader_get_settings( 'single_background' ) );

	// Margin, Padding, Border and Box Shadow.
	reader_merge_value( $css['global'][ reader_implode( $page_classes ) ], Reader_Sanitize::margin( reader_get_settings( 'mts_single_styling_margin' ) ) );
	reader_merge_value( $css['global'][ reader_implode( $page_classes ) ], Reader_Sanitize::padding( reader_get_settings( 'mts_single_styling_padding' ) ) );

	// Single border.
	$single_border = Reader_Sanitize::border( reader_get_settings( 'single_styling_border' ) );
	$css['global']['.article'][ $single_border ['direction'] ] = $single_border ['value'];

	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'mts_single_meta_info_font' ) ) );

	// Tags.
	$css['global']['.tags a, .tagcloud a, .widget .wpt_widget_content #tags-tab-content ul li a']['background-color'] = Reader_Sanitize::color( reader_get_settings( 'tags_bgcolor' ) );

	// Thanks Section.
	$css['global']['.thanks-section'] = Reader_Sanitize::background( reader_get_settings( 'thanks_background' ) );
	reader_merge_value( $css['global']['.thanks-section'], Reader_Sanitize::margin( reader_get_settings( 'thanks_margin' ) ) );
	reader_merge_value( $css['global']['.thanks-section'], Reader_Sanitize::padding( reader_get_settings( 'thanks_padding' ) ) );
	$css['global']['.thanks-section']['border-radius'] = Reader_Sanitize::size( reader_get_settings( 'thanks_border_radius' ) . 'px' );

	// Next Post Section.
	$padding       = Reader_Sanitize::padding( reader_get_settings( 'nextpost_padding' ) );
	$content       = 730;
	$total_padding = (int) $padding['padding-left'] + (int) $padding['padding-right'];

	$left_width  = ( 305 / ( $content - $total_padding ) ) * 100;
	$right_width = ( 294 / ( $content - $total_padding ) ) * 100;

	$css['global']['.next-post .left']['width']  = $left_width . '%';
	$css['global']['.next-post .right']['width'] = $right_width . '%';

	$css['global']['.nextpost-wrapper'] = Reader_Sanitize::background( reader_get_settings( 'nextpost_background' ) );

	reader_merge_value( $css['global']['.nextpost-wrapper'], Reader_Sanitize::margin( reader_get_settings( 'nextpost_margin' ) ) );
	reader_merge_value( $css['global']['.nextpost-wrapper'], Reader_Sanitize::padding( reader_get_settings( 'nextpost_padding' ) ) );

	$css['global']['.nextpost-wrapper']['border-radius'] = Reader_Sanitize::size( reader_get_settings( 'thanks_border_radius' ) . 'px' );

	$css['global']['.nextpost-wrapper .button']['background'] = Reader_Sanitize::color( reader_get_settings( 'nextpost_button_background' ) );

	// Related Posts.
	$css['global']['.related-posts'] = Reader_Sanitize::background( reader_get_settings( 'related_posts_background' ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'related_posts_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'related_posts_meta_font' ) ) );
	reader_merge_value( $css['global']['.related-posts'], Reader_Sanitize::margin( reader_get_settings( 'related_posts_margin' ) ) );
	reader_merge_value( $css['global']['.related-posts'], Reader_Sanitize::padding( reader_get_settings( 'related_posts_padding' ) ) );

	$related_posts_border = Reader_Sanitize::border( reader_get_settings( 'related_posts_border' ) );
	$css['global']['.related-posts'][ $related_posts_border ['direction'] ] = $related_posts_border ['value'];

	// Related Posts articles.
	$css['global']['.related-posts article'] = Reader_Sanitize::background( reader_get_settings( 'related_article_background' ) );
	reader_merge_value( $css['global']['.related-posts article'], Reader_Sanitize::padding( reader_get_settings( 'related_article_padding' ) ) );
	reader_merge_value( $css['global']['.related-posts article header'], Reader_Sanitize::padding( reader_get_settings( 'related_article_text_padding' ) ) );

	// Subscribe Box.
	$css['global']['.single-subscribe .widget #wp-subscribe'] = Reader_Sanitize::background( reader_get_settings( 'single_subscribe_background' ) );
	reader_merge_value( $css['global']['.single-subscribe .widget #wp-subscribe'], Reader_Sanitize::margin( reader_get_settings( 'single_subscribe_margin' ) ) );
	reader_merge_value( $css['global']['.single-subscribe .widget #wp-subscribe'], Reader_Sanitize::padding( reader_get_settings( 'single_subscribe_padding' ) ) );
	$css['global']['.single-subscribe .widget #wp-subscribe']['border-radius'] = Reader_Sanitize::size( reader_get_settings( 'single_subscribe_border_radius' ) . 'px' );

	// Subscribe Box Input fields.
	$subscribe_input_class = array(
		'.single-subscribe #wp-subscribe input.email-field',
		'.single-subscribe #wp-subscribe input.name-field',
	);
	$css['global'][ reader_implode( $subscribe_input_class ) ]['background-color'] = Reader_Sanitize::color( reader_get_settings( 'single_subscribe_input_background' ) );

	$css['global'][ reader_implode( $subscribe_input_class ) ]['height'] = Reader_Sanitize::size( reader_get_settings( 'single_subscribe_input_height' ) . 'px' );

	$css['global']['.single-subscribe .widget #wp-subscribe input.submit']['height'] = Reader_Sanitize::size( reader_get_settings( 'single_subscribe_input_height' ) . 'px' );

	$css['global'][ reader_implode( $subscribe_input_class ) ]['border-radius'] = Reader_Sanitize::size( reader_get_settings( 'single_subscribe_input_border_radius' ) . 'px' );

	// Subscribe Box Input border.
	$subscribe_box_input_border = Reader_Sanitize::border( reader_get_settings( 'single_subscribe_input_border' ) );
	$css['global'][ reader_implode( $subscribe_input_class ) ][ $subscribe_box_input_border ['direction'] ] = $subscribe_box_input_border ['value'];

	// Subscribe Box Submit button.
	$css['global']['.single-subscribe .widget #wp-subscribe input.submit']['background']    = Reader_Sanitize::color( reader_get_settings( 'single_subscribe_submit_backgroud' ) );
	$css['global']['.single-subscribe .widget #wp-subscribe input.submit']['border-radius'] = Reader_Sanitize::size( reader_get_settings( 'single_subscribe_submit_border_radius' ) . 'px' );

	// Subscribe Box Submit border.
	$subscribe_box_submit_border = Reader_Sanitize::border( reader_get_settings( 'single_subscribe_submit_border' ) );
	$css['global']['.single-subscribe .widget #wp-subscribe input.submit'][ $subscribe_box_submit_border ['direction'] ] = $subscribe_box_submit_border ['value'];

	reader_merge_value( $css['global']['.single-subscribe .widget #wp-subscribe input.submit'], Reader_Sanitize::padding( reader_get_settings( 'single_subscribe_submit_padding' ) ) );

	// Author Box.
	$css['global']['.postauthor'] = Reader_Sanitize::background( reader_get_settings( 'single_authorbox_background' ) );

	reader_merge_value( $css['global']['.postauthor'], Reader_Sanitize::margin( reader_get_settings( 'single_authorbox_margin' ) ) );

	reader_merge_value( $css['global']['.postauthor'], Reader_Sanitize::padding( reader_get_settings( 'single_authorbox_padding' ) ) );

	$css['global']['.postauthor']['border-radius'] = Reader_Sanitize::size( reader_get_settings( 'single_authorbox_border_radius' ) . 'px' );

	$single_authorbox_border = Reader_Sanitize::border( reader_get_settings( 'single_authorbox_border' ) );
	$css['global']['.postauthor'][ $single_authorbox_border ['direction'] ] = $single_authorbox_border ['value'];

	// Author image.
	reader_merge_value( $css['global']['.postauthor img'], Reader_Sanitize::margin( reader_get_settings( 'single_author_image_margin' ) ) );

	$css['global']['.postauthor img']['border-radius'] = Reader_Sanitize::size( reader_get_settings( 'single_author_image_border_radius' ) . 'px' );

	// Single Page titles Styling.
	$titles_align = reader_get_settings( 'single_title_alignment' );

	$titles_align_class = array(
		'.comment-title',
		'#respond',
		'.related-posts-title',
	);
	$titles_class       = array(
		'#respond h4',
		'.total-comments',
		'.related-posts h4',
	);

	$css['global'][ reader_implode( $titles_class ) ] = Reader_Sanitize::background( reader_get_settings( 'single_title_background' ) );
	reader_merge_value( $css['global'][ reader_implode( $titles_class ) ], Reader_Sanitize::padding( reader_get_settings( 'single_title_padding' ) ) );
	// Single title border.
	$single_titles_border = Reader_Sanitize::border( reader_get_settings( 'single_title_border' ) );
	$css['global'][ reader_implode( $titles_class ) ][ $single_titles_border ['direction'] ] = $single_titles_border ['value'];

	if ( 'left' === $titles_align ) :
		$css['global'][ reader_implode( $titles_class ) ]['display'] = 'inline-block';
	elseif ( 'center' === $titles_align ) :
		$css['global'][ reader_implode( $titles_align_class ) ]['text-align'] = 'center';
		$css['global'][ reader_implode( $titles_class ) ]['display']          = 'inline-block';
	elseif ( 'right' === $titles_align ) :
		$css['global'][ reader_implode( $titles_align_class ) ]['text-align'] = 'right';
		$css['global'][ reader_implode( $titles_class ) ]['display']          = 'inline-block';
	endif;

}

/**
 * Footer Subscribe Section
 *
 * @param array $css Array of dynamic CSS.
 */
function reader_footer_subscribe( &$css ) {

	if ( ! reader_get_settings( 'footer_subscribe' ) ) {
		return;
	}

	$input_class = '.footer-subscribe #wp-subscribe input.email-field, .footer-subscribe #wp-subscribe input.name-field';

	$css['global']['.footer-subscribe'] = Reader_Sanitize::background( reader_get_settings( 'footer_subscribe_background' ) );

	// Margin & Padding.
	reader_merge_value( $css['global']['.footer-subscribe'], Reader_Sanitize::margin( reader_get_settings( 'footer_subscribe_margin' ) ) );
	reader_merge_value( $css['global']['.footer-subscribe'], Reader_Sanitize::padding( reader_get_settings( 'footer_subscribe_padding' ) ) );

	// Border.
	$subscribe_border = Reader_Sanitize::border( reader_get_settings( 'footer_subscribe_border' ) );
	$css['global']['.footer-subscribe'][ $subscribe_border ['direction'] ] = $subscribe_border ['value'];

	$css['global'][ $input_class ]['background-color'] = Reader_Sanitize::color( reader_get_settings( 'footer_subscribe_input_background' ) );

	// Fonts.
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'footer_subscribe_title_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'footer_subscribe_input_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'footer_subscribe_submit_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'footer_subscribe_text_font' ) ) );
	reader_map_css_selectors( $css['global'], Reader_Sanitize::typography( reader_get_settings( 'footer_subscribe_small_text_font' ) ) );

}

/**
 * Copyrights
 *
 * @param array $css Array of dynamic CSS.
 */
function reader_copyrights( &$css ) {

	// copyrights border.
	$copyrights_border = Reader_Sanitize::border( reader_get_settings( 'copyrights_border' ) );
	$css['global']['.copyrights'][ $copyrights_border ['direction'] ] = $copyrights_border ['value'];

}

/**
 * Footer
 *
 * @param array $css Array of dynamic CSS.
 */
function reader_footer( &$css ) {

	// Footer.
	reader_merge_value( $css['global']['#site-footer'], Reader_Sanitize::margin( reader_get_settings( 'mts_top_footer_margin' ) ) );
	reader_merge_value( $css['global']['#site-footer'], Reader_Sanitize::padding( reader_get_settings( 'mts_top_footer_padding' ) ) );

	// Footer widgets.
	if ( 1 === reader_get_settings( 'mts_top_footer' ) && 1 === reader_get_settings( 'mts_top_footer_num' ) ) :
		$css['global']['.footer-widgets']['display']                = 'flex';
		$css['global']['.footer-widgets']['justify-content']        = 'center';
		$css['global']['.footer-widgets .f-widget']['width']        = '38.7387388%';
		$css['global']['.footer-widgets .f-widget']['text-align']   = 'center';
		$css['global']['.footer-widgets .f-widget']['margin-right'] = '0px';
	endif;

	// Footer Navigation Section.
	reader_merge_value( $css['global']['.footer-nav-section'], Reader_Sanitize::margin( reader_get_settings( 'footer_nav_margin' ) ) );
	reader_merge_value( $css['global']['.footer-nav-section'], Reader_Sanitize::padding( reader_get_settings( 'footer_nav_padding' ) ) );

	// footer Nav border.
	$footer_nav_border = Reader_Sanitize::border( reader_get_settings( 'footer_nav_border' ) );
	$css['global']['.footer-nav-section'][ $footer_nav_border ['direction'] ] = $footer_nav_border ['value'];

	// footer Nav alignment.
	$footer_nav_align = reader_get_settings( 'footer_nav_alignment' );
	if ( 'left' === $footer_nav_align ) :
		$css['global']['.footer-nav-section']['text-align'] = 'left';
	elseif ( 'center' === $footer_nav_align ) :
		$css['global']['.footer-nav-section']['text-align'] = 'center';
	elseif ( 'right' === $footer_nav_align ) :
		$css['global']['.footer-nav-section']['text-align'] = 'right';
	endif;

	// footer Nav menu item.
	reader_merge_value( $css['global']['.footer-nav-container li a'], Reader_Sanitize::margin( reader_get_settings( 'footer_menu_item_margin' ) ) );

	// footer Nav separator.
	reader_merge_value( $css['global']['.footer-nav-container .footer-separator'], Reader_Sanitize::margin( reader_get_settings( 'footer_nav_separator_margin' ) ) );
	$css['global']['.footer-nav-container .footer-separator']['color'] = Reader_Sanitize::color( reader_get_settings( 'footer_nav_separator_color' ) );

	// Footer Logo Social icons.
	if ( 1 === reader_get_settings( 'footer_logo_social_icons' ) && ! empty( reader_get_settings( 'footer_logo_social' ) ) && is_array( reader_get_settings( 'footer_logo_social' ) ) ) :
		$footer_nav_icons = reader_get_settings( 'footer_logo_social' );
		foreach ( $footer_nav_icons as $footer_nav_icon ) :
			$footer_icons[]               = $footer_nav_icon['footer_logo_social_icon'];
			$footer_nav_icon_border_size  = $footer_nav_icon['footer_logo_social_border_size'];
			$footer_nav_icon_border_style = $footer_nav_icon['footer_logo_social_border_style'];
			$footer_nav_icon_border_color = $footer_nav_icon['footer_logo_social_border_color'];
			$footer_nav_icon_border       = $footer_nav_icon_border_size . 'px ' . $footer_nav_icon_border_style . ' ' . $footer_nav_icon_border_color;
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ]['background-color']            = Reader_Sanitize::color( $footer_nav_icon['footer_logo_social_bgcolor'] );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] . ':hover' ]['background-color'] = Reader_Sanitize::color( $footer_nav_icon['footer_logo_social_hover_bgcolor'] );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ]['color']                       = Reader_Sanitize::color( $footer_nav_icon['footer_logo_social_color'] );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] . ':hover' ]['color']            = Reader_Sanitize::color( $footer_nav_icon['footer_logo_social_hover_color'] );
			reader_merge_value( $css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ], Reader_Sanitize::margin( $footer_nav_icon['footer_logo_social_margin'] ) );
			reader_merge_value( $css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ], Reader_Sanitize::padding( $footer_nav_icon['footer_logo_social_padding'] ) );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ]['border-radius'] = Reader_Sanitize::size( $footer_nav_icon['footer_logo_social_border_radius'] . 'px' );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ]['border']        = $footer_nav_icon_border;
		endforeach;
	endif;

	// Footer Nav Social icons font size.
	if ( ! empty( $footer_icons ) && is_array( $footer_icons ) ) :
		foreach ( $footer_icons as $footer_icon ) :
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_icon ]['font-size'] = Reader_Sanitize::size( reader_get_settings( 'footer_logo_social_font_size' ) . 'px' );
		endforeach;
	endif;

	// Footer Brands Sections.
	$brands_border = Reader_Sanitize::border( reader_get_settings( 'brands_border' ) );
	$css['global']['.brands-container'][ $brands_border ['direction'] ] = $brands_border ['value'];

	// footer brands alignment.
	$footer_brands_align = reader_get_settings( 'footer_brands_alignment' );
	if ( 'center' === $footer_brands_align ) :
		$css['global']['.brands-container']['justify-content'] = 'center';
	elseif ( 'right' === $footer_brands_align ) :
		$css['global']['.brands-container']['justify-content'] = 'flex-end';
	endif;

	// brand container.
	reader_merge_value( $css['global']['.brands-container'], Reader_Sanitize::margin( reader_get_settings( 'brands_margin' ) ) );
	reader_merge_value( $css['global']['.brands-container'], Reader_Sanitize::padding( reader_get_settings( 'brands_padding' ) ) );

}

/**
 * Misc
 *
 * @param array $css Array of dynamic CSS.
 */
function reader_misc_css( &$css ) {

	// Show Logo.
	$show_logo = reader_get_settings( 'hide_logo' );

	if ( 0 === $show_logo ) {
		$css['global']['.logo-wrap']['display'] = 'none';
	}

	// Back to top.
	// Border.
	$top_button_border = Reader_Sanitize::border( reader_get_settings( 'top_button_border' ) );
	$css['global']['#move-to-top'][ $top_button_border ['direction'] ] = $top_button_border ['value'];
	// Font-size, Padding and Position.
	$css['global']['#move-to-top .fa']['font-size'] = Reader_Sanitize::size( reader_get_settings( 'top_button_font_size' ) . 'px' );
	reader_merge_value( $css['global']['#move-to-top'], Reader_Sanitize::padding( reader_get_settings( 'top_button_padding' ) ) );
	$top_button_position = reader_get_settings( 'top_button_position' );
	foreach ( $top_button_position as $key => $position ) {
		$css['global']['#move-to-top'][ $key ] = $position;
	}
	// Border-radius.
	$css['global']['#move-to-top']['border-radius'] = Reader_Sanitize::size( reader_get_settings( 'top_button_border_radius' ) . 'px' );
	// Colors.
	$css['global']['#move-to-top']['color']            = Reader_Sanitize::color( reader_get_settings( 'top_button_color' ) );
	$css['global']['#move-to-top:hover']['color']      = Reader_Sanitize::color( reader_get_settings( 'top_button_color_hover' ) );
	$css['global']['#move-to-top']['background']       = Reader_Sanitize::color( reader_get_settings( 'top_button_background' ) );
	$css['global']['#move-to-top:hover']['background'] = Reader_Sanitize::color( reader_get_settings( 'top_button_background_hover' ) );
}
