<?php

/**
 * Site Logo
 *
 * @param array $args
 * @return void
 */
function reader_logo( $args = array(), $loc = 'mts' ) {

	$reader_logo = wp_get_attachment_url( reader_get_settings( $loc . '_logo' ) );
	$h_tag       = 'h2';
	$logo_type   = 'text-logo';

	if ( is_front_page() || is_home() || is_404() ) {
		$h_tag = 'h1';
	}

	if ( ! empty( $reader_logo ) ) {
		$logo_type = 'image-logo';
	}

	$defaults = array(
		'logo'   => $reader_logo,
		'url'    => esc_url( home_url() ),
		'title'  => get_bloginfo( 'name' ),
		'before' => '<' . $h_tag . ' id="logo" class="' . $logo_type . ' clearfix" itemprop="headline">',
		'after'  => '</' . $h_tag . '>',
	);

	$args = wp_parse_args( $args, $defaults );

	$output = $args['logo'] ? sprintf( '<img src="' . $args['logo'] . '" alt="' . esc_attr( $args['title'] ) . '">' ) : $args['title'];
	$output = sprintf( '<a href="%1$s">%2$s</a>', $args['url'], $output );

	echo wp_kses_post( $args['before'] ) . $output . wp_kses_post( $args['after'] );
}

function single_next_post_logo( $args = array() ) {

	$reader_logo = wp_get_attachment_url( reader_get_settings( 'mts_logo' ) );
	$logo_type   = 'text-logo';
	if ( ! empty( $reader_logo ) ) {
		$logo_type = 'image-logo';
	}

	$defaults = array(
		'logo'   => $reader_logo,
		'url'    => esc_url( home_url() ),
		'title'  => get_bloginfo( 'name' ),
		'before' => '<div class="logo ' . $logo_type . ' clearfix" itemprop="headline">',
		'after'  => '</div>',
	);

	$args = wp_parse_args( $args, $defaults );

	$output = $args['logo'] ? sprintf( '<img src="' . $args['logo'] . '" alt="' . esc_attr( $args['title'] ) . '">' ) : $args['title'];
	$output = sprintf( '<a href="%1$s">%2$s</a>', $args['url'], $output );

	echo wp_kses_post( $args['before'] ) . $output . wp_kses_post( $args['after'] );
}

/**
 * Template functions that the framework or themes may use.
 */

/**
 * Single Post Header Layout type (Parallax or Zoomout) *
 */
function reader_single_featured_image_effect() {

	$header_animation = reader_get_post_header_effect();

	if ( has_post_thumbnail() ) {
		if ( 'parallax' === $header_animation ) {
			echo '<div id="parallax" style="background-image: url(' . get_the_post_thumbnail_url( get_the_ID(), 'full' ) . ');"></div>';
		} elseif ( 'zoomout' === $header_animation ) {
			echo '<div id="zoom-out-effect"><div id="zoom-out-bg" style="background-image: url(' . get_the_post_thumbnail_url( get_the_ID(), 'full' ) . ');"></div></div>';
		}
	}

}

/**
 * Display reader-compliant the_tags()
 *
 * @param string $before
 * @param string $sep
 * @param string $after
 */
if ( ! function_exists( 'reader_post_tags' ) ) {
	function reader_post_tags( $before = '', $sep = ', ', $after = '</div>' ) {
		if ( empty( $before ) ) {
			$before = '<div class="tags border-bottom">' . esc_html__( 'Tags: ', 'reader' );
		}
		$tags = get_the_tags();
		if ( empty( $tags ) || is_wp_error( $tags ) ) {
			return;
		}
		$tag_links = array();
		foreach ( $tags as $tag ) {
			$link        = get_tag_link( $tag->term_id );
			$tag_links[] = '<a href="' . esc_url( $link ) . '" rel="tag">' . $tag->name . '</a>';
		}
		echo $before . join( $sep, $tag_links ) . $after;
	}
}

/**
 * Returns true if a blog has more than 1 category.
 *
 * @return bool
 */
function reader_categorized_blog() {
	$category_count = get_transient( 'reader_categories' );

	if ( false === $category_count ) {
		// Create an array of all the categories that are attached to posts.
		$categories = get_categories( array(
			'fields'     => 'ids',
			'hide_empty' => 1,
			// We only need to know if there is more than one category.
			'number'     => 2,
		) );

		// Count the number of categories that are attached to the posts.
		$category_count = count( $categories );

		set_transient( 'reader_categories', $category_count );
	}

	return $category_count > 1;
}

/**
 * Display the post info block.
 *
 * @param string $section
 */
function reader_the_post_meta( $section = 'home', $groupid = '' ) {

	$enabled_metas = reader_get_settings( 'mts_' . $section . '_headline_meta_info' . $groupid );
	$enabled_metas = isset( $enabled_metas['enabled'] ) ? $enabled_metas['enabled'] : array();

	if ( ! empty( $enabled_metas ) ) :
	?>
		<div class="post-info">
			<?php
			foreach ( $enabled_metas as $key => $title ) {
				if ( 'single' === $section ) :
					$pagename = '_single';
					$suffix   = '';
				else :
					$pagename = '';
					$suffix   = '_';
				endif;

				$author_icon = ( reader_get_settings( 'mts' . $pagename . '_meta_info_author_icon' . $suffix . $groupid ) ) ? '<i class="fa fa-' . reader_get_settings( 'mts' . $pagename . '_meta_info_author_icon' . $suffix . $groupid ) . '"></i>' : '';

				$date_icon = ( reader_get_settings( 'mts' . $pagename . '_meta_info_date_icon' . $suffix . $groupid ) ) ? '<i class="fa fa-' . reader_get_settings( 'mts' . $pagename . '_meta_info_date_icon' . $suffix . $groupid ) . '"></i>' : '';

				$category_icon = ( reader_get_settings( 'mts' . $pagename . '_meta_info_category_icon' . $suffix . $groupid ) ) ? '<i class="fa fa-' . reader_get_settings( 'mts' . $pagename . '_meta_info_category_icon' . $suffix . $groupid ) . '"></i>' : '';

				$comment_icon = ( reader_get_settings( 'mts' . $pagename . '_meta_info_comment_icon' . $suffix . $groupid ) ) ? '<i class="fa fa-' . reader_get_settings( 'mts' . $pagename . '_meta_info_comment_icon' . $suffix . $groupid ) . '"></i>' : '';

				switch ( $key ) {

					case 'author':
						printf( '<span class="theauthor">%1$s <span>%2$s</span></span>', $author_icon, get_the_author_posts_link() );
						break;

					case 'date':
						printf( '<span class="thetime date updated">%1$s <span>%2$s</span></span>', $date_icon, get_the_time( get_option( 'date_format' ) ) );
						break;

					case 'category':
						printf( '<span class="thecategory">%1$s %2$s</span>', $category_icon, reader_get_the_category( ', ' ) );
						break;

					case 'comment':
						printf( '<span class="thecomment">%1$s <a href="%2$s" itemprop="interactionCount">%3$s</a></span>', $comment_icon, esc_url( get_comments_link() ), get_comments_number_text() );
						break;
				}
			}
			?>
		</div>
	<?php
	endif;
}

/**
 * Display reader-compliant the_category()
 *
 * @param string $separator
 */
function reader_get_the_category( $separator = ', ' ) {
	$categories = get_the_category();

	if ( empty( $categories ) ) {
		return;
	}

	global $wp_rewrite;

	$links = array();
	$rel   = ( is_object( $wp_rewrite ) && $wp_rewrite->using_permalinks() ) ? 'rel="category tag"' : 'rel="category"';

	foreach ( $categories as $category ) {

		$links[] = sprintf(
			'<a href="%1$s" title="%2$s" %3$s>%4$s</a>',
			esc_url( get_category_link( $category->term_id ) ),
			// translators: category name.
			sprintf( esc_html__( 'View all posts in %s', 'reader' ), esc_attr( $category->name ) ),
			$rel,
			esc_html( $category->name )
		);
	}

	return join( $separator, $links );
}

/**
 * Display the pagination.
 *
 * @param string $nav_type
 */
function reader_pagination( $nav_type = '' ) {

	if ( 1 === $GLOBALS['wp_query']->max_num_pages ) {
		return;
	}

	if ( 1 === $nav_type ) { // Numeric pagination.
		the_posts_pagination( array(
			'mid_size'  => 3,
			'prev_text' => '<i class="fa fa-chevron-left"></i>',
			'next_text' => '<i class="fa fa-chevron-right"></i>',
		) );
	} else { // traditional or ajax pagination.
		?>
		<div class="pagination pagination-previous-next">
			<ul>
				<li class="nav-previous"><?php next_posts_link( '<i class="fa fa-chevron-left"></i> ' . esc_html__( 'Previous', 'reader' ) ); ?></li>
				<li class="nav-next"><?php previous_posts_link( esc_html__( 'Next', 'reader' ) . ' <i class="fa fa-chevron-right"></i>' ); ?></li>
			</ul>
		</div>
		<?php
	}
}

/**
 * Display social icons
 * @param  array  $data
 * @return html
 */
function reader_social_icons( $data = array(), $echo = false ) {

	if ( empty( $data ) ) {
		return;
	}

	$out = '<div class="header-social-icons">';
	foreach ( $data as $item ) {
		$out .= sprintf(
			'<a href="%1$s" title="%2$s" class="header-%3$s" target="_blank"><span class="fa fa-%3$s"></span></a>',
			$item['header_icon_link'],
			$item['header_icon_title'],
			$item['header_icon']
		);
	}

	$out .= '</div>';

	if ( $echo ) {
		echo $out;
	} else {
		return $out;
	}
}

/**
 * Create and show column for featured image in the post list of admin page
 * @param $post_id
 * @return string url
 */
if ( ! function_exists( 'reader_get_featured_image' ) ) {
	function reader_get_featured_image( $post_id ) {
		if ( $post_thumbnail_id = get_post_thumbnail_id( $post_id ) ) { // @codingStandardsIgnoreLine
			$post_thumbnail_img = wp_get_attachment_image_src( $post_thumbnail_id, 'reader-widgetfull' );
			return $post_thumbnail_img[0];
		}
	}
}

/**
 * Adds a `Featured Image` column header in the Post list of admin page
 *
 * @param array $defaults
 * @return array
 */
if ( ! function_exists( 'reader_columns_head' ) ) {
	function reader_columns_head( $defaults ) {
		if ( 'post' === get_post_type() ) {
			$defaults['featured_image'] = __( 'Featured Image', 'reader' );
		}

		return $defaults;
	}
}
add_filter( 'manage_posts_columns', 'reader_columns_head' );

/**
 * Adds a `Featured Image` column row value in the Post list of admin page
 *
 * @param string $column_name The name of the column to display.
 * @param int $post_id The ID of the current post.
 */
if ( ! function_exists( 'reader_columns_content' ) ) {
	function reader_columns_content( $column_name, $post_id ) {
		if ( 'featured_image' === $column_name ) {
			if ( $post_featured_image = reader_get_featured_image( $post_id ) ) { // @codingStandardsIgnoreLine
				echo '<img width="150" height="100" src="' . esc_url( $post_featured_image ) . '" />';
			}
		}
	}
}
add_action( 'manage_posts_custom_column', 'reader_columns_content', 10, 2 );

/**
 * Add data-layzr attribute to featured image ( for lazy load )
 *
 * @param array $attr
 * @param WP_Post $attachment
 * @param string|array $size
 *
 * @return array
 */
if ( ! function_exists( 'reader_image_lazy_load_attr' ) ) {
	function reader_image_lazy_load_attr( $attr, $attachment, $size ) {
		if ( is_admin() || is_feed() ) {
			return $attr;
		}

		if ( 'reader-slider' === $size && is_home() ) {
			return $attr;
		}

		if ( ! empty( reader_get_settings( 'reader_lazy_load' ) ) && ! empty( reader_get_settings( 'reader_lazy_load_thumbs' ) ) ) {
			$attr['data-layzr'] = $attr['src'];
			$attr['src']        = '';
			if ( isset( $attr['srcset'] ) ) {
				$attr['data-layzr-srcset'] = $attr['srcset'];
				$attr['srcset']            = '';
			}
		}

		return $attr;
	}
}
add_filter( 'wp_get_attachment_image_attributes', 'reader_image_lazy_load_attr', 10, 3 );

/**
 * Add data-layzr attribute to post content images ( for lazy load )
 *
 * @param string $content
 *
 * @return string
 */

function reader_content_image_lazy_load_attr( $content ) {
	if (
		! empty( reader_get_settings( 'reader_lazy_load' ) ) &&
		! empty( reader_get_settings( 'reader_lazy_load_content' ) ) &&
		! empty( $content )
	) {
		$content = preg_replace_callback(
			'/<img([^>]+?)src=[\'"]?([^\'"\s>]+)[\'"]?([^>]*)>/',
			'reader_content_image_lazy_load_attr_callback',
			$content
		);
	}

	return $content;
}
add_filter( 'the_content', 'reader_content_image_lazy_load_attr' );

/**
 * Callback to move src to data-src and replace it with a 1x1 tranparent image.
 *
 * @param $matches
 *
 * @return string
 */
if ( ! function_exists( 'reader_content_image_lazy_load_attr_callback' ) ) {
	function reader_content_image_lazy_load_attr_callback( $matches ) {
		$transparent_img = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';
		if ( preg_match( '/ data-lazy *= *"false" */', $matches[0] ) ) {
			return '<img' . $matches[1] . 'src="' . $matches[2] . '"' . $matches[3] . '>';
		} else {
			return '<img' . $matches[1] . 'src="' . $transparent_img . '" data-layzr="' . $matches[2] . '"' . str_replace( 'srcset=', 'data-layzr-srcset=', $matches[3] ) . '>';
		}
	}
}

/**
 * Footer Widget Columns
 *
 * @return string
 */
function reader_footer_widget_columns() {

	$footer_columns = intval( reader_get_settings( 'mts_top_footer_num' ) );

	if ( ! $footer_columns ) {
		return;
	}
	?>

		<div class="footer-widgets first-footer-widgets widgets-num-<?php echo esc_attr( $footer_columns ); ?>">
			<?php
			for ( $i = 1; $i <= $footer_columns; $i++ ) :

				$class = '';
				if ( $i === $footer_columns ) {
					$class = ' last';
				} elseif ( 1 === $i ) {
					$class = ' first';
				}
			?>
				<div class="f-widget f-widget-<?php echo esc_attr( $i ) . esc_attr( $class ); ?>">
					<?php dynamic_sidebar( 'footer-top-' . $i ); ?>
				</div>
			<?php endfor; ?>
		</div><!--.first-footer-widgets-->

	<?php
}

/**
 * Copyrights section
 *
 * @return string
 */
function reader_footer_copyrights() {
	$content = reader_get_settings( 'mts_copyrights' );

	$copyright_text = '<a href=" ' . esc_url( trailingslashit( home_url() ) ) . '" title=" ' . get_bloginfo( 'description' ) . '">' . get_bloginfo( 'name' ) . '</a> ' . __( 'Copyright', 'reader' ) . ' &copy; ' . date( 'Y' ) . '.';
	?>
	<div class="copyrights">
		<div class="container">
			<?php //get_template_part( 'template-parts/footer/footer', 'nav' ); ?>
			<div class="row" id="copyright-note">
				<span><?php echo $copyright_text; ?></span>
				<div class="to-top"><?php echo $content; ?></div>
			</div>
		</div>
	</div>
	<?php
}

/**
 * Reader display comments
 */
function reader_display_comments() {
	// If comments are open or we have at least one comment, load up the comment template.
	if ( comments_open() || 0 !== intval( get_comments_number() ) ) :
		comments_template();
	endif;
}

if ( ! function_exists( 'reader_comments' ) ) {
	/**
	 * Custom comments template.
	 *
	 * @param array $comment    get comment.
	 * @param array $args
	 * @param int   $depth    child depth.
	 */
	function reader_comments( $comment, $args, $depth ) {
	?>
		<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
			<?php
			switch ( $comment->comment_type ) :
				case 'pingback':
				case 'trackback':
				?>
					<div id="comment-<?php comment_ID(); ?>">
						<div class="comment-author vcard">
							Pingback: <?php comment_author_link(); ?>
							<?php if ( ! empty( reader_get_settings( 'mts_comment_date' ) ) ) { ?>
								<span class="ago"><?php comment_date( get_option( 'date_format' ) ); ?></span>
							<?php } ?>
							<span class="comment-meta">
								<?php edit_comment_link( __( '( Edit )', 'reader' ), '  ', '' ); ?>
							</span>
						</div>
						<?php if ( '0' === $comment->comment_approved ) : ?>
							<em><?php esc_html_e( 'Your comment is awaiting moderation.', 'reader' ); ?></em>
							<br />
						<?php endif; ?>
					</div>
				<?php
					break;

				default:
				?>
					<div id="comment-<?php comment_ID(); ?>" itemscope itemtype="http://schema.org/UserComments">
						<div class="comment-author vcard">
							<?php echo get_avatar( $comment->comment_author_email, 72 ); ?>
							<?php printf( '<span class="fn" itemprop="creator" itemscope itemtype="http://schema.org/Person"><span itemprop="name">%s</span></span>', get_comment_author_link() ); ?>
							<?php if ( ! empty( reader_get_settings( 'mts_comment_date' ) ) ) { ?>
								<span class="ago"><?php comment_date( get_option( 'date_format' ) ); ?></span>
							<?php } ?>
							<span class="comment-meta">
								<?php edit_comment_link( __( '( Edit )', 'reader' ), '  ', '' ); ?>
							</span>
							<div class="reply">
								<?php
								comment_reply_link( array_merge( $args, array(
									'depth'     => $depth,
									'max_depth' => $args['max_depth'],
								) ) );
								?>
							</div>
						</div>
						<?php if ( '0' === $comment->comment_approved ) : ?>
							<em><?php esc_html_e( 'Your comment is awaiting moderation.', 'reader' ); ?></em>
							<br />
						<?php endif; ?>
						<div class="commentmetadata">
							<div class="commenttext" itemprop="commentText">
								<?php comment_text(); ?>
							</div>
						</div>
					</div>
				<?php
					break;
			endswitch;
			?>
	<!-- WP adds </li> -->
	<?php
	}
}

/**
 * Display a "read more" link.
 */
function reader_readmore() {
	?>
	<div class="readMore">
		<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php esc_html_e( 'Continue Reading', 'reader' ); ?><i class="fa fa-long-arrow-right"></i></a>
	</div>
	<?php
}

if ( ! function_exists( 'reader_the_postinfo_item' ) ) {
	/**
	 * Display information of an item.
	 *
	 * @param $item
	*/
	function reader_the_postinfo_item( $item ) {

		$hash = array(
			'author'   => '<span class="theauthor"><i class="fa fa-user"></i> <span>' . get_the_author_posts_link() . '</span></span>',
			'date'     => '<span class="thetime date updated"><i class="fa fa-calendar"></i> <span>' . get_the_time( get_option( 'date_format' ) ) . '</span></span>',
			'category' => '<span class="thecategory"><i class="fa fa-tags"></i> ' . reader_get_the_category( ', ' ) . '</span>',
			'comment'  => '<span class="thecomment"><i class="fa fa-comments"></i> <a href="' . esc_url( get_comments_link() ) . '" itemprop="interactionCount"><?php comments_number();?></a></span>',
		);

		return isset( $hash[ $item ] ) ? $hash[ $item ] : '';
	}
}

if ( ! function_exists( 'reader_breadcrumbs' ) ) {
	/**
	 * Display the breadcrumbs.
	 */
	function reader_breadcrumbs() {
		if ( is_front_page() ) {
				return;
		}

		if ( function_exists( 'rank_math_the_breadcrumbs' ) && RankMath\Helper::get_settings( 'general.breadcrumbs' ) ) {
			rank_math_the_breadcrumbs();
			return;
		}

		//$arrow = reader_get_settings( 'breadcrumb_icon' );
		echo '<div class="breadcrumb" xmlns:v="http://rdf.data-vocabulary.org/#">';
		echo '<div typeof="v:Breadcrumb" class="root"><a rel="v:url" property="v:title" href="';
		echo esc_url( home_url() );
		echo '">' . esc_html( sprintf( __( 'Home', 'reader' ) ) );
		echo '</a></div><div class="separator">/</div>';
		if ( is_single() ) {
			$categories = get_the_category();
			if ( $categories ) {
				$level         = 0;
				$hierarchy_arr = array();
				foreach ( $categories as $cat ) {
					$anc       = get_ancestors( $cat->term_id, 'category' );
					$count_anc = count( $anc );
					if ( 0 < $count_anc && $level < $count_anc ) {
						$level         = $count_anc;
						$hierarchy_arr = array_reverse( $anc );
						array_push( $hierarchy_arr, $cat->term_id );
					}
				}
				if ( empty( $hierarchy_arr ) ) {
					$category = $categories[0];
					echo '<div typeof="v:Breadcrumb"><a href="' . esc_url( get_category_link( $category->term_id ) ) . '" rel="v:url" property="v:title">' . esc_html( $category->name ) . '</a></div><div class="separator">/</div>';
				} else {
					foreach ( $hierarchy_arr as $cat_id ) {
						$category = get_term_by( 'id', $cat_id, 'category' );
						echo '<div typeof="v:Breadcrumb"><a href="' . esc_url( get_category_link( $category->term_id ) ) . '" rel="v:url" property="v:title">' . esc_html( $category->name ) . '</a></div><div class="separator">/</div>';
					}
				}
			}
			echo '<div><span>';
			the_title();
			echo '</span></div></div>';
		} elseif ( is_page() ) {
			$parent_id = wp_get_post_parent_id( get_the_ID() );
			if ( $parent_id ) {
				$breadcrumbs = array();
				while ( $parent_id ) {
					$page          = get_page( $parent_id );
					$breadcrumbs[] = '<div typeof="v:Breadcrumb"><a href="' . esc_url( get_permalink( $page->ID ) ) . '" rel="v:url" property="v:title">' . esc_html( get_the_title( $page->ID ) ) . '</a></div><div class="separator">/</div>';
					$parent_id     = $page->post_parent;
				}
				$breadcrumbs = array_reverse( $breadcrumbs );
				foreach ( $breadcrumbs as $crumb ) {
					echo $crumb;
				}
			}
				echo '<div><span>';
				the_title();
				echo '</span></div></div>';
		} elseif ( is_category() ) {
			global $wp_query;
			$cat_obj       = $wp_query->get_queried_object();
			$this_cat_id   = $cat_obj->term_id;
			$hierarchy_arr = get_ancestors( $this_cat_id, 'category' );
			if ( $hierarchy_arr ) {
				$hierarchy_arr = array_reverse( $hierarchy_arr );
				foreach ( $hierarchy_arr as $cat_id ) {
					$category = get_term_by( 'id', $cat_id, 'category' );
					echo '<div typeof="v:Breadcrumb"><a href="' . esc_url( get_category_link( $category->term_id ) ) . '" rel="v:url" property="v:title">' . esc_html( $category->name ) . '</a></div><div class="separator">/</div>';
				}
			}
			echo '<div><span>';
			single_cat_title();
			echo '</span></div></div>';
		} elseif ( is_author() ) {
			echo '<div><span>';
			if ( get_query_var( 'author_name' ) ) :
				$curauth = get_user_by( 'slug', get_query_var( 'author_name' ) );
			else :
				$curauth = get_userdata( get_query_var( 'author' ) );
			endif;
			echo esc_html( $curauth->nickname );
			echo '</span></div></div>';
		} elseif ( is_search() ) {
			echo '<div><span>';
			the_search_query();
			echo '</span></div></div>';
		} elseif ( is_tag() ) {
			echo '<div><span>';
			single_tag_title();
			echo '</span></div></div>';
		}

		//echo '</div>';
	}
}

if ( ! empty( reader_get_settings( 'mts_feedburner' ) ) ) {
	/**
	 * Redirect feed to FeedBurner if a FeedBurner URL has been set.
	 */
	function reader_rss_feed_redirect() {
		global $feed;
		$new_feed = reader_get_settings( 'mts_feedburner' );
		if ( ! is_feed() ) {
				return;
		}
		if ( preg_match( '/feedburner/i', $_SERVER['HTTP_USER_AGENT'] ) ) {
				return;
		}
		if ( 'comments-rss2' != $feed ) {
				if ( function_exists( 'status_header' ) ) status_header( 302 );
				header( "Location:" . $new_feed );
				header( "HTTP/1.1 302 Temporary Redirect" );
				exit();
		}
	}
	add_action( 'template_redirect', 'reader_rss_feed_redirect' );
}

if ( ! function_exists( 'reader_related_posts' ) ) {
	/**
	 * Display the related posts.
	 */
	function reader_related_posts() {
		$post_id = get_the_ID();

		if ( ! empty( reader_get_settings( 'mts_single_post_layout' )['enabled']['related'] ) ) {
			$empty_taxonomy = false;
			if ( empty( reader_get_settings( 'mts_related_posts_taxonomy' ) ) || reader_get_settings( 'mts_related_posts_taxonomy' ) == 'tags' ) {
				// related posts based on tags
				$tags = get_the_tags( $post_id );
				if ( empty( $tags ) ) {
					$empty_taxonomy = true;
				} else {
					$tag_ids = array();
					foreach ( $tags as $individual_tag ) {
						$tag_ids[] = $individual_tag->term_id;
					}
					$args = array(
						'tag__in'             => $tag_ids,
						'post__not_in'        => array( $post_id ),
						'posts_per_page'      => ( null !== reader_get_settings( 'mts_related_postsnum' ) ) ? reader_get_settings( 'mts_related_postsnum' ) : 3,
						'ignore_sticky_posts' => 1,
						'orderby'             => 'rand',
					);
				}
			} else {
				// related posts based on categories
				$categories = get_the_category( $post_id );
				if ( empty( $categories ) ) {
					$empty_taxonomy = true;
				} else {
					$category_ids       = array();
					foreach ( $categories as $individual_category )
						$category_ids[] = $individual_category->term_id;
					$args               = array(
						'category__in'        => $category_ids,
						'post__not_in'        => array( $post_id ),
						'posts_per_page'      => reader_get_settings( 'mts_related_postsnum' ),
						'ignore_sticky_posts' => 1,
						'orderby'             => 'rand',
					);
				}
			}
			if ( ! $empty_taxonomy ) {
				$my_query = new WP_Query( $args );
				if ( $my_query->have_posts() ) {

					$title = reader_get_settings( 'related_post_title' ) ? reader_get_settings( 'related_post_title' ) : __( 'Related Posts', 'reader' );

					$related_posts_layouts = ! empty( reader_get_settings( 'related_posts_layouts' ) ) ? reader_get_settings( 'related_posts_layouts' ) : 'default';

					$grid = ! empty( reader_get_settings( 'related_posts_grid' ) ) && 'default' === $related_posts_layouts ? 'flex-grid ' . reader_get_settings( 'related_posts_grid' ) : 'flex-grid default';

					$position = ! empty( reader_get_settings( 'related_posts_position' ) ) ? reader_get_settings( 'related_posts_position' ) : 'default';
					echo '<div class="related-posts ' . $related_posts_layouts . ' position-' . $position . ' ">';
					echo ( 'full' === $position ) ? '<div class="container">' : '';
					echo '<div class="related-posts-title"><h4>' . $title . '</h4></div>';
					echo '<div class="related-posts-container clear">';
					$posts_per_row = 3;
					$j = 0;
					while ( $my_query->have_posts() ) { $my_query->the_post();
						$post_meta_info = reader_get_settings( 'related_post_meta_info' );
						switch ( $related_posts_layouts ) {
							case 'default':
							case 'related2':
							?>
								<article class="latestPost excerpt <?php echo $grid; ?>">
									<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php the_title_attribute(); ?>" id="featured-thumbnail">
										<div class="featured-thumbnail">
											<?php the_post_thumbnail( 'reader-related', array( 'title' => '' ) ); ?>
										</div>
										<?php if ( function_exists( 'wp_review_show_total' ) ) wp_review_show_total( true, 'latestPost-review-wrapper' ); ?>
									</a>
									<header>
										<h2 class="title front-view-title"><a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
										<?php
										if ( isset( $post_meta_info['author'] ) || isset( $post_meta_info['time'] ) || isset( $post_meta_info['category'] ) || isset( $post_meta_info['comment'] ) ) : ?>
											<div class="post-info">
												<?php
												if ( isset( $post_meta_info['author'] ) ) :
													printf( '<span class="theauthor"><span>%s</span></span>', get_the_author_posts_link() );
												endif;
												if ( isset( $post_meta_info['time'] ) ) :
													printf( '<span class="thetime date updated"><span>%s</span></span>', get_the_time( get_option( 'date_format' ) ) );
												endif;
												if ( isset( $post_meta_info['category'] ) ) :
													printf( '<span class="thecategory">' . __( 'In ', 'reader' ) . '%s</span>', reader_get_the_category( ', ' ) );
												endif;
												if ( isset( $post_meta_info['comment'] ) ) :
													printf( '<span class="thecomment">%s</span>', get_comments_number_text() );
												endif;
												?>
											</div>
										<?php endif; ?>
									</header>
									<div class="front-view-content">
										<?php
										if ( empty( reader_excerpt() ) ) {
											echo reader_truncate( get_the_content(), 18, 'words' );
										} else {
											echo reader_excerpt( 18 );
										}
										?>
									</div>
								</article><!--.post.excerpt-->
							<?php
							break;

							case 'related3':
							?>
								<article class="latestPost excerpt <?php echo $grid; ?>">
									<header>
										<h2 class="title front-view-title"><a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
										<?php
										if ( isset( $post_meta_info['author'] ) || isset( $post_meta_info['time'] ) || isset( $post_meta_info['category'] ) || isset( $post_meta_info['comment'] ) ) : ?>
											<div class="post-info">
												<?php
												if ( isset( $post_meta_info['author'] ) ) :
													printf( '<span class="theauthor"><span>%s</span></span>', get_the_author_posts_link() );
												endif;
												if ( isset( $post_meta_info['time'] ) ) :
													printf( '<span class="thetime date updated"><span>%s</span></span>', get_the_time( get_option( 'date_format' ) ) );
												endif;
												if ( isset( $post_meta_info['category'] ) ) :
													printf( '<span class="thecategory">%s</span>', reader_get_the_category( ' ' ) );
												endif;
												if ( isset( $post_meta_info['comment'] ) ) :
													printf( '<span class="thecomment">%s</span>', get_comments_number_text() );
												endif;
												?>
											</div>
										<?php endif; ?>
									</header>
								</article><!--.post.excerpt-->
							<?php
							break;

							case 'related5':
							?>
								<article class="latestPost excerpt flex-grid grid2">
									<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php the_title_attribute(); ?>" id="featured-thumbnail">
										<div class="featured-thumbnail">
											<?php the_post_thumbnail( 'reader-related', array( 'title' => '' ) ); ?>
										</div>
										<?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
									</a>
									<header>
										<h2 class="title front-view-title"><a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
										<?php
										if ( isset( $post_meta_info['author'] ) || isset( $post_meta_info['time'] ) || isset( $post_meta_info['category'] ) || isset( $post_meta_info['comment'] ) ) : ?>
											<div class="post-info">
												<?php
												if ( isset( $post_meta_info['author'] ) ) :
													printf( '<span class="theauthor"><span>%s</span></span>', get_the_author_posts_link() );
												endif;
												if ( isset( $post_meta_info['time'] ) ) :
													printf( '<span class="thetime date updated"><span>%s</span></span>', get_the_time( get_option( 'date_format' ) ) );
												endif;
												if ( isset( $post_meta_info['category'] ) ) :
													printf( '<span class="thecategory">%s</span>', reader_get_the_category( ' ' ) );
												endif;
												if ( isset( $post_meta_info['comment'] ) ) :
													printf( '<span class="thecomment">%s</span>', get_comments_number_text() );
												endif;
												?>
											</div>
										<?php endif; ?>
									</header>
								</article><!--.post.excerpt-->
								<?php
								if ( 1 === ++$j ) {
									$ad_code = reader_get_settings( 'related_posts_adcode' );
									if ( empty( trim( $ad_code ) ) ) {
										return;
									}
									?>
									<div class="related-posts-ad">
										<?php echo do_shortcode( $ad_code ); ?>
									</div>
								<?php
								}
							break;

							case 'related6':
							?>
							<article class="latestPost excerpt <?php echo $grid; ?>">
								<header>
									<h2 class="title front-view-title"><a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
									<?php
									if ( isset( $post_meta_info['author'] ) || isset( $post_meta_info['time'] ) || isset( $post_meta_info['category'] ) || isset( $post_meta_info['comment'] ) ) : ?>
										<div class="post-info">
											<?php
											if ( isset( $post_meta_info['author'] ) ) :
												printf( '<span class="theauthor"><span>%s</span></span>', get_the_author_posts_link() );
											endif;
											if ( isset( $post_meta_info['time'] ) ) :
												printf( '<span class="thetime date updated"><span>%s</span></span>', get_the_time( get_option( 'date_format' ) ) );
											endif;
											if ( isset( $post_meta_info['category'] ) ) :
												printf( '<span class="thecategory">%s</span>', reader_get_the_category( ' ' ) );
											endif;
											if ( isset( $post_meta_info['comment'] ) ) :
												printf( '<span class="thecomment">%s</span>', get_comments_number_text() );
											endif;
											?>
										</div>
									<?php endif; ?>
								</header>
							</article><!--.post.excerpt-->
							<?php
							break;

							default:
							?>
							<article class="latestPost excerpt <?php echo $grid; ?>">
								<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php the_title_attribute(); ?>" id="featured-thumbnail">
									<div class="featured-thumbnail">
										<?php the_post_thumbnail( 'reader-related', array( 'title' => '' ) ); ?>
									</div>
									<?php if ( function_exists( 'wp_review_show_total' ) ) wp_review_show_total( true, 'latestPost-review-wrapper' ); ?>
								</a>
								<header>
									<h2 class="title front-view-title"><a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
									<?php
									if ( isset( $post_meta_info['author'] ) || isset( $post_meta_info['time'] ) || isset( $post_meta_info['category'] ) || isset( $post_meta_info['comment'] ) ) : ?>
										<div class="post-info">
											<?php
											if ( isset( $post_meta_info['author'] ) ) :
												printf( '<span class="theauthor"><span>%s</span></span>', get_the_author_posts_link() );
											endif;
											if ( isset( $post_meta_info['time'] ) ) :
												printf( '<span class="thetime date updated"><span>%s</span></span>', get_the_time( get_option( 'date_format' ) ) );
											endif;
											if ( isset( $post_meta_info['category'] ) ) :
												printf( '<span class="thecategory">%s</span>', reader_get_the_category( ' ' ) );
											endif;
											if ( isset( $post_meta_info['comment'] ) ) :
												printf( '<span class="thecomment">%s</span>', get_comments_number_text() );
											endif;
											?>
										</div>
									<?php endif; ?>
								</header>
							</article><!--.post.excerpt-->
							<?php
							break;
						}
					}
					echo '</div>';

					if ( 'related6' === reader_get_settings( 'related_posts_layouts' ) ) {
						$ad_code = reader_get_settings( 'related_posts_adcode' );
						if ( empty( trim( $ad_code ) ) ) {
							return;
						}
						?>
						<div class="related-posts-ad">
							<?php echo do_shortcode( $ad_code ); ?>
						</div>
					<?php
					}

					echo ( 'full' === $position ) ? '</div>' : '';
					echo '</div>';
				}
			}
			wp_reset_postdata();
			?>
		<!-- .related-posts -->
	<?php }
	}
}

/**
 * Display the Social Sharing buttons.
 */
if ( ! function_exists( 'reader_social_buttons' ) ) {
	function reader_social_buttons() {
		$buttons = array();
		$layout  = reader_get_settings( 'social_button_layout' ) ? reader_get_settings( 'social_button_layout' ) : 'default';
		if ( null !== reader_get_settings( 'mts_social_buttons' ) && is_array( reader_get_settings( 'mts_social_buttons' ) ) && array_key_exists( 'enabled', reader_get_settings( 'mts_social_buttons' ) ) ) {
			$buttons = reader_get_settings( 'mts_social_buttons' )['enabled'];
		}
		if ( ! empty( $buttons ) ) {
			switch ( $layout ) {
				case 'default':
					?>
						<div class="shareit shareit-default <?php echo reader_get_settings( 'mts_social_button_position' ); ?>">
							<?php
							foreach ( $buttons as $key => $button ) {
								reader_social_button( $key );
							}
							?>
						</div>
					<?php
					break;

				case 'circular':
					?>
						<div class="shareit shareit-circular <?php echo $layout . ' ' . reader_get_settings( 'mts_social_button_position' ); ?>">
							<?php
							foreach ( $buttons as $key => $button ) {
								reader_social_circular_button( $key );
							}
							?>
						</div>
					<?php
					break;

				case 'standard':
					?>
						<div class="shareit shareit-circular <?php echo $layout . ' ' . reader_get_settings( 'mts_social_button_position' ); ?>">
							<?php
							foreach ( $buttons as $key => $button ) {
								reader_social_circular_button( $key );
							}
							?>
						</div>
					<?php
					break;

				default:
					?>
						<div class="shareit shareit-default <?php echo reader_get_settings( 'mts_social_button_position' ); ?>">
							<?php
							foreach ( $buttons as $key => $button ) {
								reader_social_button( $key );
							}
							?>
						</div>
					<?php
					break;
			}
		}
	}
}
/**
 * Display network-independent sharing buttons.
 *
 * @param $button
 */
if ( ! function_exists( 'reader_social_button' ) ) {
	function reader_social_button( $button ) {
		switch ( $button ) {
			case 'facebookshare':
				?>
				<!-- Facebook Share-->
				<span class="share-item facebooksharebtn">
					<div class="fb-share-button" data-layout="button_count"></div>
				</span>
				<?php
				break;
			case 'twitter':
				?>
				<!-- Twitter -->
				<span class="share-item twitterbtn">
					<a href="https://twitter.com/share" class="twitter-share-button" data-via="<?php echo esc_attr( reader_get_settings( 'mts_twitter_username' ) ); ?>"><?php esc_html_e( 'Tweet', 'reader' ); ?></a>
				</span>
				<?php
				break;
			case 'facebook':
				?>
				<!-- Facebook -->
				<span class="share-item facebookbtn">
					<div id="fb-root"></div>
					<div class="fb-like" data-send="false" data-layout="button_count" data-width="150" data-show-faces="false"></div>
				</span>
				<?php
				break;
			case 'pinterest':
				?>
				<!-- Pinterest -->
				<span class="share-item pinbtn">
					<a href="http://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&media=<?php $thumb = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'large' ); echo $thumb['0']; ?>&description=<?php the_title(); ?>" class="pin-it-button" count-layout="horizontal"><?php esc_html_e( 'Pin It', 'reader' ); ?></a>
				</span>
				<?php
				break;
			case 'linkedin':
				?>
				<!--Linkedin -->
				<span class="share-item linkedinbtn">
					<script type="IN/Share" data-url="<?php echo esc_url( get_the_permalink() ); ?>"></script>
				</span>
				<?php
				break;
			case 'stumble':
				?>
				<!-- Stumble -->
				<span class="share-item stumblebtn">
					<a href="http://www.stumbleupon.com/submit?url=<?php echo urlencode( get_permalink() ); ?>&title=<?php the_title(); ?>" class="stumble" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><span class="stumble-icon"><i class="fa fa-stumbleupon"></i></span><span class="stumble-text"><?php _e( 'Share', 'reader' ); ?></span></a>
				</span>
				<?php
				break;
			case 'reddit':
				?>
				<!-- Reddit -->
				<span class="share-item reddit">
					<a href="//www.reddit.com/submit" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"> <img src="<?php echo get_template_directory_uri() . '/images/reddit.png'; ?>" alt=<?php _e( 'submit to reddit', 'reader' ); ?> border="0" /></a>
				</span>
				<?php
				break;
		}
	}
}
/**
 * Display network-independent sharing buttons.
 *
 * @param $button
 */
if ( ! function_exists( 'reader_social_circular_button' ) ) {
	function reader_social_circular_button( $button ) {
		global $post;
		if ( is_single() ) {
			$img_url = '';
			$img     = '';
			if ( has_post_thumbnail( $post->ID ) ) {
				$img     = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'reader-featuredfull' );
				$img_url = $img[0];
			}
		}
		switch ( $button ) {
			case 'facebookshare':
				?>
				<!-- Facebook -->
				<a href="//www.facebook.com/share.php?m2w&s=100&p[url]=<?php echo urlencode( get_permalink() ); ?>&p[images][0]=<?php echo urlencode( $img_url[0] ); ?>&p[title]=<?php echo urlencode( get_the_title() ); ?>&u=<?php echo urlencode( get_permalink() ); ?>&t=<?php echo urlencode( get_the_title() ); ?>" class="facebooksharebtn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><span class="social-icon"><i class="fa fa-facebook-official"></i></span><span class="social-text"><?php _e( 'Share', 'reader' ); ?></span></a>
				<?php
				break;
			case 'twitter':
				?>
				<!-- Twitter -->
				<?php
				$via = '';
				if ( reader_get_settings( 'mts_twitter_username' ) ) {
					$via = '&via=' . reader_get_settings( 'mts_twitter_username' );
				}
				?>
				<a href="https://twitter.com/intent/tweet?original_referer=<?php echo urlencode( get_permalink() ); ?>&text=<?php echo get_the_title(); ?>&url=<?php echo urlencode( get_permalink() ); ?><?php echo $via; ?>" class="twitterbutton" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><span class="social-icon"><i class="fa fa-twitter"></i></span> <span class="social-text"><?php _e( 'Tweet', 'reader' ); ?></span></a>
				<?php
				break;

			case 'pinterest':
				global $post;
				?>
				<!-- Pinterest -->
				<?php $pinterestimage = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' ); ?>
				<a href="http://pinterest.com/pin/create/button/?url=<?php echo urlencode( get_permalink( $post->ID ) ); ?>&media=<?php echo $pinterestimage[0]; ?>&description=<?php the_title(); ?>" class="share-pinbtn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><span class="social-icon"><i class="fa fa-pinterest"></i></span><span class="social-text"><?php _e( 'Pin', 'reader' ); ?></span></a>
				<?php
				break;
			case 'linkedin':
				?>
				<!--Linkedin -->
				<a href="//www.linkedin.com/shareArticle?mini=true&url=<?php echo urlencode( get_permalink() ); ?>&title=<?php echo get_the_title(); ?>&source=<?php echo 'url'; ?>" class="linkedinbtn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><span class="social-icon"><i class="fa fa-linkedin"></i></span><span class="social-text"><?php _e( 'Share', 'reader' ); ?></span></a>
				<?php
				break;
			case 'stumble':
				?>
				<!-- Stumble -->
				<a href="http://www.stumbleupon.com/submit?url=<?php echo urlencode( get_permalink() ); ?>&title=<?php the_title(); ?>" class="stumblebtn" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><span class="social-icon"><i class="fa fa-stumbleupon"></i></span><span class="social-text"><?php _e( 'Stumble', 'reader' ); ?></span></a>
				<?php
				break;
			case 'reddit':
				?>
				<!-- Reddit -->
				<a href="//www.reddit.com/submit" class="reddit" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><span class="social-icon"><i class="fa fa-reddit-alien"></i></span><span class="social-text"><?php _e( 'Reddit', 'reader' ); ?></span></a>
				<?php
				break;
		}
	}
}

/**
 * Display a post of specific layout.
 *
 * @param string $layout
 */
if ( ! function_exists( 'reader_blog_articles' ) ) {
	function reader_blog_articles() {
		?>
		<article class="latestPost excerpt">
			<?php if ( has_post_thumbnail() ) : ?>
				<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>" id="featured-thumbnail" class="post-image post-image-left <?php echo 'layout-default'; ?>">
					<div class="featured-thumbnail">
						<?php the_post_thumbnail( 'reader-featured', array( 'title' => '' ) ); ?>
					</div>
					<?php
					if ( function_exists( 'wp_review_show_total' ) ) {
						wp_review_show_total( true, 'latestPost-review-wrapper' );
					}
					?>
				</a>
			<?php endif; ?>
			<div class="wrapper">
				<header>
					<h2 class="title front-view-title"><a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>"><?php the_title(); ?></a></h2>
				</header>
				<div class="front-view-content">
					<?php
					if ( empty( reader_excerpt() ) ) {
						echo reader_truncate( get_the_content(), '30', 'words' );
					} else {
						echo reader_excerpt( '30' );
					}
					?>
				</div>
				<?php reader_readmore(); ?>
			</div>
		</article>
		<?php
	}
}

/**
 * Display Instagram feeds.
 *
 * returns a big old hunk of JSON from a non-private IG account page.
 *
 * @param string $layout
 */
function scrape_insta( $username ) {
	$request         = wp_remote_get( 'http://instagram.com/' . $username );
	$insta_source    = wp_remote_retrieve_body( $request );
	$shards          = explode( 'window._sharedData = ', $insta_source );
	$insta_json      = explode( ';</script>', $shards[1] );
	$insta_array     = json_decode( $insta_json[0], true );
	$update_interval = apply_filters( 'reader_instagram_update_interval', 3600 );
	$insta_serialize = serialize( $insta_array );
	set_transient( 'reader_instagram_' . $username, $insta_serialize, $update_interval );
	return $insta_array;
}
if ( ! function_exists( 'reader_instagram' ) ) {

	function reader_instagram( $username, $number, $force_rereader = false ) {
		$results_serialized = get_transient( 'reader_instagram_' . $username );
		if ( false === $results_serialized ) {
			$results_array = scrape_insta( $username );
		} else {
			$results_array = unserialize( $results_serialized );
		}
		for ( $i = 0; $i < $number; $i++ ) {
			if ( isset( $results_array['entry_data']['ProfilePage'][0]['graphql']['user']['edge_owner_to_timeline_media']['edges'][ $i ] ) ) {
				$latest_array = $results_array['entry_data']['ProfilePage'][0]['graphql']['user']['edge_owner_to_timeline_media']['edges'][ $i ];
				if ( $latest_array['node']['is_video'] ) {
					echo '<a href="http://instagram.com/p/' . $latest_array['node']['shortcode'] . '" target="_blank"><div style="background-image:url(' . preg_replace( '/vp.*\/.{32}\/.{8}\//', '', $latest_array['node']['thumbnail_resources'][2]['src'] ) . ');"></div></a>';
				} else {
					echo '<a href="http://instagram.com/p/' . $latest_array['node']['shortcode'] . '" target="_blank"><div style="background-image:url(' . $latest_array['node']['thumbnail_resources'][2]['src'] . ');"></div></a>';
				}
			}
		}

	}
}

/**
 *  Array containing all Adsense Ad sizees [Used in Options Panel]
 *
 * @return array
 */
function ad_sizes() {
	$ad_sizes = array(
		'0'  => 'Auto',
		'1'  => '120 x 90',
		'2'  => '120 x 240',
		'3'  => '120 x 600',
		'4'  => '125 x 125',
		'5'  => '160 x 90',
		'6'  => '160 x 600',
		'7'  => '180 x 90',
		'8'  => '180 x 150',
		'9'  => '200 x 90',
		'10' => '200 x 200',
		'11' => '234 x 60',
		'12' => '250 x 250',
		'13' => '320 x 100',
		'14' => '300 x 250',
		'15' => '300 x 600',
		'16' => '300 x 1050',
		'17' => '320 x 50',
		'18' => '336 x 280',
		'19' => '360 x 300',
		'20' => '435 x 300',
		'21' => '468 x 15',
		'22' => '468 x 60',
		'23' => '640 x 165',
		'24' => '640 x 190',
		'25' => '640 x 300',
		'26' => '728 x 15',
		'27' => '728 x 90',
		'28' => '970 x 90',
		'29' => '970 x 250',
		'30' => '240 x 400',
		'31' => '250 x 360',
		'32' => '580 x 400',
		'33' => '750 x 100',
		'34' => '750 x 200',
		'35' => '750 x 300',
		'36' => '980 x 120',
		'37' => '930 x 180',
	);

	return $ad_sizes;
}

/**
 *  Returns Ad Width and Height
 *
 * @param $ad_size
 *
 * @return array
 */
function ad_size_value( $ad_size = '0' ) {
	$get_ad_size_array = ad_sizes();

	if ( 'Auto' != $get_ad_size_array[ $ad_size ] ) {
		$ad_size_parts = explode( ' x ', $get_ad_size_array[ $ad_size ] );
		$ad_size       = array(
			'ad_width'  => $ad_size_parts[0],
			'ad_height' => $ad_size_parts[1],
		);
		echo 'width:' . $ad_size['ad_width'] . 'px; height:' . $ad_size['ad_height'] . 'px;';
	}
}

/**
 * Detect Adblocker Notice
 *
 * @return blocker-notice box
 */
function detect_adblocker_notice() {
?>
	<div class="blocker-notice">
		<i class="fa fa-exclamation"></i>
		<h4><?php echo reader_get_settings( 'detect_adblocker_title' ); ?></h4>
		<p><?php echo reader_get_settings( 'detect_adblocker_description' ); ?></p>
		<div><a href="" class="rereader-button"><?php esc_html_e( 'Rereader', 'reader' ); ?></a></div>
	</div>
<?php
}

function reader_featured_layouts() {
	include_once get_parent_theme_file_path( 'includes/class-reader-featured-layouts.php' );
	reader()->featured_layouts = new Reader_Featured_Layouts;
	reader()->featured_layouts->render();
}
function reader_single_sections() {
	include_once get_parent_theme_file_path( 'includes/class-reader-single-sections.php' );
	reader()->single_sections = new Reader_Single_Sections;
	reader()->single_sections->render();
}
