<?php
/**
 * Tweaks for the footer of the document.
 *
 * @package Reader
 */

defined( 'WPINC' ) || exit;

/**
 * Tweaks for the <head> of the document.
 */
class Reader_Footer extends Reader_Base {

	/**
	 * Constructor
	 */
	public function __construct() {

		$this->add_action( 'wp_footer', 'tracking_field', 999 );
	}

	/**
	 * Add tracking field code
	 */
	public function tracking_field() {
		echo reader_get_settings( 'mts_analytics_code' );
	}
}

/**
 * Init
 */
new Reader_Footer;
