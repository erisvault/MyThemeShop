<?php
/**
 * Sidebars
 *
 * @package Reader
 */

defined( 'WPINC' ) || exit;

/**
 * Single sections
 */
class Reader_Single_Sections extends Reader_Base {

	public function render() {
		$this->breadcrumb_section();
		$this->single_post_header();
		?>
	<article class="<?php reader_article_class(); ?>">
		<?php
		if ( 'mts_nosidebar' !== mts_custom_sidebar() ) {
			$sidebar = reader_custom_sidebar_layout();
		} else {
			$sidebar = 'nosidebar';
		}
		?>
		<div id="content_box" class="<?php echo $sidebar; ?>">
			<?php
			// Elementor 'single' location.
			if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'single' ) ) {
				if ( have_posts() ) :
					while ( have_posts() ) :
						the_post();
						$img_size = reader_get_settings( 'featured_image_size' );
						?>
					<div id="post-<?php the_ID(); ?>" <?php post_class( 'g post' . isset( $img_size ) ? 'header-style-' . $img_size : '' ); ?>>
						<?php
						// Single post parts ordering.
						if ( ( null !== reader_get_settings( 'mts_single_post_layout' ) ) && is_array( reader_get_settings( 'mts_single_post_layout' ) ) && array_key_exists( 'enabled', reader_get_settings( 'mts_single_post_layout' ) ) ) {
							$single_post_parts = reader_get_settings( 'mts_single_post_layout' )['enabled'];
						} else {
							$single_post_parts = array(
								'content'   => 'content',
								'thanks'    => 'thanks',
								'author'    => 'author',
								'nextpost'  => 'nextpost',
								'related'   => 'related',
								'subscribe' => 'subscribe',
							);
						}

						foreach ( $single_post_parts as $part => $label ) {
							switch ( $part ) {
								// Content area.
								case 'content':
									reader()->single_sections->single_post();
									break;

								// Post tags.
								case 'thanks':
									reader()->single_sections->single_post_thanks_section();
									break;

								// Post tags.
								case 'tags':
									reader_post_tags( '<div class="tags"><span class="tagtext"></span>', '' );
									break;

								// Author box.
								case 'author':
									reader()->single_sections->single_author_section();
									break;

								// Post tags.
								case 'nextpost':
									reader()->single_sections->single_next_post();
									break;

								// Related Posts.
								case 'related':
									if ( 'default' === reader_get_settings( 'related_posts_position' ) ) {
										reader_related_posts();
									}
									break;

								// Subscribe box.
								case 'subscribe':
									reader()->single_sections->single_subscribe_box();
									break;
							}
						}
						?>
					</div><!--.g post-->
						<?php
						// Comment area.
						comments_template( '', true );

				endwhile;
					wp_reset_query();
			endif; /* end loop */
			}
			?>
		</div>
	</article>
		<?php
	}

	public function single_post() {
		?>
		<div class="single_post">

			<?php reader_action( 'single_post_header_thumb' ); ?>

			<div class="post-single-content box mark-links entry-content">

				<?php
				$this->single_post_ads( 'above' );
				?>

				<div class="thecontent">
					<?php the_content(); ?>
				</div>

				<?php
				$this->single_post_pagination();

				$this->single_post_ads( 'below' );
				?>

			</div><!--.post-single-content-->
		</div><!--.single_post-->
		<?php
	}

	public function breadcrumb_section() {
		if ( ! reader_get_settings( 'mts_breadcrumb' ) ) {
			return;
		}
		?>
		<div class="breadcrumb-wrapper">
			<div class="left">
				<i class="fa fa-angle-right"></i>
				<a href="<?php esc_url( trailingslashit( home_url() ) ); ?>"><?php _e( 'Back to all posts', 'reader' ); ?></a>
			</div>

			<div class="right">
				<?php reader_breadcrumbs(); ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Single post header
	 */
	public function single_post_header() {

		//$single_sections = new Reader_Single_Sections;

		?>
		<header class="single-full-header single_post clearfix">

			<h1 class="title single-title entry-title"><?php the_title(); ?></h1>

			<div class="single-postinfo-wrapper">
				<?php

				reader_the_post_meta( 'single' );

				$this->single_post_social_icons( 'above' );

				?>
			</div>

		</header><!--.single-full-header-->
		<?php
	}

	public function single_post_pagination() {
		// Single Post Pagination.
		$args = array(
			'before'           => '<div class="pagination">',
			'after'            => '</div>',
			'link_before'      => '<span class="current"><span class="currenttext">',
			'link_after'       => '</span></span>',
			'next_or_number'   => 'next_and_number',
			'nextpagelink'     => '<i class="fa fa-chevron-right"></i>',
			'previouspagelink' => '<i class="fa fa-chevron-left"></i>',
			'pagelink'         => '%',
			'echo'             => 1,
		);
		wp_link_pages( $args );
	}

	public function single_post_thanks_section() {
		$thanks_title = reader_get_settings( 'thanks_title' );
		$thanks_text  = reader_get_settings( 'thanks_text' );
	?>
		<div class="thanks-section clearfix">
			<?php
			if ( $thanks_title || $thanks_text ) {
				printf( '<div class="left"><h3>%1$s</h3><p>%2$s</p></div>', $thanks_title, $thanks_text );
			}
			?>
			<div class="right">
				<?php $this->single_post_social_icons( 'below' ); ?>
			</div>
		</div>
	<?php
	}

	public function single_author_section() {
	?>
		<div class="postauthor">

			<?php
			// Author box title.
			$author_title = reader_get_settings( 'author_box_title' );
			if ( $author_title ) {
				echo '<h4>' . $author_title . '</h4>';
			}
			// Author gravatar.
			if ( function_exists( 'get_avatar' ) ) {
				echo get_avatar( get_the_author_meta( 'email' ), '64' ); // Gravatar size.
			}
			?>
			<h5 class="vcard author">
				<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" class="fn">
					<?php the_author_meta( 'display_name' ); ?>
				</a>
			</h5>
			<p><?php the_author_meta( 'description' ); ?></p>
			<?php
			$userid    = get_current_user_id();
			$facebook  = get_the_author_meta( 'facebook', $userid );
			$youtube   = get_the_author_meta( 'youtube', $userid );
			$twitter   = get_the_author_meta( 'twitter', $userid );
			$instagram = get_the_author_meta( 'instagram', $userid );
			$pinterest = get_the_author_meta( 'pinterest', $userid );
			$linkedin  = get_the_author_meta( 'linkedin', $userid );

			if ( ! empty( $facebook ) || ! empty( $twitter ) || ! empty( $instagram ) || ! empty( $pinterest ) || ! empty( $youtube ) || ! empty( $linkedin ) ) {
				echo '<div class="author-social clearfix">';
				if ( ! empty( $facebook ) ) {
					echo '<a href="' . $facebook . '" class="facebook"><i class="fa fa-facebook-official"></i></a>';
				}
				if ( ! empty( $youtube ) ) {
					echo '<a href="' . $youtube . '" class="youtube"><i class="fa fa-youtube-play"></i></a>';
				}
				if ( ! empty( $twitter ) ) {
					echo '<a href="' . $twitter . '" class="twitter"><i class="fa fa-twitter"></i></a>';
				}
				if ( ! empty( $instagram ) ) {
					echo '<a href="' . $instagram . '" class="instagram"><i class="fa fa-instagram"></i></a>';
				}
				if ( ! empty( $pinterest ) ) {
					echo '<a href="' . $pinterest . '" class="pinterest"><i class="fa fa-pinterest"></i></a>';
				}
				if ( ! empty( $linkedin ) ) {
					echo '<a href="' . $linkedin . '" class="linkedin"><i class="fa fa-linkedin"></i></a>';
				}
				echo '</div>';
			}
			?>
		</div>
	<?php
	}

	public function single_subscribe_box() {
		if ( is_active_sidebar( 'single-subscribe' ) ) {
		?>
			<div class="single-subscribe clear">
				<?php dynamic_sidebar( 'single-subscribe' ); ?>
			</div>
		<?php
		}
	}

	public function single_post_ads( $location ) {
		// Above Content Ad Code.
		if ( ! empty( reader_get_settings( 'mts_posttop_adcode' ) ) && 'above' == $location ) {
			$toptime = ! empty( reader_get_settings( 'mts_posttop_adcode_time' ) ) ? reader_get_settings( 'mts_posttop_adcode_time' ) : '0';
			if ( strcmp( date( 'Y-m-d', strtotime( -$toptime . ' day' ) ), get_the_time( 'Y-m-d' ) ) >= 0 ) {
				?>
				<div class="topad">
					<?php echo do_shortcode( reader_get_settings( 'mts_posttop_adcode' ) ); ?>
				</div>
				<?php
			}
		}
		// Below Content Ad Code.
		if ( ! empty( reader_get_settings( 'mts_postend_adcode' ) ) && 'below' == $location ) {
			$endtime = ! empty( reader_get_settings( 'mts_postend_adcode_time' ) ) ? reader_get_settings( 'mts_postend_adcode_time' ) : '0';
			if ( strcmp( date( 'Y-m-d', strtotime( -$endtime . ' day' ) ), get_the_time( 'Y-m-d' ) ) >= 0 ) {
				?>
				<div class="bottomad">
					<?php echo do_shortcode( reader_get_settings( 'mts_postend_adcode' ) ); ?>
				</div>
				<?php
			}
		}
	}

	public function single_next_post() {

		$prev_post = get_previous_post();
		$thumb     = wp_get_attachment_image_src( get_post_thumbnail_id( $prev_post->ID ), 'reader-next-post' );
		$btn_text  = reader_get_settings( 'mts_social_button_position' );

		if ( $prev_post ) {
		?>
			<div class="next-post">

				<div class="nextpost-wrapper clearfix">

					<?php single_next_post_logo( array() ); ?>

					<div class="left">
						<h3><a href="<?php echo get_the_permalink( $prev_post ); ?>" title="<?php the_title_attribute(); ?>"><?php echo get_the_title( $prev_post ); ?></a></h3>

						<p><?php echo wp_trim_words( $prev_post->post_content, '35' ); ?></p>
					</div>

					<div class="right">
						<?php
						if ( $thumb[0] ) {
						?>
							<img src="<?php echo $thumb[0]; ?>" alt="<?php the_title_attribute(); ?>">
						<?php
						} else {
							echo '<img src="' . get_template_directory_uri() . '/images/nothumb-reader-next-post.png" alt="' . __( 'No Preview', 'reader' ) . '"  class="wp-post-image" />';
						}
						?>
					</div>

					<a href="<?php echo get_the_permalink( $prev_post ); ?>" class="button"><?php _e( 'Continue reading!', 'reader' ); ?></a>

				</div><!-- .nextpost-wrapper -->

		</div><!-- .next-post -->
		<?php
		}
	}

	public function single_post_social_icons( $location ) {
		// Social Share icons above content.
		if ( null !== reader_get_settings( 'mts_social_button_position' ) && 'top' === reader_get_settings( 'mts_social_button_position' ) && 'above' == $location ) {
			reader_social_buttons();
		}
		// Social Share icons below content and floating.
		if ( ( null !== reader_get_settings( 'mts_social_button_position' ) ) && 'top' !== reader_get_settings( 'mts_social_button_position' ) && 'below' == $location ) {
			reader_social_buttons();
		}
	}

}
