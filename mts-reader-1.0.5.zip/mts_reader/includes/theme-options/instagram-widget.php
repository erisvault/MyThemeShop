<?php
/**
 * Instagram Widget
 *
 * @package Reader
 */

$menus['instagram-widget'] = array(
	'title' => esc_html__( 'Instagram Widget', 'reader' ),
	'desc'  => esc_html__( 'From here, you can control the styling of instagram widget.', 'reader' ),
);

$sections['instagram-widget'] = array(
	array(
		'id'       => 'instagram_widget_background',
		'type'     => 'color',
		'title'    => esc_html__( 'Background Color', 'reader' ),
		'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'reader' ),
		'std'      => '#e0f9ff',
	),
	array(
		'id'       => 'instagram_widget_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'reader' ),
		'sub_desc' => esc_html__( 'Set instagram widget padding from here.', 'reader' ),
		'std'      => array(
			'top'    => '35px',
			'right'  => '32px',
			'bottom' => '30px',
			'left'   => '32px',
		),
	),
	array(
		'id'       => 'instagram_widget_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'reader' ),
		'sub_desc' => esc_html__( 'Set instagram widget border radius from here.', 'reader' ),
		'std'      => '8',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'instagram_widget_button_background',
		'type'     => 'color',
		'title'    => esc_html__( 'Submit Button Background Color', 'reader' ),
		'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'reader' ),
		'std'      => '#bff1ff',
	),

);
