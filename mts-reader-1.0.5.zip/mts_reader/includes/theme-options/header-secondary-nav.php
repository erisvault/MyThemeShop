<?php
/**
 * Secondary Nav
 *
 * @package Blocks
 */

$menus['header']['child']['header-secondary-nav'] = array(
	'title' => esc_html__( 'Secondary Nav', 'reader' ),
	'desc'  => esc_html__( 'From here, you can control the secondary nav of header section.', 'reader' ),
);

$nav_dependency = array(
	'relation' => 'and',
	array(
		'field'      => 'show_secondary_nav',
		'value'      => '1',
		'comparison' => '==',
	),
);

$sections['header-secondary-nav'] = array(

	array(
		'id'       => 'show_secondary_nav',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Secondary Nav', 'reader' ),
		// translators: Secondary Nav with strong tag.
		'sub_desc' => sprintf( esc_html__( 'Use this button to enable %s.', 'reader' ), '<strong>' . esc_html__( 'Secondary Nav', 'reader' ) . '</strong>' ),
		'std'      => '0',
	),

	array(
		'id'         => 'secondary_nav_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Secondary Nav Background', 'reader' ),
		'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'reader' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
		'dependency' => $nav_dependency,
	),

	array(
		'id'         => 'secondary_navigation_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Secondary Navigation', 'reader' ),
		'std'        => array(
			'preview-text'   => 'Secondary Navigation Font',
			'preview-color'  => 'light',
			'font-family'    => 'Barlow Condensed',
			'font-weight'    => '500',
			'font-size'      => '18px',
			'color'          => '#3a4749',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '#secondary-navigation a',
		),
		'dependency' => $nav_dependency,
	),

	array(
		'id'         => 'secondary_nav_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'reader' ),
		'sub_desc'   => esc_html__( 'Set secondary nav padding from here.', 'reader' ),
		'left'       => false,
		'right'      => false,
		'std'        => array(
			'top'    => '25px',
			'bottom' => '0',
		),
		'dependency' => $nav_dependency,
	),

	array(
		'id'         => 'secondary_nav_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'reader' ),
		'sub_desc'   => esc_html__( 'Select border.', 'reader' ),
		'std'        => array(
			'direction' => 'bottom',
			'size'      => '1',
			'style'     => 'solid',
			'color'     => '#e2e4e4',
		),
		'dependency' => $nav_dependency,
	),

);
