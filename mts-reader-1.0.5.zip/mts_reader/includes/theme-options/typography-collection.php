<?php
/**
 * Typography tab
 *
 * @package Reader
 */

$menus['typography-collection'] = array(
	'icon'       => 'fa-text-width',
	'title'      => esc_html__( 'Typography', 'reader' ),
	'hide_title' => true,
);

$sections['typography-collection'] = array(

	array(
		'id'    => 'typography-collections',
		'type'  => 'typography_collections',
		'title' => esc_html__( 'Theme Typography', 'reader' ),
		'desc'  => esc_html__( 'From here, you can control the fonts used on your site. You can choose from 17 standard font sets, or from the Google Fonts Library containing 800+ fonts.', 'reader' ),
	),

	array(
		'id'    => 'reader_logo',
		'type'  => 'typography',
		'title' => esc_html__( 'Logo Font', 'reader' ),
		'std'   => array(
			'preview-text'  => 'Logo',
			'preview-color' => 'light',
			'font-family'   => 'Barlow Condensed',
			'font-weight'   => '600',
			'font-size'     => '40px',
			'color'         => '#3a4749',
			'css-selectors' => '#logo a, .next-post .logo',
		),
	),

	array(
		'id'    => 'primary_navigation_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Primary Navigation', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Primary Navigation Font',
			'preview-color'  => 'light',
			'font-family'    => 'Barlow Condensed',
			'font-weight'    => '500',
			'font-size'      => '16px',
			'color'          => '#3a4749',
			'additional-css' => 'text-transform: uppercase;letter-spacing: 0.528px;',
			'css-selectors'  => '#primary-navigation li',
		),
	),

	array(
		'id'    => 'home_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Archive Article Titles', 'reader' ),
		'std'   => array(
			'preview-text'  => 'Archive Article Title',
			'preview-color' => 'light',
			'font-family'   => 'Barlow Condensed',
			'font-weight'   => '600',
			'font-size'     => '28px',
			'line-height'   => '42px',
			'color'         => '#3a4749',
			'css-selectors' => '.latestPost .title a',
		),
	),

	array(
		'id'    => 'content_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Content Font', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Content Font',
			'preview-color'  => 'light',
			'font-family'    => 'Karla',
			'font-weight'    => '400',
			'font-size'      => '17px',
			'line-height'    => '30px',
			'color'          => '#a3a8a9',
			'additional-css' => 'letter-spacing: 0.289px;',
			'css-selectors'  => 'body',
		),
	),

	array(
		'id'    => 'sidebar_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Widget Title', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Sidebar Title Font',
			'preview-color'  => 'light',
			'font-family'    => 'Barlow Condensed',
			'font-weight'    => '600',
			'font-size'      => '25px',
			'line-height'    => '1',
			'color'          => '#3a4749',
			'additional-css' => 'text-transform: uppercase; letter-spacing: 0.425px;',
			'css-selectors'  => '#sidebar .widget h3.widget-title, #sidebar .widget h3.widget-title a, .widget #wp-subscribe .title',
		),
	),

	array(
		'id'    => 'mts_widget_links',
		'type'  => 'typography',
		'title' => esc_html__( 'MTS Widgets Links', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Sidebar Links',
			'preview-color'  => 'light',
			'font-family'    => 'Barlow Condensed',
			'font-weight'    => '600',
			'font-size'      => '20px',
			'line-height'    => '20px',
			'color'          => '#3a4749',
			'additional-css' => 'text-transform: none;',
			'css-selectors'  => '#sidebar .widget li.horizontal-small .post-title a, #sidebar .widget .wpt_widget_content .entry-title a, #sidebar .widget .wp_review_tab_widget_content .entry-title a',
		),
	),

	array(
		'id'    => 'default_widget_links',
		'type'  => 'typography',
		'title' => esc_html__( 'Default Widgets Link', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Default Widgets',
			'preview-color'  => 'light',
			'font-family'    => 'Barlow Condensed',
			'font-weight'    => '500',
			'font-size'      => '16px',
			'color'          => '#4a5166',
			'additional-css' => 'text-transform: uppercase; letter-spacing: 0.608px;',
			'css-selectors'  => '#sidebar .widget li a, #sidebar .widget.widget_categories li a, #sidebar .widget.widget_archive li a, #sidebar .widget.widget_pages li a, #sidebar .widget.widget_meta li a, #sidebar .widget.widget_recent_comments li a, #sidebar .widget.widget_recent_entries li a, #sidebar .widget.widget_rss, #sidebar .widget.widget_nav_menu li a',
		),
	),

	array(
		'id'    => 'sidebar_url_bigthumb',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Links on Big Thumb', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Sidebar Links Big Thumb',
			'preview-color'  => 'light',
			'font-family'    => 'Barlow Condensed',
			'font-weight'    => '600',
			'font-size'      => '28px',
			'line-height'    => '30px',
			'color'          => '#3a4749',
			'additional-css' => 'text-transform: none;',
			'css-selectors'  => '#sidebar .widget .vertical-small a, #sidebar .widget li.vertical-small, #sidebar .widget .review_thumb_large .entry-title a, .f-widget .widget .vertical-small a, .f-widget .widget .vertical-small li, .f-widget .widget .review_thumb_large .entry-title a',
		),
	),

	array(
		'id'    => 'sidebar_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Font', 'reader' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Font',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '400',
			'font-size'     => '15px',
			'line-height'   => '22px',
			'color'         => '#3a4749',
			'css-selectors' => '#sidebar .widget p, #sidebar .widget .post-excerpt, .widget #wp-subscribe input.email-field, .widget #wp-subscribe input.name-field, .widget .wp-subscribe-wrap .wps-consent-wrapper label, .widget #s, #site-footer .f-widget p',
		),
	),

	array(
		'id'    => 'sidebar_font_bigthumb',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Font bigthumb', 'reader' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Font bigthumb',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '400',
			'font-size'     => '15px',
			'line-height'   => '22px',
			'color'         => '#3a4749',
			'margin-top'    => '15px',
			'css-selectors' => '#sidebar .widget .vertical-small p, #sidebar .widget .vertical-small .post-excerpt, .f-widget .widget .vertical-small p, .f-widget .widget .vertical-small .post-excerpt',
		),
	),

	array(
		'id'    => 'sidebar_postinfo_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Postinfo Font', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Sidebar Postinfo Font',
			'preview-color'  => 'light',
			'font-family'    => 'Karla',
			'font-weight'    => '700',
			'font-size'      => '12px',
			'line-height'    => '1',
			'color'          => '#3a4749',
			'margin-top'     => '5px',
			'additional-css' => 'text-transform: uppercase; letter-spacing: 1.3px;',
			'css-selectors'  => '#sidebar .widget .post-info, #sidebar .widget .post-info a, #sidebar .wpt_widget_content .wpt-postmeta, .widget .wp_review_tab_widget_content .wp-review-tab-postmeta',
		),
	),

	array(
		'id'    => 'sidebar_postinfo_font_bigthumb',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Postinfo Font bigthumb', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Sidebar Postinfo Font bigthumb',
			'preview-color'  => 'light',
			'font-family'    => 'Karla',
			'font-weight'    => '700',
			'font-size'      => '12px',
			'line-height'    => '1',
			'color'          => '#3a4749',
			'margin-top'     => '8px',
			'additional-css' => 'text-transform: uppercase; letter-spacing: 1.3px;',
			'css-selectors'  => '#sidebar .widget .vertical-small .post-info, #sidebar .widget .vertical-small .post-info a, .f-widget .widget .vertical-small .post-info, .f-widget .widget .vertical-small .post-info a, .widget .wp_review_tab_widget_content .review_thumb_large .wp-review-tab-postmeta, .wpt_comment_content, .wpt_excerpt',
		),
	),

	array(
		'id'    => 'tabs_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Tabs Title', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Tabs Title Font',
			'preview-color'  => 'light',
			'font-family'    => 'Barlow Condensed',
			'font-weight'    => '400',
			'font-size'      => '18px',
			'color'          => '#3a4749',
			'additional-css' => 'text-transform: uppercase; letter-spacing: 0.306px;',
			'css-selectors'  => '#sidebar .widget .wp_review_tab_widget_content .tab_title a, #sidebar .widget .wpt_widget_content .tab_title a, .f-widget .widget .wp_review_tab_widget_content .tab_title a, .f-widget .widget .wpt_widget_content .tab_title a, .reply',
		),
	),

	array(
		'id'    => 'top_footer_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Widget Title', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Footer Title Font',
			'preview-color'  => 'light',
			'font-family'    => 'Barlow Condensed',
			'font-weight'    => '700',
			'font-size'      => '15px',
			'color'          => '#3a4749',
			'additional-css' => 'text-transform: uppercase; letter-spacing: 0.15px;',
			'css-selectors'  => '.footer-widgets h3, #site-footer .widget #wp-subscribe .title, .brands-title',
		),
	),

	array(
		'id'    => 'top_footer_link_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Link', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Footer Links',
			'preview-color'  => 'light',
			'font-family'    => 'Barlow Condensed',
			'font-weight'    => '500',
			'font-size'      => '15px',
			'color'          => '#9ca3a4',
			'additional-css' => 'text-transform: uppercase; letter-spacing: 0.15px;',
			'css-selectors'  => '.f-widget a, footer .wpt_widget_content a, footer .wp_review_tab_widget_content a, footer .wpt_tab_widget_content a, footer .widget .wp_review_tab_widget_content a',
		),
	),

	array(
		'id'    => 'top_footer_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer font', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Footer Font',
			'preview-color'  => 'light',
			'font-family'    => 'Karla',
			'font-weight'    => '400',
			'font-size'      => '14px',
			'line-height'    => '24px',
			'color'          => '#9ca3a4',
			'additional-css' => 'letter-spacing: 0.15px;',
			'css-selectors'  => '.footer-widgets, .f-widget .top-posts .comment_num, footer .meta, footer .twitter_time, footer .widget .wpt_widget_content .wpt-postmeta, footer .widget .wpt_comment_content, footer .widget .wpt_excerpt, footer .wp_review_tab_widget_content .wp-review-tab-postmeta, footer .advanced-recent-posts p, footer .popular-posts p, footer .category-posts p, footer .widget .post-info',
		),
	),

	array(
		'id'    => 'copyrights_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Copyrights Section', 'reader' ),
		'std'   => array(
			'preview-text'  => 'Copyrights Font',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '400',
			'font-size'     => '18px',
			'color'         => '#ffffff',
			'css-selectors' => '#copyright-note, #copyright-note a',
		),
	),

	array(
		'id'    => 'fields_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Text Fields Font', 'reader' ),
		'color' => false,
		'std'   => array(
			'preview-text'   => 'Text Fields Font',
			'preview-color'  => 'light',
			'font-family'    => 'Barlow Condensed',
			'font-weight'    => '400',
			'font-size'      => '16px',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => 'input#author, .contact-form input[type="text"], input#email, input#url, #commentform textarea, #commentform input#submit, #mtscontact_submit, .contact-form textarea',
		),
	),

	array(
		'id'    => 'sidebar_buttons_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Widgets Button Font', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Sidebar Widgets Button Font',
			'preview-color'  => 'light',
			'font-family'    => 'Karla',
			'font-weight'    => '700',
			'font-size'      => '15px',
			'color'          => '#3a4749',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.widget #wp-subscribe input.submit, .widget .sbutton, .next-post .button, .widget_product_search button[type="submit"]',
		),
	),

	array(
		'id'    => 'h1_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H1 Heading in Content', 'reader' ),
		'std'   => array(
			'preview-text'  => 'H1 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Barlow Condensed',
			'font-weight'   => '600',
			'font-size'     => '36px',
			'color'         => '#3a4749',
			'css-selectors' => 'h1',
		),
	),

	array(
		'id'    => 'h2_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H2 Heading in Content', 'reader' ),
		'std'   => array(
			'preview-text'  => 'H2 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Barlow Condensed',
			'font-weight'   => '600',
			'font-size'     => '34px',
			'color'         => '#3a4749',
			'css-selectors' => 'h2',
		),
	),

	array(
		'id'    => 'h3_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H3 Heading in Content', 'reader' ),
		'std'   => array(
			'preview-text'  => 'H3 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Barlow Condensed',
			'font-weight'   => '600',
			'font-size'     => '32px',
			'color'         => '#3a4749',
			'css-selectors' => 'h3',
		),
	),

	array(
		'id'    => 'h4_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H4 Heading in Content', 'reader' ),
		'std'   => array(
			'preview-text'  => 'H4 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Barlow Condensed',
			'font-weight'   => '600',
			'font-size'     => '30px',
			'color'         => '#3a4749',
			'css-selectors' => 'h4',
		),
	),

	array(
		'id'    => 'h5_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H5 Heading in Content', 'reader' ),
		'std'   => array(
			'preview-text'  => 'H5 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Barlow Condensed',
			'font-weight'   => '600',
			'font-size'     => '28px',
			'color'         => '#3a4749',
			'css-selectors' => 'h5',
		),
	),

	array(
		'id'    => 'h6_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H6 Heading in Content', 'reader' ),
		'std'   => array(
			'preview-text'  => 'H6 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Barlow Condensed',
			'font-weight'   => '600',
			'font-size'     => '24px',
			'color'         => '#3a4749',
			'css-selectors' => 'h6',
		),
	),

	array(
		'id'       => 'typography-subsets',
		'type'     => 'multi_checkbox',
		'title'    => esc_html__( 'Character sets', 'reader' ),
		'sub_desc' => esc_html__( 'Choose the character sets you wish to include. Please note that not all sets are available for all fonts.', 'reader' ),
		'options'  => array(
			'latin'        => esc_html__( 'Latin', 'reader' ),
			'latin-ext'    => esc_html__( 'Latin Extended', 'reader' ),
			'cyrillic'     => esc_html__( 'Cyrillic', 'reader' ),
			'cyrillic-ext' => esc_html__( 'Cyrillic Extended', 'reader' ),
			'greek'        => esc_html__( 'Greek', 'reader' ),
			'greek-ext'    => esc_html__( 'Greek Extended', 'reader' ),
			'vietnamese'   => esc_html__( 'Vietnamese', 'reader' ),
			'khmer'        => esc_html__( 'Khmer', 'reader' ),
			'devanagari'   => esc_html__( 'Devanagari', 'reader' ),
		),
		'std'      => array( 'latin' ),
	),
);
