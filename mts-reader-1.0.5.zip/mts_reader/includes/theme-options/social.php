<?php
/**
 * Social Tab
 *
 * @package Reader
 */

$menus['social'] = array(
	'icon'  => 'fa-users',
	'title' => esc_html__( 'Social Share', 'reader' ),
	'desc'  => esc_html__( 'Enable or disable social sharing buttons on single posts using these buttons.', 'reader' ),
);

$menus['social']['child']['social-general'] = array(
	'title' => esc_html__( 'General', 'reader' ),
	'desc'  => esc_html__( 'From here, you can control the elements of social sharing buttons.', 'reader' ),
);

$sections['social-general'] = array(

	array(
		'id'       => 'social_button_layout',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Social Sharing Buttons Layout', 'reader' ),
		'sub_desc' => wp_kses( __( 'Choose default <strong>social sharing buttons</strong> layout or modern <strong>social sharing buttons</strong> layout for your site. ', 'reader' ), array( 'strong' => array() ) ),
		'options'  => array(
			'default'  => array( 'img' => $uri . 'social/default.jpg' ),
			'standard' => array( 'img' => $uri . 'social/standard.jpg' ),
			'circular' => array( 'img' => $uri . 'social/circular.jpg' ),
		),
		'std'      => 'standard',
	),

	array(
		'id'       => 'mts_social_button_position',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Social Sharing Buttons Position', 'reader' ),
		'options'  => array(
			'top'      => esc_html__( 'Above Content', 'reader' ),
			'bottom'   => esc_html__( 'Below Content', 'reader' ),
			'floating' => esc_html__( 'Floating', 'reader' ),
		),
		'sub_desc' => esc_html__( 'Choose position for Social Sharing Buttons.', 'reader' ),
		'std'      => 'top',
		'class'    => 'green',
	),

	array(
		'id'       => 'mts_social_buttons_on_pages',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Social Sharing Buttons on Pages', 'reader' ),
		'options'  => array(
			'0' => esc_html__( 'Off', 'reader' ),
			'1' => esc_html__( 'On', 'reader' ),
		),
		'sub_desc' => esc_html__( 'Enable the sharing buttons for pages too, not just posts.', 'reader' ),
		'std'      => '0',
	),

	array(
		'id'       => 'mts_social_buttons',
		'type'     => 'layout',
		'title'    => esc_html__( 'Social Media Buttons', 'reader' ),
		'sub_desc' => esc_html__( 'Organize how you want the social sharing buttons to appear on single posts', 'reader' ),
		'options'  => array(
			'enabled'  => array(
				'facebookshare' => esc_html__( 'Facebook Share', 'reader' ),
				'pinterest'     => esc_html__( 'Pinterest', 'reader' ),
				'twitter'       => esc_html__( 'Twitter', 'reader' ),
			),
			'disabled' => array(
				'facebook' => esc_html__( 'Facebook Like', 'reader' ),
				'reddit'   => esc_html__( 'Reddit', 'reader' ),
				'linkedin' => esc_html__( 'LinkedIn', 'reader' ),
				'stumble'  => esc_html__( 'StumbleUpon', 'reader' ),
			),
		),
		'std'      => array(
			'enabled'  => array(
				'facebookshare' => esc_html__( 'Facebook Share', 'reader' ),
				'pinterest'     => esc_html__( 'Pinterest', 'reader' ),
				'twitter'       => esc_html__( 'Twitter', 'reader' ),
			),
			'disabled' => array(
				'facebook' => esc_html__( 'Facebook Like', 'reader' ),
				'reddit'   => esc_html__( 'Reddit', 'reader' ),
				'linkedin' => esc_html__( 'LinkedIn', 'reader' ),
				'stumble'  => esc_html__( 'StumbleUpon', 'reader' ),
			),
		),
	),

);
