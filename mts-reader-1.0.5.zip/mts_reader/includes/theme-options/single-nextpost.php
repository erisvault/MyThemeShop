<?php
/**
 * Single Next Post
 *
 * @package Reader
 */

$menus['single-nextpost'] = array(
	'title' => esc_html__( 'Next Post Section', 'reader' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of Author box in single posts page.', 'reader' ),
);

$sections['single-nextpost'] = array(

	array(
		'id'       => 'nextpost_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Background', 'reader' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image for subscribe box from here.', 'reader' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#faebe3',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'nextpost_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Margin', 'reader' ),
		'sub_desc' => esc_html__( 'Set next post section margin from here.', 'reader' ),
		'std'      => array(
			'top'    => '48px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'nextpost_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'reader' ),
		'sub_desc' => esc_html__( 'Set next post section padding from here.', 'reader' ),
		'std'      => array(
			'top'    => '36px',
			'right'  => '48px',
			'bottom' => '39px',
			'left'   => '48px',
		),
	),
	array(
		'id'       => 'nextpost_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'reader' ),
		'sub_desc' => esc_html__( 'Set border radius for next post section.', 'reader' ),
		'std'      => '8',
		'args'     => array( 'type' => 'number' ),
	),

	array(
		'id'       => 'nextpost_button_background',
		'type'     => 'color',
		'title'    => esc_html__( 'Button Background Color', 'reader' ),
		'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'reader' ),
		'std'      => '#f3d4c3',
	),

	array(
		'id'    => 'nextpost_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Next Post Section Title Font', 'reader' ),
		'std'   => array(
			'preview-text'  => 'Next Post Section Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Barlow Condensed',
			'font-weight'   => '600',
			'font-size'     => '32px',
			'color'         => '#3a4749',
			'css-selectors' => '.next-post h3 a',
		),
	),
	array(
		'id'    => 'nextpost_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Next Post Section Text Font', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Next Post Section Text Font',
			'preview-color'  => 'light',
			'font-family'    => 'Karla',
			'font-weight'    => '400',
			'font-size'      => '15px',
			'line-height'    => '25px',
			'color'          => '#3a4749',
			'additional-css' => 'opacity: 0.75; letter-spacing: 0.255px;',
			'css-selectors'  => '.next-post p',
		),
	),

);
