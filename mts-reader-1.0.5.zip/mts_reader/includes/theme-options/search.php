<?php
/**
 * Search Tab
 *
 * @package Reader
 */

$menus['search'] = array(
	'icon'  => 'fa fa-search',
	'title' => esc_html__( 'Search', 'reader' ),
	'desc'  => esc_html__( 'Setting here apply to search pages.', 'reader' ),
);

$sections['search'] = array(

	array(
		'id'       => 'search_content',
		'type'     => 'select',
		'title'    => esc_html__( 'Search Results Content', 'reader' ),
		'sub_desc' => esc_html__( 'Controls the type of content that displays in search results.', 'reader' ),
		'options'  => array(
			'all'          => esc_html__( 'All Post Types and Pages', 'reader' ),
			'all-no-pages' => esc_html__( 'All Post Types without Pages', 'reader' ),
			'pages'        => esc_html__( 'Only Pages', 'reader' ),
			'posts'        => esc_html__( 'Only Blog Posts', 'reader' ),
			'woocommerce'  => esc_html__( 'Only WooCommerce Products', 'reader' ),
		),
		'std'      => 'posts_pages',
	),

	array(
		'id'       => 'search_results_per_page',
		'type'     => 'text',
		'title'    => esc_html__( 'Number of Search Results Per Page', 'reader' ),
		'sub_desc' => esc_html__( 'Controls the number of search results per page.', 'reader' ),
		'validate' => 'numeric',
		'std'      => '9',
		'class'    => 'small-text',
	),

	array(
		'id'       => 'search_position',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Search Form Position', 'reader' ),
		'sub_desc' => esc_html__( 'Controls the position of the search bar on the search results page.', 'reader' ),
		'options'  => array(
			'above' => esc_html__( 'Above Results', 'reader' ),
			'below' => esc_html__( 'Below Results', 'reader' ),
			'hide'  => esc_html__( 'Hide', 'reader' ),
		),
		'std'      => 'above',
	),
);
