<?php
/**
 * Header Tab
 *
 * @package Reader
 */

$menus['header'] = array(
	'icon'  => 'fa-header',
	'title' => esc_html__( 'Header', 'reader' ),
);

$menus['header']['child']['header-general'] = array(
	'title' => esc_html__( 'General', 'reader' ),
	'desc'  => esc_html__( 'From here, you can control the elements of header section.', 'reader' ),
);

$featured_dependency = array(
	'relation' => 'and',
	array(
		'field'      => 'header_styles',
		'value'      => 'header-default',
		'comparison' => '==',
	),
);

$nav_dependency = array(
	'relation' => 'and',
	array(
		'field'      => 'nav_button',
		'value'      => '1',
		'comparison' => '==',
	),
	array(
		'field'      => 'header_styles',
		'value'      => 'header-layout2',
		'comparison' => '!=',
	),
);

$sections['header-general'] = array(

	array(
		'id'       => 'header_styles',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Header Styling', 'reader' ),
		'sub_desc' => wp_kses( __( 'Choose the <strong>Header design</strong> for your site.', 'reader' ), array( 'strong' => '' ) ),
		'options'  => array(
			'header-default' => array( 'img' => $uri . 'headers/header-default.jpg' ),
			'header-layout2' => array( 'img' => $uri . 'headers/header-layout2.jpg' ),
			'header-layout3' => array( 'img' => $uri . 'headers/header-layout3.jpg' ),
		),
		'std'      => 'header-default',
	),

	array(
		'id'         => 'header_social_icons',
		'title'      => esc_html__( 'Header Social Icons', 'reader' ),
		'sub_desc'   => esc_html__( 'Add Social Media icons in header.', 'reader' ),
		'type'       => 'group',
		'groupname'  => esc_html__( 'Header Icons', 'reader' ), // Group name.
		'subfields'  => array(
			array(
				'id'    => 'header_icon_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'reader' ),
			),
			array(
				'id'    => 'header_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Icon', 'reader' ),
			),
			array(
				'id'    => 'header_icon_link',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'reader' ),
			),
			array(
				'id'    => 'header_icon_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background color', 'reader' ),
			),
			array(
				'id'    => 'header_icon_hover_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background hover color', 'reader' ),
			),
			array(
				'id'    => 'header_icon_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon color', 'reader' ),
			),
			array(
				'id'    => 'header_icon_hover_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon hover color', 'reader' ),
			),
			array(
				'id'    => 'header_icon_margin',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Margin', 'reader' ),
			),
			array(
				'id'    => 'header_icon_padding',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Padding', 'reader' ),
			),
			array(
				'id'       => 'header_icon_border',
				'type'     => 'border',
				'title'    => esc_html__( 'Border', 'reader' ),
				'sub_desc' => esc_html__( 'Select border.', 'reader' ),
			),
			array(
				'id'    => 'header_icon_border_radius',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Header icon border radius', 'reader' ),
				'args'  => array( 'type' => 'number' ),
			),
		),
		'std'        => array(
			'twitter'   => array(
				'group_title'               => 'Twitter',
				'group_sort'                => '1',
				'header_icon_title'         => 'Twitter',
				'header_icon'               => 'twitter',
				'header_icon_link'          => '#',
				'header_icon_bgcolor'       => reader_get_settings( 'primary_color_scheme' ),
				'header_icon_hover_bgcolor' => '#383b34',
				'header_icon_color'         => '#ffffff',
				'header_icon_hover_color'   => '#ffffff',
				'header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '5px',
				),
				'header_icon_padding'       => array(
					'top'    => '11px',
					'right'  => '11px',
					'bottom' => '11px',
					'left'   => '11px',
				),
				'header_icon_border_radius' => '3',
			),
			'instagram' => array(
				'group_title'               => 'Instagram',
				'group_sort'                => '2',
				'header_icon_title'         => 'Instagram',
				'header_icon'               => 'instagram',
				'header_icon_link'          => '#',
				'header_icon_bgcolor'       => reader_get_settings( 'primary_color_scheme' ),
				'header_icon_hover_bgcolor' => '#383b34',
				'header_icon_color'         => '#ffffff',
				'header_icon_hover_color'   => '#ffffff',
				'header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '5px',
				),
				'header_icon_padding'       => array(
					'top'    => '11px',
					'right'  => '11px',
					'bottom' => '11px',
					'left'   => '11px',
				),
				'header_icon_border_radius' => '3',
			),
			'facebook'  => array(
				'group_title'               => 'Facebook',
				'group_sort'                => '3',
				'header_icon_title'         => 'Facebook',
				'header_icon'               => 'facebook-official',
				'header_icon_link'          => '#',
				'header_icon_bgcolor'       => reader_get_settings( 'primary_color_scheme' ),
				'header_icon_hover_bgcolor' => '#383b34',
				'header_icon_color'         => '#ffffff',
				'header_icon_hover_color'   => '#ffffff',
				'header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '5px',
				),
				'header_icon_padding'       => array(
					'top'    => '11px',
					'right'  => '11px',
					'bottom' => '11px',
					'left'   => '11px',
				),
				'header_icon_border_radius' => '3',
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout2',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Featured Area', 'reader' ),
		'dependency' => $featured_dependency,
	),

	array(
		'id'         => 'featured_title',
		'type'       => 'text',
		'title'      => esc_html__( 'Title', 'reader' ),
		'std'        => 'Welcome to reader blog',
		'dependency' => $featured_dependency,
	),

	array(
		'id'         => 'featured_text',
		'type'       => 'textarea',
		'title'      => esc_html__( 'Text', 'reader' ),
		'std'        => 'A Trusted Place to learn how to successfully publish your book',
		'dependency' => $featured_dependency,
	),

	array(
		'id'         => 'featured_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Featured Margin', 'reader' ),
		'sub_desc'   => esc_html__( 'Set top bar margin from here.', 'reader' ),
		'left'       => false,
		'right'      => false,
		'std'        => array(
			'top'    => '0',
			'bottom' => '0',
		),
		'dependency' => $featured_dependency,
	),
	array(
		'id'         => 'featured_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Featured Padding', 'reader' ),
		'sub_desc'   => esc_html__( 'Set top bar padding from here.', 'reader' ),
		'left'       => false,
		'right'      => false,
		'std'        => array(
			'top'    => '63px',
			'bottom' => '121px',
		),
		'dependency' => $featured_dependency,
	),

	array(
		'id'         => 'header_featured_title_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Featured Title', 'reader' ),
		'std'        => array(
			'preview-text'   => 'Featured Title',
			'preview-color'  => 'light',
			'font-family'    => 'Barlow Condensed',
			'font-weight'    => '600',
			'font-size'      => '60px',
			'color'          => '#2a384a',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.header-featured h1',
		),
		'dependency' => $featured_dependency,
	),
	array(
		'id'         => 'header_featured_text_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Featured Text', 'reader' ),
		'std'        => array(
			'preview-text'  => 'Featured Text',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '400',
			'font-size'     => '18px',
			'color'         => '#2a384a',
			'css-selectors' => '.header-featured p',
		),
		'dependency' => $featured_dependency,
	),

	array(
		'id'         => 'header_nav_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Nav Button Settings', 'reader' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout2',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'         => 'nav_button',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Nav Button', 'reader' ),
		'sub_desc'   => wp_kses( __( 'Use this button to Show or Hide the <strong>Nav Button</strong> completely.', 'reader' ), array( 'strong' => '' ) ),
		'std'        => '1',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout2',
				'comparison' => '!=',
			),
		),
	),

	array(
		'id'         => 'nav_button_text',
		'type'       => 'text',
		'title'      => esc_html__( 'Button Text', 'reader' ),
		'sub_desc'   => esc_html__( 'Enter button text.', 'reader' ),
		'std'        => 'Join Us',
		'dependency' => $nav_dependency,
	),

	array(
		'id'         => 'nav_button_url',
		'type'       => 'text',
		'title'      => esc_html__( 'Button URL', 'reader' ),
		'sub_desc'   => esc_html__( 'Enter button URL.', 'reader' ),
		'std'        => '#',
		'dependency' => $nav_dependency,
	),

	array(
		'id'    => 'header_general_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Header General Settings', 'reader' ),
	),

	array(
		'id'       => 'sticky_nav',
		'type'     => 'switch',
		'title'    => esc_html__( 'Floating Navigation Menu', 'reader' ),
		// translators: Floating Navigation Menu with strong tag.
		'sub_desc' => sprintf( esc_html__( 'Use this button to enable %s.', 'reader' ), '<strong>' . esc_html__( 'Floating Navigation Menu', 'reader' ) . '</strong>' ),
		'std'      => '0',
	),

	array(
		'id'       => 'hide_logo',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Logo', 'reader' ),
		'sub_desc' => wp_kses( __( 'Use this button to Show or Hide the <strong>Logo</strong> completely.', 'reader' ), array( 'strong' => '' ) ),
		'std'      => '1',
	),

	array(
		'id'       => 'header_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Header Margin', 'reader' ),
		'sub_desc' => esc_html__( 'Set header margin from here.', 'reader' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '0',
		),
	),
	array(
		'id'       => 'header_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Header Padding', 'reader' ),
		'sub_desc' => esc_html__( 'Set header padding from here.', 'reader' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '43px',
			'bottom' => '43px',
		),
	),

	array(
		'id'       => 'header_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'reader' ),
		'sub_desc' => esc_html__( 'Select border.', 'reader' ),
	),

	array(
		'id'       => 'header_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Header Background', 'reader' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'reader' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'upload',
			'image_pattern' => 'nobg',
			'image_upload'  => get_template_directory_uri() . '/images/featured-bg.jpg',
			'repeat'        => 'no-repeat',
			'attachment'    => 'scroll',
			'position'      => 'center center',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'main_navigation_dropdown_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Color', 'reader' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'reader' ),
		'std'      => '#3a4749',
	),
	array(
		'id'       => 'main_navigation_dropdown_hover_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Hover Color', 'reader' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'reader' ),
		'std'      => reader_get_settings( 'primary_color_scheme' ),
	),

);
