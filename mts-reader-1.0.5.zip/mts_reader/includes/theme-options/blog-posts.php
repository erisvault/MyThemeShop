<?php
/**
 * HomePage Posts
 *
 * @package Reader
 */

$features = reader_get_settings( 'mts_featured_categories' );
if ( empty( $features ) ) {
	return;
}
foreach ( $features as $feature ) :
	$title        = isset( $feature['mts_featured_title'] ) ? $feature['mts_featured_title'] : 'No Title';
	$posts_layout = isset( $feature['blog_layout'] ) ? $feature['blog_layout'] : '';
	if ( 'layout-default' === $posts_layout ) {
		$posts_layout = 'default';
	}
	$unique_id = isset( $feature['unique_id'] ) ? $feature['unique_id'] : '';

	$menus['blog']['child'][ 'blog-' . $unique_id ] = array(
		'title' => $title,
		// translators: description.
		'desc'  => sprintf( wp_kses_post( __( 'From here, you can control the elements of %s', 'reader' ) ), $title ),
	);

	// Dependency check that back to top option is enable.
	$post_title_dependency = array(
		'relation' => 'and',
		array(
			'field'      => 'mts_featured_category_title_' . $unique_id,
			'value'      => '1',
			'comparison' => '==',
		),
	);

	$sections[ 'blog-' . $unique_id ] = array(

		/**
		 * Layout Default Settings
		 *
		 * @package Reader
		 */

		// Section Title.
		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'reader' ),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'reader' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'reader' ),
			'std'      => '0',
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'reader' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'reader' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'reader' ),
				'center' => esc_html__( 'Center', 'reader' ),
				'right'  => esc_html__( 'Right', 'reader' ),
			),
			'std'        => 'left',
			'dependency' => $post_title_dependency,
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'reader' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'reader' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => $post_title_dependency,
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'reader' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'reader' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '40px',
				'left'   => '0',
			),
			'dependency' => $post_title_dependency,
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'reader' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'reader' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
			'dependency' => $post_title_dependency,
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'reader' ),
			'sub_desc'   => esc_html__( 'Select border', 'reader' ),
			'dependency' => $post_title_dependency,
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'reader' ),
			'std'        => array(
				'preview-text'   => 'Title Font',
				'preview-color'  => 'light',
				'font-family'    => 'Barlow Condensed',
				'font-weight'    => '500',
				'font-size'      => '22px',
				'color'          => '#2a384a',
				'additional-css' => 'text-transform: uppercase; letter-spacing: 0.528px;',
				'css-selectors'  => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => $post_title_dependency,
		) : null,

		// Meta info.
		( 'default' === $posts_layout ) ? array(
			'id'    => 'post_meta_info_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Meta Info', 'reader' ),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_home_headline_meta_info' . $unique_id,
			'type'     => 'layout2',
			// translators: title.
			'title'    => sprintf( wp_kses_post( __( '%s Meta Info', 'reader' ) ), $title ),
			// translators: description.
			'sub_desc' => sprintf( wp_kses_post( __( 'Organize how you want the post meta info to appear on %s', 'reader' ) ), $title ),
			'options'  => array(
				'enabled'  => array(
					'date'     => array(
						'label'     => esc_html__( 'Date', 'reader' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_date_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reader' ),
							),
						),
					),
					'category' => array(
						'label'     => esc_html__( 'Categories', 'reader' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_category_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reader' ),
							),
						),
					),
					'comment'  => array(
						'label'     => esc_html__( 'Comment Count', 'reader' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_comment_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reader' ),
							),
						),
					),
				),
				'disabled' => array(
					'author' => array(
						'label'     => __( 'Author Name', 'reader' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_author_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reader' ),
							),
						),
					),
				),
			),
			'std'      => array(
				'enabled'  => array(
					'date'     => array(
						'label'     => esc_html__( 'Date', 'reader' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_date_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reader' ),
							),
						),
					),
					'category' => array(
						'label'     => esc_html__( 'Categories', 'reader' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_category_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reader' ),
							),
						),
					),
					'comment'  => array(
						'label'     => esc_html__( 'Comment Count', 'reader' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_comment_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reader' ),
							),
						),
					),
				),
				'disabled' => array(
					'author' => array(
						'label'     => __( 'Author Name', 'reader' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_author_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reader' ),
							),
						),
					),
				),
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'meta_info_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'reader' ),
			'sub_desc' => esc_html__( 'Select border.', 'reader' ),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'    => 'meta_info_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Meta Info Typography', 'reader' ),
			'std'   => array(
				'preview-text'   => 'Post Meta Info Font',
				'preview-color'  => 'light',
				'font-family'    => 'Karla',
				'font-weight'    => '700',
				'font-size'      => '13px',
				'color'          => '#3a4749',
				'margin-top'     => '22px',
				'margin-bottom'  => '30px',
				'additional-css' => 'text-transform: uppercase; letter-spacing: 1.3px;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .post-info',
			),
		) : null,
		// Post Container.
		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'reader' ),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'readmore_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Read More', 'reader' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide readmore.', 'reader' ),
			'std'      => '0',
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'reader' ),
			'sub_desc' => esc_html__( 'Select border', 'reader' ),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'post_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'reader' ),
			'sub_desc' => esc_html__( 'Post margin.', 'reader' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '56px',
				'bottom' => '0',
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'post_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'reader' ),
			'sub_desc' => esc_html__( 'Post padding.', 'reader' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'    => 'post_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'reader' ),
			'std'   => array(
				'preview-text'  => 'Post Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Barlow Condensed',
				'font-weight'   => '600',
				'font-size'     => '42px',
				'line-height'   => '48px',
				'color'         => '#3a4749',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'    => 'post_excerpt_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Excerpt Font', 'reader' ),
			'std'   => array(
				'preview-text'   => 'Post Excerpt Font',
				'preview-color'  => 'light',
				'font-family'    => 'Karla',
				'font-weight'    => '400',
				'font-size'      => '16px',
				'line-height'    => '26px',
				'color'          => '#3a4749',
				'additional-css' => 'opacity: 0.75; letter-spacing: 0.272px;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .front-view-content',
			),
		) : null,

		/**
		 * Layout 1 Settings
		 *
		 * @package Reader
		 */

		// Section Title.
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'reader' ),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'reader' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'reader' ),
			'std'      => '0',
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'reader' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'reader' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'reader' ),
				'center' => esc_html__( 'Center', 'reader' ),
				'right'  => esc_html__( 'Right', 'reader' ),
			),
			'std'        => 'left',
			'dependency' => $post_title_dependency,
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'reader' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'reader' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => $post_title_dependency,
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'reader' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'reader' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '40px',
				'left'   => '0',
			),
			'dependency' => $post_title_dependency,
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'reader' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'reader' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
			'dependency' => $post_title_dependency,
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'reader' ),
			'sub_desc'   => esc_html__( 'Select border', 'reader' ),
			'dependency' => $post_title_dependency,
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'reader' ),
			'std'        => array(
				'preview-text'   => 'Title Font',
				'preview-color'  => 'light',
				'font-family'    => 'Barlow Condensed',
				'font-weight'    => '500',
				'font-size'      => '22px',
				'color'          => '#2a384a',
				'additional-css' => 'text-transform: uppercase; letter-spacing: 0.528px;',
				'css-selectors'  => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => $post_title_dependency,
		) : null,

		// Meta info.
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'post_meta_info_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Meta Info', 'reader' ),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_home_headline_meta_info' . $unique_id,
			'type'     => 'layout2',
			// translators: title.
			'title'    => sprintf( wp_kses_post( __( '%s Meta Info', 'reader' ) ), $title ),
			// translators: description.
			'sub_desc' => sprintf( wp_kses_post( __( 'Organize how you want the post meta info to appear on %s', 'reader' ) ), $title ),
			'options'  => array(
				'enabled'  => array(
					'date'    => array(
						'label'     => esc_html__( 'Date', 'reader' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_date_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reader' ),
							),
						),
					),
					'comment' => array(
						'label'     => esc_html__( 'Comment Count', 'reader' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_comment_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reader' ),
							),
						),
					),
				),
				'disabled' => array(
					'category' => array(
						'label'     => esc_html__( 'Categories', 'reader' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_category_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reader' ),
							),
						),
					),
					'author'   => array(
						'label'     => __( 'Author Name', 'reader' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_author_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reader' ),
							),
						),
					),
				),
			),
			'std'      => array(
				'enabled'  => array(
					'date'    => array(
						'label'     => esc_html__( 'Date', 'reader' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_date_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reader' ),
							),
						),
					),
					'comment' => array(
						'label'     => esc_html__( 'Comment Count', 'reader' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_comment_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reader' ),
							),
						),
					),
				),
				'disabled' => array(
					'category' => array(
						'label'     => esc_html__( 'Categories', 'reader' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_category_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reader' ),
							),
						),
					),
					'author'   => array(
						'label'     => __( 'Author Name', 'reader' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_author_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reader' ),
							),
						),
					),
				),
			),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'meta_info_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'reader' ),
			'sub_desc' => esc_html__( 'Select border.', 'reader' ),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'meta_info_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Meta Info Typography', 'reader' ),
			'std'   => array(
				'preview-text'   => 'Post Meta Info Font',
				'preview-color'  => 'light',
				'font-family'    => 'Karla',
				'font-weight'    => '700',
				'font-size'      => '13px',
				'color'          => '#3a4749',
				'margin-top'     => '20px',
				'additional-css' => 'text-transform: uppercase; letter-spacing: 1.3px;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .post-info',
			),
		) : null,
		// Post Container.
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'reader' ),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'readmore_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Read More', 'reader' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide readmore.', 'reader' ),
			'std'      => '1',
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'reader' ),
			'sub_desc' => esc_html__( 'Select border', 'reader' ),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'post_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'reader' ),
			'sub_desc' => esc_html__( 'Post margin.', 'reader' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '56px',
				'bottom' => '0',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'post_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'reader' ),
			'sub_desc' => esc_html__( 'Post padding.', 'reader' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'post_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'reader' ),
			'std'   => array(
				'preview-text'  => 'Post Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Barlow Condensed',
				'font-weight'   => '600',
				'font-size'     => '32px',
				'line-height'   => '36px',
				'color'         => '#3a4749',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'post_excerpt_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Excerpt Font', 'reader' ),
			'std'   => array(
				'preview-text'   => 'Post Excerpt Font',
				'preview-color'  => 'light',
				'font-family'    => 'Karla',
				'font-weight'    => '400',
				'font-size'      => '16px',
				'line-height'    => '26px',
				'color'          => '#3a4749',
				'additional-css' => 'opacity: 0.75; letter-spacing: 0.272px;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .front-view-content',
			),
		) : null,

	);
endforeach;
