<?php
/**
 * Single Subscribe
 *
 * @package Reader
 */

$menus['single-subscribe'] = array(
	'title' => esc_html__( 'Subscribe Box', 'reader' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of Subscribe box in single posts page.', 'reader' ),
);

$sections['single-subscribe'] = array(

	array(
		'id'    => 'single_subscribe_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Subscribe box Settings', 'reader' ),
	),
	array(
		'id'       => 'single_subscribe_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Subscribe box Background', 'reader' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image for subscribe box from here.', 'reader' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#e0f9ff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'single_subscribe_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Margin', 'reader' ),
		'sub_desc' => esc_html__( 'Set Subscribe box margin from here.', 'reader' ),
		'std'      => array(
			'top'    => '30px',
			'right'  => '0',
			'bottom' => '30px',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_subscribe_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'reader' ),
		'sub_desc' => esc_html__( 'Set Subscribe box padding from here.', 'reader' ),
		'std'      => array(
			'top'    => '30px',
			'right'  => '30px',
			'bottom' => '30px',
			'left'   => '30px',
		),
	),
	array(
		'id'       => 'single_subscribe_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'reader' ),
		'sub_desc' => esc_html__( 'Subscribe box border radius.', 'reader' ),
		'std'      => '0',
		'args'     => array( 'type' => 'number' ),
	),

	array(
		'id'    => 'single_subscribe_title_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Subscribe box Title Settings', 'reader' ),
	),
	array(
		'id'    => 'single_subscribe_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Subscribe Title Font', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Subscribe Title Font',
			'preview-color'  => 'light',
			'font-family'    => 'Barlow Condensed',
			'font-weight'    => '600',
			'font-size'      => '30px',
			'line-height'    => '32px',
			'color'          => '#3a4749',
			'additional-css' => 'text-transform: uppercase; letter-spacing: 0.608px;',
			'css-selectors'  => '.single-subscribe .widget #wp-subscribe .title',
		),
	),
	array(
		'id'    => 'single_subscribe_text_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Subscribe box Text Settings', 'reader' ),
	),
	array(
		'id'    => 'single_subscribe_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Subscribe Text Font', 'reader' ),
		'std'   => array(
			'preview-text'  => 'Subscribe Text Font',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '24px',
			'color'         => '#3a4749',
			'css-selectors' => '.single-subscribe .widget #wp-subscribe p.text, .single-subscribe .widget .wp-subscribe .wps-consent-wrapper label, .single-subscribe .widget .wp-subscribe-wrap .error, .single-subscribe .widget .wp-subscribe-wrap .thanks',
		),
	),
	array(
		'id'    => 'single_subscribe_input_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Subscribe box Input Settings', 'reader' ),
	),
	array(
		'id'       => 'single_subscribe_input_background',
		'type'     => 'color',
		'title'    => esc_html__( 'Background Color', 'reader' ),
		'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'reader' ),
		'std'      => '#ffffff',
	),
	array(
		'id'       => 'single_subscribe_input_height',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Height', 'reader' ),
		'sub_desc' => esc_html__( 'Subscribe box input fields height.', 'reader' ),
		'std'      => '42',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'single_subscribe_input_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'reader' ),
		'sub_desc' => esc_html__( 'Subscribe box input fields border radius.', 'reader' ),
		'std'      => '0',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'single_subscribe_input_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'reader' ),
		'sub_desc' => esc_html__( 'Select border', 'reader' ),
	),
	array(
		'id'    => 'single_subscribe_input_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Subscribe Input Fields Font', 'reader' ),
		'std'   => array(
			'preview-text'  => 'Subscribe Input Fields',
			'preview-color' => 'light',
			'font-family'   => 'karla',
			'font-weight'   => '400',
			'font-size'     => '14px',
			'color'         => '#3a4749',
			'css-selectors' => '.single-subscribe .widget #wp-subscribe input.email-field, .single-subscribe .widget #wp-subscribe input.name-field',
		),
	),
	array(
		'id'    => 'single_subscribe_submit_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Subscribe box Submit Settings', 'reader' ),
	),
	array(
		'id'       => 'single_subscribe_submit_backgroud',
		'type'     => 'color',
		'title'    => esc_html__( 'Background Color', 'reader' ),
		'sub_desc' => esc_html__( 'Submit button background color', 'reader' ),
		'std'      => reader_get_settings( 'primary_color_scheme' ),
	),
	array(
		'id'       => 'single_subscribe_submit_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'reader' ),
		'sub_desc' => esc_html__( 'Subscribe box submit button border radius.', 'reader' ),
		'std'      => '0',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'single_subscribe_submit_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'reader' ),
		'sub_desc' => esc_html__( 'Select border', 'reader' ),
	),
	array(
		'id'       => 'single_subscribe_submit_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'reader' ),
		'sub_desc' => esc_html__( 'Set subscribe submit button padding from here.', 'reader' ),
		'std'      => array(
			'top'    => '10px',
			'right'  => '0',
			'bottom' => '10px',
			'left'   => '0',
		),
	),
	array(
		'id'    => 'single_subscribe_submit_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Subscribe Submit Button Font', 'reader' ),
		'std'   => array(
			'preview-text'  => 'Subscribe Submit Button',
			'preview-color' => 'dark',
			'font-family'   => 'Karla',
			'font-weight'   => '700',
			'font-size'     => '16px',
			'color'         => '#ffffff',
			'css-selectors' => '.single-subscribe .widget #wp-subscribe input.submit',
		),
	),
	array(
		'id'    => 'single_subscribe_small_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Subscribe box small text Settings', 'reader' ),
	),
	array(
		'id'    => 'single_subscribe_small_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Subscribe Small Text Font', 'reader' ),
		'std'   => array(
			'preview-text'  => 'Subscribe Small Text',
			'preview-color' => 'dark',
			'font-family'   => 'Karla',
			'font-weight'   => '400',
			'font-size'     => '13px',
			'line-height'   => '20px',
			'color'         => '#a6a7aa',
			'css-selectors' => '.single-subscribe .widget .wp-subscribe-wrap p.footer-text',
		),
	),
);
