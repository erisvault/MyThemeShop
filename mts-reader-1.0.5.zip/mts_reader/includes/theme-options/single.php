<?php
/**
 * Single Tab
 *
 * @package Reader
 */

$menus['single-general'] = array(
	'title' => esc_html__( 'General', 'reader' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of your single posts page.', 'reader' ),
);

$sections['single-general'] = array(

	array(
		'id'       => 'show_single_featured',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Featured image', 'reader' ),
		'sub_desc' => esc_html__( 'Enable/Disable the Featured images in the single post.', 'reader' ),
		'std'      => '1',
	),

	array(
		'id'       => 'mts_single_post_layout',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Post Layout', 'reader' ),
		'sub_desc' => esc_html__( 'Customize the look of single posts', 'reader' ),
		'options'  => array(
			'enabled'  => array(
				'content'  => array(
					'label'     => esc_html__( 'Post Content', 'reader' ),
					'subfields' => array(),
				),
				'thanks'   => array(
					'label'     => esc_html__( 'Thanks Section', 'reader' ),
					'subfields' => array(),
				),
				'tags'     => array(
					'label'     => esc_html__( 'Tags', 'reader' ),
					'subfields' => array(
						array(
							'id'    => 'tags_bgcolor',
							'type'  => 'color',
							'title' => esc_html__( 'Tags background color', 'reader' ),
							'std'   => '#3a4749',
						),
					),
				),
				'author'   => array(
					'label'     => esc_html__( 'Author Box', 'reader' ),
					'subfields' => array(),
				),
				'nextpost' => array(
					'label'     => esc_html__( 'Next Post Section', 'reader' ),
					'subfields' => array(),
				),
				'related'  => array(
					'label'     => esc_html__( 'Related Posts', 'reader' ),
					'subfields' => array(
						array(
							'id'       => 'related_post_title',
							'type'     => 'text',
							'title'    => esc_html__( 'Related Posts Title', 'reader' ),
							'sub_desc' => esc_html__( 'Enter the title text to show in the related posts section.', 'reader' ),
							'std'      => 'Related Posts',
						),
						array(
							'id'       => 'mts_related_posts_taxonomy',
							'type'     => 'switch',
							'title'    => esc_html__( 'Related Posts Taxonomy', 'reader' ),
							'options'  => array(
								'tags'       => esc_html__( 'Tags', 'reader' ),
								'categories' => esc_html__( 'Categories', 'reader' ),
							),
							'class'    => 'green',
							'sub_desc' => esc_html__( 'Related Posts based on tags or categories.', 'reader' ),
							'std'      => 'categories',
						),
					),
				),
			),
			'disabled' => array(
				'subscribe' => array(
					'label'     => esc_html__( 'Subscribe Box', 'reader' ),
					'subfields' => array(),
				),
			),
		),
	),

	array(
		'id'       => 'mts_single_headline_meta_info',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Meta Info', 'reader' ),
		'sub_desc' => esc_html__( 'Organize how you want the post meta info to appear on single page', 'reader' ),
		'options'  => array(
			'enabled'  => array(
				'date'     => array(
					'label'     => esc_html__( 'Date', 'reader' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_date_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'reader' ),
						),
					),
				),
				'category' => array(
					'label'     => esc_html__( 'Categories', 'reader' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_category_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'reader' ),
						),
					),
				),
				'comment'  => array(
					'label'     => esc_html__( 'Comment Count', 'reader' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_comment_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'reader' ),
						),
					),
				),
			),
			'disabled' => array(
				'author' => array(
					'label'     => esc_html__( 'Author Name', 'reader' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_author_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'reader' ),
						),
					),
				),
			),
		),
	),

	array(
		'id'       => 'mts_breadcrumb',
		'type'     => 'switch',
		'title'    => esc_html__( 'Breadcrumbs', 'reader' ),
		'sub_desc' => esc_html__( 'Breadcrumbs are a great way to make your site more user-friendly. You can enable them by checking this box.', 'reader' ),
		'std'      => '1',
	),

	array(
		'id'         => 'breadcrumb_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Breadcrumbs Font', 'reader' ),
		'std'        => array(
			'preview-text'   => 'Breadcrumbs',
			'preview-color'  => 'light',
			'font-family'    => 'Barlow Condensed',
			'font-weight'    => '500',
			'font-size'      => '18px',
			'color'          => '#3a4749',
			'additional-css' => 'text-transform: uppercase; letter-spacing: 0.594px;',
			'css-selectors'  => '.breadcrumb-wrapper, .breadcrumb-wrapper a',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_author_comment',
		'type'     => 'switch',
		'title'    => esc_html__( 'Highlight Author Comment', 'reader' ),
		'sub_desc' => esc_html__( 'Use this button to highlight author comments.', 'reader' ),
		'std'      => '1',
	),

	array(
		'id'       => 'mts_comment_date',
		'type'     => 'switch',
		'title'    => esc_html__( 'Date in Comments', 'reader' ),
		'sub_desc' => esc_html__( 'Use this button to show the date for comments.', 'reader' ),
		'std'      => '1',
	),
);
