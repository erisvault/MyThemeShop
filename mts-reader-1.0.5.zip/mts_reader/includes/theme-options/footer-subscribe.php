<?php
/**
 * Footer Subscribe
 *
 * @package Reader
 */

$menus['footer']['child']['footer-subscribe'] = array(
	'title' => esc_html__( 'Footer Subscribe', 'reader' ),
	'desc'  => esc_html__( 'From here, you can control the Footer Subscribe Section.', 'reader' ),
);

// Dependency check - enable/disable Footer Subscribe Section.
$footer_subscribe_dependency = array(
	'relation' => 'and',
	array(
		'field'      => 'footer_subscribe',
		'value'      => '1',
		'comparison' => '==',
	),
);

$sections['footer-subscribe'] = array(

	array(
		'id'       => 'footer_subscribe',
		'type'     => 'switch',
		'title'    => esc_html__( 'Footer Subscribe Section', 'reader' ),
		'sub_desc' => esc_html__( 'Enable or disable Footer Subscribe Section with this option.', 'reader' ),
		'std'      => '0',
	),

	array(
		'id'         => 'footer_subscribe_location',
		'type'       => 'button_set',
		'class'      => 'green',
		'title'      => esc_html__( 'Show Footer Subscribe On', 'reader' ),
		'sub_desc'   => wp_kses( __( 'Choose where you want to show the <strong>Footer Subscribe</strong>', 'reader' ), array( 'strong' => '' ) ),
		'options'    => array(
			'all'    => esc_html__( 'All Pages', 'reader' ),
			'home'   => esc_html__( 'Home Page', 'reader' ),
			'single' => esc_html__( 'Single Page', 'reader' ),
			'both'   => esc_html__( 'Home and Single Page', 'reader' ),
		),
		'std'        => 'both',
		'dependency' => $footer_subscribe_dependency,
	),

	array(
		'id'         => 'footer_subscribe_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Background Color', 'reader' ),
		'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'reader' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '#e0f9ff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
		'dependency' => $footer_subscribe_dependency,
	),

	array(
		'id'         => 'footer_subscribe_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'reader' ),
		'sub_desc'   => esc_html__( 'Post margin.', 'reader' ),
		'left'       => false,
		'right'      => false,
		'std'        => array(
			'top'    => '68px',
			'bottom' => '0',
		),
		'dependency' => $footer_subscribe_dependency,
	),
	array(
		'id'         => 'footer_subscribe_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'reader' ),
		'sub_desc'   => esc_html__( 'Post padding.', 'reader' ),
		'std'        => array(
			'left'   => '0',
			'top'    => '87px',
			'right'  => '0',
			'bottom' => '70px',
		),
		'dependency' => $footer_subscribe_dependency,
	),
	array(
		'id'         => 'footer_subscribe_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'reader' ),
		'sub_desc'   => esc_html__( 'Select border', 'reader' ),
		'dependency' => $footer_subscribe_dependency,
	),

	array(
		'id'         => 'footer_subscribe_form_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Form Elements', 'reader' ),
		'dependency' => $footer_subscribe_dependency,
	),

	array(
		'id'         => 'footer_subscribe_title_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Title Typography', 'reader' ),
		'std'        => array(
			'preview-text'  => 'Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Barlow Condensed',
			'font-weight'   => '600',
			'font-size'     => '40px',
			'color'         => '#2a384a',
			'css-selectors' => '.footer-subscribe .widget #wp-subscribe h4.title',
		),
		'dependency' => $footer_subscribe_dependency,
	),
	array(
		'id'         => 'footer_subscribe_input_background',
		'type'       => 'color',
		'title'      => esc_html__( 'Input Fields Background Color', 'reader' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'reader' ),
		'std'        => '#ffffff',
		'dependency' => $footer_subscribe_dependency,
	),
	array(
		'id'         => 'footer_subscribe_input_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Input Fields Typography', 'reader' ),
		'std'        => array(
			'preview-text'   => 'Input Fields Font',
			'preview-color'  => 'light',
			'font-family'    => 'Karla',
			'font-weight'    => '400',
			'font-size'      => '14px',
			'color'          => '#566073',
			'additional-css' => 'text-transform: uppercase; letter-spacing: 1.316px;',
			'css-selectors'  => '.footer-subscribe #wp-subscribe input.email-field, .footer-subscribe #wp-subscribe input.name-field',
		),
		'dependency' => $footer_subscribe_dependency,
	),

	array(
		'id'         => 'footer_subscribe_submit_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Submit Button Typography', 'reader' ),
		'std'        => array(
			'preview-text'   => 'Submit Button Font',
			'preview-color'  => 'dark',
			'font-family'    => 'Barlow Condensed',
			'font-weight'    => '700',
			'font-size'      => '16px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase; letter-spacing: 0.528px;',
			'css-selectors'  => '.footer-subscribe .widget #wp-subscribe input.submit',
		),
		'dependency' => $footer_subscribe_dependency,
	),

	array(
		'id'         => 'footer_subscribe_text_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Text Typography', 'reader' ),
		'std'        => array(
			'preview-text'  => 'Text Font',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '400',
			'font-size'     => '18px',
			'color'         => '#2a384a',
			'css-selectors' => '.footer-subscribe #wp-subscribe p.text, .footer-subscribe .subscribe-icons-container p',
		),
		'dependency' => $footer_subscribe_dependency,
	),
	array(
		'id'         => 'footer_subscribe_small_text_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Small Text Typography', 'reader' ),
		'std'        => array(
			'preview-text'  => 'Text Font',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '400',
			'font-size'     => '14px',
			'color'         => '#2a384a',
			'css-selectors' => '.footer-subscribe .widget #wp-subscribe p.footer-text, .footer-subscribe .widget .wp-subscribe .wps-consent-wrapper label',
		),
		'dependency' => $footer_subscribe_dependency,
	),

);
