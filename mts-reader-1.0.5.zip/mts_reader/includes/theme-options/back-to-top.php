<?php
/**
 * Back to top
 *
 * @package Reader
 */

$menus['footer']['child']['footer-back-to-top'] = array(
	'title' => esc_html__( 'Back to Top', 'reader' ),
	'desc'  => esc_html__( 'From here, you can control the back to top button.', 'reader' ),
);

// Dependency check that back to top option is enable.
$top_button_dependency = array(
	'relation' => 'and',
	array(
		'field'      => 'show_top_button',
		'value'      => '1',
		'comparison' => '==',
	),
);

$sections['footer-back-to-top'] = array(

	array(
		'id'       => 'show_top_button',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Top Button', 'reader' ),
		'sub_desc' => esc_html__( 'Enable or disable back to top button with this option.', 'reader' ),
		'std'      => '1',
	),

	array(
		'id'         => 'top_button_icon',
		'type'       => 'icon_select',
		'title'      => esc_html__( 'Top Button Icon', 'reader' ),
		'sub_desc'   => esc_html__( 'Set icon for top button icon with this option.', 'reader' ),
		'std'        => 'angle-up',
		'dependency' => $top_button_dependency,
	),

	array(
		'id'         => 'top_button_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Top Button Icon Color', 'reader' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'reader' ),
		'std'        => '#ffffff',
		'dependency' => $top_button_dependency,
	),
	array(
		'id'         => 'top_button_color_hover',
		'type'       => 'color',
		'title'      => esc_html__( 'Top Button Icon Hover Color', 'reader' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'reader' ),
		'std'        => '#ffffff',
		'dependency' => $top_button_dependency,
	),

	array(
		'id'         => 'top_button_background',
		'type'       => 'color',
		'title'      => esc_html__( 'Top Button Background', 'reader' ),
		'sub_desc'   => esc_html__( 'Set top button background color, pattern and image from here.', 'reader' ),
		'std'        => reader_get_settings( 'primary_color_scheme' ),
		'dependency' => $top_button_dependency,
	),
	array(
		'id'         => 'top_button_background_hover',
		'type'       => 'color',
		'title'      => esc_html__( 'Top Button Hover Background', 'reader' ),
		'sub_desc'   => esc_html__( 'Set top button background color, pattern and image from here.', 'reader' ),
		'std'        => '#3a4749',
		'dependency' => $top_button_dependency,
	),

	array(
		'id'         => 'top_button_font_size',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Font Size', 'reader' ),
		'sub_desc'   => esc_html__( 'Set font size of top button in px.', 'reader' ),
		'std'        => '28',
		'args'       => array( 'type' => 'number' ),
		'dependency' => $top_button_dependency,
	),

	array(
		'id'         => 'top_button_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'reader' ),
		'sub_desc'   => esc_html__( 'Set Top button padding from here.', 'reader' ),
		'std'        => array(
			'top'    => '3px',
			'right'  => '19px',
			'bottom' => '7px',
			'left'   => '19px',
		),
		'dependency' => $top_button_dependency,
	),
	array(
		'id'         => 'top_button_position',
		'type'       => 'margin',
		'title'      => esc_html__( 'Top Button Position', 'reader' ),
		'sub_desc'   => esc_html__( 'Set top button position from here.', 'reader' ),
		'std'        => array(
			'top'    => 'auto',
			'right'  => '40px',
			'bottom' => '100px',
			'left'   => 'auto',
		),
		'dependency' => $top_button_dependency,
	),

	array(
		'id'         => 'top_button_border_radius',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Border Radius', 'reader' ),
		'sub_desc'   => esc_html__( 'Set border radius of top button in px.', 'reader' ),
		'std'        => '5',
		'args'       => array( 'type' => 'number' ),
		'dependency' => $top_button_dependency,
	),

	array(
		'id'         => 'top_button_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'reader' ),
		'sub_desc'   => esc_html__( 'Select border', 'reader' ),
		'dependency' => $top_button_dependency,
	),

);
