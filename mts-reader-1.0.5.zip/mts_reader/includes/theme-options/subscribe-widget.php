<?php
/**
 * Subscribe Widget
 *
 * @package Reader
 */

$menus['subscribe-widget'] = array(
	'title' => esc_html__( 'Subscribe Widget', 'reader' ),
	'desc'  => esc_html__( 'From here, you can control the styling of subscribe widget.', 'reader' ),
);

$sections['subscribe-widget'] = array(
	array(
		'id'       => 'subscribe_widget_background',
		'type'     => 'color',
		'title'    => esc_html__( 'Background Color', 'reader' ),
		'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'reader' ),
		'std'      => '#faebe3',
	),
	array(
		'id'       => 'subscribe_widget_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'reader' ),
		'sub_desc' => esc_html__( 'Set subscribe widget padding from here.', 'reader' ),
		'std'      => array(
			'top'    => '35px',
			'right'  => '30px',
			'bottom' => '30px',
			'left'   => '25px',
		),
	),
	array(
		'id'       => 'subscribe_widget_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'reader' ),
		'sub_desc' => esc_html__( 'Set subscribe widget border radius from here.', 'reader' ),
		'std'      => '8',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'subscribe_widget_button_background',
		'type'     => 'color',
		'title'    => esc_html__( 'Submit Button Background Color', 'reader' ),
		'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'reader' ),
		'std'      => '#f3d4c3',
	),

);
