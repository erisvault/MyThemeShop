<?php
/**
 * Styling tab.
 *
 * @package Reader
 */

$menus['styling'] = array(
	'icon'  => 'fa-adjust',
	'title' => esc_html__( 'Styling', 'reader' ),
	'desc'  => esc_html__( 'Control the visual appearance of your theme, such as colors, layout and patterns, from here.', 'reader' ),
);

$sections['styling'] = array(

	array(
		'id'       => 'primary_color_scheme',
		'type'     => 'color',
		'title'    => esc_html__( 'Primary Color Scheme', 'reader' ),
		'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'reader' ),
		'std'      => '#5ce2c7',
	),

	array(
		'id'       => 'mts_layout',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Layout Style', 'reader' ),
		'sub_desc' => wp_kses( __( 'Choose the <strong>default sidebar position</strong> for your site. The position of the sidebar for individual posts can be set in the post editor.', 'reader' ), array( 'strong' => array() ) ),
		'options'  => array(
			'cslayout' => array( 'img' => $uri . 'layouts/cs.png' ),
			'sclayout' => array( 'img' => $uri . 'layouts/sc.png' ),
		),
		'std'      => 'cslayout',
	),

	array(
		'id'       => 'mts_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Site Background', 'reader' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'reader' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

);
