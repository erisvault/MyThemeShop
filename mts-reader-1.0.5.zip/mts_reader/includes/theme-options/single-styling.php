<?php
/**
 * Single Styling
 *
 * @package Reader
 */

$menus['single-styling'] = array(
	'title' => esc_html__( 'Single Styling', 'reader' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of your single posts page.', 'reader' ),
);

$sections['single-styling'] = array(

	array(
		'id'    => 'single_title_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Single Titles Styling', 'reader' ),
	),

	array(
		'id'       => 'single_title_alignment',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Single Page Title Alignment', 'reader' ),
		'sub_desc' => esc_html__( 'Choose the single page title alignment', 'reader' ),
		'options'  => array(
			'left'   => esc_html__( 'Left', 'reader' ),
			'center' => esc_html__( 'Center', 'reader' ),
			'right'  => esc_html__( 'Right', 'reader' ),
		),
		'std'      => 'left',
	),

	array(
		'id'       => 'single_title_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Single Page Title Background Color', 'reader' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'reader' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'single_title_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Page Title Padding', 'reader' ),
		'sub_desc' => esc_html__( 'Set single page title padding from here.', 'reader' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_title_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'reader' ),
		'sub_desc' => esc_html__( 'Select border', 'reader' ),
	),
	array(
		'id'    => 'single_page_titles_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Comment Section Title', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Title Font',
			'preview-color'  => 'light',
			'font-family'    => 'Barlow Condensed',
			'font-weight'    => '600',
			'font-size'      => '32px',
			'line-height'    => '1',
			'color'          => '#3a4749',
			'additional-css' => 'text-transform: uppercase; letter-spacing: 0.544px;',
			'css-selectors'  => '#respond h4, .total-comments',
		),
	),

	array(
		'id'    => 'mts_single_styling_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Single Styling', 'reader' ),
	),

	array(
		'id'       => 'single_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Background', 'reader' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image of Single, Page, Archive, Search, Category and 404 Page from here.', 'reader' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'mts_single_styling_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Margin', 'reader' ),
		'sub_desc' => esc_html__( 'Set single post margin from here.', 'reader' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '35px',
		),
	),
	array(
		'id'       => 'mts_single_styling_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Padding', 'reader' ),
		'sub_desc' => esc_html__( 'Set single post padding from here.', 'reader' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_styling_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'reader' ),
		'sub_desc' => esc_html__( 'Select border', 'reader' ),
	),
	array(
		'id'    => 'single_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Single Post Title', 'reader' ),
		'std'   => array(
			'preview-text'  => 'Single Article Title',
			'preview-color' => 'light',
			'font-family'   => 'Barlow Condensed',
			'font-weight'   => '600',
			'font-size'     => '42px',
			'color'         => '#3a4749',
			'css-selectors' => '.single-title',
		),
	),
	array(
		'id'    => 'mts_single_meta_info_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Single Meta Info Font', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Post Meta Info Font',
			'preview-color'  => 'light',
			'font-family'    => 'Karla',
			'font-weight'    => '700',
			'font-size'      => '13px',
			'color'          => '#3a4749',
			'additional-css' => 'text-transform: uppercase; letter-spacing: 1.3px;',
			'css-selectors'  => '.single_post .post-info',
		),
	),

);
