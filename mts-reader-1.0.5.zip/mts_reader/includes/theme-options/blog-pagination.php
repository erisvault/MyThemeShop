<?php
/**
 * HomePage Pagination
 *
 * @package Reader
 */

$menus['blog']['child']['blog-pagination'] = array(
	'title' => esc_html__( 'Pagination', 'reader' ),
	'desc'  => esc_html__( 'From here, you can control the elements of pagination.', 'reader' ),
);

// Dependency check - Default and Numbered pagination.
$default_pagination_dependency = array(
	'relation' => 'and',
	array(
		'field'      => 'mts_pagenavigation_type',
		'value'      => '2',
		'comparison' => '!=',
	),
);

// Dependency check the load more button.
$loadmore_button_dependency = array(
	'relation' => 'and',
	array(
		'field'      => 'mts_pagenavigation_type',
		'value'      => '2',
		'comparison' => '==',
	),
);

$sections['blog-pagination'] = array(

	array(
		'id'       => 'mts_pagenavigation_type',
		'type'     => 'radio',
		'title'    => esc_html__( 'Pagination Type', 'reader' ),
		'sub_desc' => esc_html__( 'Select pagination type.', 'reader' ),
		'options'  => array(
			'0' => esc_html__( 'Default (Next / Previous)', 'reader' ),
			'1' => esc_html__( 'Numbered (1 2 3 4...)', 'reader' ),
			'2' => esc_html__( 'AJAX (Load More Button)', 'reader' ),
			'3' => esc_html__( 'AJAX (Auto Infinite Scroll)', 'reader' ),
		),
		'std'      => '1',
	),

	array(
		'id'         => 'pagenavigation_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Pagination Alignment', 'reader' ),
		'sub_desc'   => esc_html__( 'Choose pagination alignment from here.', 'reader' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'reader' ),
			'center' => esc_html__( 'Center', 'reader' ),
			'right'  => esc_html__( 'Right', 'reader' ),
		),
		'std'        => 'center',
		'dependency' => $default_pagination_dependency,
	),

	array(
		'id'         => 'load_more_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Load More Alignment', 'reader' ),
		'sub_desc'   => esc_html__( 'Choose the load more alignment from here.', 'reader' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'reader' ),
			'center' => esc_html__( 'Center', 'reader' ),
			'right'  => esc_html__( 'Right', 'reader' ),
			'full'   => esc_html__( 'Full Width', 'reader' ),
		),
		'std'        => 'center',
		'dependency' => $loadmore_button_dependency,
	),

	array(
		'id'         => 'mts_pagenavigation_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination background color', 'reader' ),
		'sub_desc'   => esc_html__( 'Select pagination background color.', 'reader' ),
		'std'        => '#ffffff',
		'dependency' => $default_pagination_dependency,
	),
	array(
		'id'         => 'load_more_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More background color', 'reader' ),
		'sub_desc'   => esc_html__( 'Select background color for load more button.', 'reader' ),
		'std'        => reader_get_settings( 'primary_color_scheme' ),
		'dependency' => $loadmore_button_dependency,
	),
	array(
		'id'         => 'mts_pagenavigation_hover_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination background hover color', 'reader' ),
		'sub_desc'   => esc_html__( 'Select pagination background hover color.', 'reader' ),
		'std'        => reader_get_settings( 'primary_color_scheme' ),
		'dependency' => $default_pagination_dependency,
	),
	array(
		'id'         => 'load_more_hover_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More background hover color', 'reader' ),
		'sub_desc'   => esc_html__( 'Select background hover color for load more button.', 'reader' ),
		'std'        => '#3a4749',
		'dependency' => $loadmore_button_dependency,
	),
	array(
		'id'         => 'mts_pagenavigation_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination color', 'reader' ),
		'sub_desc'   => esc_html__( 'Select pagination color.', 'reader' ),
		'std'        => '#3a4749',
		'dependency' => $default_pagination_dependency,
	),
	array(
		'id'         => 'load_more_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More color', 'reader' ),
		'sub_desc'   => esc_html__( 'Select color for load more button.', 'reader' ),
		'std'        => '#ffffff',
		'dependency' => $loadmore_button_dependency,
	),
	array(
		'id'         => 'mts_pagenavigation_hover_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination hover color', 'reader' ),
		'sub_desc'   => esc_html__( 'Select pagination hover color.', 'reader' ),
		'std'        => '#ffffff',
		'dependency' => $default_pagination_dependency,
	),
	array(
		'id'         => 'load_more_hover_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More hover color', 'reader' ),
		'sub_desc'   => esc_html__( 'Select hover color for load more button.', 'reader' ),
		'std'        => '#ffffff',
		'dependency' => $loadmore_button_dependency,
	),
	array(
		'id'       => 'mts_pagenavigation_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Pagination Margin', 'reader' ),
		'sub_desc' => esc_html__( 'Update pagination margin from here.', 'reader' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '8px',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'         => 'mts_pagenavigation_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Pagination Padding', 'reader' ),
		'sub_desc'   => esc_html__( 'Update pagination padding from here.', 'reader' ),
		'std'        => array(
			'top'    => '9px',
			'right'  => '0',
			'bottom' => '9px',
			'left'   => '0',
		),
		'dependency' => $default_pagination_dependency,
	),
	array(
		'id'         => 'load_more_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Load More Padding', 'reader' ),
		'sub_desc'   => esc_html__( 'Update padding for load more button from here.', 'reader' ),
		'std'        => array(
			'top'    => '20px',
			'right'  => '30px',
			'bottom' => '17px',
			'left'   => '30px',
		),
		'dependency' => $loadmore_button_dependency,
	),
	array(
		'id'       => 'mts_pagenavigation_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Pagination border radius', 'reader' ),
		'sub_desc' => esc_html__( 'Update pagination border radius in px.', 'reader' ),
		'std'      => '35',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'pagenavigation_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'reader' ),
		'sub_desc' => esc_html__( 'Select border', 'reader' ),
	),
	array(
		'id'    => 'pagination_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Pagination', 'reader' ),
		'color' => false,
		'std'   => array(
			'preview-text'  => 'Pagination',
			'preview-color' => 'light',
			'font-family'   => 'Barlow Condensed',
			'font-weight'   => '700',
			'font-size'     => '14px',
			'css-selectors' => '.pagination',
		),
	),

);
