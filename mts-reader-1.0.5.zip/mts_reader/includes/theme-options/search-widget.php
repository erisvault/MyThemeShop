<?php
/**
 * Search Widget
 *
 * @package Reader
 */

$menus['search-widget'] = array(
	'title' => esc_html__( 'Search Widget', 'reader' ),
	'desc'  => esc_html__( 'From here, you can control the styling of search widget and social profile icons widget.', 'reader' ),
);

$sections['search-widget'] = array(
	array(
		'id'       => 'search_widget_background',
		'type'     => 'color',
		'title'    => esc_html__( 'Background Color', 'reader' ),
		'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'reader' ),
		'std'      => '#e9ecf1',
	),
	array(
		'id'       => 'search_widget_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'reader' ),
		'sub_desc' => esc_html__( 'Set search widget padding from here.', 'reader' ),
		'std'      => array(
			'top'    => '35px',
			'right'  => '30px',
			'bottom' => '30px',
			'left'   => '25px',
		),
	),
	array(
		'id'       => 'search_widget_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'reader' ),
		'sub_desc' => esc_html__( 'Set search widget border radius from here.', 'reader' ),
		'std'      => '8',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'search_widget_button_background',
		'type'     => 'color',
		'title'    => esc_html__( 'Submit Button Background Color', 'reader' ),
		'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'reader' ),
		'std'      => '#cdd5e3',
	),

);
