<?php
/**
 * Single Thanks
 *
 * @package Reader
 */

$menus['single-thanks'] = array(
	'title' => esc_html__( 'Thanks Section', 'reader' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of Author box in single posts page.', 'reader' ),
);

$sections['single-thanks'] = array(

	array(
		'id'       => 'thanks_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Background', 'reader' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image for subscribe box from here.', 'reader' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#e9ecf1',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'thanks_title',
		'type'     => 'text',
		'title'    => esc_html__( 'Title', 'reader' ),
		'sub_desc' => esc_html__( 'Enter title for thanks section.', 'reader' ),
		'std'      => 'Thanks for Reading',
	),
	array(
		'id'       => 'thanks_text',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Text', 'reader' ),
		'sub_desc' => esc_html__( 'Enter text for thanks section.', 'reader' ),
		'std'      => 'Enjoyed this post? Share it with your networks.',
	),
	array(
		'id'       => 'thanks_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Margin', 'reader' ),
		'sub_desc' => esc_html__( 'Set thanks section margin from here.', 'reader' ),
		'std'      => array(
			'top'    => '25px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'thanks_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'reader' ),
		'sub_desc' => esc_html__( 'Set thanks section padding from here.', 'reader' ),
		'std'      => array(
			'top'    => '36px',
			'right'  => '48px',
			'bottom' => '39px',
			'left'   => '48px',
		),
	),
	array(
		'id'       => 'thanks_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'reader' ),
		'sub_desc' => esc_html__( 'Set border radius for thanks section.', 'reader' ),
		'std'      => '8',
		'args'     => array( 'type' => 'number' ),
	),

	array(
		'id'    => 'thanks_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Thanks Section Title Font', 'reader' ),
		'std'   => array(
			'preview-text'  => 'Thanks Section Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Barlow Condensed',
			'font-weight'   => '600',
			'font-size'     => '32px',
			'color'         => '#3a4749',
			'css-selectors' => '.thanks-section h3',
		),
	),
	array(
		'id'    => 'thanks_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Thanks Section Text Font', 'reader' ),
		'std'   => array(
			'preview-text'   => 'Thanks Section Text Font',
			'preview-color'  => 'light',
			'font-family'    => 'Karla',
			'font-weight'    => '400',
			'font-size'      => '15px',
			'line-height'    => '30px',
			'color'          => '#3a4749',
			'additional-css' => 'opacity: 0.75;',
			'css-selectors'  => '.thanks-section p',
		),
	),

);
