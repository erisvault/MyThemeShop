<?php
/**
 * Footer Tab
 *
 * @package Reader
 */

$menus['footer'] = array(
	'icon'  => 'fa-table',
	'title' => esc_html__( 'Footer', 'reader' ),
	'desc'  => esc_html__( 'From here, you can control the elements of footer section.', 'reader' ),
);

$menus['footer']['child']['footer-general'] = array(
	'title' => esc_html__( 'General', 'reader' ),
	'desc'  => esc_html__( 'From here, you can control the elements of footer section.', 'reader' ),
);

$mts_patterns = array(
	'nobg' => array( 'img' => $uri . 'bg-patterns/nobg.png' ),
);
for ( $i = 1; $i <= 29; $i++ ) {
	$mts_patterns[ 'hbg' . $i ] = array( 'img' => $uri . 'bg-patterns/hbg' . $i . '.png' );
}

$sections['footer-general'] = array(

	array(
		'id'       => 'mts_top_footer',
		'type'     => 'switch',
		'title'    => esc_html__( 'Footer', 'reader' ),
		'sub_desc' => esc_html__( 'Enable or disable footer with this option.', 'reader' ),
		'std'      => '0',
	),

	array(
		'id'         => 'mts_top_footer_num',
		'type'       => 'button_set',
		'class'      => 'green',
		'title'      => esc_html__( 'Footer Layout', 'reader' ),
		'sub_desc'   => wp_kses( __( 'Choose the number of widget areas in the <strong>footer</strong>', 'reader' ), array( 'strong' => '' ) ),
		'options'    => array(
			'3' => esc_html__( '3 Widgets', 'reader' ),
			'4' => esc_html__( '4 Widgets', 'reader' ),
			'5' => esc_html__( '5 Widgets', 'reader' ),
		),
		'std'        => '5',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_top_footer',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_copyrights',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Copyrights Text', 'reader' ),
		'sub_desc' => esc_html__( 'You can change or remove our link from footer and use your own custom text.', 'reader' ) . ( MTS_THEME_WHITE_LABEL ? '' : wp_kses( __( '(You can also use your affiliate link to <strong>earn 55% of sales</strong>. Ex: <a href="https://mythemeshop.com/go/aff/aff" target="_blank">https://mythemeshop.com/?ref=username</a>)', 'reader' ), array( 'strong' => '', 'a' => array( 'href' => array(), 'target' => array() ) ) ) ),
		// translators: Default value.
		'std'      => MTS_THEME_WHITE_LABEL ? null : sprintf( __( 'Theme by %s', 'reader' ), '<a href="https://mythemeshop.com/" rel="nofollow">MyThemeShop</a>' ),
	),

);
