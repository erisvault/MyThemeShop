<?php
/**
 * Performance Tab
 *
 * @package Reader
 */

$menus['performance'] = array(
	'icon'  => 'fa-bolt',
	'title' => esc_html__( 'Performance', 'reader' ),
	'desc'  => esc_html__( 'This tab contains optimization options which can help make your site run faster.', 'reader' ),
);

$sections['performance'] = array(

	array(
		'id'       => 'async_js',
		'type'     => 'switch',
		'title'    => esc_html__( 'Async JavaScript', 'reader' ),
		// translators: Using code tag in description.
		'sub_desc' => sprintf( esc_html__( 'Add %s attribute to script tags to improve page download speed.', 'reader' ), '<code>async</code>' ),
		'std'      => '1',
	),

	array(
		'id'       => 'remove_ver_params',
		'type'     => 'switch',
		'title'    => esc_html__( 'Remove ver parameters', 'reader' ),
		// translators: Using code tag in description.
		'sub_desc' => sprintf( esc_html__( 'Remove %s parameter from CSS and JS file calls. It may improve speed in some browsers which do not cache files having the parameter.', 'reader' ), '<code>ver</code>' ),
		'std'      => '1',
	),

	array(
		'id'       => 'disable_emojis',
		'type'     => 'switch',
		'title'    => esc_html__( 'Disable Emojis', 'reader' ),
		'sub_desc' => esc_html__( 'Disables the new WordPress emoji functionality.', 'reader' ),
		'std'      => '0',
	),

	array(
		'id'       => 'prefetching',
		'type'     => 'switch',
		'title'    => esc_html__( 'Prefetching', 'reader' ),
		'sub_desc' => esc_html__( 'Enable or disable prefetching. If user is on homepage, then single page will load faster and if user is on single page, homepage will load faster in modern browsers.', 'reader' ),
		'std'      => '0',
	),
);

if ( reader_is_woocommerce_active() ) {
	$sections['performance'][] = array(
		'id'       => 'optimize_wc',
		'type'     => 'switch',
		'title'    => esc_html__( 'Optimize WooCommerce scripts', 'reader' ),
		'sub_desc' => esc_html__( 'Load WooCommerce scripts and styles only on WooCommerce pages.', 'reader' ),
		'std'      => '1',
	);
}
