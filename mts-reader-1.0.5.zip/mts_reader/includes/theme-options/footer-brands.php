<?php
/**
 * Brands
 *
 * @package Reader
 */

$menus['footer']['child']['footer-brands'] = array(
	'title' => esc_html__( 'Brands Section', 'reader' ),
	'desc'  => esc_html__( 'From here, you can control the Brands Section.', 'reader' ),
);

$brands_dependency = array(
	'relation' => 'and',
	array(
		'field'      => 'footer_brands_section',
		'value'      => '1',
		'comparison' => '==',
	),
);

$sections['footer-brands'] = array(

	array(
		'id'       => 'footer_brands_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Brands Section', 'reader' ),
		'sub_desc' => esc_html__( 'Enable or disable Brands Section with this option.', 'reader' ),
		'std'      => '0',
	),

	array(
		'id'         => 'footer_brands_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Brands Section Alignment', 'reader' ),
		'sub_desc'   => esc_html__( 'Choose alignment of Brands Section.', 'reader' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'reader' ),
			'center' => esc_html__( 'Center', 'reader' ),
			'right'  => esc_html__( 'Right', 'reader' ),
		),
		'std'        => 'center',
		'class'      => 'green',
		'dependency' => $brands_dependency,
	),

	array(
		'id'         => 'brands_section_title',
		'type'       => 'text',
		'title'      => esc_html__( 'Brands Title', 'reader' ),
		'sub_desc'   => esc_html__( 'Enter brands title here.', 'reader' ),
		'std'        => esc_html__( 'Our Brands:', 'reader' ),
		'dependency' => $brands_dependency,

	),

	array(
		'id'         => 'footer_brands_items',
		'type'       => 'group',
		'title'      => esc_html__( 'Brands', 'reader' ),
		'groupname'  => esc_html__( 'Brand', 'reader' ), // Group name.
		'subfields'  => array(
			array(
				'id'       => 'brand_title',
				'type'     => 'text',
				'title'    => esc_html__( 'Title', 'reader' ),
				'sub_desc' => esc_html__( 'The title will not be shown.', 'reader' ),
			),
			array(
				'id'       => 'brand_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Image', 'reader' ),
				'sub_desc' => esc_html__( 'Upload or select an image for brand', 'reader' ),
			),
			array(
				'id'       => 'brand_url',
				'type'     => 'text',
				'title'    => esc_html__( 'Link', 'reader' ),
				'sub_desc' => esc_html__( 'Insert a link URL of brand', 'reader' ),
				'std'      => '#',
			),
		),
		'dependency' => $brands_dependency,
	),

	array(
		'id'         => 'brands_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'reader' ),
		'sub_desc'   => esc_html__( 'Brands Section margin.', 'reader' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => $brands_dependency,
	),
	array(
		'id'         => 'brands_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'reader' ),
		'sub_desc'   => esc_html__( 'Brands Section padding.', 'reader' ),
		'std'        => array(
			'top'    => '40px',
			'right'  => '0',
			'bottom' => '27px',
			'left'   => '0',
		),
		'dependency' => $brands_dependency,
	),
	array(
		'id'         => 'brands_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'reader' ),
		'sub_desc'   => esc_html__( 'Select border', 'reader' ),
		'dependency' => $brands_dependency,
	),
);
