<?php
/**
 * Clickable Background
 *
 */

if ( reader_get_settings( 'background_clickable' ) && reader_get_settings( 'background_link' ) ) {
	$target = ( 1 === reader_get_settings( 'background_link_new_tab' ) ) ? 'target="_blank"' : '';
	printf( '<a href="%1$s" rel="nofollow" class="clickable-background" %2$s>', reader_get_settings( 'background_link' ), $target );
}
