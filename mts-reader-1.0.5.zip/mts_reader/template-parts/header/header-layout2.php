<?php
/**
 * Header Layout Default
 *
 * @package Reader
 */
?>

<header<?php reader_attr( 'header' ); ?>>
<?php
if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'header' ) ) {
	if ( reader_get_settings( 'mts_sticky_nav' ) ) {
		?>
	<div class="clear" id="catcher"></div>
	<div id="header" class="sticky-navigation clearfix">
	<?php } else { ?>
	<div id="header" class="clearfix">
	<?php } ?>
		<div class="container">

			<div class="logo-wrap">
				<?php reader_logo(); ?>
			</div>

			<?php
			// Header Social Icons.
			if ( ! empty( reader_get_settings( 'header_social_icons' ) ) && is_array( reader_get_settings( 'header_social_icons' ) ) ) {
				$header_icons = reader_get_settings( 'header_social_icons' );
				reader_social_icons( $header_icons, true );
			}
			?>

			<div id="primary-navigation" class="primary-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
				<a href="#" id="pull" class="toggle-mobile-menu"><?php _e( 'Menu', 'reader' ); ?></a>
				<?php if ( has_nav_menu( 'mobile' ) ) { ?>

					<nav class="navigation clearfix">
						<?php
						// Primary Navigation.
						if ( has_nav_menu( 'primary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'primary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new reader_menu_walker(),
							));
						}
						?>
					</nav>
					<nav class="navigation mobile-only clearfix mobile-menu-wrapper">
						<?php
						// Mobile Menu.
						if ( has_nav_menu( 'mobile' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'mobile',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new reader_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } else { ?>

					<nav class="navigation clearfix mobile-menu-wrapper">
						<?php
						// Primary Navigation.
						if ( has_nav_menu( 'primary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'primary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new reader_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } ?>
			</div>

		</div><!--.container-->

	</div><!--#header-->
	<?php
}
?>

</header>

<?php get_template_part( 'template-parts/header/header', 'nav-adcode' ); ?>

<?php if ( reader_get_settings( 'show_secondary_nav' ) ) { ?>
	<div id="secondary-nav">
		<div class="container clearfix">
			<div id="secondary-navigation" class="secondary-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
				<nav class="navigation clearfix">
					<?php
					// Primary Navigation.
					if ( has_nav_menu( 'secondary-menu' ) ) {
						wp_nav_menu( array(
							'theme_location' => 'secondary-menu',
							'menu_class'     => 'menu clearfix',
							'container'      => '',
							'walker'         => new reader_menu_walker(),
						));
					}
					?>
				</nav>
			</div>
		</div>
	</div>
<?php } ?>

<?php get_template_part( 'template-parts/header/header', 'adcode' ); ?>
