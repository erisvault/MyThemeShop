<?php if ( reader_get_settings( 'navigation_ad' ) && reader_get_settings( 'navigation_adcode' ) ) { ?>
	<div class="navigation-banner">
		<div class="container">
			<div style="<?php ad_size_value( reader_get_settings( 'navigation_ad_size' ) ); ?>">
				<?php echo reader_get_settings( 'navigation_adcode' ); ?>
			</div>
		</div>
	</div>
<?php } ?>
