<?php
/**
 * Posts Layout - default
 *
 * @package Reader
 */

$featured = reader()->featured_layouts;
?>

<div class="container clear <?php $featured->get_post_container_class(); ?>">

	<div class="<?php reader_article_class(); ?>">

		<?php
		// Elementor 'archive' location.
		if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'archive' ) ) {
			?>

			<?php $featured->get_section_title(); ?>

			<div id="content_box">

				<?php reader_action( 'start_content_box' ); ?>

				<section id="latest-posts" class="layout-default clearfix">
					<?php
					while ( have_posts() ) :
						the_post();
						?>
						<article class="latestPost excerpt">

							<?php $featured->get_post_thumbnail(); ?>

							<div class="wrapper">

								<?php $featured->get_post_title(); ?>

								<?php $featured->get_post_content(); ?>

							</div>

						</article>
						<?php
					endwhile;

					$featured->get_post_pagination();
					?>
				</section><!--#latest-posts-->

			</div>

			<?php
		}
		?>

	</div>

	<?php get_sidebar(); ?>

</div>
