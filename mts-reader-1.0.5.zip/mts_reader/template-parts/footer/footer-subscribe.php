<?php
/**
 * Footer Subscribe Section
 *
 * @package reader
 */

if ( ! reader_get_settings( 'footer_subscribe' ) ) {
	return;
}

$page = reader_get_settings( 'footer_subscribe_location' );
if ( 'all' === $page ) {
	$condition = $page;
} elseif ( 'home' === $page ) {
	$condition = is_home();
} elseif ( 'single' === $page ) {
	$condition = is_single() || ( ! is_home() && ! is_archive() || ( reader_is_woocommerce_active() && ! is_shop() && ! is_product_taxonomy() ) );
} elseif ( 'both' === $page ) {
	$condition = is_home() || ( is_single() || ( reader_is_woocommerce_active() ) );
}
?>

<?php
if ( $condition ) {
?>

<section class="footer-subscribe clearfix">

	<div class="container">

		<div class="wrapper clearfix">

			<div class="footer-subscribe-wrapper">
				<?php
				dynamic_sidebar( 'footer-subscribe' );
				?>
			</div>

		</div>

	</div>

</section><!-- .footer-subscribe -->

<?php
}
?>
