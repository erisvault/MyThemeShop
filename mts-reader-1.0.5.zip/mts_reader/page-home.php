<?php
/**
 * Template Name: HomePage
 *
 * @package Reader
 */

get_header();

?>

<div id="wrapper" class="clearfix">

	<?php

	reader_homepage_sections();

	get_footer();
