<?php $mts_options = get_option(MTS_THEME_NAME); ?>

<?php if ( isset($mts_options['mts_shop_section']) && $mts_options['mts_shop_section'] == '1' ) { ?>
	<section class="lets-shop">
		<div class="container clearfix">
			<?php echo !empty($mts_options['mts_shop_title']) ? '<h3 class="featured-category-title">'.$mts_options['mts_shop_title'].'</h3>' : ''; ?>
			<div class="left-section">
				<?php if( !empty($mts_options['mts_shop_image']) ) { ?>
					<img src="<?php echo $mts_options['mts_shop_image']; ?>" alt="<?php echo $mts_options['mts_shop_title']; ?>">
				<?php } else { ?>
					<img src="<?php echo get_template_directory_uri() . '/images/nothumb-lets-shop.png'; ?>" alt="<?php echo $mts_options['mts_shop_title']; ?>">
				<?php } ?>
			</div><!-- left-section -->

			<div class="right-section">
				<?php if( !empty($mts_options['mts_shop_description']) ) { ?>
					<p class="shop-description"><?php echo $mts_options['mts_shop_description']; ?></p>
				<?php } ?>
				<?php echo isset($mts_options['mts_shop_subheading']) ? '<h5 class="subheading">'.$mts_options['mts_shop_subheading'].'</h5>' : ''; ?>

				<?php if ( !empty($mts_options['mts_shop_list']) && is_array($mts_options['mts_shop_list']) ) { ?>
					<ul class="shop-list">
						<?php foreach( $mts_options['mts_shop_list'] as $shop_list ) : ?>
							<li>
							<?php echo !empty($shop_list['mts_shop_list_url']) ? '<a href="'.$shop_list['mts_shop_list_url'].'">' : ''; ?>
							<?php if( !empty( $shop_list['mts_shop_list_icon'] ) && isset( $shop_list['mts_shop_list_icon'] ) ) : ?>
								<i class="fa fa-<?php print $shop_list['mts_shop_list_icon'] ?>"></i>
							<?php endif; ?>
							<?php echo isset($shop_list['mts_shop_list_title']) ? $shop_list['mts_shop_list_title'] : ''; ?>
							<?php echo isset($shop_list['mts_shop_list_url']) ? '</a>' : ''; ?>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php } ?>
			</div><!-- right-section -->
		</div>
	</section>
<?php } ?>