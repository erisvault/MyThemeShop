<?php $mts_options = get_option(MTS_THEME_NAME);

if ( isset($mts_options['mts_home_social_icons_section']) && $mts_options['mts_home_social_icons_section'] == '1' ) { ?>
	<?php if ( !empty($mts_options['mts_home_social']) && is_array($mts_options['mts_home_social']) ) { ?>
		<div class="home-social-icons">
			<div class="container clearfix">
				<?php foreach( $mts_options['mts_home_social'] as $home_social_icons ) :
					if( ! empty( $home_social_icons['mts_home_social_icon'] ) && isset( $home_social_icons['mts_home_social_icon'] ) ) : ?>
						<div class="home-social-icon icon-<?php print $home_social_icons['mts_home_social_icon'] ?>">
							<div class="social-left" style="background-color: <?php echo $home_social_icons['mts_home_social_bgcolor']; ?>;">
								<i class="fa fa-<?php print $home_social_icons['mts_home_social_icon'] ?>"></i> 
								<?php echo $home_social_icons['mts_home_social_title']; ?>
							</div>
							<div class="social-right" style="color: <?php echo $home_social_icons['mts_home_social_bgcolor']; ?>;">
								<?php echo $home_social_icons['mts_home_social_followers']; ?>
							</div>
						</div>
					<?php endif;
				endforeach; ?>
			</div>
		</div>
	<?php }
} ?>