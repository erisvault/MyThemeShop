<?php
/**
 * The main template file.
 *
 * Used to display the homepage when home.php doesn't exist.
 */
$mts_options = get_option(MTS_THEME_NAME);
get_header(); ?>

<div id="page">
	<div class="article">
		<div id="content_box">
			<?php if ( !is_paged() ) {
				$section_count = 0;
				$featured_categories = array();
				if ( !empty( $mts_options['mts_featured_categories'] ) ) {
					foreach ( $mts_options['mts_featured_categories'] as $section ) {
						$section_count++;
						$category_id = $section['mts_featured_category'];
						$featured_categories[] = $category_id;
						$posts_num = $section['mts_featured_category_postsnum'];
						$text_color = isset($section['mts_featured_text_color']) ? $section['mts_featured_text_color'] : '#212121';
						$post_info = isset($section['mts_home_meta_info_enable']) ? $section['mts_home_meta_info_enable'] : '0';
						$layout = isset( $section['mts_featured_category_layout'] ) ? $section['mts_featured_category_layout'] : 'layout-1';
						if ( 'latest' == $category_id ) { ?>
							<?php switch ($layout) {
								case 'layout-1':
									echo '<div class="article-layout-1 clearfix">';
									echo '<div class="article-layout-inner clearfix clearfix">';
									break;

								case 'layout-2':
									echo '<div class="article-layout-2 clearfix" style="background-color:' . $section['mts_featured_bg_color'] . '">';
									echo '<div class="article-layout-inner clearfix">';
									break;

								case 'layout-3':
									echo '<div class="article-layout-3 clearfix" style="background-color:' . $section['mts_featured_bg_color'] . '">';
									echo '<div class="article-layout-inner clearfix">';
									break;
							}
							$j = 0; if ( have_posts() ) : while ( have_posts() ) : the_post();
								get_template_part('home-templates/post', $layout );
							$j++; endwhile; endif;

							if ( $layout == 'layout-1' || $layout == 'layout-2' || $layout == 'layout-3' ) {
								if ( $j !== 0 ) { // No pagination if there is no posts
									mts_pagination();
								} ?>
								</div>
								</div><!-- layout -->

							<?php }

						} else { // if $category_id != 'latest': ?>
							<?php switch ($layout) {
								case 'layout-1':
									echo '<div class="article-layout-1 clearfix">';
									echo '<div class="article-layout-inner clearfix">';
									break;

								case 'layout-2':
									echo '<div class="article-layout-2 clearfix" style="background-color:' . $section['mts_featured_bg_color'] . '">'; ?>
									<h3 class="featured-category-title"><a style="color: <?php echo $text_color; ?>;" href="<?php echo esc_url( get_category_link( $category_id ) ); ?>" title="<?php echo esc_attr( get_cat_name( $category_id ) ); ?>"><?php echo esc_html( get_cat_name( $category_id ) ); ?></a></h3>
									<?php echo '<div class="article-layout-inner clearfix">';
									break;

								case 'layout-3':
									echo '<div class="article-layout-3 clearfix" style="background-color:' . $section['mts_featured_bg_color'] . '">'; ?>
									<h3 class="featured-category-title"><a href="<?php echo esc_url( get_category_link( $category_id ) ); ?>" title="<?php echo esc_attr( get_cat_name( $category_id ) ); ?>"><?php echo esc_html( get_cat_name( $category_id ) ); ?></a></h3>
									<?php echo '<div class="article-layout-inner clearfix">';
								break;
							}
							$j = 0; $cat_query = new WP_Query('cat='.$category_id.'&posts_per_page='.$posts_num);
							if ( $cat_query->have_posts() ) : while ( $cat_query->have_posts() ) : $cat_query->the_post();
								get_template_part('home-templates/post', $layout );
							$j++; endwhile; endif; wp_reset_postdata(); ?>


							<a style="color: <?php echo $section['mts_featured_bg_color']; ?>;" href="<?php echo esc_url( get_category_link( $category_id ) ); ?>" title="<?php echo esc_attr( get_cat_name( $category_id ) ); ?>" class="btn-archive-link"><i class="fa fa-long-arrow-right"></i> <?php _e( 'Read More', 'dividend' ); ?></a>

							<?php if ( $layout == 'layout-1' || $layout == 'layout-2' || $layout == 'layout-3' ) { ?>
								</div>
								</div><!-- cat-layout -->
							<?php }
						}

						$social_icons_after_x_sections = (int) $mts_options['mts_home_social_icons_after_x_sections'];
						$lets_shop_after_x_sections = (int) $mts_options['mts_lets_shop_after_x_sections'];
						$instagram_after_x_sections = isset($mts_options['mts_instagram_after_x_sections']) ? (int) $mts_options['mts_instagram_after_x_sections'] : $section_count;
						if ( $social_icons_after_x_sections === $section_count ) get_template_part('home-templates/home', 'social-icons' );
						if ( $lets_shop_after_x_sections === $section_count ) get_template_part('home-templates/lets', 'shop' );
						if ( $instagram_after_x_sections === $section_count ) get_template_part('home-templates/instagram', 'section' );
					}
				} ?>

			<?php } else { //Paged ?>

				<?php if ( !empty( $mts_options['mts_featured_categories'] ) ) {
					foreach ( $mts_options['mts_featured_categories'] as $section ) {
						$category_id = $section['mts_featured_category'];
						$featured_categories[] = $category_id;
						$posts_num = $section['mts_featured_category_postsnum'];
						$post_info = isset($section['mts_home_meta_info_enable']) ? $section['mts_home_meta_info_enable'] : '0';
						$layout = isset( $section['mts_featured_category_layout'] ) ? $section['mts_featured_category_layout'] : 'layout-1';
						if ( 'latest' == $category_id ) { ?>
							<?php switch ($layout) {
								case 'layout-1':
									echo '<div class="article-layout-1 clearfix">';
									echo '<div class="article-layout-inner clearfix clearfix">';
									break;

								case 'layout-2':
									echo '<div class="article-layout-2 clearfix" style="background-color:' . $section['mts_featured_bg_color'] . '">';
									echo '<div class="article-layout-inner clearfix">';
									break;

								case 'layout-3':
									echo '<div class="article-layout-3 clearfix" style="background-color:' . $section['mts_featured_bg_color'] . '">';
									echo '<div class="article-layout-inner clearfix">';
								break;
							}
							$j = 0; if ( have_posts() ) : while ( have_posts() ) : the_post();
								get_template_part('home-templates/post', $layout );
							$j++; endwhile; endif;

							if ( $layout == 'layout-1' || $layout == 'layout-2' || $layout == 'layout-3' ) {
								if ( $j !== 0 ) { // No pagination if there is no posts
									mts_pagination();
								} ?>
								</div>
								</div><!-- layout -->
							<?php }
						}
					}
				}
			} ?>
		</div>
	</div>

<?php get_footer(); ?>
