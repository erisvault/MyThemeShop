<?php

defined('ABSPATH') or die;

/*
 *
 * Require the framework class before doing anything else, so we can use the defined urls and dirs
 *
 */
require_once( dirname( __FILE__ ) . '/options/options.php' );

/*
 * 
 * Add support tab
 *
 */
if ( ! defined('MTS_THEME_WHITE_LABEL') || ! MTS_THEME_WHITE_LABEL ) {
	require_once( dirname( __FILE__ ) . '/options/support.php' );
	$mts_options_tab_support = MTS_Options_Tab_Support::get_instance();
}

/*
 *
 * Custom function for filtering the sections array given by theme, good for child themes to override or add to the sections.
 * Simply include this function in the child themes functions.php file.
 *
 * NOTE: the defined constansts for urls, and dir will NOT be available at this point in a child theme, so you must use
 * get_template_directory_uri() if you want to use any of the built in icons
 *
 */
function add_another_section($sections){

	//$sections = array();
	$sections[] = array(
		'title' => __('A Section added by hook', 'clean' ),
		'desc' => '<p class="description">' . __('This is a section created by adding a filter to the sections array, great to allow child themes, to add/remove sections from the options.', 'clean' ) . '</p>',
		//all the glyphicons are included in the options folder, so you can hook into them, or link to your own custom ones.
		//You dont have to though, leave it blank for default.
		'icon' => trailingslashit(get_template_directory_uri()).'options/img/glyphicons/glyphicons_062_attach.png',
		//Lets leave this as a blank section, no options just some intro text set above.
		'fields' => array()
	);

	return $sections;

}//function
//add_filter('nhp-opts-sections-twenty_eleven', 'add_another_section');


/*
 *
 * Custom function for filtering the args array given by theme, good for child themes to override or add to the args array.
 *
 */
function change_framework_args($args){

	//$args['dev_mode'] = false;

	return $args;

}//function
//add_filter('nhp-opts-args-twenty_eleven', 'change_framework_args');

/*
 * This is the meat of creating the optons page
 *
 * Override some of the default values, uncomment the args and change the values
 * - no $args are required, but there there to be over ridden if needed.
 *
 *
 */

function setup_framework_options(){
	$args = array();

	//Set it to dev mode to view the class settings/info in the form - default is false
	$args['dev_mode'] = false;
	//Remove the default stylesheet? make sure you enqueue another one all the page will look whack!
	//$args['stylesheet_override'] = true;

	//Add HTML before the form
	//$args['intro_text'] = __('<p>This is the HTML which can be displayed before the form, it isnt required, but more info is always better. Anything goes in terms of markup here, any HTML.</p>', 'clean' );

	if ( ! MTS_THEME_WHITE_LABEL ) {
		//Setup custom links in the footer for share icons
		$args['share_icons']['twitter'] = array(
			'link' => 'http://twitter.com/mythemeshopteam',
			'title' => __( 'Follow Us on Twitter', 'clean' ),
			'img' => 'fa fa-twitter-square'
		);
		$args['share_icons']['facebook'] = array(
			'link' => 'http://www.facebook.com/mythemeshop',
			'title' => __( 'Like us on Facebook', 'clean' ),
			'img' => 'fa fa-facebook-square'
		);
	}

	//Choose to disable the import/export feature
	//$args['show_import_export'] = false;

	//Choose a custom option name for your theme options, the default is the theme name in lowercase with spaces replaced by underscores
	$args['opt_name'] = MTS_THEME_NAME;

	//Custom menu icon
	//$args['menu_icon'] = '';

	//Custom menu title for options page - default is "Options"
	$args['menu_title'] = __('Theme Options', 'clean' );

	//Custom Page Title for options page - default is "Options"
	$args['page_title'] = __('Theme Options', 'clean' );

	//Custom page slug for options page (wp-admin/themes.php?page=***) - default is "nhp_theme_options"
	$args['page_slug'] = 'theme_options';

	//Custom page capability - default is set to "manage_options"
	//$args['page_cap'] = 'manage_options';

	//page type - "menu" (adds a top menu section) or "submenu" (adds a submenu) - default is set to "menu"
	//$args['page_type'] = 'submenu';

	//parent menu - default is set to "themes.php" (Appearance)
	//the list of available parent menus is available here: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
	//$args['page_parent'] = 'themes.php';

	//custom page location - default 100 - must be unique or will override other items
	$args['page_position'] = 62;

	//Custom page icon class (used to override the page icon next to heading)
	//$args['page_icon'] = 'icon-themes';

	if ( ! MTS_THEME_WHITE_LABEL ) {
		//Set ANY custom page help tabs - displayed using the new help tab API, show in order of definition
		$args['help_tabs'][] = array(
			'id' => 'nhp-opts-1',
			'title' => __('Support', 'clean' ),
			'content' => '<p>' . sprintf( __('If you are facing any problem with our theme or theme option panel, head over to our %s.', 'clean' ), '<a href="http://community.mythemeshop.com/">'. __( 'Support Forums', 'clean' ) . '</a>' ) . '</p>'
		);
		$args['help_tabs'][] = array(
			'id' => 'nhp-opts-2',
			'title' => __('Earn Money', 'clean' ),
			'content' => '<p>' . sprintf( __('Earn 70%% commision on every sale by refering your friends and readers. Join our %s.', 'clean' ), '<a href="http://mythemeshop.com/affiliate-program/">' . __( 'Affiliate Program', 'clean' ) . '</a>' ) . '</p>'
		);
	}

	//Set the Help Sidebar for the options page - no sidebar by default
	//$args['help_sidebar'] = __('<p>This is the sidebar content, HTML is allowed.</p>', 'clean' );

	$mts_home_layout = array(
		'3-col-grid' => array('img' => NHP_OPTIONS_URL.'img/layouts/home-layout-1.png'), // 3 Column grid without sidebar
		'2-col-grid' => array('img' => NHP_OPTIONS_URL.'img/layouts/home-layout-5.png'),  // Two Column grid with sidebar
		'traditional-grid' => array('img' => NHP_OPTIONS_URL.'img/layouts/home-layout-7.png')  // Traditional Blog Layout with Sidebar
	);

	$mts_patterns = array(
		'nobg' => array('img' => NHP_OPTIONS_URL.'img/patterns/nobg.png'),
		'pattern0' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern0.png'),
		'pattern1' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern1.png'),
		'pattern2' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern2.png'),
		'pattern3' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern3.png'),
		'pattern4' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern4.png'),
		'pattern5' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern5.png'),
		'pattern6' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern6.png'),
		'pattern7' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern7.png'),
		'pattern8' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern8.png'),
		'pattern9' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern9.png'),
		'pattern10' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern10.png'),
		'pattern11' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern11.png'),
		'pattern12' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern12.png'),
		'pattern13' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern13.png'),
		'pattern14' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern14.png'),
		'pattern15' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern15.png'),
		'pattern16' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern16.png'),
		'pattern17' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern17.png'),
		'pattern18' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern18.png'),
		'pattern19' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern19.png'),
		'pattern20' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern20.png'),
		'pattern21' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern21.png'),
		'pattern22' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern22.png'),
		'pattern23' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern23.png'),
		'pattern24' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern24.png'),
		'pattern25' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern25.png'),
		'pattern26' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern26.png'),
		'pattern27' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern27.png'),
		'pattern28' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern28.png'),
		'pattern29' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern29.png'),
		'pattern30' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern30.png'),
		'pattern31' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern31.png'),
		'pattern32' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern32.png'),
		'pattern33' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern33.png'),
		'pattern34' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern34.png'),
		'pattern35' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern35.png'),
		'pattern36' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern36.png'),
		'pattern37' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern37.png'),
		'hbg' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg.png'),
		'hbg2' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg2.png'),
		'hbg3' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg3.png'),
		'hbg4' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg4.png'),
		'hbg5' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg5.png'),
		'hbg6' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg6.png'),
		'hbg7' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg7.png'),
		'hbg8' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg8.png'),
		'hbg9' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg9.png'),
		'hbg10' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg10.png'),
		'hbg11' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg11.png'),
		'hbg12' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg12.png'),
		'hbg13' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg13.png'),
		'hbg14' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg14.png'),
		'hbg15' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg15.png'),
		'hbg16' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg16.png'),
		'hbg17' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg17.png'),
		'hbg18' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg18.png'),
		'hbg19' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg19.png'),
		'hbg20' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg20.png'),
		'hbg21' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg21.png'),
		'hbg22' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg22.png'),
		'hbg23' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg23.png'),
		'hbg24' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg24.png'),
		'hbg25' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg25.png')
	);

	$sections = array();

	$sections[] = array(
		'icon' => 'fa fa-cogs',
		'title' => __('General Settings', 'clean' ),
		'desc' => '<p class="description">' . __('This tab contains common setting options which will be applied to the whole theme.', 'clean' ) . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_logo',
				'type' => 'upload',
				'title' => __('Logo Image', 'clean' ),
				'sub_desc' => wp_kses( __('Upload your logo using the Upload Button or insert image URL. Recommended Size <strong>145 x 36 px</strong>', 'clean' ), array( 'strong' => array() ) ),
				'return' => 'id'
			),
			array(
				'id' => 'mts_favicon',
				'type' => 'upload',
				'title' => __('Favicon', 'clean' ),
				'sub_desc' => sprintf( __('Upload a %s image that will represent your website\'s favicon.', 'clean' ), '<strong>32 x 32 px</strong>' ),
				'return' => 'id'
			),
			array(
				'id' => 'mts_touch_icon',
				'type' => 'upload',
				'title' => __('Touch icon', 'clean' ),
				'sub_desc' => sprintf( __('Upload a %s image that will represent your website\'s touch icon for iOS 2.0+ and Android 2.1+ devices.', 'clean' ), '<strong>152 x 152 px</strong>' ),
				'return' => 'id'
			),
			array(
				'id' => 'mts_metro_icon',
				'type' => 'upload',
				'title' => __('Metro icon', 'clean' ),
				'sub_desc' => sprintf( __('Upload a %s image that will represent your website\'s IE 10 Metro tile icon.', 'clean' ), '<strong>144 x 144 px</strong>' ),
				'return' => 'id'
			),
			array(
				'id' => 'mts_twitter_username',
				'type' => 'text',
				'title' => __('Twitter Username', 'clean' ),
				'sub_desc' => __('Enter your Username here.', 'clean' ),
			),
			array(
				'id' => 'mts_feedburner',
				'type' => 'text',
				'title' => __('FeedBurner URL', 'clean' ),
				'sub_desc' => sprintf( __('Enter your FeedBurner\'s URL here, ex: %s and your main feed (http://example.com/feed) will get redirected to the FeedBurner ID entered here.)', 'clean' ), '<strong>http://feeds.feedburner.com/mythemeshop</strong>' ),
				'validate' => 'url'
			),
			array(
				'id' => 'mts_header_code',
				'type' => 'textarea',
				'title' => __('Header Code', 'clean' ),
				'sub_desc' => wp_kses( __('Enter the code which you need to place <strong>before closing &lt;/head&gt; tag</strong>. (ex: Google Webmaster Tools verification, Bing Webmaster Center, BuySellAds Script, Alexa verification etc.)', 'clean' ), array( 'strong' => array() ) )
			),
			array(
				'id' => 'mts_analytics_code',
				'type' => 'textarea',
				'title' => __('Footer Code', 'clean' ),
				'sub_desc' => wp_kses( __('Enter the codes which you need to place in your footer. <strong>(ex: Google Analytics, Clicky, STATCOUNTER, Woopra, Histats, etc.)</strong>.', 'clean' ), array( 'strong' => array() ) )
			),
			array(
				'id' => 'mts_pagenavigation_type',
				'type' => 'radio',
				'title' => __('Pagination Type', 'clean' ),
				'sub_desc' => __('Select pagination type.', 'clean' ),
				'options' => array(
					'0'=> __('Next / Previous', 'clean' ),
					'1' => __('Default Numbered (1 2 3 4...)', 'clean' ),
					'2' => __( 'AJAX (Load More Button)', 'clean' ),
					'3' => __( 'AJAX (Auto Infinite Scroll)', 'clean' )
				),
				'std' => '1'
			),
			array(
				'id' => 'mts_ajax_search',
				'type' => 'button_set',
				'title' => __('AJAX Quick search', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => __('Enable or disable search results appearing instantly below the search form', 'clean' ),
				'std' => '0'
			),
			array(
				'id' => 'mts_responsive',
				'type' => 'button_set',
				'title' => __('Responsiveness', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => __('MyThemeShop themes are responsive, which means they adapt to tablet and mobile devices, ensuring that your content is always displayed beautifully no matter what device visitors are using. Enable or disable responsiveness using this option.', 'clean' ),
				'std' => '1'
			),
			array(
				'id' => 'mts_rtl',
				'type' => 'button_set',
				'title' => __('Right To Left Language Support', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => __('Enable this option for right-to-left sites.', 'clean' ),
				'std' => '0'
			),
			array(
				'id' => 'mts_shop_products',
				'type' => 'text',
				'title' => __('No. of Products', 'clean' ),
				'sub_desc' => __('Enter the total number of products which you want to show on shop page (WooCommerce plugin must be enabled).', 'clean' ),
				'validate' => 'numeric',
				'std' => '9',
				'class' => 'small-text'
			),
		)
	);
	$sections[] = array(
		'icon' => 'fa fa-bolt',
		'title' => __('Performance', 'clean' ),
		'desc' => '<p class="description">' . __('This tab contains performance-related options which can help speed up your website.', 'clean' ) . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_prefetching',
				'type' => 'button_set',
				'title' => __('Prefetching', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => __('Enable or disable prefetching. If user is on homepage, then single page will load faster and if user is on single page, homepage will load faster in modern browsers.', 'clean' ),
				'std' => '0'
			),
			array(
				'id' => 'mts_lazy_load',
				'type' => 'button_set_hide_below',
				'title' => __('Lazy Load', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => __('Delay loading of images outside of viewport, until user scrolls to them.', 'clean' ),
				'std' => '0',
				'args' => array('hide' => 2)
			),
			array(
				'id' => 'mts_lazy_load_thumbs',
				'type' => 'button_set',
				'title' => __('Lazy load featured images', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => __('Enable or disable Lazy load of featured images across site.', 'clean' ),
				'std' => '0'
			),
			array(
				'id' => 'mts_lazy_load_content',
				'type' => 'button_set',
				'title' => __('Lazy load post content images', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => __('Enable or disable Lazy load of images inside post/page content.', 'clean' ),
				'std' => '0'
			),
			array(
				'id' => 'mts_async_js',
				'type' => 'button_set',
				'title' => __('Async JavaScript', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => sprintf( __('Add %s attribute to script tags to improve page download speed.', 'clean' ), '<code>async</code>' ),
				'std' => '1',
			),
			array(
				'id' => 'mts_remove_ver_params',
				'type' => 'button_set',
				'title' => __('Remove ver parameters', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => sprintf( __('Remove %s parameter from CSS and JS file calls. It may improve speed in some browsers which do not cache files having the parameter.', 'clean' ), '<code>ver</code>' ),
				'std' => '1',
			),
			array(
				'id' => 'mts_optimize_wc',
				'type' => 'button_set',
				'title' => __('Optimize WooCommerce scripts', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => __('Load WooCommerce scripts and styles only on WooCommerce pages (WooCommerce plugin must be enabled).', 'clean' ),
				'std' => '1'
			),
			'cache_message' => array(
				'id' => 'mts_cache_message',
				'type' => 'info',
				'title' => __('Use Cache', 'clean' ),
				// Translators: %1$s = popup link to W3 Total Cache, %2$s = popup link to WP Super Cache
				'desc' => sprintf(
					__('A cache plugin can increase page download speed dramatically. We recommend using %1$s or %2$s.', 'clean' ),
					'<a href="https://community.mythemeshop.com/tutorials/article/8-make-your-website-load-faster-using-w3-total-cache-plugin/" target="_blank" title="W3 Total Cache">W3 Total Cache</a>',
					'<a href="'.admin_url( 'plugin-install.php?tab=plugin-information&plugin=wp-super-cache&TB_iframe=true&width=772&height=574' ).'" class="thickbox" title="WP Super Cache">WP Super Cache</a>'
				),
			),
		)
	);

	// Hide cache message on multisite or if a chache plugin is active already
	if ( is_multisite() || strstr( join( ';', get_option( 'active_plugins' ) ), 'cache' ) ) {
		unset( $sections[1]['fields']['cache_message'] );
	}

	$sections[] = array(
		'icon' => 'fa fa-adjust',
		'title' => __('Styling Options', 'clean' ),
		'desc' => '<p class="description">' . __('Control the visual appearance of your theme, such as colors, layout and patterns, from here.', 'clean' ) . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_color_scheme',
				'type' => 'color',
				'title' => __('Color Scheme', 'clean' ),
				'sub_desc' => __('The theme comes with unlimited color schemes for your theme\'s styling.', 'clean' ),
				'std' => '#3cc7c5'
			),
			array(
				'id' => 'mts_layout',
				'type' => 'radio_img',
				'title' => __('Layout Style', 'clean' ),
				'sub_desc' => wp_kses( __('Choose the <strong>default sidebar position</strong> for your site. The position of the sidebar for individual posts can be set in the post editor.', 'clean' ), array( 'strong' => array() ) ),
				'options' => array(
					'cslayout' => array('img' => NHP_OPTIONS_URL.'img/layouts/cs.png'),
					'sclayout' => array('img' => NHP_OPTIONS_URL.'img/layouts/sc.png')
				),
				'std' => 'cslayout'
			),
			array(
				'id' => 'mts_background',
				'type' => 'background',
				'title' => __('Site Background', 'clean' ),
				'sub_desc' => __('Set background color, pattern and image from here.', 'clean' ),
				'options' => array(
					'color'		 => '',
					'image_pattern' => $mts_patterns,
					'image_upload'  => '',
					'repeat'		=> array(),
					'attachment'	=> array(),
					'position'	=> array(),
					'size'		=> array(),
					'gradient'	=> '',
					'parallax'	=> array(),
				),
				'std' => array(
					'color'		 => '#ffffff',
					'use'		 => 'pattern',
					'image_pattern' => 'nobg',
					'image_upload'  => '',
					'repeat'		=> 'repeat',
					'attachment'	=> 'scroll',
					'position'	=> 'left top',
					'size'		=> 'cover',
					'gradient'	=> array('from' => '#ffffff', 'to' => '#000000', 'direction' => 'horizontal' ),
					'parallax'	=> '0',
				)
			),
			array(
				'id' => 'mts_custom_css',
				'type' => 'textarea',
				'title' => __('Custom CSS', 'clean' ),
				'sub_desc' => __('You can enter custom CSS code here to further customize your theme. This will override the default CSS used on your site.', 'clean' )
			),
			array(
				'id' => 'mts_lightbox',
				'type' => 'button_set',
				'title' => __('Lightbox', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => __('A lightbox is a stylized pop-up that allows your visitors to view larger versions of images without leaving the current page. You can enable or disable the lightbox here.', 'clean' ),
				'std' => '0'
			),
		)
	);
	$sections[] = array(
		'icon' => 'fa fa-credit-card',
		'title' => __('Header', 'clean' ),
		'desc' => '<p class="description">' . __('From here, you can control the elements of header section.', 'clean' ) . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_sticky_nav',
				'type' => 'button_set',
				'title' => __('Floating Navigation Menu', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => sprintf( __('Use this button to enable %s.', 'clean' ), '<strong>' . __('Floating Navigation Menu', 'clean' ) . '</strong>' ),
				'std' => '0'
			),
			array(
			    'id'     => 'mts_header_layout',
			    'type'   => 'layout2',
			    'title' => __('Header Layout', 'clean' ),
			    'sub_desc' => __('Customize the look of header', 'clean' ),
			    'options'  => array(
			        'enabled'  => array(
			            'logo-section'   => array(
			                'label'     => __('Logo Section', 'clean' ),
			                'subfields' => array(
			                )
			            ),
			            'main-navigation'   => array(
			                'label'     => __('Main Navigation', 'clean' ),
			                'subfields' => array(
			                )
			            ),
			        ),
			        'disabled' => array(
			        )
			    )
			),
			array(
				'id' => 'mts_header_section2',
				'type' => 'button_set',
				'title' => __('Show Logo', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => wp_kses( __('Use this button to Show or Hide the <strong>Logo</strong> completely.', 'clean' ), array( 'strong' => array() ) ),
				'std' => '1'
			),
			array(
				'id' => 'mts_show_primary_nav',
				'type' => 'button_set',
				'title' => __('Show Top Menu', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => sprintf( __('Use this button to enable %s.', 'clean' ), '<strong>' . __( 'Top Navigation Menu', 'clean' ) . '</strong>' ),
				'std' => '1'
			),
			array(
				'id' => 'mts_show_secondary_nav',
				'type' => 'button_set',
				'title' => __('Show Main Menu', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => sprintf( __('Use this button to enable %s.', 'clean' ), '<strong>' . __( 'Main Navigation Menu', 'clean' ) . '</strong>' ),
				'std' => '1'
			),
			array(
				'id' => 'mts_header_search',
				'type' => 'button_set',
				'title' => __('Show Header Search', 'clean' ), 
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => sprintf( __('Use this button to enable %s.', 'clean' ), '<strong>' . __( 'Header Search', 'clean' ) . '</strong>' ),
				'std' => '1'
			),
			array(
				'id' => 'mts_social_icon_head',
				'type' => 'button_set_hide_below',
				'title' => __('Show Social Icons in Header','clean'),
				'sub_desc' => sprintf( __('Use this button to show %s.', 'clean' ), '<strong>' . __( 'Header Social Icons', 'clean' ) . '</strong>' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'std' => '1',
				'args' => array('hide' => '1')
			),
			array(
			 	'id' => 'mts_header_social',
			 	'title' => __('Add Social Icons','clean'), 
			 	'sub_desc' => __( 'Add Social Media icons in header.', 'clean' ),
			 	'type' => 'group',
			 	'groupname' => __('Header Icons','clean'), // Group name
			 	'subfields' => array(
					array(
						'id' => 'mts_header_icon_title',
						'type' => 'text',
						'title' => __('Title', 'clean'), 
					),
					array(
						'id' => 'mts_header_icon',
						'type' => 'icon_select',
						'title' => __('Icon', 'clean')
					),
					array(
						'id' => 'mts_header_icon_link',
						'type' => 'text',
						'title' => __('URL', 'clean'), 
					),
					array(
						'id' => 'mts_header_icon_color',
						'type' => 'color',
						'title' => __('Color', 'clean'),
						'std' => '#20303c'
					),
					array(
						'id' => 'mts_header_icon_hover_color',
						'type' => 'color',
						'title' => __('Hover Color', 'clean'),
						'std' => '#3cc7c5'
					)
				),
				'std' => array(
					'facebook' => array(
						'group_title' => 'Facebook',
						'group_sort' => '1',
						'mts_header_icon_title' => 'Facebook',
						'mts_header_icon' => 'facebook',
						'mts_header_icon_link' => '#',
						'mts_header_icon_color' => '#20303c',
						'mts_header_icon_hover_color' => '#3cc7c5'
					),
					'twitter' => array(
						'group_title' => 'Twitter',
						'group_sort' => '2',
						'mts_header_icon_title' => 'Twitter',
						'mts_header_icon' => 'twitter',
						'mts_header_icon_link' => '#',
						'mts_header_icon_color' => '#20303c',
						'mts_header_icon_hover_color' => '#3cc7c5'
					),
					'instagram' => array(
						'group_title' => 'Instagram',
						'group_sort' => '3',
						'mts_header_icon_title' => 'Instagram',
						'mts_header_icon' => 'instagram',
						'mts_header_icon_link' => '#',
						'mts_header_icon_color' => '#20303c',
						'mts_header_icon_hover_color' => '#3cc7c5'
					),
					'youtube' => array(
						'group_title' => 'You Tube',
						'group_sort' => '4',
						'mts_header_icon_title' => 'You Tube',
						'mts_header_icon' => 'youtube',
						'mts_header_icon_link' => '#',
						'mts_header_icon_color' => '#20303c',
						'mts_header_icon_hover_color' => '#3cc7c5'
					)
				)
			),
			array(
				'id' => 'mts_header_buttons_section',
				'type' => 'button_set_hide_below',
				'title' => __('Show Header Custom Buttons','clean'),
				'sub_desc' => sprintf( __('Use this button to show %s.', 'clean' ), '<strong>' . __( 'Header Custom Buttons', 'clean' ) . '</strong>' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'std' => '0',
				'args' => array('hide' => '1')
			),
			array(
			 	'id' => 'mts_header_buttons',
			 	'title' => __('Add Custom Buttons','clean'), 
			 	'sub_desc' => __( 'Add links in your buttons to redirect to any page.', 'clean' ),
			 	'type' => 'group',
			 	'groupname' => __('Custom Button','clean'), // Group name
			 	'subfields' => array(
					array(
						'id' => 'mts_header_button_title',
						'type' => 'text',
						'title' => __('Title', 'clean'), 
					),
					array(
						'id' => 'mts_header_button_link',
						'type' => 'text',
						'title' => __('URL', 'clean'), 
					),
					array(
						'id' => 'mts_header_button_bg',
						'type' => 'color',
						'title' => __('Button Background Color', 'clean'),
						'std' => '#65c888'
					),
					array(
						'id' => 'mts_header_button_color',
						'type' => 'color',
						'title' => __('Button Color', 'clean'),
						'std' => '#ffffff'
					),
				),
			),
			array(
				'id' => 'mts_top_header_background',
				'type' => 'background',
				'title' => __('Logo Section Background', 'clean' ),
				'sub_desc' => __('Set logo section background color, pattern and image from here.', 'clean' ),
				'options' => array(
					'color'		 => '',
					'image_pattern' => $mts_patterns,
					'image_upload'  => '',
					'repeat'		=> array(),
					'attachment'	=> array(),
					'position'	=> array(),
					'size'		=> array(),
					'gradient'	=> '',
					'parallax'	=> array(),
				),
				'std' => array(
					'color'		 => '#ffffff',
					'use'		 => 'pattern',
					'image_pattern' => 'nobg',
					'image_upload'  => '',
					'repeat'		=> 'repeat',
					'attachment'	=> 'scroll',
					'position'	=> 'left top',
					'size'		=> 'cover',
					'gradient'	=> array('from' => '#ffffff', 'to' => '#000000', 'direction' => 'horizontal' ),
					'parallax'	=> '0',
				)
			),
			array(
				'id' => 'mts_bottom_header_background',
				'type' => 'background',
				'title' => __('Main Menu Background', 'clean' ),
				'sub_desc' => __('Set main menu background color, pattern and image from here.', 'clean' ),
				'options' => array(
					'color'		 => '',
					'image_pattern' => $mts_patterns,
					'image_upload'  => '',
					'repeat'		=> array(),
					'attachment'	=> array(),
					'position'	=> array(),
					'size'		=> array(),
					'gradient'	=> '',
					'parallax'	=> array(),
				),
				'std' => array(
					'color'		 => '#ffffff',
					'use'		 => 'pattern',
					'image_pattern' => 'nobg',
					'image_upload'  => '',
					'repeat'		=> 'repeat',
					'attachment'	=> 'scroll',
					'position'	=> 'left top',
					'size'		=> 'cover',
					'gradient'	=> array('from' => '#ffffff', 'to' => '#000000', 'direction' => 'horizontal' ),
					'parallax'	=> '0',
				)
			),
		)
	);
	$sections[] = array(
		'icon' => 'fa fa-table',
		'title' => __('Footer', 'clean' ),
		'desc' => '<p class="description">' . __('From here, you can control the elements of Footer section.', 'clean' ) . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_first_footer',
				'type' => 'button_set_hide_below',
				'title' => __('Footer Widgets', 'clean' ),
				'sub_desc' => __('Enable or disable footer widgets with this option.', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'std' => '0'
				),
			array(
				'id' => 'mts_first_footer_num',
				'type' => 'button_set',
				'class' => 'green',
				'title' => __('Footer Widgets Layout', 'clean' ),
				'sub_desc' => wp_kses( __('Choose the number of widget areas in the <strong>footer</strong>', 'clean' ), array( 'strong' => array() ) ),
				'options' => array(
					'3' => __( '3 Widgets', 'clean' ),
					'4' => __( '4 Widgets', 'clean' ),
					'5' => __( '5 Widgets', 'clean' ),
				),
				'std' => '5'
			),
			array(
				'id' => 'mts_footer_background',
				'type' => 'background',
				'title' => __('Footer Background', 'clean' ),
				'sub_desc' => wp_kses( __('Set <strong><i>Footer</i></strong> background color, pattern and image from here.', 'clean' ), array( 'strong' => array() ) ),
				'options' => array(
					'color'		 => '',
					'image_pattern' => $mts_patterns,
					'image_upload'  => '',
					'repeat'		=> array(),
					'attachment'	=> array(),
					'position'	=> array(),
					'size'		=> array(),
					'gradient'	=> '',
					'parallax'	=> array(),
				),
				'std' => array(
					'color'		 => '#ffffff',
					'use'		 => 'pattern',
					'image_pattern' => 'nobg',
					'image_upload'  => '',
					'repeat'		=> 'repeat',
					'attachment'	=> 'scroll',
					'position'	=> 'left top',
					'size'		=> 'cover',
					'gradient'	=> array('from' => '#ffffff', 'to' => '#000000', 'direction' => 'horizontal' ),
					'parallax'	=> '0',
				)
			),
			array(
				'id' => 'mts_copyrights',
				'type' => 'textarea',
				'title' => __('Copyrights Text', 'clean' ),
				'sub_desc' => __( 'You can change or remove our link from footer and use your own custom text.', 'clean' ) . ( MTS_THEME_WHITE_LABEL ? '' : wp_kses( __('(You can also use your affiliate link to <strong>earn 70% of sales</strong>. Ex: <a href="https://mythemeshop.com/go/aff/aff" target="_blank">https://mythemeshop.com/?ref=username</a>)', 'clean' ), array( 'strong' => array(), 'a' => array( 'href' => array(), 'target' => array() ) ) ) ),
				'std' => MTS_THEME_WHITE_LABEL ? null : sprintf( __( 'Theme by %s', 'clean' ), '<a href="http://mythemeshop.com/" rel="nofollow">MyThemeShop</a>' )
			),
		)
	);
	$sections[] = array(
		'icon' => 'fa fa-home',
		'title' => __('Homepage', 'clean' ),
		'desc' => '<p class="description">' . __('From here, you can control the elements of the homepage.', 'clean' ) . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_home_layout',
				'type' => 'radio_img',
				'title' => __('Select Homepage Layout', 'clean' ),
				'sub_desc' => wp_kses( __('Choose the layout for homepage posts.', 'clean' ), array( 'strong' => array() ) ),
				'options' => $mts_home_layout,
				'std' => '3-col-grid'
			),
			array(
				'id' => 'mts_featured_slider',
				'type' => 'button_set_hide_below',
				'title' => __('Homepage Slider', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => wp_kses( __('<strong>Enable or Disable</strong> homepage slider with this button. The slider will show recent articles from the selected categories.', 'clean' ), array( 'strong' => array() ) ),
				'std' => '0',
				'args' => array('hide' => 4)
			),
			array(
				'id' => 'mts_featured_slider_cat',
				'type' => 'cats_multi_select',
				'title' => __('Slider Category(s)', 'clean' ),
				'sub_desc' => wp_kses( __('Select a category from the drop-down menu, latest articles from this category will be shown <strong>in the slider</strong>.', 'clean' ), array( 'strong' => array() ) ),
			),
			array(
				'id' => 'mts_featured_slider_num',
				'type' => 'text',
				'class' => 'small-text',
				'title' => __('Number of posts', 'clean' ),
				'sub_desc' => __('Enter the number of posts to show in the slider', 'clean' ),
				'std' => '5',
				'args' => array('type' => 'number')
			),
			array(
				'id' => 'mts_featured_slider_sides',
				'type' => 'button_set',
				'title' => __('Slider Types', 'clean' ),
				'options' => array('left-content' => __('Left Content','clean'), 'right-content' => __('Right Content', 'clean' ), 'full-width-slider' => __('Full Width Slider','clean'), 'no-slider-content' => __('No Slider Content', 'clean' )),
				'sub_desc' => __('Choose the Slider layout', 'clean' ),
				'std' => 'right-content',
				'class' => 'green'
			),
			array(
				'id' => 'mts_custom_slider',
				'type' => 'group',
				'title' => __('Custom Slider', 'clean' ),
				'sub_desc' => __('With this option you can set up a slider with custom image and text instead of the default slider automatically generated from your posts.', 'clean' ),
				'groupname' => __('Slider', 'clean' ), // Group name
				'subfields' =>
				array(
					array(
						'id' => 'mts_custom_slider_title',
						'type' => 'text',
						'title' => __('Title', 'clean' ),
						'sub_desc' => __('Title of the slide', 'clean' ),
					),
					array(
						'id' => 'mts_custom_slider_image',
						'type' => 'upload',
						'title' => __('Image', 'clean' ),
						'sub_desc' => __('Upload or select an image for this slide', 'clean' ),
						'return' => 'id'
					),
					array('id' => 'mts_custom_slider_link',
						'type' => 'text',
						'title' => __('Link', 'clean' ),
						'sub_desc' => __('Insert a link URL for the slide', 'clean' ),
						'std' => '#'
					),
				),
			),
			array(
				'id' => 'mts_featured_categories',
				'type' => 'group',
				'title'	 => __('Featured Categories', 'clean' ),
				'sub_desc'  => __('Select categories appearing on the homepage.', 'clean' ),
				'groupname' => __('Section', 'clean' ), // Group name
				'subfields' =>
					array(
						array(
							'id' => 'mts_featured_category',
							'type' => 'cats_select',
							'title' => __('Category', 'clean' ),
							'sub_desc' => __('Select a category or the latest posts for this section', 'clean' ),
							'std' => 'latest',
							'args' => array('include_latest' => 1, 'hide_empty' => 0),
						),
						array(
							'id' => 'mts_featured_category_postsnum',
							'type' => 'text',
							'class' => 'small-text',
							'title' => __('Number of posts', 'clean' ),
							'sub_desc' => __('Enter the number of posts to show in this section.', 'clean' ),
							'std' => '3',
							'args' => array('type' => 'number')
						),
				),
				'std' => array(
					'1' => array(
						'group_title' => '',
						'group_sort' => '1',
						'mts_featured_category' => 'latest',
						'mts_featured_category_postsnum' => get_option('posts_per_page')
					)
				)
			),
			array(
				'id'	 => 'mts_home_headline_meta_info',
				'type'	 => 'layout',
				'title'	=> __('HomePage Post Meta Info', 'clean' ),
				'sub_desc' => __('Organize how you want the post meta info to appear on the homepage', 'clean' ),
				'options'  => array(
					'enabled'  => array(
						'author'   => __('Author Name', 'clean' ),
						'date'	 => __('Date', 'clean' )
					),
					'disabled' => array(
						'comment'  => __('Comment Count', 'clean' )
					)
				),
				'std'  => array(
					'enabled'  => array(
						'author'   => __('Author Name', 'clean' ),
						'date'	 => __('Date', 'clean' )
					),
					'disabled' => array(
						'comment'  => __('Comment Count', 'clean' )
					)
				),
			),
			array(
				'id' => 'mts_home_category',
				'type' => 'button_set',
				'title' => __('Homepage Posts Category', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => __('Use this button to enable/disable category from homepage post', 'clean' ),
				'std' => '1'
			)
		)
	);
	$sections[] = array(
		'icon' => 'fa fa-file-text',
		'title' => __('Single Posts', 'clean' ),
		'desc' => '<p class="description">' . __('From here, you can control the appearance and functionality of your single posts page.', 'clean' ) . '</p>',
		'fields' => array(
			array(
				'id'	 => 'mts_single_post_layout',
				'type'	 => 'layout2',
				'title'	=> __('Single Post Layout', 'clean' ),
				'sub_desc' => __('Customize the look of single posts', 'clean' ),
				'options'  => array(
					'enabled'  => array(
						'tags'   => array(
							'label' 	=> __('Tags', 'clean' ),
							'subfields'	=> array(
							)
						),
						'related'   => array(
							'label' 	=> __('Related Posts', 'clean' ),
							'subfields'	=> array(
								array(
									'id' => 'mts_related_posts_taxonomy',
									'type' => 'button_set',
									'title' => __('Related Posts Taxonomy', 'clean' ) ,
									'options' => array(
										'tags' => __( 'Tags', 'clean' ),
										'categories' => __( 'Categories', 'clean' )
									) ,
									'class' => 'green',
									'sub_desc' => __('Related Posts based on tags or categories.', 'clean' ) ,
									'std' => 'categories'
								),
								array(
									'id' => 'mts_related_postsnum',
									'type' => 'text',
									'class' => 'small-text',
									'title' => __('Number of related posts', 'clean' ) ,
									'sub_desc' => __('Enter the number of posts to show in the related posts section.', 'clean' ) ,
									'std' => '2',
									'args' => array(
										'type' => 'number'
									)
								),

							)
						),
						'author'   => array(
							'label' 	=> __('Author Box', 'clean' ),
							'subfields'	=> array(

							)
						),
					),
					'disabled' => array()
				)
			),
			array(
				'id'	 => 'mts_single_headline_meta_info',
				'type'	 => 'layout',
				'title'	=> __('Meta Info to Show', 'clean' ),
				'sub_desc' => __('Organize how you want the post meta info to appear', 'clean' ),
				'options'  => array(
					'enabled'  => array(
						'category' => __('Categories', 'clean' ),
						'date' => __('Date', 'clean' )
					),
					'disabled' => array(
						'author' => __('Author Name', 'clean' ),
						'comment'  => __('Comment Count', 'clean' )
					)
				),
				'std'  => array(
					'enabled'  => array(
						'category' => __('Categories', 'clean' ),
						'date' => __('Date', 'clean' )
					),
					'disabled' => array(
						'author'   => __('Author Name', 'clean' ),
						'comment'  => __('Comment Count', 'clean' )
					)
				)
			),
			array(
				'id' => 'mts_show_views',
				'type' => 'button_set',
				'title' => __('Total Number of Views', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => __('Use this button to show total number of views on Single Post.', 'clean' ),
				'std' => '1'
			),
			array(
				'id' => 'mts_like_button',
				'type' => 'button_set',
				'title' => __('Post Like Button', 'clean' ), 
				'sub_desc' => __('Use this button to show Post Like Button on Single Post', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'std' => '1'
			),
			array(
				'id' => 'mts_single_featured_image',
				'type' => 'button_set',
				'title' => __('Show Featured Image', 'clean' ), 
				'sub_desc' => __('Use this button to show Featured Image on Single Post', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'std' => '1'
			),
			array(
				'id' => 'mts_breadcrumb',
				'type' => 'button_set',
				'title' => __('Breadcrumbs', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => __('Breadcrumbs are a great way to make your site more user-friendly. Show Breadcrumbs from here.', 'clean' ),
				'std' => '0'
			),
			array(
				'id' => 'mts_facebook_comments',
				'type' => 'button_set_hide_below',
				'title' => __('Facebook Comments','clean'),
				'sub_desc' => __('Use this button to show facebook comments', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'std' => '0',
				'args' => array('hide' => '1')
			),
			array(
				'id' => 'mts_fb_app_id',
				'type' => 'text',
				'title' => __('Facebook App ID for FB Comments', 'clean'),
				'sub_desc' => __('Enter your Facebook app ID here. You can create Facebook App id <a href="https://developers.facebook.com/apps" target="_blank">here</a>', 'clean'),
				'class' => 'small'
			),
			array(
				'id' => 'mts_author_comment',
				'type' => 'button_set',
				'title' => __('Highlight Author Comment', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => __('Use this button to highlight author comments.', 'clean' ),
				'std' => '1'
			),
			array(
				'id' => 'mts_comment_date',
				'type' => 'button_set',
				'title' => __('Date in Comments', 'clean' ),
				'options' => array( '0' => __( 'Off', 'clean' ), '1' => __( 'On', 'clean' ) ),
				'sub_desc' => __('Use this button to show the date for comments.', 'clean' ),
				'std' => '1'
			),
		)
	);
	$sections[] = array(
		'icon' => 'fa fa-group',
		'title' => __('Social Buttons', 'clean' ),
		'desc' => '<p class="description">' . __('Enable or disable social sharing buttons on single posts using these buttons.', 'clean' ) . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_social_button_layout',
				'type' => 'radio_img',
				'title' => __('Social Sharing Buttons Layout', 'MTSTHEMENAME' ),
				'sub_desc' => wp_kses( __('Choose default <strong>social sharing buttons</strong> layout or modern <strong>social sharing buttons</strong> layout for your site. ', 'MTSTHEMENAME' ), array( 'strong' => array() ) ),
				'options' => array(
					'default' => array('img' => NHP_OPTIONS_URL.'img/layouts/default-social.jpg'),
					'modern' => array('img' => NHP_OPTIONS_URL.'img/layouts/modern-social.jpg')
				),
				'std' => 'modern',
				'reset_at_version' => '1.0.8'
			),
			array(
				'id' => 'mts_social_button_position',
				'type' => 'button_set',
				'title' => __('Social Sharing Buttons Position', 'clean' ),
				'options' => array('top' => __('Above Content', 'clean' ), 'bottom' => __('Below Content', 'clean' ), 'floating' => __('Floating', 'clean' )),
				'sub_desc' => __('Choose position for Social Sharing Buttons.', 'clean' ),
				'std' => 'floating',
				'class' => 'green'
			),
			array(
				'id' => 'mts_social_buttons_on_pages',
				'type' => 'button_set',
				'title' => __('Social Sharing Buttons on Pages', 'clean' ),
				'options' => array('0' => __('Off', 'clean' ), '1' => __('On', 'clean' )),
				'sub_desc' => __('Enable the sharing buttons for pages too, not just posts.', 'clean' ),
				'std' => '0',
			),
			array(
				'id'   => 'mts_social_buttons',
				'type' => 'layout',
				'title'	=> __('Social Media Buttons', 'clean' ),
				'sub_desc' => __('Organize how you want the social sharing buttons to appear on single posts', 'clean' ),
				'options'  => array(
					'enabled'  => array(
						'facebookshare'   => __('Facebook Share', 'clean' ),
						'twitter'   => __('Twitter', 'clean' ),
						'gplus' => __('Google Plus', 'clean' ),
						'linkedin'  => __('LinkedIn', 'clean' ),
						'pinterest' => __('Pinterest', 'clean' ),
					),
					'disabled' => array(
						'stumble'   => __('StumbleUpon', 'clean' ),
						'reddit'   => __('Reddit', 'clean' ),
					)
				),
				'std'  => array(
					'enabled'  => array(
						'facebookshare'   => __('Facebook Share', 'clean' ),
						'twitter'   => __('Twitter', 'clean' ),
						'gplus' => __('Google Plus', 'clean' ),
						'linkedin'  => __('LinkedIn', 'clean' ),
						'pinterest' => __('Pinterest', 'clean' ),
					),
					'disabled' => array(
						'stumble'   => __('StumbleUpon', 'clean' ),
						'reddit'   => __('Reddit', 'clean' ),
					)
				),
				'reset_at_version' => '1.0.8'
			),
		)
	);
	$sections[] = array(
		'icon' => 'fa fa-bar-chart-o',
		'title' => __('Ad Management', 'clean' ),
		'desc' => '<p class="description">' . __('Now, ad management is easy with our options panel. You can control everything from here, without using separate plugins.', 'clean' ) . '</p>',
		'fields' => array(
			array(
				'id' => 'mts_posttop_adcode',
				'type' => 'textarea',
				'title' => __('Below Post Title', 'clean' ),
				'sub_desc' => __('Paste your Adsense, BSA or other ad code here to show ads below your article title on single posts.', 'clean' )
			),
			array(
				'id' => 'mts_posttop_adcode_time',
				'type' => 'text',
				'title' => __('Show After X Days', 'clean' ),
				'sub_desc' => __('Enter the number of days after which you want to show the Below Post Title Ad. Enter 0 to disable this feature.', 'clean' ),
				'validate' => 'numeric',
				'std' => '0',
				'class' => 'small-text',
				'args' => array('type' => 'number')
			),
			array(
				'id' => 'mts_postend_adcode',
				'type' => 'textarea',
				'title' => __('Below Post Content', 'clean' ),
				'sub_desc' => __('Paste your Adsense, BSA or other ad code here to show ads below the post content on single posts.', 'clean' )
			),
			array(
				'id' => 'mts_postend_adcode_time',
				'type' => 'text',
				'title' => __('Show After X Days', 'clean' ),
				'sub_desc' => __('Enter the number of days after which you want to show the Below Post Title Ad. Enter 0 to disable this feature.', 'clean' ),
				'validate' => 'numeric',
				'std' => '0',
				'class' => 'small-text',
				'args' => array('type' => 'number')
			),
		)
	);
	$sections[] = array(
		'icon' => 'fa fa-columns',
		'title' => __('Sidebars', 'clean' ),
		'desc' => '<p class="description">' . __('Now you have full control over the sidebars. Here you can manage sidebars and select one for each section of your site, or select a custom sidebar on a per-post basis in the post editor.', 'clean' ) . '<br></p>',
		'fields' => array(
			array(
				'id' => 'mts_custom_sidebars',
				'type'  => 'group', //doesn't need to be called for callback fields
				'title' => __('Custom Sidebars', 'clean' ),
				'sub_desc'  => wp_kses( __('Add custom sidebars. <strong style="font-weight: 800;">You need to save the changes to use the sidebars in the dropdowns below.</strong><br />You can add content to the sidebars in Appearance &gt; Widgets.', 'clean' ), array( 'strong' => array(), 'br' => array() ) ),
				'groupname' => __('Sidebar', 'clean' ), // Group name
				'subfields' =>
					array(
						array(
							'id' => 'mts_custom_sidebar_name',
							'type' => 'text',
							'title' => __('Name', 'clean' ),
							'sub_desc' => __('Example: Homepage Sidebar', 'clean' )
						),
						array(
							'id' => 'mts_custom_sidebar_id',
							'type' => 'text',
							'title' => __('ID', 'clean' ),
							'sub_desc' => __('Enter a unique ID for the sidebar. Use only alphanumeric characters, underscores (_) and dashes (-), eg. "sidebar-home"', 'clean' ),
							'std' => 'sidebar-'
						),
					),
			),
			array(
				'id' => 'mts_sidebar_for_home',
				'type' => 'sidebars_select',
				'title' => __('Homepage', 'clean' ),
				'sub_desc' => __('Select a sidebar for the homepage.', 'clean' ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-first-5', 'home-sidebar-1', 'home-sidebar-2', 'widget-header','shop-sidebar', 'product-sidebar')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_post',
				'type' => 'sidebars_select',
				'title' => __('Single Post', 'clean' ),
				'sub_desc' => __('Select a sidebar for the single posts. If a post has a custom sidebar set, it will override this.', 'clean' ),
				'args' => array('exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-first-5', 'home-sidebar-1', 'home-sidebar-2', 'widget-header','shop-sidebar', 'product-sidebar')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_page',
				'type' => 'sidebars_select',
				'title' => __('Single Page', 'clean' ),
				'sub_desc' => __('Select a sidebar for the single pages. If a page has a custom sidebar set, it will override this.', 'clean' ),
				'args' => array('exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-first-5', 'home-sidebar-1', 'home-sidebar-2', 'widget-header','shop-sidebar', 'product-sidebar')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_archive',
				'type' => 'sidebars_select',
				'title' => __('Archive', 'clean' ),
				'sub_desc' => __('Select a sidebar for the archives. Specific archive sidebars will override this setting (see below).', 'clean' ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-first-5', 'home-sidebar-1', 'home-sidebar-2', 'widget-header','shop-sidebar', 'product-sidebar')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_category',
				'type' => 'sidebars_select',
				'title' => __('Category Archive', 'clean' ),
				'sub_desc' => __('Select a sidebar for the category archives.', 'clean' ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-first-5', 'home-sidebar-1', 'home-sidebar-2', 'widget-header','shop-sidebar', 'product-sidebar')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_tag',
				'type' => 'sidebars_select',
				'title' => __('Tag Archive', 'clean' ),
				'sub_desc' => __('Select a sidebar for the tag archives.', 'clean' ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-first-5', 'home-sidebar-1', 'home-sidebar-2', 'widget-header','shop-sidebar', 'product-sidebar')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_date',
				'type' => 'sidebars_select',
				'title' => __('Date Archive', 'clean' ),
				'sub_desc' => __('Select a sidebar for the date archives.', 'clean' ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-first-5', 'home-sidebar-1', 'home-sidebar-2', 'widget-header','shop-sidebar', 'product-sidebar')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_author',
				'type' => 'sidebars_select',
				'title' => __('Author Archive', 'clean' ),
				'sub_desc' => __('Select a sidebar for the author archives.', 'clean' ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-first-5', 'home-sidebar-1', 'home-sidebar-2', 'widget-header','shop-sidebar', 'product-sidebar')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_search',
				'type' => 'sidebars_select',
				'title' => __('Search', 'clean' ),
				'sub_desc' => __('Select a sidebar for the search results.', 'clean' ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-first-5', 'home-sidebar-1', 'home-sidebar-2', 'widget-header','shop-sidebar', 'product-sidebar')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_notfound',
				'type' => 'sidebars_select',
				'title' => __('404 Error', 'clean' ),
				'sub_desc' => __('Select a sidebar for the 404 Not found pages.', 'clean' ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-first-5', 'home-sidebar-1', 'home-sidebar-2', 'widget-header','shop-sidebar', 'product-sidebar')),
				'std' => ''
			),
			array(
				'id' => 'mts_sidebar_for_shop',
				'type' => 'sidebars_select',
				'title' => __('Shop Pages', 'clean' ),
				'sub_desc' => wp_kses( __('Select a sidebar for Shop main page and product archive pages (WooCommerce plugin must be enabled). Default is <strong>Shop Page Sidebar</strong>.', 'clean' ), array( 'strong' => array() ) ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-first-5', 'home-sidebar-1', 'home-sidebar-2', 'widget-header','shop-sidebar', 'product-sidebar')),
				'std' => 'shop-sidebar'
			),
			array(
				'id' => 'mts_sidebar_for_product',
				'type' => 'sidebars_select',
				'title' => __('Single Product', 'clean' ),
				'sub_desc' => wp_kses( __('Select a sidebar for single products (WooCommerce plugin must be enabled). Default is <strong>Single Product Sidebar</strong>.', 'clean' ), array( 'strong' => array() ) ),
				'args' => array('allow_nosidebar' => false, 'exclude' => array('sidebar', 'footer-first', 'footer-first-2', 'footer-first-3', 'footer-first-4', 'footer-first-5', 'home-sidebar-1', 'home-sidebar-2', 'widget-header','shop-sidebar', 'product-sidebar')),
				'std' => 'product-sidebar'
			),
		),
	);

	$sections[] = array(
		'icon' => 'fa fa-list-alt',
		'title' => __('Navigation', 'clean' ),
		'desc' => '<p class="description"><div class="controls">' . sprintf( __('Navigation settings can now be modified from the %s.', 'clean' ), '<a href="nav-menus.php"><b>' . __( 'Menus Section', 'clean' ) . '</b></a>' ) . '<br></div></p>'
	);


	$tabs = array();

	$args['presets'] = array();
	$args['show_translate'] = false;
	include('theme-presets.php');

	global $NHP_Options;
	$NHP_Options = new NHP_Options($sections, $args, $tabs);

} //function

add_action('init', 'setup_framework_options', 0);

/*
 *
 * Custom function for the callback referenced above
 *
 */
function my_custom_field($field, $value){
	print_r($field);
	print_r($value);

}//function

/*
 *
 * Custom function for the callback validation referenced above
 *
 */
function validate_callback_function($field, $value, $existing_value){

	$error = false;
	$value =  'just testing';
	$return['value'] = $value;
	if($error == true){
		$return['error'] = $field;
	}
	return $return;

}//function

/*--------------------------------------------------------------------
 *
 * Default Font Settings
 *
 --------------------------------------------------------------------*/
if(function_exists('mts_register_typography')) {
	mts_register_typography( array(
		'logo_font' => array(
			'preview_text' => __( 'Logo Font', 'clean' ),
			'preview_color' => 'dark',
			'font_family' => 'Roboto',
			'font_variant' => 'normal',
			'font_size' => '36px',
			'font_color' => '#20303c',
			'css_selectors' => '#header #logo a'
		),
		'primary_navigation_font' => array(
			'preview_text' => __( 'Top Navigation', 'clean' ),
			'preview_color' => 'dark',
			'font_family' => 'Roboto',
			'font_variant' => '300',
			'font_size' => '15px',
			'font_color' => '#20303c',
			'css_selectors' => '#primary-navigation a, .header-button'
		),
		'secondary_navigation_font' => array(
			'preview_text' => __( 'Main Navigation', 'clean' ),
			'preview_color' => 'dark',
			'font_family' => 'Roboto',
			'font_variant' => '300',
			'font_size' => '16px',
			'font_color' => '#20303c',
			'css_selectors' => '#secondary-navigation a, .search-wrap'
		),
		'slider_title_font' => array(
			'preview_text' => __( 'Slider Title', 'clean' ),
			'preview_color' => 'light',
			'font_family' => 'Roboto',
			'font_size' => '38px',
			'font_variant' => '300',
			'font_color' => '#20303c',
			'css_selectors' => '.primary-slider .slide-caption .slide-title'
		),
		'home_title_font' => array(
			'preview_text' => __( 'Homepage Article Title', 'clean' ),
			'preview_color' => 'light',
			'font_family' => 'Roboto',
			'font_size' => '20px',
			'font_variant' => 'normal',
			'font_color' => '#20303c',
			'css_selectors' => '.latestPost .title a'
		),
		'text_info_links' => array(
			'preview_text' => __( 'Post Info Text', 'clean' ),
			'preview_color' => 'light',
			'font_family' => 'Roboto',
			'font_size' => '15px',
			'font_variant' => '300',
			'font_color' => '#66737c',
			'css_selectors' => '.post-info, .pagination, .tags, .breadcrumb, .post-excerpt'
		),
		'single_title_font' => array(
			'preview_text' => __( 'Single Article Title', 'clean' ),
			'preview_color' => 'light',
			'font_family' => 'Roboto',
			'font_size' => '48px',
			'font_variant' => '300',
			'font_color' => '#20303c',
			'css_selectors' => '.single-title'
		),
		'content_font' => array(
			'preview_text' => __( 'Content Font', 'clean' ),
			'preview_color' => 'light',
			'font_family' => 'Roboto',
			'font_size' => '20px',
			'font_variant' => '300',
			'font_color' => '#20303c',
			'css_selectors' => 'body'
		),
		'sidebar_title' => array(
			'preview_text' => __( 'Sidebar Widget Title', 'clean' ),
			'preview_color' => 'light',
			'font_family' => 'Roboto',
			'font_variant' => 'normal',
			'font_size' => '24px',
			'font_color' => '#20303c',
			'css_selectors' => '.widget h3'
		),
		'sidebar_heading' => array(
			'preview_text' => __( 'Sidebar Post Heading', 'clean' ),
			'preview_color' => 'light',
			'font_family' => 'Roboto',
			'font_variant' => '300',
			'font_size' => '20px',
			'font_color' => '#20303c',
			'css_selectors' => '.widget .post-title, .widget-slider .slide-title, .sidebar .widget .entry-title'
		),
		'sidebar_font' => array(
			'preview_text' => __( 'Sidebar Font', 'clean' ),
			'preview_color' => 'light',
			'font_family' => 'Roboto',
			'font_variant' => '300',
			'font_size' => '16px',
			'font_color' => '#20303c',
			'css_selectors' => '.widget'
		),
		'footer_heading' => array(
			'preview_text' => __( 'Footer Widget Title', 'clean' ),
			'preview_color' => 'light',
			'font_family' => 'Roboto',
			'font_variant' => 'normal',
			'font_size' => '16px',
			'font_color' => '#20303c',
			'additional_css' => 'text-transform: uppercase;',
			'css_selectors' => '#site-footer .widget h3'
		),
		'footer_title_font' => array(
			'preview_text' => __( 'Footer Post Heading', 'clean' ),
			'preview_color' => 'light',
			'font_family' => 'Roboto',
			'font_variant' => '300',
			'font_size' => '16px',
			'font_color' => '#20303c',
			'css_selectors' => '#site-footer .widget .post-title, #site-footer .widget-slider .slide-title, #site-footer .widget .entry-title'
		),
		'footer_font' => array(
			'preview_text' => __( 'Footer Font', 'clean' ),
			'preview_color' => 'light',
			'font_family' => 'Roboto',
			'font_variant' => '300',
			'font_size' => '14px',
			'font_color' => '#20303c',
			'css_selectors' => '#site-footer, #site-footer .widget'
		),
		'h1_headline' => array(
			'preview_text' => __( 'Content H1', 'clean' ),
			'preview_color' => 'light',
			'font_family' => 'Roboto',
			'font_variant' => 'normal',
			'font_size' => '36px',
			'font_color' => '#20303c',
			'css_selectors' => 'h1'
		),
		'h2_headline' => array(
			'preview_text' => __( 'Content H2', 'clean' ),
			'preview_color' => 'light',
			'font_family' => 'Roboto',
			'font_variant' => 'normal',
			'font_size' => '32px',
			'font_color' => '#20303c',
			'css_selectors' => 'h2'
		),
		'h3_headline' => array(
			'preview_text' => __( 'Content H3', 'clean' ),
			'preview_color' => 'light',
			'font_family' => 'Roboto',
			'font_variant' => 'normal',
			'font_size' => '30px',
			'font_color' => '#20303c',
			'css_selectors' => 'h3'
		),
		'h4_headline' => array(
			'preview_text' => __( 'Content H4', 'clean' ),
			'preview_color' => 'light',
			'font_family' => 'Roboto',
			'font_variant' => 'normal',
			'font_size' => '28px',
			'font_color' => '#20303c',
			'css_selectors' => 'h4'
		),
		'h5_headline' => array(
			'preview_text' => __( 'Content H5', 'clean' ),
			'preview_color' => 'light',
			'font_family' => 'Roboto',
			'font_variant' => 'normal',
			'font_size' => '24px',
			'font_color' => '#20303c',
			'css_selectors' => 'h5'
		),
		'h6_headline' => array(
			'preview_text' => __( 'Content H6', 'clean' ),
			'preview_color' => 'light',
			'font_family' => 'Roboto',
			'font_variant' => 'normal',
			'font_size' => '20px',
			'font_color' => '#20303c',
			'css_selectors' => 'h6'
		)
	));
}
