<?php
/**
 * The template for displaying the header.
 *
 * Displays everything from the doctype declaration down to the navigation.
 */
?>
<!DOCTYPE html>
<?php $mts_options = get_option(MTS_THEME_NAME); ?>

<html class="no-js" <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame -->
	<!--[if IE ]>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<![endif]-->
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<?php mts_meta(); ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<?php wp_head(); ?>
</head>
<body id="blog" <?php body_class('main'); ?>>
	<div class="main-container">
		<header id="site-header" role="banner" itemscope itemtype="http://schema.org/WPHeader">
		<?php if ( isset( $mts_options['mts_header_layout'] ) && is_array( $mts_options['mts_header_layout'] ) && array_key_exists( 'enabled', $mts_options['mts_header_layout'] ) ) {
            $header_parts = $mts_options['mts_header_layout']['enabled'];
		} else {
		    $header_parts = array( 'logo-section' => 'logo-section', 'main-navigation' => 'main-navigation' );
		}
		foreach( $header_parts as $part => $label ) {
		    switch ($part) {
		        case 'logo-section': ?>
		        <div id="header">
					<div class="container clearfix">
						<div class="logo-wrap">
							<?php if ( $mts_options['mts_logo'] != '' && $mts_logo = wp_get_attachment_image_src( $mts_options['mts_logo'], 'full' ) ) { ?>
								<?php if ( is_front_page() || is_home() || is_404() ) { ?>
									<h1 id="logo" class="image-logo" itemprop="headline">
										<a href="<?php echo esc_url( home_url() ); ?>">
											<img src="<?php echo esc_url( $mts_logo[0] ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="<?php echo esc_attr( $mts_logo[1] ); ?>" height="<?php echo esc_attr( $mts_logo[2] ); ?>">
										</a>
									</h1><!-- END #logo -->
								<?php } else { ?>
									<h2 id="logo" class="image-logo" itemprop="headline">
										<a href="<?php echo esc_url( home_url() ); ?>">
											<img src="<?php echo esc_url( $mts_logo[0] ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="<?php echo esc_attr( $mts_logo[1] ); ?>" height="<?php echo esc_attr( $mts_logo[2] ); ?>">
										</a>
									</h2><!-- END #logo -->
								<?php } ?>

							<?php } else { ?>

								<?php if ( is_front_page() || is_home() || is_404() ) { ?>
									<h1 id="logo" class="text-logo" itemprop="headline">
										<a href="<?php echo esc_url( home_url() ); ?>"><?php bloginfo( 'name' ); ?></a>
									</h1><!-- END #logo -->
								<?php } else { ?>
									<h2 id="logo" class="text-logo" itemprop="headline">
										<a href="<?php echo esc_url( home_url() ); ?>"><?php bloginfo( 'name' ); ?></a>
									</h2><!-- END #logo -->
								<?php } ?>
							<?php } ?>
						</div>

						<?php if ( !empty($mts_options['mts_header_buttons']) && is_array($mts_options['mts_header_buttons']) && !empty($mts_options['mts_header_buttons_section'])) { ?>
							<div class="mts_header_buttons">
								<?php 
								foreach( $mts_options['mts_header_buttons'] as $button ) :
									$mts_header_button_title = $button['mts_header_button_title'];
									$mts_header_button_link = $button['mts_header_button_link'];
									$mts_header_button_bg = $button['mts_header_button_bg'];
									$mts_header_button_color = $button['mts_header_button_color'];
									if( ! empty( $mts_header_button_link ) || ! empty( $mts_header_button_title ) ) : ?>
										<div class="header-button">
											<?php if( ! empty( $mts_header_button_link )) { ?><a href="<?php print $button['mts_header_button_link'] ?>" style="background: <?php echo $mts_header_button_bg; ?>; color: <?php echo $mts_header_button_color; ?>; "><?php } print $mts_header_button_title; if( ! empty( $mts_header_button_link )) { ?></a> <?php } ?> 
										</div>
									<?php endif;
								endforeach; ?>
							</div>
						<?php } ?>

						<?php if ( !empty($mts_options['mts_header_social']) && is_array($mts_options['mts_header_social']) && !empty($mts_options['mts_social_icon_head'])) { ?>
							<div class="header-social">
								<?php foreach( $mts_options['mts_header_social'] as $header_icons ) : ?>
									<?php if( ! empty( $header_icons['mts_header_icon'] ) && isset( $header_icons['mts_header_icon'] ) && ! empty( $header_icons['mts_header_icon_link'] )) : ?>
										<a href="<?php print $header_icons['mts_header_icon_link'] ?>" class="header-<?php print $header_icons['mts_header_icon'] ?>" target="_blank"><span class="fa fa-<?php print $header_icons['mts_header_icon'] ?>"></span></a>
									<?php endif; ?>
								<?php endforeach; ?>
							</div>
						<?php } ?>

						<?php if ( $mts_options['mts_show_primary_nav'] == '1' ) { ?>
							<div id="primary-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
							<?php if ( $mts_options['mts_show_secondary_nav'] !== '1' ) {?><a href="#" id="pull" class="toggle-mobile-menu"><?php _e('Menu', 'clean' ); ?></a><?php } ?>
								<nav class="navigation clearfix<?php if ( $mts_options['mts_show_secondary_nav'] !== '1' ) echo ' mobile-menu-wrapper'; ?>">
									<?php if ( has_nav_menu( 'primary' ) ) { ?>
										<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'menu clearfix', 'container' => '', 'walker' => new mts_menu_walker ) ); ?>
									<?php } else { ?>
										<ul class="menu clearfix">
											<?php wp_list_pages('title_li='); ?>
										</ul>
									<?php } ?>
								</nav>
							</div>
						<?php } ?>
					</div><!--#header-->
				</div>
		    <?php break;
		    case 'main-navigation':
				if( $mts_options['mts_sticky_nav'] == '1' ) { ?>
				<div id="catcher" class="clear" ></div>
				<div class="sticky-navigation navigation-header" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
				<?php } else { ?>
					<div class="navigation-header">
				<?php } ?>
				<div class="container clearfix">
					<?php if ( $mts_options['mts_show_secondary_nav'] == '1' ) { ?>
						<div id="secondary-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
						<a href="#" id="pull" class="toggle-mobile-menu"><?php _e('Menu', 'clean' ); ?></a>
						<?php if ( has_nav_menu( 'mobile' ) ) { ?>
							<nav class="navigation clearfix">
								<?php if ( has_nav_menu( 'secondary' ) ) { ?>
									<?php wp_nav_menu( array( 'theme_location' => 'secondary', 'menu_class' => 'menu clearfix', 'container' => '', 'walker' => new mts_menu_walker ) ); ?>
								<?php } else { ?>
									<ul class="menu clearfix">
										<?php wp_list_categories('title_li='); ?>
									</ul>
								<?php } ?>
							</nav>
							<nav class="navigation mobile-only clearfix mobile-menu-wrapper">
								<?php wp_nav_menu( array( 'theme_location' => 'mobile', 'menu_class' => 'menu clearfix', 'container' => '', 'walker' => new mts_menu_walker ) ); ?>
							</nav>
						<?php } else { ?>
							<nav class="navigation clearfix mobile-menu-wrapper">
								<?php if ( has_nav_menu( 'secondary' ) ) { ?>
									<?php wp_nav_menu( array( 'theme_location' => 'secondary', 'menu_class' => 'menu clearfix', 'container' => '', 'walker' => new mts_menu_walker ) ); ?>
								<?php } else { ?>
									<ul class="menu clearfix">
										<?php wp_list_categories('title_li='); ?>
									</ul>
								<?php } ?>
							</nav>
						<?php } ?>
						</div>
					<?php } ?>
					<?php if ( !empty($mts_options['mts_header_search']) ) { ?>
						<div class="search-wrap">
							<button class="mts-search"><img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz48c3ZnIHZlcnNpb249IjEuMSIgaWQ9IkxheWVyXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IiB3aWR0aD0iMjEuOHB4IiBoZWlnaHQ9IjIxLjhweCIgdmlld0JveD0iMCAwIDIxLjggMjEuOCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMjEuOCAyMS44OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+PHN0eWxlIHR5cGU9InRleHQvY3NzIj4uc3Qwe2ZpbGw6IzIwMzAzQzt9PC9zdHlsZT48cGF0aCBjbGFzcz0ic3QwIiBkPSJNMTcuNiwxNi4yYzEuMy0xLjcsMi4xLTMuOCwyLjEtNi4xYzAtNS4zLTQuMy05LjYtOS42LTkuNmMtNS4zLDAtOS42LDQuMy05LjYsOS42czQuMyw5LjYsOS42LDkuNmMyLjMsMCw0LjQtMC44LDYuMS0yLjFsNC4yLDQuMmwxLjQtMS40TDE3LjYsMTYuMnogTTEwLjEsMTcuN2MtNC4yLDAtNy42LTMuNC03LjYtNy42czMuNC03LjYsNy42LTcuNmM0LjIsMCw3LjYsMy40LDcuNiw3LjZTMTQuMywxNy43LDEwLjEsMTcuN3oiLz48L3N2Zz4="></button>
						</div>
						<div class="mts-header-search">
							<form method="get" id="searchform" class="search-form" action="<?php echo home_url(); ?>" _lpchecked="1">
								<input type="text" name="s" id="s" value="<?php the_search_query(); ?>" class="search_input" type="search" placeholder="<?php _e('search...','clean'); ?>" <?php if (!empty($mts_options['mts_ajax_search'])) echo ' autocomplete="off"'; ?>/>
									<!-- <span class="search__info">Hit enter to search or ESC to close</span> -->
								<button id="mts-search-close" class="btn--hidden" aria-label="Close search form"><svg enable-background="new 0 0 100 100" id="Layer_1" version="1.1" viewBox="0 0 100 100" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><polygon fill="#000" points="77.6,21.1 49.6,49.2 21.5,21.1 19.6,23 47.6,51.1 19.6,79.2 21.5,81.1 49.6,53 77.6,81.1 79.6,79.2   51.5,51.1 79.6,23 "/></polygon></svg></button>
							</form>
						</div><!-- /search -->
					<?php } ?>
				</div>
			</div><!--.container-->
		    <?php break;
		    }
		} ?>
		</header>
		<?php if ( is_active_sidebar( 'widget-header' ) ) { ?>
			<div class="container">
				<?php dynamic_sidebar('widget-header'); ?>
			</div>	
		<?php } ?>
