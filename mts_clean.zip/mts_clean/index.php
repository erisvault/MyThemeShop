<?php
/**
 * The main template file.
 *
 * Used to display the homepage when home.php doesn't exist.
 */
$mts_options = get_option(MTS_THEME_NAME); 

get_header();

$mts_home_layout = $mts_options['mts_home_layout'];
$sidebar1 = '';
$sidebar2 = ''; ?>

<div id="page"">
	<div id="content_box">
	<?php if ( '3-col-grid' == $mts_home_layout && is_active_sidebar( 'home-sidebar-1' ) ) {
		$sidebar1 = "sidebar1";
	} 
	if( '3-col-grid' == $mts_home_layout && is_active_sidebar( 'home-sidebar-2' ) ) {
		$sidebar2 = "sidebar2";
	}

	if ( !is_paged() ) {
		if ( is_home() && $mts_options['mts_featured_slider'] == '1' ) {
			$mts_slider_sides = $mts_options['mts_featured_slider_sides'];
			if ( 'full-width-slider' == $mts_slider_sides || 'no-slider-content' == $mts_slider_sides ) {
				$class = 'slider-full-width';
				$thumb = 'clean-full-slider';
			} elseif ( 'right-content' == $mts_slider_sides) {
				$class = 'slider-right';
				$thumb = 'clean-featuredfull';
			} else {
				$class = '';
				$thumb = 'clean-featuredfull';
			} ?>
			<div class="primary-slider-container clearfix loading">
				<div id="slider" class="primary-slider <?php echo $class; ?>">
					<?php if ( empty( $mts_options['mts_custom_slider'] ) ) {

						// prevent implode error
						if ( empty( $mts_options['mts_featured_slider_cat'] ) || !is_array( $mts_options['mts_featured_slider_cat'] ) ) {
							$mts_options['mts_featured_slider_cat'] = array('0');
						}

						$slider_cat = implode( ",", $mts_options['mts_featured_slider_cat'] );
						$slider_query = new WP_Query('cat='.$slider_cat.'&posts_per_page='.$mts_options['mts_featured_slider_num']);
						while ( $slider_query->have_posts() ) : $slider_query->the_post(); ?>
							<div class="primary-slider-item"> 
								<a href="<?php echo esc_url( get_the_permalink() ); ?>">
									<?php the_post_thumbnail($thumb, array('title' => '')); ?>
								</a> 
								<?php if ( 'full-width-slider' == $mts_slider_sides ) { ?>
									<div class="slider-caption-wrap">
								<?php } ?>	
								<?php if('no-slider-content' != $mts_slider_sides) { ?>
									<div class="slide-caption">
										<h2 class="slide-title"><a href="<?php echo esc_url( get_the_permalink() ); ?>"><?php the_title(); ?></a></h2>
										<div class="thecategory">
											<?php $category = get_the_category(); echo $category[0]->cat_name; ?>
										</div>
									</div>
								<?php } ?>
					            <div class="slider-controls <?php echo $mts_slider_sides == 'no-slider-content' ? 'mts-no-content': ''?>">
						            <?php if('no-slider-content' != $mts_slider_sides) { ?>    
						                <a href="<?php echo esc_url( get_the_permalink() ); ?>" class="slider-readmore"><?php _e('Read More','clean'); ?> <i class="fa fa-angle-right"></i></a>
						            <?php } ?>    
					                <div class="btn-prev-next">
						                <a class="btn slider-prev"><i class="fa fa-long-arrow-left"></i></a>
						                <div class="slider-numbers"><?php _e('1','clean'); ?> / <?php echo $mts_options['mts_featured_slider_num']; ?></div>
						                <a class="btn slider-next"><i class="fa fa-long-arrow-right"></i></a>
									</div>
								</div>
								<?php if ( 'full-width-slider' == $mts_slider_sides ) { ?>
									</div>
								<?php } ?>
							</div>
						<?php endwhile; wp_reset_postdata(); ?>

					<?php } else {

						foreach( $mts_options['mts_custom_slider'] as $slide ) : ?>
							<div class="primary-slider-item"> 
								<a href="<?php echo esc_url( $slide['mts_custom_slider_link'] ); ?>">
									<?php echo wp_get_attachment_image( $slide['mts_custom_slider_image'], $thumb, false, array('title' => '') ); ?>
								</a> 
								<?php if ( 'full-width-slider' == $mts_slider_sides ) { ?>
									<div class="slider-caption-wrap">
								<?php } ?>	
								<?php if('no-slider-content' != $mts_slider_sides) { ?>
									<div class="slide-caption">
										<h2 class="slide-title"><a href="<?php echo esc_url( $slide['mts_custom_slider_link'] ); ?>"><?php echo esc_html( $slide['mts_custom_slider_title'] ); ?></a></h2>
									</div>
								<?php } ?>
					            <div class="slider-controls <?php echo $mts_slider_sides == 'no-slider-content' ? 'mts-no-content': ''?>">
						            <?php if('no-slider-content' != $mts_slider_sides) {   
							            if( ! empty( $slide['mts_custom_slider_link'] )) { ?>    
							                <a href="<?php echo esc_url( $slide['mts_custom_slider_link'] ); ?>" class="slider-readmore"><?php _e('Read More','clean'); ?> <i class="fa fa-angle-right"></i></a>
							            <?php }   
						            } ?>    
					                <div class="btn-prev-next">
						                <a class="btn slider-prev"><i class="fa fa-long-arrow-left"></i></a>
						                 <div class="slider-numbers"><?php _e('1','clean'); ?> / <?php echo count($mts_options['mts_custom_slider']); ?></div>
						                <a class="btn slider-next"><i class="fa fa-long-arrow-right"></i></a>
									</div>
								</div>
								<?php if ( 'full-width-slider' == $mts_slider_sides ) { ?>
								</div>
							<?php } ?>
							</div>
						<?php endforeach;

					} ?>
				</div><!-- .primary-slider -->
			</div><!-- .primary-slider-container -->
		<?php }

		if( '2-col-grid' == $mts_home_layout ) { ?>
			<div class="page-2-col-grid">
		<?php }
		if( 'traditional-grid' == $mts_home_layout ) { ?>
			<div class="page-traditional-grid">
		<?php }
		
		$featured_categories = array();
		if ( !empty( $mts_options['mts_featured_categories'] ) ) {
			foreach ( $mts_options['mts_featured_categories'] as $section ) {
				$category_id = $section['mts_featured_category'];
				$featured_categories[] = $category_id;
				$posts_num = $section['mts_featured_category_postsnum'];
				if ( 'latest' == $category_id ) { ?>

					<div class="post-wrap <?php echo $sidebar1; ?> <?php echo $sidebar2;?>">
						<?php $j = 0; if ( have_posts() ) : while ( have_posts() ) : the_post(); $j++; ?>
							<article class="latestPost excerpt" data-aos="fade-up">
								<?php mts_archive_post(); ?>
							</article>
							<?php if ( $j == 5 && is_active_sidebar( 'home-sidebar-1' ) && ('3-col-grid' == $mts_home_layout) ) { ?>
                               	<aside class="latestPost sidebar c-4-12 home-sidebar-1" data-aos="fade-up">
                               		<?php dynamic_sidebar('home-sidebar-1'); ?>
                               	</aside>	 
                            <?php } ?>
                            <?php if ( $j == 10 && is_active_sidebar( 'home-sidebar-2' ) && ('3-col-grid' == $mts_home_layout) ) { ?>
                               	<aside class="latestPost sidebar c-4-12 home-sidebar-2" data-aos="fade-up">
                               		<?php dynamic_sidebar('home-sidebar-2'); ?>
                               	</aside>	 
                            <?php } ?>								
						<?php endwhile; endif; ?>
						<?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
							<?php mts_pagination(); ?>
						<?php } ?>
					</div>

				<?php } else { // if $category_id != 'latest': ?>

					<h3 class="featured-category-title"><a href="<?php echo esc_url( get_category_link( $category_id ) ); ?>" title="<?php echo esc_attr( get_cat_name( $category_id ) ); ?>"><?php echo esc_html( get_cat_name( $category_id ) ); ?></a></h3>
					<div class="featured-category-wrap <?php echo $sidebar1; ?> <?php echo $sidebar2;?>">
						<?php $j = 0;
						$cat_query = new WP_Query('cat='.$category_id.'&posts_per_page='.$posts_num);
						if ( $cat_query->have_posts() ) : while ( $cat_query->have_posts() ) : $cat_query->the_post(); ?>
							<article class="latestPost excerpt" data-aos="fade-up">
								<?php mts_archive_post(); ?>
							</article>
						<?php
						endwhile; endif; wp_reset_postdata(); ?>
					</div>
					
				<?php }	
			}
		}

		if( '2-col-grid' == $mts_home_layout ) { ?></div><?php }

		if( 'traditional-grid' == $mts_home_layout ) { ?></div><?php }

	} else { //Paged ?>

		<?php if( '2-col-grid' == $mts_home_layout ) { ?>
			<div class="page-2-col-grid">
		<?php }
		if( 'traditional-grid' == $mts_home_layout ) { ?>
			<div class="page-traditional-grid">
		<?php } ?>
		<div class="post-wrap <?php echo $sidebar1; ?> <?php echo $sidebar2; ?>">
			<?php $j = 0; if ( have_posts() ) : while ( have_posts() ) : the_post(); $j++; ?>
				<article class="latestPost excerpt" data-aos="fade-up">
					<?php mts_archive_post(); ?>
				</article>

				<?php if ( $j == 5 && is_active_sidebar( 'home-sidebar-1' ) && ('3-col-grid' == $mts_home_layout) ) { ?>
                   	<aside class="latestPost sidebar c-4-12 home-sidebar-1" data-aos="fade-up">
                   		<?php dynamic_sidebar('home-sidebar-1'); ?>
                   	</aside>	 
                <?php } ?>

                <?php if ( $j == 10 && is_active_sidebar( 'home-sidebar-2' ) && ('3-col-grid' == $mts_home_layout) ) { ?>
                   	<aside class="latestPost sidebar c-4-12 home-sidebar-2" data-aos="fade-up">
                   		<?php dynamic_sidebar('home-sidebar-2'); ?>
                   	</aside>	 
                <?php } ?>
			<?php endwhile; endif; ?>
			<?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
				<?php mts_pagination(); ?>
			<?php } ?>
		</div>

		<?php if( '2-col-grid' == $mts_home_layout ) { ?></div><?php }

		if( 'traditional-grid' == $mts_home_layout ) { ?></div><?php }

	} ?>
<?php if( '2-col-grid' == $mts_home_layout || 'traditional-grid' == $mts_home_layout ) get_sidebar(); ?>
</div>
<?php get_footer(); ?>