<?php
/**
 * Before footer detect ad blocker notice.
 *
 */

if ( blocks_get_settings( 'detect_adblocker' ) && ( 'popup' === blocks_get_settings( 'detect_adblocker_type' ) || 'floating' === blocks_get_settings( 'detect_adblocker_type' ) ) ) { ?>
	<?php if ( 'popup' === blocks_get_settings( 'detect_adblocker_type' ) ) { ?>
		<div class="blocker-overlay"></div>
	<?php } ?>
	<?php echo detect_adblocker_notice(); ?>
<?php } ?>
