<?php
/**
 * Posts Layout - layout 1
 *
 * @package Blocks
 */
$featured = blocks()->featured_layouts;
?>
<div class="<?php blocks_article_class(); ?> <?php $featured->get_post_container_class(); ?> clear ">

	<div class="container">

		<div id="content_box">

			<?php blocks_action( 'start_content_box' ); ?>

			<?php $featured->get_section_title(); ?>

			<?php $featured->get_view_more_button(); ?>

			<section id="latest-posts" class="<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
				<article class="latestPost excerpt <?php echo ( 0 === ++$j % 2 ) ? 'last' : ''; ?>">

					<?php $featured->get_post_thumbnail(); ?>

						<div class="wrapper">

							<?php
							if ( blocks_get_settings( 'home_category_' . $featured->current['unique_id'] ) ) :
								printf( '<div class="thecategory">%s</div>', blocks_get_the_category( ' ' ) );
							endif;
							?>

							<?php $featured->get_post_title( false ); ?>

							<?php $featured->get_post_content( true ); ?>

						</div>

				</article>
					<?php
					endwhile;

					$featured->get_post_pagination();
				?>

			</section><!--#latest-posts-->

		</div>

	</div>

</div>
