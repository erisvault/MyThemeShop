<?php
/**
 * Clickable Background
 *
 */

if ( blocks_get_settings( 'background_clickable' ) && blocks_get_settings( 'background_link' ) ) {
	$target = ( 1 === blocks_get_settings( 'background_link_new_tab' ) ) ? 'target="_blank"' : '';
	printf( '<a href="%1$s" rel="nofollow" class="clickable-background" %2$s>', blocks_get_settings( 'background_link' ), $target );
}
