<?php
/**
 * Header Layout
 *
 * @package Blocks
 */

?>

<header id="site-header" class="main-header <?php echo esc_attr( blocks_get_settings( 'mts_header_style' ) ); ?> clearfix" role="banner" itemscope itemtype="http://schema.org/WPHeader">
	<?php if ( blocks_get_settings( 'mts_show_primary_nav' ) === 1 ) { ?>
		<div id="primary-nav">
			<div class="container clearfix">
				<div id="primary-navigation" class="primary-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
					<nav class="navigation clearfix">
						<?php
						// Primary Navigation.
						if ( has_nav_menu( 'primary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'primary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new blocks_menu_walker(),
							));
						}
						?>
					</nav>
				</div>
			</div>
		</div>
	<?php } ?>

	<?php if ( blocks_get_settings( 'mts_sticky_nav' ) ) { ?>
	<div class="clear" id="catcher"></div>
	<div id="header" class="sticky-navigation">
	<?php } else { ?>
	<div id="header">
	<?php } ?>
		<div class="container">

			<div class="logo-wrap">
				<?php blocks_logo(); ?>
			</div>

			<div id="secondary-navigation" class="secondary-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
				<a href="#" id="pull" class="toggle-mobile-menu"><span><?php esc_html_e( 'Menu', 'blocks' ); ?></span></a>
				<?php if ( has_nav_menu( 'mobile' ) ) { ?>

					<nav class="navigation clearfix">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'secondary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new blocks_menu_walker(),
							));
						}
						?>
					</nav>
					<nav class="navigation mobile-only clearfix mobile-menu-wrapper">
						<?php
						// Mobile Navigation.
						if ( has_nav_menu( 'mobile' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'mobile',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new blocks_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } else { ?>

					<nav class="navigation clearfix mobile-menu-wrapper">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'secondary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new blocks_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } ?>
			</div>

			<?php
			// Header Search.
			if ( blocks_get_settings( 'header_search_box' ) ) {
				$ajax_search = ! empty( blocks_get_settings( 'mts_ajax_search' ) ) ? ' autocomplete="off"' : '';
				?>
				<div class="header-search">
					<form method="get" id="searchform" class="searchbox search-form" action="<?php echo esc_attr( home_url() ); ?>" _lpchecked="1">
						<input type="text" name="s" id="s" class="searchbox-input" value="<?php the_search_query(); ?>" placeholder="<?php esc_html_e( 'Search...', 'blocks' ); ?>" <?php echo $ajax_search; ?> />
						<span class="searchbox-icon sbutton"><i class="fa fa-search"></i></span>
					</form>
				</div>
			<?php
			}

			// Header Social Icons.
			if ( ! empty( blocks_get_settings( 'mts_header_social' ) ) && is_array( blocks_get_settings( 'mts_header_social' ) ) ) {
				$header_icons = blocks_get_settings( 'mts_header_social' );
				blocks_social_icons( $header_icons, true );
			}
			?>

		</div><!--.container-->

	</div>
</header>
<?php get_template_part( 'template-parts/header/header', 'nav-adcode' ); ?>
<?php get_template_part( 'template-parts/header/header', 'adcode' ); ?>
