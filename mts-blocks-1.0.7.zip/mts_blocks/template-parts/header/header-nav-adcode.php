<?php if ( blocks_get_settings( 'navigation_ad' ) && blocks_get_settings( 'navigation_adcode' ) ) { ?>
	<div class="navigation-banner">
		<div class="container">
			<div style="<?php ad_size_value( blocks_get_settings( 'navigation_ad_size' ) ); ?>">
				<?php echo blocks_get_settings( 'navigation_adcode' ); ?>
			</div>
		</div>
	</div>
<?php } ?>
