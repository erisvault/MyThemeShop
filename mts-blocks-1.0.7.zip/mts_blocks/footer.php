<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Blocks
 */

get_template_part( 'template-parts/footer/footer', 'ad' );
?>
	</div><!--#wrapper-->

	<footer<?php blocks_attr( 'footer' ); ?>>

		<div class="container">
			<?php

			get_template_part( 'template-parts/footer/footer', 'logo' );

			if ( 'bottom' !== blocks_get_settings( 'footer_sections_position' ) ) {
				get_template_part( 'template-parts/footer/footer', 'sections' );
			}

			if ( blocks_get_settings( 'mts_top_footer' ) ) {
				blocks_footer_widget_columns();
			}

			if ( 'bottom' === blocks_get_settings( 'footer_sections_position' ) ) {
				get_template_part( 'template-parts/footer/footer', 'sections' );
			}
			if ( 'bottom' === blocks_get_settings( 'bt_top_button_position' ) ) {
				?>
				<a id="move-to-top" class="animate filling move-to-top" href="#blog"><span class="top-text"><?php echo blocks_get_settings( 'top_button_text' ); ?></span><i class="fa fa-<?php echo blocks_get_settings( 'top_button_icon' ); ?>"></i></a>
				<?php
			}
			?>
		</div>

		<?php blocks_footer_copyrights(); ?>

	</footer><!--#site-footer-->

</div><!--.main-container-->

<?php get_template_part( 'template-parts/footer/footer', 'detect-adblocker' ); ?>

<?php wp_footer(); ?>

</body>
</html>
