<?php
/**
 * The template for displaying all single posts.
 *
 * @package Blocks
 */

get_header(); ?>

	<div id="wrapper" class="<?php blocks_single_page_class(); ?>">

		<?php blocks_action( 'single_top' ); ?>

		<div class="container clearfix">

			<?php
			blocks_single_featured_image_effect();

			blocks_action( 'before_content' );

			blocks_single_sections();

			blocks_action( 'after_content' );

			get_sidebar();
			?>

		</div>

		<?php
		if ( 'full' === blocks_get_settings( 'related_posts_position' ) ) {
			blocks_related_posts();
		}
		?>

<?php
get_footer();
