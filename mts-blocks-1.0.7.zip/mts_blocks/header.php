<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="page">
 *
 * @package Blocks
 */

?><!doctype html>
<html<?php blocks_attr( 'html' ); ?>>
<head<?php blocks_attr( 'head' ); ?>>
	<?php wp_head(); ?>
</head>

<body<?php blocks_attr( 'body' ); ?>>

	<?php get_template_part( 'template-parts/header/clickable', 'background' ); ?>

	<div<?php blocks_attr( 'main' ); ?>>

		<?php blocks_action( 'before_wrapper' ); ?>
