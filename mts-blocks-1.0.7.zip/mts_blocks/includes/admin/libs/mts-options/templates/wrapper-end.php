	</form>

	<?php
		blocks_action( 'options-page_after_form' );
		blocks_action( 'options_page_after_form_' . $this->args['opt_name'] );
	?>

	<div class="clear"></div>

</div><!--/wrap-->
