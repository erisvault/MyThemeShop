<?php
/**
 * Set blocks layout according to options
 *
 * @package Blocks
 */

defined( 'WPINC' ) || exit;

/**
 * Layout manager.
 */
class Blocks_Layout extends Blocks_Base {

	/**
	 * The Construct
	 */
	public function __construct() {
		$this->add_action( 'blocks_before_wrapper', 'add_header' );
		$this->add_action( 'blocks_single_top', 'full_single_post_header' );
		$this->add_action( 'blocks_single_post_header', 'single_post_header' );
	}

	/**
	 * Add header
	 */
	public function add_header() {
		$hash = array(
			'header-default' => 'default',
			'header-layout2' => 'layout2',
		);

		$layout = blocks_get_settings( 'mts_header_style' );
		get_template_part( 'template-parts/header/header', isset( $hash[ $layout ] ) ? $hash[ $layout ] : $layout );
	}

	/**
	 * Single post header if fullwidth layout
	 */
	public function full_single_post_header() {
		$img_size = blocks_get_settings( 'featured_image_size' );

		if ( 'full' === $img_size ) {

			if ( have_posts() ) :
				while ( have_posts() ) :
					the_post();

					$featured_image = array();
					if ( blocks_get_settings( 'mts_show_featured' ) ) {
						if ( has_post_thumbnail() ) {
							$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'blocks-full-header' );
							$class          = 'with-featured';
						} else {
							$nothumb = get_parent_theme_file_uri() . '/images/nothumb-blocks-full-header.png';
							$class   = 'with-featured';
						}
					}
					?>
						<header class="single-full-header <?php echo isset( $class ) ? $class : ''; ?> clearfix" style="background-image: url('<?php echo has_post_thumbnail() ? $featured_image[0] : $nothumb; ?>');">
						<?php
						if ( 1 === blocks_get_settings( 'show_prev_next' ) ) {
						?>
							<div class="prev-next">
								<?php
								previous_post_link( '<div class="prev">%link</div>', '<i class="fa fa-angle-left"></i>', true );
								next_post_link( '<div class="next">%link</div>', '<i class="fa fa-angle-right"></i>', true );
								?>
							</div>
						<?php
						}
						?>
						<div class="content">
							<div class="container">
								<div class="full-header-wrapper clearfix">
									<?php
									// Author gravatar.
									if ( 1 === blocks_get_settings( 'author_image_on_full' ) && 1 === blocks_get_settings( 'mts_show_featured' ) && function_exists( 'get_avatar' ) ) {
										echo get_avatar( get_the_author_meta( 'email' ), '70' ); // Gravatar size.
									}
									if ( blocks_get_settings( 'single_category_post' ) ) :
										printf( '<div class="thesinglecategory">%s</div>', blocks_get_the_category( ' ' ) );
									endif;
									?>
									<h1 class="title single-title entry-title"><?php the_title(); ?></h1>
									<?php blocks_the_post_meta( 'single' ); ?>
								</div>
							</div>
						</div>
					</header>
				<?php
				endwhile;
			endif; /* end loop */

		}
	}

	/**
	 * Single post header
	 */
	public function single_post_header() {

		$img_size = blocks_get_settings( 'featured_image_size' );

		if ( 'default' === $img_size ) {
		?>
			<header>
				<?php
				if ( 1 === blocks_get_settings( 'mts_show_featured' ) ) {
					the_post_thumbnail( 'full', array( 'class' => 'single-featured-image' ) );
				}
				if ( blocks_get_settings( 'single_category_post' ) ) :
					printf( '<div class="thesinglecategory">%s</div>', blocks_get_the_category( ' ' ) );
				endif;
				?>

				<h1 class="title single-title entry-title"><?php the_title(); ?></h1>
				<?php blocks_the_post_meta( 'single' ); ?>
			</header><!--.headline_area-->
		<?php
		}
	}
}

// Init.
new Blocks_Layout;
