<?php
/**
 * Tweaks for the footer of the document.
 *
 * @package Blocks
 */

defined( 'WPINC' ) || exit;

/**
 * Tweaks for the <head> of the document.
 */
class Blocks_Footer extends Blocks_Base {

	/**
	 * Constructor
	 */
	public function __construct() {

		$this->add_action( 'wp_footer', 'tracking_field', 999 );
	}

	/**
	 * Add tracking field code
	 */
	public function tracking_field() {
		echo blocks_get_settings( 'mts_analytics_code' );
	}
}

/**
 * Init
 */
new Blocks_Footer;
