<?php
/**
 * Back to top
 *
 * @package Blocks
 */

$menus['footer']['child']['footer-back-to-top'] = array(
	'title' => esc_html__( 'Back to Top', 'blocks' ),
	'desc'  => esc_html__( 'From here, you can control the back to top button.', 'blocks' ),
);

$sections['footer-back-to-top'] = array(

	array(
		'id'       => 'show_top_button',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Top Button', 'blocks' ),
		'sub_desc' => esc_html__( 'Enable or disable back to top button with this option.', 'blocks' ),
		'std'      => '1',
	),

	array(
		'id'         => 'bt_top_button_position',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Top Buttons Position', 'blocks' ),
		'options'    => array(
			'floating' => esc_html__( 'Floating', 'blocks' ),
			'bottom'   => esc_html__( 'Bottom', 'blocks' ),
		),
		'sub_desc'   => esc_html__( 'Choose position for Top Button.', 'blocks' ),
		'std'        => 'bottom',
		'class'      => 'green',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_icon',
		'type'       => 'icon_select',
		'title'      => esc_html__( 'Top Button Icon', 'blocks' ),
		'sub_desc'   => esc_html__( 'Set icon for top button icon with this option.', 'blocks' ),
		'std'        => 'chevron-up',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_text',
		'type'       => 'text',
		'title'      => esc_html__( 'Top Button Text', 'blocks' ),
		'sub_desc'   => esc_html__( 'Set Top button text from here.', 'blocks' ),
		'std'        => 'Back to Top',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Button Color', 'blocks' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'blocks' ),
		'std'        => blocks_get_settings( 'mts_color_scheme' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'top_button_color_hover',
		'type'       => 'color',
		'title'      => esc_html__( 'Button Hover Color', 'blocks' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'blocks' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_background',
		'type'       => 'color',
		'title'      => esc_html__( 'Top Button Background', 'blocks' ),
		'sub_desc'   => esc_html__( 'Set top button background color, pattern and image from here.', 'blocks' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'top_button_background_hover',
		'type'       => 'color',
		'title'      => esc_html__( 'Top Button Hover Background', 'blocks' ),
		'sub_desc'   => esc_html__( 'Set top button background color, pattern and image from here.', 'blocks' ),
		'std'        => blocks_get_settings( 'mts_color_scheme' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_font_size',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Font Size', 'blocks' ),
		'sub_desc'   => esc_html__( 'Set font size of top button in px.', 'blocks' ),
		'std'        => '14',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'blocks' ),
		'sub_desc'   => esc_html__( 'Set Top button padding from here.', 'blocks' ),
		'std'        => array(
			'top'    => '12px',
			'right'  => '15px',
			'bottom' => '11px',
			'left'   => '25px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'top_button_position',
		'type'       => 'margin',
		'title'      => esc_html__( 'Button Position', 'blocks' ),
		'sub_desc'   => esc_html__( 'Set button position from here.', 'blocks' ),
		'std'        => array(
			'top'    => 'auto',
			'right'  => '30px',
			'bottom' => '100px',
			'left'   => 'auto',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'bt_top_button_position',
				'value'      => 'floating',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_border_radius',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Border Radius', 'blocks' ),
		'sub_desc'   => esc_html__( 'Set border radius of top button in px.', 'blocks' ),
		'std'        => '4',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'blocks' ),
		'sub_desc'   => esc_html__( 'Select border', 'blocks' ),
		'std'        => array(
			'direction' => 'all',
			'size'      => '1',
			'style'     => 'solid',
			'color'     => blocks_get_settings( 'mts_color_scheme' ),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

);
