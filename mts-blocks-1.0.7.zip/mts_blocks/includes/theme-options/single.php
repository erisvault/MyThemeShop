<?php
/**
 * Single Tab
 *
 * @package Blocks
 */

$menus['single-general'] = array(
	'title' => esc_html__( 'General', 'blocks' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of your single posts page.', 'blocks' ),
);

$sections['single-general'] = array(

	array(
		'id'       => 'mts_show_featured',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Featured image', 'blocks' ),
		'sub_desc' => esc_html__( 'Enable/Disable the Featured images in the single post.', 'blocks' ),
		'std'      => '1',
	),
	array(
		'id'       => 'featured_image_size',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Header Size', 'blocks' ),
		'sub_desc' => esc_html__( 'Choose the featured image size', 'blocks' ),
		'options'  => array(
			'default' => esc_html__( 'Content Size', 'blocks' ),
			'full'    => esc_html__( 'Full Width', 'blocks' ),
		),
		'std'      => 'full',
	),
	array(
		'id'         => 'featured_image_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Header Image Margin', 'blocks' ),
		'sub_desc'   => esc_html__( 'Set header image margin from here.', 'blocks' ),
		'std'        => array(
			'top'    => '-80px',
			'right'  => '0',
			'bottom' => '64px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'featured_text_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Alignment', 'blocks' ),
		'sub_desc'   => esc_html__( 'Choose the featured image text alignment', 'blocks' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'blocks' ),
			'center' => esc_html__( 'Center', 'blocks' ),
			'right'  => esc_html__( 'Right', 'blocks' ),
		),
		'std'        => 'center',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'author_image_on_full',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Author Image', 'blocks' ),
		'sub_desc'   => esc_html__( 'Enable or disable author image with this option', 'blocks' ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'show_prev_next',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show preview and next article buttons', 'blocks' ),
		'sub_desc'   => esc_html__( 'Use this button to show or hide preview and next article buttons.', 'blocks' ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'single_category_post',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show category on single post', 'blocks' ),
		'sub_desc' => esc_html__( 'Use this button to show or hide category on single post.', 'blocks' ),
		'std'      => '1',
	),

	array(
		'id'         => 'single_category_post_background',
		'type'       => 'color',
		'title'      => esc_html__( 'Single Category Background Color', 'blocks' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'blocks' ),
		'std'        => '',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_category_post',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_single_post_layout',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Post Layout', 'blocks' ),
		'sub_desc' => esc_html__( 'Customize the look of single posts', 'blocks' ),
		'options'  => array(
			'enabled'  => array(
				'content' => array(
					'label'     => esc_html__( 'Post Content', 'blocks' ),
					'subfields' => array(),
				),
				'tags'    => array(
					'label'     => esc_html__( 'Tags & Social Share', 'blocks' ),
					'subfields' => array(
						array(
							'id'       => 'single_like_button',
							'type'     => 'switch',
							'title'    => esc_html__( 'Show Like button', 'blocks' ),
							'sub_desc' => esc_html__( 'Use this button to show or hide like button on single post.', 'blocks' ),
							'std'      => '1',
						),
						array(
							'id'       => 'mts_social_button_position',
							'type'     => 'button_set',
							'title'    => esc_html__( 'Social Sharing Buttons Position', 'blocks' ),
							'options'  => array(
								'top'    => esc_html__( 'Above Content', 'blocks' ),
								'bottom' => esc_html__( 'Below Content', 'blocks' ),
							),
							'sub_desc' => esc_html__( 'Choose position for Social Sharing Buttons.', 'blocks' ),
							'std'      => 'bottom',
							'class'    => 'green',
						),
					),
				),
				'author'  => array(
					'label'     => esc_html__( 'Author Box', 'blocks' ),
					'subfields' => array(
						array(
							'id'       => 'mts_related_posts_taxonomy',
							'type'     => 'switch',
							'title'    => esc_html__( 'Related Posts Taxonomy', 'blocks' ),
							'options'  => array(
								'tags'       => esc_html__( 'Tags', 'blocks' ),
								'categories' => esc_html__( 'Categories', 'blocks' ),
							),
							'class'    => 'green',
							'sub_desc' => esc_html__( 'Related Posts based on tags or categories.', 'blocks' ),
							'std'      => 'categories',
						),
					),
				),
				'related' => array(
					'label'     => esc_html__( 'Related Posts', 'blocks' ),
					'subfields' => array(
						array(
							'id'       => 'related_post_title',
							'type'     => 'text',
							'title'    => esc_html__( 'Related Posts Title', 'blocks' ),
							'sub_desc' => esc_html__( 'Enter the title text to show in the related posts section.', 'blocks' ),
							'std'      => 'Related Posts',

						),
						array(
							'id'       => 'mts_related_posts_taxonomy',
							'type'     => 'switch',
							'title'    => esc_html__( 'Related Posts Taxonomy', 'blocks' ),
							'options'  => array(
								'tags'       => esc_html__( 'Tags', 'blocks' ),
								'categories' => esc_html__( 'Categories', 'blocks' ),
							),
							'class'    => 'green',
							'sub_desc' => esc_html__( 'Related Posts based on tags or categories.', 'blocks' ),
							'std'      => 'categories',
						),
					),
				),
			),
			'disabled' => array(
				'subscribe' => array(
					'label'     => esc_html__( 'Subscribe Box', 'blocks' ),
					'subfields' => array(),
				),
			),
		),
	),

	array(
		'id'       => 'mts_single_headline_meta_info',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Meta Info', 'blocks' ),
		'sub_desc' => esc_html__( 'Organize how you want the post meta info to appear on single page', 'blocks' ),
		'options'  => array(
			'enabled'  => array(
				'author' => array(
					'label'     => esc_html__( 'Author Name', 'blocks' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_author_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'blocks' ),
						),
					),
				),
				'date'   => array(
					'label'     => esc_html__( 'Date', 'blocks' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_date_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'blocks' ),
						),
					),
				),
			),
			'disabled' => array(
				'comment' => array(
					'label'     => esc_html__( 'Comment Count', 'blocks' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_comment_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'blocks' ),
						),
					),
				),
			),
		),
	),

	array(
		'id'       => 'single_meta_info_background',
		'type'     => 'color',
		'title'    => esc_html__( 'Single Meta Info Background Color', 'blocks' ),
		'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'blocks' ),
		'std'      => '',
	),

	array(
		'id'       => 'mts_breadcrumb',
		'type'     => 'switch',
		'title'    => esc_html__( 'Breadcrumbs', 'blocks' ),
		'sub_desc' => esc_html__( 'Breadcrumbs are a great way to make your site more user-friendly. You can enable them by checking this box.', 'blocks' ),
		'std'      => '0',
	),

	array(
		'id'         => 'breadcrumb_icon',
		'type'       => 'icon_select',
		'title'      => esc_html__( 'Icon', 'blocks' ),
		'sub_desc'   => esc_html__( 'Select divider icons from here.', 'blocks' ),
		'std'        => 'angle-right',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_author_comment',
		'type'     => 'switch',
		'title'    => esc_html__( 'Highlight Author Comment', 'blocks' ),
		'sub_desc' => esc_html__( 'Use this button to highlight author comments.', 'blocks' ),
		'std'      => '1',
	),

	array(
		'id'       => 'mts_comment_date',
		'type'     => 'switch',
		'title'    => esc_html__( 'Date in Comments', 'blocks' ),
		'sub_desc' => esc_html__( 'Use this button to show the date for comments.', 'blocks' ),
		'std'      => '1',
	),
);
