<?php
/**
 * Top Bar
 *
 * @package Blocks
 */

$menus['header']['child']['header-top-bar'] = array(
	'title' => esc_html__( 'Topbar', 'blocks' ),
	'desc'  => esc_html__( 'From here, you can control the topbar of header section.', 'blocks' ),
);

$sections['header-top-bar'] = array(

	array(
		'id'       => 'mts_show_primary_nav',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Primary Menu', 'blocks' ),
		// translators: Primary Navigation Menu with strong tag.
		'sub_desc' => sprintf( esc_html__( 'Use this button to enable %s.', 'blocks' ), '<strong>' . esc_html__( 'Primary Navigation Menu', 'blocks' ) . '</strong>' ),
		'std'      => '0',
	),

	array(
		'id'         => 'mts_top_bar_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Top Bar Background', 'blocks' ),
		'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'blocks' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'primary_navigation_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Primary Navigation', 'blocks' ),
		'std'        => array(
			'preview-text'  => 'Primary Navigation Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => 'normal',
			'font-size'     => '14px',
			'color'         => '#424c63',
			'css-selectors' => '#primary-navigation a, .header-layout2 .header-search span.sbutton',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'mts_top_header_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'blocks' ),
		'sub_desc'   => esc_html__( 'Select border.', 'blocks' ),
		'std'        => array(
			'direction' => 'bottom',
			'size'      => '1',
			'style'     => 'solid',
			'color'     => '#ecedf1',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_header_social',
		'title'      => esc_html__( 'Header Social Icons', 'blocks' ),
		'sub_desc'   => esc_html__( 'Add Social Media icons in header.', 'blocks' ),
		'type'       => 'group',
		'groupname'  => esc_html__( 'Header Icons', 'blocks' ), // Group name.
		'subfields'  => array(
			array(
				'id'    => 'top_header_icon_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'blocks' ),
			),
			array(
				'id'    => 'top_header_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Icon', 'blocks' ),
			),
			array(
				'id'    => 'top_header_icon_link',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'blocks' ),
			),
			array(
				'id'    => 'top_header_icon_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background color', 'blocks' ),
			),
			array(
				'id'    => 'top_header_icon_hover_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background hover color', 'blocks' ),
			),
			array(
				'id'    => 'top_header_icon_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon color', 'blocks' ),
			),
			array(
				'id'    => 'top_header_icon_hover_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon hover color', 'blocks' ),
			),
			array(
				'id'    => 'top_header_icon_margin',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Margin', 'blocks' ),
			),
			array(
				'id'    => 'top_header_icon_padding',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Padding', 'blocks' ),
			),
			array(
				'id'       => 'top_header_icon_border',
				'type'     => 'border',
				'title'    => esc_html__( 'Border', 'blocks' ),
				'sub_desc' => esc_html__( 'Select border.', 'blocks' ),
			),
			array(
				'id'    => 'top_header_icon_border_radius',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Header icon border radius', 'blocks' ),
				'args'  => array( 'type' => 'number' ),
			),
		),
		'std'        => array(
			'instagram' => array(
				'group_title'                   => 'Instagram',
				'group_sort'                    => '3',
				'top_header_icon_title'         => 'Instagram',
				'top_header_icon'               => 'instagram',
				'top_header_icon_link'          => '#',
				'top_header_icon_bgcolor'       => '',
				'top_header_icon_hover_bgcolor' => '',
				'top_header_icon_color'         => '#97a0af',
				'top_header_icon_hover_color'   => blocks_get_settings( 'mts_color_scheme' ),
				'top_header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '19px',
					'bottom' => '0',
					'left'   => '19px',
				),
				'top_header_icon_padding'       => array(
					'top'    => '15px',
					'right'  => '0',
					'bottom' => '15px',
					'left'   => '0',
				),
				'top_header_icon_border_radius' => '0',
				'top_header_icon_border'        => array(
					'direction' => 'all',
					'size'      => '0',
					'style'     => 'solid',
					'color'     => '#777',
				),
			),
			'facebook'  => array(
				'group_title'                   => 'Facebook',
				'group_sort'                    => '1',
				'top_header_icon_title'         => 'Facebook',
				'top_header_icon'               => 'facebook',
				'top_header_icon_link'          => '#',
				'top_header_icon_bgcolor'       => '',
				'top_header_icon_hover_bgcolor' => '',
				'top_header_icon_color'         => '#97a0af',
				'top_header_icon_hover_color'   => blocks_get_settings( 'mts_color_scheme' ),
				'top_header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '19px',
					'bottom' => '0',
					'left'   => '19px',
				),
				'top_header_icon_padding'       => array(
					'top'    => '15px',
					'right'  => '0',
					'bottom' => '15px',
					'left'   => '0',
				),
				'top_header_icon_border_radius' => '0',
				'top_header_icon_border_radius' => '0',
				'top_header_icon_border'        => array(
					'direction' => 'all',
					'size'      => '0',
					'style'     => 'solid',
					'color'     => '#777',
				),
			),
			'twitter'   => array(
				'group_title'                   => 'Twitter',
				'group_sort'                    => '2',
				'top_header_icon_title'         => 'Twitter',
				'top_header_icon'               => 'twitter',
				'top_header_icon_link'          => '#',
				'top_header_icon_bgcolor'       => '',
				'top_header_icon_hover_bgcolor' => '',
				'top_header_icon_color'         => '#97a0af',
				'top_header_icon_hover_color'   => blocks_get_settings( 'mts_color_scheme' ),
				'top_header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '19px',
					'bottom' => '0',
					'left'   => '19px',
				),
				'top_header_icon_padding'       => array(
					'top'    => '15px',
					'right'  => '0',
					'bottom' => '15px',
					'left'   => '0',
				),
				'top_header_icon_border_radius' => '0',
				'top_header_icon_border'        => array(
					'direction' => 'all',
					'size'      => '0',
					'style'     => 'solid',
					'color'     => '#777',
				),
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'mts_header_style',
				'value'      => 'header-layout2',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_header_search_box',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Header Search Form', 'blocks' ),
		'sub_desc'   => wp_kses( __( 'Use this button to Show or Hide the <strong>Header Search Form</strong> completely.', 'blocks' ), array( 'strong' => '' ) ),
		'std'        => '1',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'mts_header_style',
				'value'      => 'header-layout2',
				'comparison' => '==',
			),
		),
	),

);
