<?php
/**
 * Single Subscribe
 *
 * @package Blocks
 */

$menus['single-subscribe'] = array(
	'title' => esc_html__( 'Subscribe Box', 'blocks' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of Subscribe box in single posts page.', 'blocks' ),
);

$sections['single-subscribe'] = array(

	array(
		'id'    => 'single_subscribe_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Subscribe box Settings', 'blocks' ),
	),
	array(
		'id'       => 'single_subscribe_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Subscribe box Background', 'blocks' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image for subscribe box from here.', 'blocks' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#f7f8fa',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'single_subscribe_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Margin', 'blocks' ),
		'sub_desc' => esc_html__( 'Set Subscribe box margin from here.', 'blocks' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '40',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_subscribe_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'blocks' ),
		'sub_desc' => esc_html__( 'Set Subscribe box padding from here.', 'blocks' ),
		'std'      => array(
			'top'    => '50px',
			'right'  => '10%',
			'bottom' => '50px',
			'left'   => '10%',
		),
	),
	array(
		'id'       => 'single_subscribe_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'blocks' ),
		'sub_desc' => esc_html__( 'Subscribe box border radius.', 'blocks' ),
		'std'      => '0',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'single_subscribe_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'blocks' ),
		'sub_desc' => esc_html__( 'Select border', 'blocks' ),
	),
	array(
		'id'    => 'single_subscribe_title_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Subscribe box Title Settings', 'blocks' ),
	),
	array(
		'id'    => 'single_subscribe_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Subscribe Title Font', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Subscribe Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '700',
			'font-size'     => '28px',
			'color'         => '#091e42',
			'css-selectors' => '.single-subscribe .widget #wp-subscribe .title',
		),
	),
	array(
		'id'    => 'single_subscribe_text_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Subscribe box Text Settings', 'blocks' ),
	),
	array(
		'id'    => 'single_subscribe_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Subscribe Text Font', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Subscribe Text Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'color'         => '#505f79',
			'css-selectors' => '.single-subscribe .widget #wp-subscribe p.text, .single-subscribe .widget .wp-subscribe .wps-consent-wrapper label, .single-subscribe .widget .wp-subscribe-wrap .error, .single-subscribe .widget .wp-subscribe-wrap .thanks',
		),
	),
	array(
		'id'    => 'single_subscribe_input_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Subscribe box Input Settings', 'blocks' ),
	),
	array(
		'id'       => 'single_subscribe_input_background',
		'type'     => 'color',
		'title'    => esc_html__( 'Background Color', 'blocks' ),
		'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'blocks' ),
		'std'      => '#ffffff',
	),
	array(
		'id'       => 'single_subscribe_input_height',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Height', 'blocks' ),
		'sub_desc' => esc_html__( 'Subscribe box input fields height.', 'blocks' ),
		'std'      => '48',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'single_subscribe_input_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'blocks' ),
		'sub_desc' => esc_html__( 'Subscribe box input fields border radius.', 'blocks' ),
		'std'      => '4',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'single_subscribe_input_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'blocks' ),
		'sub_desc' => esc_html__( 'Select border', 'blocks' ),
	),
	array(
		'id'    => 'single_subscribe_input_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Subscribe Input Fields Font', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Subscribe Input Fields',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'color'         => '#505f79',
			'css-selectors' => '.single-subscribe .widget #wp-subscribe input.email-field, .single-subscribe .widget #wp-subscribe input.name-field',
		),
	),
	array(
		'id'    => 'single_subscribe_submit_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Subscribe box Submit Settings', 'blocks' ),
	),
	array(
		'id'       => 'single_subscribe_submit_backgroud',
		'type'     => 'color',
		'title'    => esc_html__( 'Background Color', 'blocks' ),
		'sub_desc' => esc_html__( 'Submit button background color', 'blocks' ),
		'std'      => blocks_get_settings( 'mts_color_scheme' ),
	),
	array(
		'id'       => 'single_subscribe_submit_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'blocks' ),
		'sub_desc' => esc_html__( 'Subscribe box submit button border radius.', 'blocks' ),
		'std'      => '4',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'single_subscribe_submit_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'blocks' ),
		'sub_desc' => esc_html__( 'Select border', 'blocks' ),
	),
	array(
		'id'       => 'single_subscribe_submit_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'blocks' ),
		'sub_desc' => esc_html__( 'Set subscribe submit button padding from here.', 'blocks' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'    => 'single_subscribe_submit_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Subscribe Submit Button Font', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Subscribe Submit Button',
			'preview-color' => 'dark',
			'font-family'   => 'Roboto',
			'font-weight'   => '500',
			'font-size'     => '18px',
			'color'         => '#ffffff',
			'css-selectors' => '.single-subscribe .widget #wp-subscribe input.submit',
		),
	),
	array(
		'id'    => 'single_subscribe_small_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Subscribe box small text Settings', 'blocks' ),
	),
	array(
		'id'    => 'single_subscribe_small_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Subscribe Small Text Font', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Subscribe Small Text',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '20px',
			'color'         => '#505f79',
			'css-selectors' => '.single-subscribe .widget .wp-subscribe-wrap p.footer-text',
		),
	),
);
