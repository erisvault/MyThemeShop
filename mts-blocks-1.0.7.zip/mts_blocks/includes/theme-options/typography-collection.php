<?php
/**
 * Typography tab
 *
 * @package Blocks
 */

$menus['typography-collection'] = array(
	'icon'       => 'fa-text-width',
	'title'      => esc_html__( 'Typography', 'blocks' ),
	'hide_title' => true,
);

$sections['typography-collection'] = array(

	array(
		'id'    => 'typography-collections',
		'type'  => 'typography_collections',
		'title' => esc_html__( 'Theme Typography', 'blocks' ),
		'desc'  => esc_html__( 'From here, you can control the fonts used on your site. You can choose from 17 standard font sets, or from the Google Fonts Library containing 800+ fonts.', 'blocks' ),
	),

	array(
		'id'    => 'blocks_logo',
		'type'  => 'typography',
		'title' => esc_html__( 'Logo Font', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Logo',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '700',
			'font-size'     => '38px',
			'color'         => '#091e42',
			'css-selectors' => '#logo a',
		),
	),

	array(
		'id'    => 'secondary_navigation_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Secondary Navigation', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Secondary Navigation Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => 'normal',
			'font-size'     => '16px',
			'color'         => '#091e42',
			'css-selectors' => '#secondary-navigation a, .header-default .header-search span.sbutton',
		),
	),

	array(
		'id'    => 'home_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Archive Post Titles', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Archive Article Title',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '500',
			'font-size'     => '26px',
			'line-height'   => '42px',
			'color'         => '#091e42',
			'css-selectors' => '.latestPost .title a',
		),
	),

	array(
		'id'    => 'single_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Single Post Title', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Single Article Title',
			'preview-color' => 'dark',
			'font-family'   => 'Roboto',
			'font-weight'   => '700',
			'font-size'     => '40px',
			'line-height'   => '1.5',
			'color'         => '#ffffff',
			'css-selectors' => '.single-title',
		),
	),

	array(
		'id'    => 'content_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Content Font', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Content Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '28px',
			'color'         => '#505f79',
			'css-selectors' => 'body',
		),
	),

	array(
		'id'    => 'sidebar_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Widget Title', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '700',
			'font-size'     => '20px',
			'line-height'   => '32px',
			'color'         => '#091e42',
			'css-selectors' => '#sidebar .widget h3.widget-title, .widget #wp-subscribe .title',
		),
	),

	array(
		'id'    => 'sidebar_url',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Links', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Links',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '500',
			'font-size'     => '16px',
			'line-height'   => '25px',
			'color'         => '#091e42',
			'css-selectors' => '.sidebar .widget a, .sidebar .widget li',
		),
	),
	array(
		'id'    => 'sidebar_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Font', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '14px',
			'line-height'   => '26px',
			'color'         => '#505f79',
			'css-selectors' => '#sidebar .widget p, #sidebar .widget .post-excerpt',
		),
	),

	array(
		'id'    => 'top_footer_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Widget Title', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Footer Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '500',
			'font-size'     => '16px',
			'color'         => '#091e42',
			'css-selectors' => '.footer-widgets h3, #site-footer .widget #wp-subscribe .title, .brands-title',
		),
	),

	array(
		'id'    => 'top_footer_link_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Link', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Footer Links',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '14px',
			'line-height'   => '1.6',
			'color'         => '#6c798f',
			'css-selectors' => '.f-widget a, .f-widget .wpt_widget_content a, .f-widget .wp_review_tab_widget_content a',
		),
	),

	array(
		'id'    => 'top_footer_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer font', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Footer Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '14px',
			'line-height'   => '1.6',
			'color'         => '#6c798f',
			'css-selectors' => '.footer-widgets, footer .widget .wpt_excerpt, footer .advanced-recent-posts p, footer .popular-posts p, footer .category-posts p',
		),
	),

	array(
		'id'    => 'top_footer_meta_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Meta font', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Footer Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '12px',
			'line-height'   => '1.6',
			'color'         => '#6c798f',
			'css-selectors' => 'footer .widget .post-info, footer .widget .post-info a, footer .widget .wpt_widget_content .wpt-postmeta, footer .wp_review_tab_widget_content .wp-review-tab-postmeta',
		),
	),

	array(
		'id'    => 'copyrights_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Copyrights Section', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'Copyrights Font',
			'preview-color' => 'dark',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '12px',
			'color'         => '#a8aaae',
			'css-selectors' => '#copyright-note',
		),
	),

	array(
		'id'    => 'h1_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H1 Heading in Content', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'H1 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '700',
			'font-size'     => '28px',
			'color'         => '#091e42',
			'css-selectors' => 'h1',
		),
	),

	array(
		'id'    => 'h2_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H2 Heading in Content', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'H2 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '700',
			'font-size'     => '24px',
			'color'         => '#091e42',
			'css-selectors' => 'h2',
		),
	),

	array(
		'id'    => 'h3_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H3 Heading in Content', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'H3 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '700',
			'font-size'     => '22px',
			'color'         => '#091e42',
			'css-selectors' => 'h3',
		),
	),

	array(
		'id'    => 'h4_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H4 Heading in Content', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'H4 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '700',
			'font-size'     => '20px',
			'color'         => '#091e42',
			'css-selectors' => 'h4',
		),
	),

	array(
		'id'    => 'h5_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H5 Heading in Content', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'H5 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '700',
			'font-size'     => '18px',
			'color'         => '#091e42',
			'css-selectors' => 'h5',
		),
	),

	array(
		'id'    => 'h6_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H6 Heading in Content', 'blocks' ),
		'std'   => array(
			'preview-text'  => 'H6 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '700',
			'font-size'     => '16px',
			'color'         => '#091e42',
			'css-selectors' => 'h6',
		),
	),

	array(
		'id'       => 'typography-subsets',
		'type'     => 'multi_checkbox',
		'title'    => esc_html__( 'Character sets', 'blocks' ),
		'sub_desc' => esc_html__( 'Choose the character sets you wish to include. Please note that not all sets are available for all fonts.', 'blocks' ),
		'options'  => array(
			'latin'        => esc_html__( 'Latin', 'blocks' ),
			'latin-ext'    => esc_html__( 'Latin Extended', 'blocks' ),
			'cyrillic'     => esc_html__( 'Cyrillic', 'blocks' ),
			'cyrillic-ext' => esc_html__( 'Cyrillic Extended', 'blocks' ),
			'greek'        => esc_html__( 'Greek', 'blocks' ),
			'greek-ext'    => esc_html__( 'Greek Extended', 'blocks' ),
			'vietnamese'   => esc_html__( 'Vietnamese', 'blocks' ),
			'khmer'        => esc_html__( 'Khmer', 'blocks' ),
			'devanagari'   => esc_html__( 'Devanagari', 'blocks' ),
		),
		'std'      => array( 'latin' ),
	),
);
