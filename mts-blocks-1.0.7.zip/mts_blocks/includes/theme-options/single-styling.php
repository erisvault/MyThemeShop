<?php
/**
 * Single Styling
 *
 * @package Blocks
 */

$menus['single-styling'] = array(
	'title' => esc_html__( 'Single Styling', 'blocks' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of your single posts page.', 'blocks' ),
);

$sections['single-styling'] = array(

	array(
		'id'    => 'single_title_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Single Titles Styling', 'blocks' ),
	),

	array(
		'id'       => 'single_title_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Single Page Title Background Color', 'blocks' ),
		'sub_desc' => esc_html__( 'Set Single Page Title( Comments & Comments form ) background color, pattern and image from here.', 'blocks' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'single_title_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Page Title Padding', 'blocks' ),
		'sub_desc' => esc_html__( 'Set single page title padding from here.', 'blocks' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_title_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'blocks' ),
		'sub_desc' => esc_html__( 'Select border', 'blocks' ),
	),
	array(
		'id'    => 'single_page_titles_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Section Title Typography', 'blocks' ),
		'std'   => array(
			'preview-text'   => 'Title Font',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '20px',
			'color'          => '#091e42',
			'additional-css' => 'text-align: center;',
			'css-selectors'  => '#respond h4, .total-comments',
		),
	),

	array(
		'id'    => 'mts_single_styling_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Single Styling', 'blocks' ),
	),

	array(
		'id'       => 'single_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Background', 'blocks' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image of Single, Page, and 404 Page from here.', 'blocks' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'mts_single_styling_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Margin', 'blocks' ),
		'sub_desc' => esc_html__( 'Set single post margin from here.', 'blocks' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '40px',
		),
	),
	array(
		'id'       => 'mts_single_styling_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Padding', 'blocks' ),
		'sub_desc' => esc_html__( 'Set single post padding from here.', 'blocks' ),
		'std'      => array(
			'left'   => '0',
			'top'    => '0',
			'right'  => '0',
			'bottom' => '20px',
		),
	),
	array(
		'id'       => 'single_styling_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'blocks' ),
		'sub_desc' => esc_html__( 'Select border', 'blocks' ),
	),
	array(
		'id'         => 'breadcrumb_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Breadcrumbs Font', 'blocks' ),
		'std'        => array(
			'preview-text'  => 'Breadcrumbs',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '500',
			'font-size'     => '16px',
			'color'         => '#091e42',
			'css-selectors' => '.breadcrumb, .rank-math-breadcrumb',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_category_post_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Single Category Font', 'blocks' ),
		'std'        => array(
			'preview-text'   => 'Single Category',
			'preview-color'  => 'dark',
			'font-family'    => 'Roboto',
			'font-weight'    => '400',
			'font-size'      => '16px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.thesinglecategory a',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_category_post',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'    => 'mts_single_meta_info_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Single Meta Info Font', 'blocks' ),
		'std'   => array(
			'preview-text'   => 'Post Font',
			'preview-color'  => 'dark',
			'font-family'    => 'Roboto',
			'font-weight'    => '400',
			'font-size'      => '12px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.single_post .post-info, .single_post .post-info a, .single-full-header .post-info, .single-full-header .post-info a',
		),
	),

);
