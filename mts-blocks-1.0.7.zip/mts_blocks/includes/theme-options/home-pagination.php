<?php
/**
 * HomePage Pagination
 *
 * @package Blocks
 */

$menus['home-pagination'] = array(
	'title' => esc_html__( 'Pagination', 'blocks' ),
	'desc'  => esc_html__( 'From here, you can control the elements of homepage pagination.', 'blocks' ),
);

$sections['home-pagination'] = array(

	array(
		'id'       => 'mts_pagenavigation_type',
		'type'     => 'radio',
		'title'    => esc_html__( 'Pagination Type', 'blocks' ),
		'sub_desc' => esc_html__( 'Select pagination type.', 'blocks' ),
		'options'  => array(
			'0' => esc_html__( 'Default (Next / Previous)', 'blocks' ),
			'1' => esc_html__( 'Numbered (1 2 3 4...)', 'blocks' ),
			'2' => esc_html__( 'AJAX (Load More Button)', 'blocks' ),
			'3' => esc_html__( 'AJAX (Auto Infinite Scroll)', 'blocks' ),
		),
		'std'      => '1',
	),

	array(
		'id'         => 'load_more_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Load More Alignment', 'blocks' ),
		'sub_desc'   => esc_html__( 'Choose the load more alignment from here.', 'blocks' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'blocks' ),
			'center' => esc_html__( 'Center', 'blocks' ),
			'right'  => esc_html__( 'Right', 'blocks' ),
			'full'   => esc_html__( 'Full Width', 'blocks' ),
		),
		'std'        => 'center',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'mts_pagenavigation_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination background color', 'blocks' ),
		'sub_desc'   => esc_html__( 'Select pagination background color.', 'blocks' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More background color', 'blocks' ),
		'sub_desc'   => esc_html__( 'Select background color for load more button.', 'blocks' ),
		'std'        => '#f3f4f6',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_hover_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination background hover color', 'blocks' ),
		'sub_desc'   => esc_html__( 'Select pagination background hover color.', 'blocks' ),
		'std'        => '#fafbfc',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_hover_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More background hover color', 'blocks' ),
		'sub_desc'   => esc_html__( 'Select background hover color for load more button.', 'blocks' ),
		'std'        => blocks_get_settings( 'mts_color_scheme' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination color', 'blocks' ),
		'sub_desc'   => esc_html__( 'Select pagination color.', 'blocks' ),
		'std'        => '#505f79',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More color', 'blocks' ),
		'sub_desc'   => esc_html__( 'Select color for load more button.', 'blocks' ),
		'std'        => '#091e42',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_hover_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination hover color', 'blocks' ),
		'sub_desc'   => esc_html__( 'Select pagination hover color.', 'blocks' ),
		'std'        => blocks_get_settings( 'mts_color_scheme' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_hover_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More hover color', 'blocks' ),
		'sub_desc'   => esc_html__( 'Select hover color for load more button.', 'blocks' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Pagination Margin', 'blocks' ),
		'sub_desc'   => esc_html__( 'Update pagination margin from here.', 'blocks' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '-5px',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Pagination Padding', 'blocks' ),
		'sub_desc'   => esc_html__( 'Update pagination padding from here.', 'blocks' ),
		'std'        => array(
			'top'    => '13px',
			'right'  => '16px',
			'bottom' => '12px',
			'left'   => '16px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Load More Margin', 'blocks' ),
		'sub_desc'   => esc_html__( 'Update margin for load more button from here.', 'blocks' ),
		'std'        => array(
			'top'    => '20px',
			'right'  => '0',
			'bottom' => '40px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'load_more_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Load More Padding', 'blocks' ),
		'sub_desc'   => esc_html__( 'Update padding for load more button from here.', 'blocks' ),
		'std'        => array(
			'top'    => '13px',
			'right'  => '35px',
			'bottom' => '13px',
			'left'   => '35px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_border_radius',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Pagination border radius', 'blocks' ),
		'sub_desc'   => esc_html__( 'Update pagination border radius in px.', 'blocks' ),
		'std'        => '4',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'pagenavigation_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'blocks' ),
		'sub_desc'   => esc_html__( 'Select border', 'blocks' ),
		'std'        => array(
			'direction' => 'all',
			'size'      => '1',
			'style'     => 'solid',
			'color'     => '#dfe1e6',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'blocks' ),
		'sub_desc'   => esc_html__( 'Select border', 'blocks' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),

);
