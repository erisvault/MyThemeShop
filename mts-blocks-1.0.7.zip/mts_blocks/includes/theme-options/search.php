<?php
/**
 * Search Tab
 *
 * @package Blocks
 */

$menus['search'] = array(
	'icon'  => 'fa fa-search',
	'title' => esc_html__( 'Search', 'blocks' ),
	'desc'  => esc_html__( 'Setting here apply to search pages.', 'blocks' ),
);

$sections['search'] = array(

	array(
		'id'       => 'search_content',
		'type'     => 'select',
		'title'    => esc_html__( 'Search Results Content', 'blocks' ),
		'sub_desc' => esc_html__( 'Controls the type of content that displays in search results.', 'blocks' ),
		'options'  => array(
			'all'          => esc_html__( 'All Post Types and Pages', 'blocks' ),
			'all-no-pages' => esc_html__( 'All Post Types without Pages', 'blocks' ),
			'pages'        => esc_html__( 'Only Pages', 'blocks' ),
			'posts'        => esc_html__( 'Only Blog Posts', 'blocks' ),
			'woocommerce'  => esc_html__( 'Only WooCommerce Products', 'blocks' ),
		),
		'std'      => 'posts_pages',
	),

	array(
		'id'       => 'search_results_per_page',
		'type'     => 'text',
		'title'    => esc_html__( 'Number of Search Results Per Page', 'blocks' ),
		'sub_desc' => esc_html__( 'Controls the number of search results per page.', 'blocks' ),
		'validate' => 'numeric',
		'std'      => '9',
		'class'    => 'small-text',
	),

	array(
		'id'       => 'search_position',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Search Form Position', 'blocks' ),
		'sub_desc' => esc_html__( 'Controls the position of the search bar on the search results page.', 'blocks' ),
		'options'  => array(
			'above' => esc_html__( 'Above Results', 'blocks' ),
			'below' => esc_html__( 'Below Results', 'blocks' ),
			'hide'  => esc_html__( 'Hide', 'blocks' ),
		),
		'std'      => 'above',
	),
);
