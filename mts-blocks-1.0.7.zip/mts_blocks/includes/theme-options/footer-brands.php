<?php
/**
 * Brands
 *
 * @package Blocks
 */

$menus['footer']['child']['footer-brands'] = array(
	'title' => esc_html__( 'Brands Section', 'blocks' ),
	'desc'  => esc_html__( 'From here, you can control the Brands Section.', 'blocks' ),
);

$sections['footer-brands'] = array(

	array(
		'id'       => 'footer_brands_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Brands Section', 'blocks' ),
		'sub_desc' => esc_html__( 'Enable or disable Brands Section with this option.', 'blocks' ),
		'std'      => '0',
	),

	array(
		'id'         => 'footer_brands_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Brands Section Alignment', 'blocks' ),
		'sub_desc'   => esc_html__( 'Choose alignment of Brands Section.', 'blocks' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'blocks' ),
			'center' => esc_html__( 'Center', 'blocks' ),
			'right'  => esc_html__( 'Right', 'blocks' ),
		),
		'std'        => 'center',
		'class'      => 'green',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'brands_section_title',
		'type'       => 'text',
		'title'      => esc_html__( 'Brands Title', 'blocks' ),
		'sub_desc'   => esc_html__( 'Enter brands title here.', 'blocks' ),
		'std'        => esc_html__( 'Our Brands:', 'blocks' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),

	),

	array(
		'id'         => 'footer_brands_items',
		'type'       => 'group',
		'title'      => esc_html__( 'Brands', 'blocks' ),
		'groupname'  => esc_html__( 'Brand', 'blocks' ), // Group name.
		'subfields'  => array(
			array(
				'id'       => 'brand_title',
				'type'     => 'text',
				'title'    => esc_html__( 'Title', 'blocks' ),
				'sub_desc' => esc_html__( 'The title will not be shown.', 'blocks' ),
			),
			array(
				'id'       => 'brand_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Image', 'blocks' ),
				'sub_desc' => esc_html__( 'Upload or select an image for brand', 'blocks' ),
			),
			array(
				'id'       => 'brand_url',
				'type'     => 'text',
				'title'    => esc_html__( 'Link', 'blocks' ),
				'sub_desc' => esc_html__( 'Insert a link URL of brand', 'blocks' ),
				'std'      => '#',
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'brands_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'blocks' ),
		'sub_desc'   => esc_html__( 'Brands Section margin.', 'blocks' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'brands_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'blocks' ),
		'sub_desc'   => esc_html__( 'Brands Section padding.', 'blocks' ),
		'std'        => array(
			'top'    => '30px',
			'right'  => '0',
			'bottom' => '27px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'brands_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'blocks' ),
		'sub_desc'   => esc_html__( 'Select border', 'blocks' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
);
