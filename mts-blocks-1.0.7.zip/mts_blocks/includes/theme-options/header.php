<?php
/**
 * Header Tab
 *
 * @package Blocks
 */

$menus['header'] = array(
	'icon'  => 'fa-header',
	'title' => esc_html__( 'Header', 'blocks' ),
);

$menus['header']['child']['header-general'] = array(
	'title' => esc_html__( 'General', 'blocks' ),
	'desc'  => esc_html__( 'From here, you can control the elements of header section.', 'blocks' ),
);

$sections['header-general'] = array(

	array(
		'id'       => 'mts_header_style',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Header Styling', 'blocks' ),
		'sub_desc' => wp_kses( __( 'Choose the <strong>Header design</strong> for your site.', 'blocks' ), array( 'strong' => '' ) ),
		'options'  => array(
			'header-default' => array( 'img' => $uri . 'headers/header-default.jpg' ),
			'header-layout2' => array( 'img' => $uri . 'headers/header-layout2.jpg' ),
		),
		'std'      => 'header-default',
	),

	array(
		'id'       => 'mts_sticky_nav',
		'type'     => 'switch',
		'title'    => esc_html__( 'Floating Navigation Menu', 'blocks' ),
		// translators: Floating Navigation Menu with strong tag.
		'sub_desc' => sprintf( esc_html__( 'Use this button to enable %s.', 'blocks' ), '<strong>' . esc_html__( 'Floating Navigation Menu', 'blocks' ) . '</strong>' ),
		'std'      => '0',
	),

	array(
		'id'       => 'mts_header_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Header Margin', 'blocks' ),
		'sub_desc' => esc_html__( 'Set header margin from here.', 'blocks' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '0',
		),
	),
	array(
		'id'       => 'mts_header_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Header Padding', 'blocks' ),
		'sub_desc' => esc_html__( 'Set header padding from here.', 'blocks' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '20px',
			'bottom' => '20px',
		),
	),

	array(
		'id'       => 'mts_header_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'blocks' ),
		'sub_desc' => esc_html__( 'Select border.', 'blocks' ),
	),

	array(
		'id'         => 'mts_header_social',
		'title'      => esc_html__( 'Header Social Icons', 'blocks' ),
		'sub_desc'   => esc_html__( 'Add Social Media icons in header.', 'blocks' ),
		'type'       => 'group',
		'groupname'  => esc_html__( 'Header Icons', 'blocks' ), // Group name.
		'subfields'  => array(
			array(
				'id'    => 'mts_header_icon_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'blocks' ),
			),
			array(
				'id'    => 'mts_header_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Icon', 'blocks' ),
			),
			array(
				'id'    => 'mts_header_icon_link',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'blocks' ),
			),
			array(
				'id'    => 'mts_header_icon_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background color', 'blocks' ),
			),
			array(
				'id'    => 'mts_header_icon_hover_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background hover color', 'blocks' ),
			),
			array(
				'id'    => 'mts_header_icon_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon color', 'blocks' ),
			),
			array(
				'id'    => 'mts_header_icon_hover_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon hover color', 'blocks' ),
			),
			array(
				'id'    => 'mts_header_icon_margin',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Margin', 'blocks' ),
			),
			array(
				'id'    => 'mts_header_icon_padding',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Padding', 'blocks' ),
			),
			array(
				'id'       => 'mts_header_icon_border',
				'type'     => 'border',
				'title'    => esc_html__( 'Border', 'blocks' ),
				'sub_desc' => esc_html__( 'Select border.', 'blocks' ),
			),
			array(
				'id'    => 'mts_header_icon_border_radius',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Header icon border radius', 'blocks' ),
				'args'  => array( 'type' => 'number' ),
			),
		),
		'std'        => array(
			'instagram' => array(
				'group_title'                   => 'Instagram',
				'group_sort'                    => '3',
				'mts_header_icon_title'         => 'Instagram',
				'mts_header_icon'               => 'instagram',
				'mts_header_icon_link'          => '#',
				'mts_header_icon_bgcolor'       => '',
				'mts_header_icon_hover_bgcolor' => '',
				'mts_header_icon_color'         => '#97a0af',
				'mts_header_icon_hover_color'   => blocks_get_settings( 'mts_color_scheme' ),
				'mts_header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '19px',
					'bottom' => '0',
					'left'   => '19px',
				),
				'mts_header_icon_padding'       => array(
					'top'    => '15px',
					'right'  => '0',
					'bottom' => '15px',
					'left'   => '0',
				),
				'mts_header_icon_border_radius' => '0',
				'mts_header_icon_border'        => array(
					'direction' => 'all',
					'size'      => '0',
					'style'     => 'solid',
					'color'     => '#777',
				),
			),
			'facebook'  => array(
				'group_title'                   => 'Facebook',
				'group_sort'                    => '1',
				'mts_header_icon_title'         => 'Facebook',
				'mts_header_icon'               => 'facebook',
				'mts_header_icon_link'          => '#',
				'mts_header_icon_bgcolor'       => '',
				'mts_header_icon_hover_bgcolor' => '',
				'mts_header_icon_color'         => '#97a0af',
				'mts_header_icon_hover_color'   => blocks_get_settings( 'mts_color_scheme' ),
				'mts_header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '19px',
					'bottom' => '0',
					'left'   => '19px',
				),
				'mts_header_icon_padding'       => array(
					'top'    => '15px',
					'right'  => '0',
					'bottom' => '15px',
					'left'   => '0',
				),
				'mts_header_icon_border_radius' => '0',
				'mts_header_icon_border_radius' => '0',
				'mts_header_icon_border'        => array(
					'direction' => 'all',
					'size'      => '0',
					'style'     => 'solid',
					'color'     => '#777',
				),
			),
			'twitter'   => array(
				'group_title'                   => 'Twitter',
				'group_sort'                    => '2',
				'mts_header_icon_title'         => 'Twitter',
				'mts_header_icon'               => 'twitter',
				'mts_header_icon_link'          => '#',
				'mts_header_icon_bgcolor'       => '',
				'mts_header_icon_hover_bgcolor' => '',
				'mts_header_icon_color'         => '#97a0af',
				'mts_header_icon_hover_color'   => blocks_get_settings( 'mts_color_scheme' ),
				'mts_header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '19px',
					'bottom' => '0',
					'left'   => '19px',
				),
				'mts_header_icon_padding'       => array(
					'top'    => '15px',
					'right'  => '0',
					'bottom' => '15px',
					'left'   => '0',
				),
				'mts_header_icon_border_radius' => '0',
				'mts_header_icon_border'        => array(
					'direction' => 'all',
					'size'      => '0',
					'style'     => 'solid',
					'color'     => '#777',
				),
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_header_style',
				'value'      => 'header-default',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'header_search_box',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Header Search Form', 'blocks' ),
		'sub_desc'   => wp_kses( __( 'Use this button to Show or Hide the <strong>Header Search Form</strong> completely.', 'blocks' ), array( 'strong' => '' ) ),
		'std'        => '1',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_header_style',
				'value'      => 'header-default',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_header_section2',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Logo', 'blocks' ),
		'sub_desc' => wp_kses( __( 'Use this button to Show or Hide the <strong>Logo</strong> completely.', 'blocks' ), array( 'strong' => '' ) ),
		'std'      => '1',
	),

	array(
		'id'       => 'mts_main_navigation_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Header Background', 'blocks' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'blocks' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'main_navigation_dropdown_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Color', 'blocks' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'blocks' ),
		'std'      => '#424c63',
	),
	array(
		'id'       => 'main_navigation_dropdown_hover_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Hover Color', 'blocks' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'blocks' ),
		'std'      => blocks_get_settings( 'mts_color_scheme' ),
	),

);
