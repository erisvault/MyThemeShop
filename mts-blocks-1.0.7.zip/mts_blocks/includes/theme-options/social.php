<?php
/**
 * Social Tab
 *
 * @package Blocks
 */

$menus['social'] = array(
	'icon'  => 'fa-users',
	'title' => esc_html__( 'Social Share', 'blocks' ),
	'desc'  => esc_html__( 'Enable or disable social sharing buttons on single posts using these buttons.', 'blocks' ),
);

$menus['social']['child']['social-general'] = array(
	'title' => esc_html__( 'General', 'blocks' ),
	'desc'  => esc_html__( 'From here, you can control the elements of social sharing buttons.', 'blocks' ),
);

$sections['social-general'] = array(

	array(
		'id'       => 'social_button_layout',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Social Sharing Buttons Layout', 'blocks' ),
		'sub_desc' => wp_kses( __( 'Choose default <strong>social sharing buttons</strong> layout or modern <strong>social sharing buttons</strong> layout for your site. ', 'blocks' ), array( 'strong' => array() ) ),
		'options'  => array(
			'default'       => array( 'img' => $uri . 'social/default.jpg' ),
			'rectwithname'  => array( 'img' => $uri . 'social/modern.jpg' ),
			'circwithname'  => array( 'img' => $uri . 'social/circwithname.jpg' ),
			'rectwithcount' => array( 'img' => $uri . 'social/rectwithcount.jpg' ),
			'standard'      => array( 'img' => $uri . 'social/standard.jpg' ),
			'circular'      => array( 'img' => $uri . 'social/circular.jpg' ),
		),
		'std'      => 'circular',
	),

	array(
		'id'       => 'mts_social_buttons_on_pages',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Social Sharing Buttons on Pages', 'blocks' ),
		'options'  => array(
			'0' => esc_html__( 'Off', 'blocks' ),
			'1' => esc_html__( 'On', 'blocks' ),
		),
		'sub_desc' => esc_html__( 'Enable the sharing buttons for pages too, not just posts.', 'blocks' ),
		'std'      => '0',
	),

	array(
		'id'       => 'mts_social_buttons',
		'type'     => 'layout',
		'title'    => esc_html__( 'Social Media Buttons', 'blocks' ),
		'sub_desc' => esc_html__( 'Organize how you want the social sharing buttons to appear on single posts', 'blocks' ),
		'options'  => array(
			'enabled'  => array(
				'facebookshare' => esc_html__( 'Facebook Share', 'blocks' ),
				'twitter'       => esc_html__( 'Twitter', 'blocks' ),
				'pinterest'     => esc_html__( 'Pinterest', 'blocks' ),
			),
			'disabled' => array(
				'facebook' => esc_html__( 'Facebook Like', 'blocks' ),
				'linkedin' => esc_html__( 'LinkedIn', 'blocks' ),
				'stumble'  => esc_html__( 'StumbleUpon', 'blocks' ),
				'reddit'   => esc_html__( 'Reddit', 'blocks' ),
			),
		),
		'std'      => array(
			'enabled'  => array(
				'facebookshare' => esc_html__( 'Facebook Share', 'blocks' ),
				'twitter'       => esc_html__( 'Twitter', 'blocks' ),
				'pinterest'     => esc_html__( 'Pinterest', 'blocks' ),
			),
			'disabled' => array(
				'facebook' => esc_html__( 'Facebook Like', 'blocks' ),
				'linkedin' => esc_html__( 'LinkedIn', 'blocks' ),
				'stumble'  => esc_html__( 'StumbleUpon', 'blocks' ),
				'reddit'   => esc_html__( 'Reddit', 'blocks' ),
			),
		),
	),

);
