<?php
// make sure to not include translations
$args['presets']['default'] = array(
	'title' => 'Default',
	'demo' => 'http://demo.mythemeshop.com/lifestyle/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/default/thumb.jpg',
	'menus' => array( 'primary' => 'Primary'), // menu location slug => Demo menu name
	'options' => array( 'show_on_front' => 'posts' ),
);

$args['presets']['beauty'] = array(
	'title' => 'Beauty',
	'demo' => 'http://demo.mythemeshop.com/lifestyle-beauty/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/beauty/thumb.jpg',
	'menus' => array( 'primary' => 'Primary'), // menu location slug => Demo menu name
	//'options' => array( 'show_on_front' => 'page', 'page_on_front' => '4' ), // To set static front page
);

$args['presets']['food'] = array(
	'title' => 'Food',
	'demo' => 'http://demo.mythemeshop.com/lifestyle-food/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/food/thumb.jpg',
	'menus' => array( 'primary' => 'Primary'), // menu location slug => Demo menu name
	//'options' => array( 'show_on_front' => 'page', 'page_on_front' => '4' ), // To set static front page
);

$args['presets']['travel'] = array(
	'title' => 'Travel',
	'demo' => 'http://demo.mythemeshop.com/lifestyle-travel/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/travel/thumb.jpg',
	'menus' => array( 'primary' => 'Primary'), // menu location slug => Demo menu name
	//'options' => array( 'show_on_front' => 'page', 'page_on_front' => '4' ), // To set static front page
);

global $mts_presets;
$mts_presets = $args['presets'];
