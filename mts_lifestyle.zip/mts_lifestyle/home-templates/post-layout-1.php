<?php $mts_options = get_option(MTS_THEME_NAME); ?>

<?php global $j, $post_info; ?>

<article class="latestPost excerpt <?php echo ($j % 3 == 0) ? 'last' : ''; ?>">
	<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>" class="post-image post-image-left" style="background-image: url('<?php if ( has_post_thumbnail() ) { echo get_the_post_thumbnail_url( get_the_ID(), 'lifestyle-grid' ); } else { echo get_template_directory_uri() . '/images/nothumb-lifestyle-grid.png'; } ?>');">
		<?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
	</a>
	<div class="article-content">
		<?php if( isset($post_info['author']) == '1' || isset($post_info['comment']) == '1' || isset($post_info['time']) == '1' || isset($post_info['category']) == '1' ) { ?>
			<div class="post-info">
				<?php if( isset($post_info['author']) == '1' ) { ?>
					<span class="theauthor"><span><?php the_author_posts_link(); ?></span></span>
				<?php }
				if( isset($post_info['comment']) == '1' ) { ?>
					<span class="thecomment"><?php comments_number();?></span>
				<?php }
				if( isset($post_info['time']) == '1' ) { ?>
					<span class="thetime date updated"><span><?php the_time( get_option( 'date_format' ) ); ?></span></span>
				<?php }
				if( isset($post_info['category']) == '1' ) { ?>
					<span class="thecategory"><?php mts_the_category(', ') ?></span>
				<?php } ?>
			</div>
		<?php } ?>
		<header>
			<h2 class="title front-view-title"><a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>"><?php the_title(); ?></a></h2>
		</header>
	</div>
</article>