<?php $mts_options = get_option(MTS_THEME_NAME); ?>

<?php if( isset( $mts_options['mts_instagram'] ) && $mts_options['mts_instagram'] == 1 ) : ?>
	<div class="instagram-feeds clearfix">
		<?php if( isset($mts_options['mts_instagram_title']) ) { ?>
			<h4 class="instagram-title">
				<i class="fa fa-instagram"></i><?php echo $mts_options['mts_instagram_title']; ?>
			</h4>
		<?php }
		mts_instagram($mts_options['mts_username'], 6); ?>
	</div>
<?php endif; ?>