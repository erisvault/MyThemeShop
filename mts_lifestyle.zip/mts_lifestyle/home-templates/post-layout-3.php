<?php $mts_options = get_option(MTS_THEME_NAME);
global $j, $post_info;

if( $j == 0 ) {
		$thumb = 'lifestyle-layout3full';
		$class = 'big-thumb';
	} else {
		$thumb = 'lifestyle-layout3';
} ?>
<article class="latestPost excerpt<?php echo isset($class) ? ' '.$class : '' ?><?php echo ($j % 2 == 0) ? ' last' : ''; ?>">
	<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>" class="post-image post-image-left">
		<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail($thumb,array('title' => '')); echo '</div>';
		if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
	</a>
	<div class="article-content">
		<header>
			<h2 class="title front-view-title"><a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>"><?php echo esc_html( mts_truncate( get_the_title(), 48, 'letters', '...' ) ); ?></a></h2>
		</header>
		<?php if( $j == 0 ) { ?>
			<div class="front-view-content">
				<?php echo mts_excerpt(35); ?>
			</div>
			<?php if( isset($post_info['author']) == '1' || isset($post_info['comment']) == '1' || isset($post_info['time']) == '1' || isset($post_info['category']) == '1' ) { ?>
				<div class="post-info">
					<?php if( isset($post_info['author']) == '1' ) { ?>
						<span class="theauthor"><span><?php the_author_posts_link(); ?></span></span>
					<?php }
					if( isset($post_info['comment']) == '1' ) { ?>
						<span class="thecomment"><?php comments_number();?></span>
					<?php }
					if( isset($post_info['time']) == '1' ) { ?>
						<span class="thetime date updated"><span><?php the_time( get_option( 'date_format' ) ); ?></span></span>
					<?php }
					if( isset($post_info['category']) == '1' ) { ?>
						<span class="thecategory"><?php mts_the_category(', ') ?></span>
					<?php } ?>
				</div>
			<?php } ?>
		<?php } ?>
	</div>
</article>