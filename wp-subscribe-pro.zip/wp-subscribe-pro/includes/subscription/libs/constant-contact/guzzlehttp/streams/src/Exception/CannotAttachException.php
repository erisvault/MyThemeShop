<?php
namespace GuzzleHttp\Stream\Exception;

class CannotAttachException extends \RuntimeException {}
