<?php

namespace MailerLiteApi\Exceptions;

use Exception;

class MailerLiteSdkException extends Exception {}