<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Reactor
 */

get_header(); ?>

	<div id="wrapper">

		<div class="container">

			<div class="<?php reactor_article_class(); ?>">

				<?php reactor_action( 'before_content' ); ?>

				<div id="content_box">
					<?php
					the_archive_title( '<h1 class="page-title">', '</h1>' );
					the_archive_description( '<div class="taxonomy-description">', '</div>' );

					$j = 0;
					if ( have_posts() ) {
						while ( have_posts() ) {
							the_post();
							reactor_blog_articles( 'default' );
						}
					}

					if ( 0 !== ++$j ) {
						reactor_pagination( reactor_get_settings( 'mts_pagenavigation_type' ) );
					}
					?>
				</div>

				<?php reactor_action( 'after_content' ); ?>

			</div>

			<?php get_sidebar(); ?>

		</div>

<?php
get_footer();
