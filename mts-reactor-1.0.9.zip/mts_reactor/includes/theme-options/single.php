<?php
/**
 * Single Tab
 *
 * @package Reactor
 */

$menus['single-general'] = array(
	'title' => esc_html__( 'General', 'reactor' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of your single posts page.', 'reactor' ),
);

$sections['single-general'] = array(

	array(
		'id'       => 'mts_show_featured',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Featured image', 'reactor' ),
		'sub_desc' => esc_html__( 'Enable/Disable the Featured images in the single post.', 'reactor' ),
		'std'      => '1',
	),
	array(
		'id'       => 'featured_image_size',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Header Size', 'reactor' ),
		'sub_desc' => esc_html__( 'Choose the featured image size', 'reactor' ),
		'options'  => array(
			'default' => esc_html__( 'Content Size', 'reactor' ),
			'full'    => esc_html__( 'Full Width', 'reactor' ),
		),
		'std'      => 'full',
	),
	array(
		'id'         => 'featured_image_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Header Image Margin', 'reactor' ),
		'sub_desc'   => esc_html__( 'Set header image margin from here.', 'reactor' ),
		'std'        => array(
			'top'    => '-35px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'featured_text_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Alignment', 'reactor' ),
		'sub_desc'   => esc_html__( 'Choose the featured image text alignment', 'reactor' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'reactor' ),
			'center' => esc_html__( 'Center', 'reactor' ),
			'right'  => esc_html__( 'Right', 'reactor' ),
		),
		'std'        => 'left',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'show_prev_next',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show preview and next article buttons', 'reactor' ),
		'sub_desc'   => esc_html__( 'Use this button to show or hide preview and next article buttons.', 'reactor' ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_single_post_layout',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Post Layout', 'reactor' ),
		'sub_desc' => esc_html__( 'Customize the look of single posts', 'reactor' ),
		'options'  => array(
			'enabled'  => array(
				'content' => array(
					'label'     => esc_html__( 'Post Content', 'reactor' ),
					'subfields' => array(),
				),
				'tags'    => array(
					'label'     => esc_html__( 'Tags', 'reactor' ),
					'subfields' => array(),
				),
				'author'  => array(
					'label'     => esc_html__( 'Author Box', 'reactor' ),
					'subfields' => array(),
				),
				'related' => array(
					'label'     => esc_html__( 'Related Posts', 'reactor' ),
					'subfields' => array(
						array(
							'id'       => 'related_post_title',
							'type'     => 'text',
							'title'    => esc_html__( 'Related Posts Title', 'reactor' ),
							'sub_desc' => esc_html__( 'Enter the title text to show in the related posts section.', 'reactor' ),
							'std'      => 'See More Posts',

						),
						array(
							'id'       => 'mts_related_posts_taxonomy',
							'type'     => 'switch',
							'title'    => esc_html__( 'Related Posts Taxonomy', 'reactor' ),
							'options'  => array(
								'tags'       => esc_html__( 'Tags', 'reactor' ),
								'categories' => esc_html__( 'Categories', 'reactor' ),
							),
							'class'    => 'green',
							'sub_desc' => esc_html__( 'Related Posts based on tags or categories.', 'reactor' ),
							'std'      => 'categories',
						),
					),
				),
			),
			'disabled' => array(
				'subscribe' => array(
					'label'     => esc_html__( 'Subscribe Box', 'reactor' ),
					'subfields' => array(),
				),
			),
		),
	),

	array(
		'id'       => 'single_meta_info',
		'type'     => 'multi_checkbox',
		'title'    => esc_html__( 'Single Post Meta Info', 'schema' ),
		'sub_desc' => esc_html__( 'Select single post meta info from here.', 'schema' ),
		'options'  => array(
			'author'   => esc_html__( 'Author Name', 'schema' ),
			'comment'  => esc_html__( 'Comments', 'schema' ),
			'time'     => esc_html__( 'Time/Date', 'schema' ),
			'category' => esc_html__( 'Category', 'schema' ),
		),
		'std'      => array(
			'author',
			'comment',
			'category',
		),
	),

	array(
		'id'       => 'mts_breadcrumb',
		'type'     => 'switch',
		'title'    => esc_html__( 'Breadcrumbs', 'reactor' ),
		'sub_desc' => esc_html__( 'Breadcrumbs are a great way to make your site more user-friendly. You can enable them by checking this box.', 'reactor' ),
		'std'      => '0',
	),

	array(
		'id'         => 'breadcrumb_icon',
		'type'       => 'icon_select',
		'title'      => esc_html__( 'Icon', 'reactor' ),
		'sub_desc'   => esc_html__( 'Select divider icons from here.', 'reactor' ),
		'std'        => 'angle-right',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'breadcrumb_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Breadcrumbs Font', 'reactor' ),
		'std'        => array(
			'preview-text'  => 'Breadcrumbs',
			'preview-color' => 'light',
			'font-family'   => 'Oswald',
			'font-weight'   => '500',
			'font-size'     => '18px',
			'color'         => '#2e2f36',
			'css-selectors' => '.breadcrumb, .rank-math-breadcrumb',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_author_comment',
		'type'     => 'switch',
		'title'    => esc_html__( 'Highlight Author Comment', 'reactor' ),
		'sub_desc' => esc_html__( 'Use this button to highlight author comments.', 'reactor' ),
		'std'      => '1',
	),

	array(
		'id'       => 'mts_comment_date',
		'type'     => 'switch',
		'title'    => esc_html__( 'Date in Comments', 'reactor' ),
		'sub_desc' => esc_html__( 'Use this button to show the date for comments.', 'reactor' ),
		'std'      => '1',
	),
);
