<?php
/**
 * WooCommerce Tab
 *
 * @package Reactor
 */

if ( ! reactor_is_woocommerce_active() ) {
	return;
}

$menus['woocommerce'] = array(
	'icon'  => 'fa-shopping-cart',
	'title' => esc_html__( 'Woocommerce', 'reactor' ),
	'desc'  => esc_html__( 'Setting here apply both for the archive and search pages.', 'reactor' ),
);

$sections['woocommerce'] = array(

	array(
		'id'       => 'woocommerce_shop_items',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'WooCommerce Number of Products per Page', 'reactor' ),
		'sub_desc' => esc_html__( 'Controls the number of products that display per page.', 'reactor' ),
		'args'     => array( 'type' => 'number' ),
		'std'      => '12',
	),

	array(
		'id'       => 'woocommerce_shop_page_columns',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'WooCommerce Number of Product Columns', 'reactor' ),
		'sub_desc' => esc_html__( 'Controls the number of columns for the main shop and archive pages.', 'reactor' ),
		'args'     => array( 'type' => 'number' ),
		'std'      => '3',
	),

	array(
		'id'       => 'woocommerce_related_items',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'WooCommerce Related/Up-Sell/Cross-Sell Product Number', 'reactor' ),
		'sub_desc' => esc_html__( 'Controls the number of products for the related and up-sell products on single posts and cross-sells on cart page.', 'reactor' ),
		'args'     => array( 'type' => 'number' ),
		'std'      => '3',
	),

	array(
		'id'       => 'woocommerce_related_columns',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'WooCommerce Related/Up-Sell/Cross-Sell Product Number of Columns', 'reactor' ),
		'sub_desc' => esc_html__( 'Controls the number of columns for the related and up-sell products on single posts and cross-sells on cart page.', 'reactor' ),
		'args'     => array( 'type' => 'number' ),
		'std'      => '4',
	),
);
