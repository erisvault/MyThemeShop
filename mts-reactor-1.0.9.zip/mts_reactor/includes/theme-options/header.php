<?php
/**
 * Header Tab
 *
 * @package Reactor
 */

$menus['header'] = array(
	'icon'  => 'fa-header',
	'title' => esc_html__( 'Header', 'reactor' ),
);

$menus['header']['child']['header-general'] = array(
	'title' => esc_html__( 'General', 'reactor' ),
	'desc'  => esc_html__( 'From here, you can control the elements of header section.', 'reactor' ),
);

$sections['header-general'] = array(

	array(
		'id'       => 'mts_header_style',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Header Styling', 'reactor' ),
		'sub_desc' => wp_kses( __( 'Choose the <strong>Header design</strong> for your site.', 'reactor' ), array( 'strong' => '' ) ),
		'options'  => array(
			'header-default' => array( 'img' => $uri . 'headers/header-default.jpg' ),
			'header-layout2' => array( 'img' => $uri . 'headers/header-layout2.jpg' ),
			'header-layout3' => array( 'img' => $uri . 'headers/header-layout3.jpg' ),
			'header-layout4' => array( 'img' => $uri . 'headers/header-layout4.jpg' ),
		),
		'std'      => 'header-layout4',
	),

	array(
		'id'       => 'mts_sticky_nav',
		'type'     => 'switch',
		'title'    => esc_html__( 'Floating Navigation Menu', 'reactor' ),
		// translators: Floating Navigation Menu with strong tag.
		'sub_desc' => sprintf( esc_html__( 'Use this button to enable %s.', 'reactor' ), '<strong>' . esc_html__( 'Floating Navigation Menu', 'reactor' ) . '</strong>' ),
		'std'      => '0',
	),

	array(
		'id'       => 'mts_header_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Header Margin', 'reactor' ),
		'sub_desc' => esc_html__( 'Set header margin from here.', 'reactor' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '0',
		),
	),
	array(
		'id'       => 'mts_header_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Header Padding', 'reactor' ),
		'sub_desc' => esc_html__( 'Set header padding from here.', 'reactor' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '11px',
			'bottom' => '0',
		),
	),

	array(
		'id'       => 'mts_header_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'reactor' ),
		'sub_desc' => esc_html__( 'Select border.', 'reactor' ),
	),

	array(
		'id'         => 'mts_header_social',
		'title'      => esc_html__( 'Header Social Icons', 'reactor' ),
		'sub_desc'   => esc_html__( 'Add Social Media icons in header.', 'reactor' ),
		'type'       => 'group',
		'groupname'  => esc_html__( 'Header Icons', 'reactor' ), // Group name.
		'subfields'  => array(
			array(
				'id'    => 'mts_header_icon_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'reactor' ),
			),
			array(
				'id'    => 'mts_header_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Icon', 'reactor' ),
			),
			array(
				'id'    => 'mts_header_icon_link',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'reactor' ),
			),
			array(
				'id'    => 'mts_header_icon_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background color', 'reactor' ),
			),
			array(
				'id'    => 'mts_header_icon_hover_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background hover color', 'reactor' ),
			),
			array(
				'id'    => 'mts_header_icon_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon color', 'reactor' ),
			),
			array(
				'id'    => 'mts_header_icon_hover_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon hover color', 'reactor' ),
			),
			array(
				'id'    => 'mts_header_icon_margin',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Margin', 'reactor' ),
			),
			array(
				'id'    => 'mts_header_icon_padding',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Padding', 'reactor' ),
			),
			array(
				'id'       => 'mts_header_icon_border',
				'type'     => 'border',
				'title'    => esc_html__( 'Border', 'reactor' ),
				'sub_desc' => esc_html__( 'Select border.', 'reactor' ),
			),
			array(
				'id'    => 'mts_header_icon_border_radius',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Header icon border radius', 'reactor' ),
				'args'  => array( 'type' => 'number' ),
			),
		),
		'std'        => array(
			'facebook'  => array(
				'group_title'                   => 'Facebook',
				'group_sort'                    => '1',
				'mts_header_icon_title'         => 'Facebook',
				'mts_header_icon'               => 'facebook-square',
				'mts_header_icon_link'          => '#',
				'mts_header_icon_bgcolor'       => '',
				'mts_header_icon_hover_bgcolor' => '',
				'mts_header_icon_color'         => '#2e2f36',
				'mts_header_icon_hover_color'   => reactor_get_settings( 'primary_color_scheme' ),
				'mts_header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '21px',
					'bottom' => '0',
					'left'   => '0',
				),
				'mts_header_icon_padding'       => array(
					'top'    => '12px',
					'right'  => '0',
					'bottom' => '10px',
					'left'   => '0',
				),
				'mts_header_icon_border_radius' => '0',
				'mts_header_icon_border_radius' => '0',
				'mts_header_icon_border'        => array(
					'direction' => 'all',
					'size'      => '0',
					'style'     => 'solid',
					'color'     => '#777',
				),
			),
			'instagram' => array(
				'group_title'                   => 'Instagram',
				'group_sort'                    => '2',
				'mts_header_icon_title'         => 'Instagram',
				'mts_header_icon'               => 'instagram',
				'mts_header_icon_link'          => '#',
				'mts_header_icon_bgcolor'       => '',
				'mts_header_icon_hover_bgcolor' => '',
				'mts_header_icon_color'         => '#2e2f36',
				'mts_header_icon_hover_color'   => reactor_get_settings( 'primary_color_scheme' ),
				'mts_header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '21px',
					'bottom' => '0',
					'left'   => '0',
				),
				'mts_header_icon_padding'       => array(
					'top'    => '12px',
					'right'  => '0',
					'bottom' => '10px',
					'left'   => '0',
				),
				'mts_header_icon_border_radius' => '0',
				'mts_header_icon_border'        => array(
					'direction' => 'all',
					'size'      => '0',
					'style'     => 'solid',
					'color'     => '#777',
				),
			),
			'twitter'   => array(
				'group_title'                   => 'Twitter',
				'group_sort'                    => '3',
				'mts_header_icon_title'         => 'Twitter',
				'mts_header_icon'               => 'twitter',
				'mts_header_icon_link'          => '#',
				'mts_header_icon_bgcolor'       => '',
				'mts_header_icon_hover_bgcolor' => '',
				'mts_header_icon_color'         => '#2e2f36',
				'mts_header_icon_hover_color'   => reactor_get_settings( 'primary_color_scheme' ),
				'mts_header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '21px',
					'bottom' => '0',
					'left'   => '0',
				),
				'mts_header_icon_padding'       => array(
					'top'    => '12px',
					'right'  => '0',
					'bottom' => '10px',
					'left'   => '0',
				),
				'mts_header_icon_border_radius' => '0',
				'mts_header_icon_border'        => array(
					'direction' => 'all',
					'size'      => '0',
					'style'     => 'solid',
					'color'     => '#777',
				),
			),
		),
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'mts_header_style',
				'value'      => 'header-layout3',
				'comparison' => '==',
			),
			array(
				'field'      => 'mts_header_style',
				'value'      => 'header-layout4',
				'comparison' => '==',
			),
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'mts_header_search',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Header Search Form', 'reactor' ),
		'sub_desc'   => wp_kses( __( 'Use this button to Show or Hide the <strong>Header Search Form</strong> completely.', 'reactor' ), array( 'strong' => '' ) ),
		'std'        => '1',
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'mts_header_style',
				'value'      => 'header-layout3',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'header_search_position',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Search Position from Top', 'schema' ),
		'sub_desc'   => esc_html__( 'Enter search position from top in px.', 'schema' ),
		'std'        => '83',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_header_style',
				'value'      => 'header-layout3',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_header_section2',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Logo', 'reactor' ),
		'sub_desc' => wp_kses( __( 'Use this button to Show or Hide the <strong>Logo</strong> completely.', 'reactor' ), array( 'strong' => '' ) ),
		'std'      => '1',
	),

	array(
		'id'         => 'mts_header_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Header Background', 'reactor' ),
		'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'         => 'mts_main_navigation_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Main Navigation Background', 'reactor' ),
		'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '#2e2f36',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'mts_header_style',
				'value'      => 'header-default',
				'comparison' => '==',
			),
			array(
				'field'      => 'mts_header_style',
				'value'      => 'header-layout4',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'       => 'main_navigation_dropdown_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Color', 'reactor' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'reactor' ),
		'std'      => '#2e2f36',
	),
	array(
		'id'       => 'main_navigation_dropdown_hover_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Hover Color', 'reactor' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'reactor' ),
		'std'      => '#ff8516',
	),

);
