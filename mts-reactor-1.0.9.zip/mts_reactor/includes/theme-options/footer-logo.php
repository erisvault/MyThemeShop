<?php
/**
 * Navigation
 *
 * @package Reactor
 */

$menus['footer']['child']['footer-logo'] = array(
	'title' => esc_html__( 'Footer Logo Section', 'reactor' ),
	'desc'  => esc_html__( 'From here, you can control footer logo and social icons.', 'reactor' ),
);

$sections['footer-logo'] = array(

	array(
		'id'       => 'footer_logo_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Footer Logo and Social icons', 'reactor' ),
		'sub_desc' => esc_html__( 'Enable or disable Footer Logo and Social icons with this option.', 'reactor' ),
		'std'      => '1',
	),

	array(
		'id'         => 'footer_logo',
		'type'       => 'upload',
		'title'      => esc_html__( 'Footer Logo', 'reactor' ),
		'sub_desc'   => esc_html__( 'Select an image file for your footer logo.', 'reactor' ),
		'return'     => 'id',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'    => 'footer_reactor_logo',
		'type'  => 'typography',
		'title' => esc_html__( 'Logo Font', 'reactor' ),
		'std'   => array(
			'preview-text'  => 'Logo',
			'preview-color' => 'dark',
			'font-family'   => 'Oswald',
			'font-weight'   => '700',
			'font-size'     => '38px',
			'color'         => '#ffffff',
			'css-selectors' => '.footer #logo a',
		),
	),

	array(
		'id'         => 'footer_social_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Social Icons', 'reactor' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_logo_social_icons',
		'type'       => 'switch',
		'title'      => esc_html__( 'Social Icons', 'reactor' ),
		'sub_desc'   => esc_html__( 'Enable or disable social icons with this option.', 'reactor' ),
		'std'        => '1',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_logo_social',
		'title'      => esc_html__( 'Footer Social Icons', 'reactor' ),
		'sub_desc'   => esc_html__( 'Add Social Media icons in footer logo section.', 'reactor' ),
		'type'       => 'group',
		'groupname'  => esc_html__( 'Social Icons', 'reactor' ), // Group name.
		'subfields'  => array(
			array(
				'id'    => 'footer_logo_social_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'reactor' ),
			),
			array(
				'id'    => 'footer_logo_social_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Icon', 'reactor' ),
			),
			array(
				'id'    => 'footer_logo_social_link',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'reactor' ),
			),
			array(
				'id'    => 'footer_logo_social_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Background color', 'reactor' ),
			),
			array(
				'id'    => 'footer_logo_social_hover_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Background hover color', 'reactor' ),
			),
			array(
				'id'    => 'footer_logo_social_color',
				'type'  => 'color',
				'title' => esc_html__( 'Icon color', 'reactor' ),
			),
			array(
				'id'    => 'footer_logo_social_hover_color',
				'type'  => 'color',
				'title' => esc_html__( 'Icon hover color', 'reactor' ),
			),
			array(
				'id'    => 'footer_logo_social_margin',
				'type'  => 'margin',
				'title' => esc_html__( 'Margin', 'reactor' ),
			),
			array(
				'id'    => 'footer_logo_social_padding',
				'type'  => 'margin',
				'title' => esc_html__( 'Padding', 'reactor' ),
			),
			array(
				'id'    => 'footer_logo_social_border_radius',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Border radius', 'reactor' ),
				'args'  => array( 'type' => 'number' ),
			),
			array(
				'id'    => 'footer_logo_social_border_size',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Border Size', 'reactor' ),
				'args'  => array( 'type' => 'number' ),
			),
			array(
				'id'      => 'footer_logo_social_border_style',
				'type'    => 'select',
				'title'   => esc_html__( 'Border Style', 'reactor' ),
				'options' => array(
					'none'   => esc_html__( 'None', 'reactor' ),
					'solid'  => esc_html__( 'Solid', 'reactor' ),
					'dotted' => esc_html__( 'Dotted', 'reactor' ),
					'dashed' => esc_html__( 'Dashed', 'reactor' ),
					'double' => esc_html__( 'Double', 'reactor' ),
					'groove' => esc_html__( 'Groove', 'reactor' ),
					'ridge'  => esc_html__( 'Ridge', 'reactor' ),
					'inset'  => esc_html__( 'Inset', 'reactor' ),
					'outset' => esc_html__( 'Outset', 'reactor' ),
				),
			),
			array(
				'id'    => 'footer_logo_social_border_color',
				'type'  => 'color',
				'title' => esc_html__( 'Border Color', 'reactor' ),
			),
		),
		'std'        => array(
			'facebook'  => array(
				'group_title'                      => 'Facebook',
				'group_sort'                       => '1',
				'footer_logo_social_title'         => 'Facebook',
				'footer_logo_social_icon'          => 'facebook-square',
				'footer_logo_social_link'          => '#',
				'footer_logo_social_bgcolor'       => '',
				'footer_logo_social_hover_bgcolor' => '',
				'footer_logo_social_color'         => reactor_get_settings( 'primary_color_scheme' ),
				'footer_logo_social_hover_color'   => '#ffffff',
				'footer_logo_social_margin'        => array(
					'top'    => '0',
					'right'  => '20px',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_border_radius' => '0',
				'footer_logo_social_border_size'   => '1',
				'footer_logo_social_border_style'  => 'none',
				'footer_logo_social_border_color'  => '#dddddd',
			),
			'twitter'   => array(
				'group_title'                      => 'Twitter',
				'group_sort'                       => '2',
				'footer_logo_social_title'         => 'Twitter',
				'footer_logo_social_icon'          => 'twitter',
				'footer_logo_social_link'          => '#',
				'footer_logo_social_bgcolor'       => '',
				'footer_logo_social_hover_bgcolor' => '',
				'footer_logo_social_color'         => reactor_get_settings( 'primary_color_scheme' ),
				'footer_logo_social_hover_color'   => '#ffffff',
				'footer_logo_social_margin'        => array(
					'top'    => '0',
					'right'  => '20px',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_border_radius' => '0',
				'footer_logo_social_border_size'   => '1',
				'footer_logo_social_border_style'  => 'none',
				'footer_logo_social_border_color'  => '#dddddd',
			),
			'instagram' => array(
				'group_title'                      => 'Instagram',
				'group_sort'                       => '3',
				'footer_logo_social_title'         => 'Instagram',
				'footer_logo_social_icon'          => 'instagram',
				'footer_logo_social_link'          => '#',
				'footer_logo_social_bgcolor'       => '',
				'footer_logo_social_hover_bgcolor' => '',
				'footer_logo_social_color'         => reactor_get_settings( 'primary_color_scheme' ),
				'footer_logo_social_hover_color'   => '#ffffff',
				'footer_logo_social_margin'        => array(
					'top'    => '0',
					'right'  => '20px',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_border_radius' => '0',
				'footer_logo_social_border_size'   => '1',
				'footer_logo_social_border_style'  => 'none',
				'footer_logo_social_border_color'  => '#dddddd',
			),
			'youtube'   => array(
				'group_title'                      => 'Youtube',
				'group_sort'                       => '4',
				'footer_logo_social_title'         => 'Youtube',
				'footer_logo_social_icon'          => 'youtube',
				'footer_logo_social_link'          => '#',
				'footer_logo_social_bgcolor'       => '',
				'footer_logo_social_hover_bgcolor' => '',
				'footer_logo_social_color'         => reactor_get_settings( 'primary_color_scheme' ),
				'footer_logo_social_hover_color'   => '#ffffff',
				'footer_logo_social_margin'        => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_border_radius' => '0',
				'footer_logo_social_border_size'   => '1',
				'footer_logo_social_border_style'  => 'none',
				'footer_logo_social_border_color'  => '#dddddd',
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_social_icons',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'footer_logo_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_logo_social_font_size',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Font Size', 'reactor' ),
		'sub_desc'   => esc_html__( 'Set font size of footer nav social icons in px.', 'reactor' ),
		'std'        => '18',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_social_icons',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'footer_logo_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

);
