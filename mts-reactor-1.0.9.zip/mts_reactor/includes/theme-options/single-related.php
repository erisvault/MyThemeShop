<?php
/**
 * Single Related Posts
 *
 * @package Reactor
 */

$menus['single-related'] = array(
	'title' => esc_html__( 'Related Posts', 'reactor' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of related posts in single posts page.', 'reactor' ),
);

$sections['single-related'] = array(

	array(
		'id'       => 'related_posts_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Related Posts Background', 'reactor' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'related_posts_layouts',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Related Posts Layouts', 'reactor' ),
		'sub_desc' => esc_html__( 'Choose the Related Posts layouts for your site.', 'reactor' ),
		'options'  => array(
			'default'  => array( 'img' => $uri . 'related/r1.jpg' ),
			'related2' => array( 'img' => $uri . 'related/r2.jpg' ),
			'related3' => array( 'img' => $uri . 'related/r3.jpg' ),
			'related4' => array( 'img' => $uri . 'related/r4.jpg' ),
			'related5' => array( 'img' => $uri . 'related/r5.jpg' ),
			'related6' => array( 'img' => $uri . 'related/r6.jpg' ),
		),
		'std'      => 'default',
	),

	array(
		'id'         => 'related_posts_grid',
		'type'       => 'select',
		'class'      => 'small',
		'title'      => esc_html__( 'Grid', 'reactor' ),
		'sub_desc'   => esc_html__( 'Select the number of grid for Related Posts.', 'reactor' ),
		'options'    => array(
			'grid2' => esc_html__( '2', 'reactor' ),
			'grid3' => esc_html__( '3', 'reactor' ),
			'grid4' => esc_html__( '4', 'reactor' ),
			'grid5' => esc_html__( '5', 'reactor' ),
			'grid6' => esc_html__( '6', 'reactor' ),
		),
		'std'        => 'grid2',
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'default',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_related_postsnum',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Number of related posts', 'reactor' ),
		'sub_desc' => esc_html__( 'Enter the number of posts to show in the related posts section.', 'reactor' ),
		'std'      => '4',
		'args'     => array(
			'type' => 'number',
		),
	),

	array(
		'id'         => 'related_posts_excerpt_length',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Excerpt Length', 'reactor' ),
		'sub_desc'   => esc_html__( 'Enter excerpt length for big post here.', 'reactor' ),
		'std'        => '15',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'related4',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'related_posts_image_position',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Image Position from Top', 'reactor' ),
		'sub_desc'   => esc_html__( 'Enter image position from top in px.', 'reactor' ),
		'std'        => '95',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'related4',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'related_posts_adcode',
		'type'       => 'ace_editor',
		'mode'       => 'html',
		'title'      => esc_html__( 'Related Posts Ad', 'reactor' ),
		'sub_desc'   => esc_html__( 'Paste your Adsense, BSA or other ad code here to show ads in Related Posts Area.', 'reactor' ),
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'related5',
				'comparison' => '==',
			),
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'related6',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'related_posts_position',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Related Posts Position', 'reactor' ),
		'sub_desc' => esc_html__( 'Choose the position for related posts, below content will be Full width', 'reactor' ),
		'options'  => array(
			'default' => esc_html__( 'Default', 'reactor' ),
			'full'    => esc_html__( 'Below Content', 'reactor' ),
		),
		'std'      => 'default',
	),

	array(
		'id'       => 'related_post_meta_info',
		'type'     => 'multi_checkbox',
		'title'    => esc_html__( 'Post Meta Info', 'reactor' ),
		'sub_desc' => esc_html__( 'Show or hide post meta info.', 'reactor' ),
		'options'  => array(
			'author'   => esc_html__( 'Author Name', 'reactor' ),
			'time'     => esc_html__( 'Time/Date', 'reactor' ),
			'category' => esc_html__( 'Category', 'reactor' ),
			'comment'  => esc_html__( 'Comments', 'reactor' ),
		),
		'std'      => array(),
	),

	array(
		'id'       => 'related_posts_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Margin', 'reactor' ),
		'sub_desc' => esc_html__( 'Set related posts margin from here.', 'reactor' ),
		'std'      => array(
			'top'    => '55px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'related_posts_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'reactor' ),
		'sub_desc' => esc_html__( 'Set related posts padding from here.', 'reactor' ),
		'std'      => array(
			'top'    => '58px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),

	array(
		'id'    => 'related_post_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Related Post Section Title Typography', 'reactor' ),
		'std'   => array(
			'preview-text'   => 'Related Post Section Title Typography',
			'preview-color'  => 'light',
			'font-family'    => 'Oswald',
			'font-weight'    => '500',
			'font-size'      => '32px',
			'color'          => '#2e2f36',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.related-posts h4',
		),
	),

	array(
		'id'         => 'related_big_posts_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Big Related Posts Title', 'reactor' ),
		'std'        => array(
			'preview-text'  => 'Big Related Posts Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Oswald',
			'font-weight'   => '500',
			'font-size'     => '28px',
			'line-height'   => '38px',
			'color'         => '#2e2f36',
			'css-selectors' => '.related-posts.related4 .latestPost.big .title a',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'related4',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'related_posts_excerpt_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Related Posts Excerpt', 'reactor' ),
		'std'        => array(
			'preview-text'  => 'Related Posts Excerpt Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '300',
			'font-size'     => '16px',
			'line-height'   => '25px',
			'color'         => '#70747a',
			'css-selectors' => '.related-posts .front-view-content',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'related4',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'    => 'related_posts_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Related Posts Title', 'reactor' ),
		'std'   => array(
			'preview-text'  => 'Related Posts Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '700',
			'font-size'     => '22px',
			'line-height'   => '30px',
			'color'         => '#2e2f36',
			'css-selectors' => '.related-posts .title a',
		),
	),
	array(
		'id'    => 'related_posts_meta_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Related Posts Meta Info', 'reactor' ),
		'std'   => array(
			'preview-text'  => 'Related Posts Meta Info Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '300',
			'font-size'     => '13px',
			'color'         => '#70747a',
			'css-selectors' => '.related-posts .post-info, .related-posts .post-info a',
		),
	),

	array(
		'id'    => 'related_posts_article_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Related Posts Articles', 'reactor' ),
	),

	array(
		'id'       => 'related_article_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Related Posts Background', 'reactor' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'related_article_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Articles Padding', 'reactor' ),
		'sub_desc' => esc_html__( 'Set related posts articles padding from here.', 'reactor' ),
		'std'      => array(
			'left'   => '0',
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
		),
	),

	array(
		'id'       => 'related_article_text_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Articles Text Padding', 'reactor' ),
		'sub_desc' => esc_html__( 'Set related posts articles text padding from here.', 'reactor' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),

);
