<?php
/**
 * HomePage Posts
 *
 * @package Reactor
 */

$features = reactor_get_settings( 'mts_featured_categories' );
if ( empty( $features ) ) {
	return;
}
foreach ( $features as $feature ) :
	$title        = isset( $feature['mts_featured_title'] ) ? $feature['mts_featured_title'] : 'No Title';
	$posts_layout = isset( $feature['mts_thumb_layout'] ) ? $feature['mts_thumb_layout'] : '';
	if ( 'layout-default' === $posts_layout ) {
		$posts_layout = 'default';
	}
	$unique_id = isset( $feature['unique_id'] ) ? $feature['unique_id'] : '';

	$menus[ 'homepage-' . $unique_id ] = array(
		'title' => $title,
		// translators: description.
		'desc'  => sprintf( wp_kses_post( __( 'From here, you can control the elements of %s', 'reactor' ) ), $title ),
	);

	$sections[ 'homepage-' . $unique_id ] = array(

		/**
		 * Layout Default Settings
		 *
		 * @package Reactor
		 */

		// Section Title.
		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'reactor' ),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'reactor' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'reactor' ),
			'std'      => '0',
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'reactor' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'reactor' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'reactor' ),
				'center' => esc_html__( 'Center', 'reactor' ),
				'right'  => esc_html__( 'Right', 'reactor' ),
				'full'   => esc_html__( 'Full Width', 'reactor' ),
			),
			'std'        => 'left',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => reactor_get_settings( 'primary_color_scheme' ),
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'post_title_shadow' . $unique_id,
			'type'       => 'switch',
			'title'      => esc_html__( 'Box Shadow', 'reactor' ),
			'sub_desc'   => esc_html__( 'Use this button to show or hide box shadow in post container.', 'reactor' ),
			'std'        => '1',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'reactor' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'reactor' ),
			'std'        => array(
				'top'    => '10px',
				'right'  => '50px',
				'bottom' => '10px',
				'left'   => '50px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'reactor' ),
			'sub_desc'   => esc_html__( 'Select border', 'reactor' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'reactor' ),
			'std'        => array(
				'preview-text'  => 'Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Oswald',
				'font-weight'   => '500',
				'font-size'     => '32px',
				'color'         => '#2e2f36',
				'css-selectors' => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Meta info.
		( 'default' === $posts_layout ) ? array(
			'id'    => 'post_meta_info_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Meta Info', 'reactor' ),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_home_headline_meta_info' . $unique_id,
			'type'     => 'layout2',
			// translators: title.
			'title'    => sprintf( wp_kses_post( __( '%s Meta Info', 'reactor' ) ), $title ),
			// translators: description.
			'sub_desc' => sprintf( wp_kses_post( __( 'Organize how you want the post meta info to appear on %s', 'reactor' ) ), $title ),
			'options'  => array(
				'enabled'  => array(
					'author' => array(
						'label'     => __( 'Author Name', 'reactor' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_author_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reactor' ),
							),
						),
					),
					'date'   => array(
						'label'     => esc_html__( 'Date', 'reactor' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_date_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reactor' ),
							),
						),
					),
				),
				'disabled' => array(
					'category' => array(
						'label'     => esc_html__( 'Categories', 'reactor' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_category_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reactor' ),
							),
						),
					),
					'comment'  => array(
						'label'     => esc_html__( 'Comment Count', 'reactor' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_comment_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reactor' ),
							),
						),
					),
				),
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'reactor' ),
			'sub_desc' => esc_html__( 'Post Meta Info margin.', 'reactor' ),
			'std'      => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '20px',
				'left'   => '0',
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'reactor' ),
			'sub_desc' => esc_html__( 'Post Meta Info padding.', 'reactor' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'    => 'meta_info_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Meta Info Typography', 'reactor' ),
			'std'   => array(
				'preview-text'  => 'Post Meta Info Font',
				'preview-color' => 'light',
				'font-family'   => 'Oswald',
				'font-weight'   => '300',
				'font-size'     => '16px',
				'color'         => '#70747a',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .post-info, .layout-' . $unique_id . ' .latestPost .post-info a',
			),
		) : null,
		// Post Container.
		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'reactor' ),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'reactor' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'reactor' ),
			'sub_desc' => esc_html__( 'Select border', 'reactor' ),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'reactor' ),
			'sub_desc' => esc_html__( 'Post margin.', 'reactor' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '0',
				'bottom' => '35px',
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'reactor' ),
			'sub_desc' => esc_html__( 'Post padding.', 'reactor' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_featured_category_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'reactor' ),
			'std'   => array(
				'preview-text'  => 'Post Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Oswald',
				'font-weight'   => '500',
				'font-size'     => '40px',
				'line-height'   => '46px',
				'color'         => '#2e2f36',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		) : null,

		/**
		 * Layout 1.
		 *
		 * @package Reactor
		 */

		// Section Title.
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'reactor' ),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'reactor' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'reactor' ),
			'std'      => '0',
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'reactor' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'reactor' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'reactor' ),
				'center' => esc_html__( 'Center', 'reactor' ),
				'right'  => esc_html__( 'Right', 'reactor' ),
				'full'   => esc_html__( 'Full Width', 'reactor' ),
			),
			'std'        => 'center',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => reactor_get_settings( 'primary_color_scheme' ),
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'post_title_shadow' . $unique_id,
			'type'       => 'switch',
			'title'      => esc_html__( 'Box Shadow', 'reactor' ),
			'sub_desc'   => esc_html__( 'Use this button to show or hide box shadow in post container.', 'reactor' ),
			'std'        => '1',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'reactor' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '40px',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'reactor' ),
			'std'        => array(
				'top'    => '10px',
				'right'  => '50px',
				'bottom' => '10px',
				'left'   => '50px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'reactor' ),
			'sub_desc'   => esc_html__( 'Select border', 'reactor' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'reactor' ),
			'std'        => array(
				'preview-text'  => 'Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Roboto',
				'font-weight'   => '700',
				'font-size'     => '26px',
				'color'         => '#2e2f36',
				'css-selectors' => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Meta info.
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'post_meta_info_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Meta Info', 'reactor' ),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_home_headline_meta_info' . $unique_id,
			'type'     => 'layout2',
			// translators: title.
			'title'    => sprintf( wp_kses_post( __( '%s Meta Info', 'reactor' ) ), $title ),
			// translators: description.
			'sub_desc' => sprintf( wp_kses_post( __( 'Organize how you want the post meta info to appear on %s', 'reactor' ) ), $title ),
			'options'  => array(
				'enabled'  => array(
					'date'   => array(
						'label'     => esc_html__( 'Date', 'reactor' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_date_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reactor' ),
							),
						),
					),
					'author' => array(
						'label'     => __( 'Author Name', 'reactor' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_author_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reactor' ),
							),
						),
					),
				),
				'disabled' => array(
					'category' => array(
						'label'     => esc_html__( 'Categories', 'reactor' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_category_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reactor' ),
							),
						),
					),
					'comment'  => array(
						'label'     => esc_html__( 'Comment Count', 'reactor' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_comment_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reactor' ),
							),
						),
					),
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'reactor' ),
			'sub_desc' => esc_html__( 'Post Meta Info margin.', 'reactor' ),
			'std'      => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'big_meta_info_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Big Post Meta Info Font', 'reactor' ),
			'std'   => array(
				'preview-text'   => 'Big Post Meta Info Font',
				'preview-color'  => 'dark',
				'font-family'    => 'Roboto',
				'font-weight'    => '400',
				'font-size'      => '16px',
				'color'          => '#ffffff',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost.big .post-info, .layout-' . $unique_id . ' .latestPost.big .post-info a',
			),
		) : null,

		// Post Container.
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'reactor' ),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'reactor' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'reactor' ),
			'sub_desc' => esc_html__( 'Select border', 'reactor' ),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'reactor' ),
			'sub_desc' => esc_html__( 'Post margin.', 'reactor' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '77',
				'bottom' => '0',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'reactor' ),
			'sub_desc' => esc_html__( 'Post padding.', 'reactor' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'big_post_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Big Post Title Font', 'reactor' ),
			'std'   => array(
				'preview-text'  => 'Big Post Title Font',
				'preview-color' => 'dark',
				'font-family'   => 'Oswald',
				'font-weight'   => '500',
				'font-size'     => '37px',
				'line-height'   => '48px',
				'color'         => '#ffffff',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost.big .title a',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'small_post_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Small Post Title Font', 'reactor' ),
			'std'   => array(
				'preview-text'  => 'Small Post Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Roboto',
				'font-weight'   => '700',
				'font-size'     => '22px',
				'line-height'   => '30px',
				'color'         => '#2e2f36',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost.small .title a',
			),
		) : null,

		/**
		 * Layout 2.
		 *
		 * @package Reactor
		 */

		// Section Title.
		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'reactor' ),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'reactor' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'reactor' ),
			'std'      => '1',
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'reactor' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'reactor' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'reactor' ),
				'center' => esc_html__( 'Center', 'reactor' ),
				'right'  => esc_html__( 'Right', 'reactor' ),
				'full'   => esc_html__( 'Full Width', 'reactor' ),
			),
			'std'        => 'center',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => reactor_get_settings( 'primary_color_scheme' ),
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'post_title_shadow' . $unique_id,
			'type'       => 'switch',
			'title'      => esc_html__( 'Box Shadow', 'reactor' ),
			'sub_desc'   => esc_html__( 'Use this button to show or hide box shadow in post container.', 'reactor' ),
			'std'        => '1',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'reactor' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '40px',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'reactor' ),
			'std'        => array(
				'top'    => '10px',
				'right'  => '50px',
				'bottom' => '10px',
				'left'   => '50px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'reactor' ),
			'sub_desc'   => esc_html__( 'Select border', 'reactor' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'reactor' ),
			'std'        => array(
				'preview-text'  => 'Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Roboto',
				'font-weight'   => '700',
				'font-size'     => '26px',
				'color'         => '#2e2f36',
				'css-selectors' => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Meta info.
		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'post_meta_info_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Meta Info', 'reactor' ),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'mts_home_headline_meta_info' . $unique_id,
			'type'     => 'layout2',
			// translators: title.
			'title'    => sprintf( wp_kses_post( __( '%s Meta Info', 'reactor' ) ), $title ),
			// translators: description.
			'sub_desc' => sprintf( wp_kses_post( __( 'Organize how you want the post meta info to appear on %s', 'reactor' ) ), $title ),
			'options'  => array(
				'enabled'  => array(
					'date'   => array(
						'label'     => esc_html__( 'Date', 'reactor' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_date_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reactor' ),
							),
						),
					),
					'author' => array(
						'label'     => __( 'Author Name', 'reactor' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_author_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reactor' ),
							),
						),
					),
				),
				'disabled' => array(
					'category' => array(
						'label'     => esc_html__( 'Categories', 'reactor' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_category_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reactor' ),
							),
						),
					),
					'comment'  => array(
						'label'     => esc_html__( 'Comment Count', 'reactor' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_comment_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reactor' ),
							),
						),
					),
				),
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'reactor' ),
			'sub_desc' => esc_html__( 'Post Meta Info margin.', 'reactor' ),
			'std'      => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'big_meta_info_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Meta Info Font', 'reactor' ),
			'std'   => array(
				'preview-text'   => 'Post Meta Info Font',
				'preview-color'  => 'dark',
				'font-family'    => 'Roboto',
				'font-weight'    => '400',
				'font-size'      => '16px',
				'color'          => '#ffffff',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .post-info, .layout-' . $unique_id . ' .latestPost .post-info a',
			),
		) : null,

		// Post Container.
		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'reactor' ),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'reactor' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'reactor' ),
			'sub_desc' => esc_html__( 'Select border', 'reactor' ),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'reactor' ),
			'sub_desc' => esc_html__( 'Post margin.', 'reactor' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '72',
				'bottom' => '0',
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'reactor' ),
			'sub_desc' => esc_html__( 'Post padding.', 'reactor' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'big_post_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'reactor' ),
			'std'   => array(
				'preview-text'  => 'Post Title Font',
				'preview-color' => 'dark',
				'font-family'   => 'Oswald',
				'font-weight'   => '500',
				'font-size'     => '37px',
				'line-height'   => '48px',
				'color'         => '#ffffff',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		) : null,

		/**
		 * Layout 3.
		 *
		 * @package Reactor
		 */

		// Section Title.
		( 'layout-3' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'reactor' ),
		) : null,

		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'reactor' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'reactor' ),
			'std'      => '1',
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'reactor' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'reactor' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'reactor' ),
				'center' => esc_html__( 'Center', 'reactor' ),
				'right'  => esc_html__( 'Right', 'reactor' ),
				'full'   => esc_html__( 'Full Width', 'reactor' ),
			),
			'std'        => 'center',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => reactor_get_settings( 'primary_color_scheme' ),
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'         => 'post_title_shadow' . $unique_id,
			'type'       => 'switch',
			'title'      => esc_html__( 'Box Shadow', 'reactor' ),
			'sub_desc'   => esc_html__( 'Use this button to show or hide box shadow in post container.', 'reactor' ),
			'std'        => '1',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'reactor' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '40px',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'reactor' ),
			'std'        => array(
				'top'    => '10px',
				'right'  => '50px',
				'bottom' => '10px',
				'left'   => '50px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'reactor' ),
			'sub_desc'   => esc_html__( 'Select border', 'reactor' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-3' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'reactor' ),
			'std'        => array(
				'preview-text'  => 'Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Roboto',
				'font-weight'   => '700',
				'font-size'     => '26px',
				'color'         => '#2e2f36',
				'css-selectors' => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Post Container.
		( 'layout-3' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'reactor' ),
		) : null,

		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'reactor' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'reactor' ),
			'sub_desc' => esc_html__( 'Select border', 'reactor' ),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'reactor' ),
			'sub_desc' => esc_html__( 'Post margin.', 'reactor' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '64',
				'bottom' => '0',
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'reactor' ),
			'sub_desc' => esc_html__( 'Post padding.', 'reactor' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'layout-3' === $posts_layout ) ? array(
			'id'    => 'small_post_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'reactor' ),
			'std'   => array(
				'preview-text'  => 'Post Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Roboto',
				'font-weight'   => '700',
				'font-size'     => '22px',
				'line-height'   => '30px',
				'color'         => '#2e2f36',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		) : null,

		/**
		 * Layout 4.
		 *
		 * @package Reactor
		 */

		// Section Title.
		( 'layout-4' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'reactor' ),
		) : null,

		( 'layout-4' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'reactor' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'reactor' ),
			'std'      => '1',
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'reactor' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'reactor' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'reactor' ),
				'center' => esc_html__( 'Center', 'reactor' ),
				'right'  => esc_html__( 'Right', 'reactor' ),
				'full'   => esc_html__( 'Full Width', 'reactor' ),
			),
			'std'        => 'center',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => reactor_get_settings( 'primary_color_scheme' ),
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'         => 'post_title_shadow' . $unique_id,
			'type'       => 'switch',
			'title'      => esc_html__( 'Box Shadow', 'reactor' ),
			'sub_desc'   => esc_html__( 'Use this button to show or hide box shadow in post container.', 'reactor' ),
			'std'        => '1',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'reactor' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '40px',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'reactor' ),
			'std'        => array(
				'top'    => '10px',
				'right'  => '50px',
				'bottom' => '10px',
				'left'   => '50px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'reactor' ),
			'sub_desc'   => esc_html__( 'Select border', 'reactor' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-4' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'reactor' ),
			'std'        => array(
				'preview-text'  => 'Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Roboto',
				'font-weight'   => '700',
				'font-size'     => '26px',
				'color'         => '#2e2f36',
				'css-selectors' => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Meta info.
		( 'layout-4' === $posts_layout ) ? array(
			'id'    => 'post_meta_info_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Meta Info', 'reactor' ),
		) : null,

		( 'layout-4' === $posts_layout ) ? array(
			'id'       => 'mts_home_headline_meta_info' . $unique_id,
			'type'     => 'layout2',
			// translators: title.
			'title'    => sprintf( wp_kses_post( __( '%s Meta Info', 'reactor' ) ), $title ),
			// translators: description.
			'sub_desc' => sprintf( wp_kses_post( __( 'Organize how you want the post meta info to appear on %s', 'reactor' ) ), $title ),
			'options'  => array(
				'enabled'  => array(
					'date'   => array(
						'label'     => esc_html__( 'Date', 'reactor' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_date_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reactor' ),
							),
						),
					),
					'author' => array(
						'label'     => __( 'Author Name', 'reactor' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_author_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reactor' ),
							),
						),
					),
				),
				'disabled' => array(
					'category' => array(
						'label'     => esc_html__( 'Categories', 'reactor' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_category_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reactor' ),
							),
						),
					),
					'comment'  => array(
						'label'     => esc_html__( 'Comment Count', 'reactor' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_comment_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'reactor' ),
							),
						),
					),
				),
			),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'reactor' ),
			'sub_desc' => esc_html__( 'Post Meta Info margin.', 'reactor' ),
			'std'      => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'    => 'big_meta_info_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Meta Info Font', 'reactor' ),
			'std'   => array(
				'preview-text'   => 'Post Meta Info Font',
				'preview-color'  => 'dark',
				'font-family'    => 'Roboto',
				'font-weight'    => '400',
				'font-size'      => '16px',
				'color'          => '#ffffff',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .post-info, .layout-' . $unique_id . ' .latestPost .post-info a',
			),
		) : null,

		// Post Container.
		( 'layout-4' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'reactor' ),
		) : null,

		( 'layout-4' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'reactor' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'reactor' ),
			'sub_desc' => esc_html__( 'Select border', 'reactor' ),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'reactor' ),
			'sub_desc' => esc_html__( 'Post margin.', 'reactor' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '60',
				'bottom' => '0',
			),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'reactor' ),
			'sub_desc' => esc_html__( 'Post padding.', 'reactor' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'layout-4' === $posts_layout ) ? array(
			'id'    => 'big_post_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Big Post Title Font', 'reactor' ),
			'std'   => array(
				'preview-text'  => 'Big Post Title Font',
				'preview-color' => 'dark',
				'font-family'   => 'Oswald',
				'font-weight'   => '500',
				'font-size'     => '37px',
				'line-height'   => '48px',
				'color'         => '#ffffff',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost.big .title a',
			),
		) : null,

		( 'layout-4' === $posts_layout ) ? array(
			'id'    => 'small_post_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Small Post Title Font', 'reactor' ),
			'std'   => array(
				'preview-text'  => 'Small Post Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Roboto',
				'font-weight'   => '700',
				'font-size'     => '22px',
				'line-height'   => '30px',
				'color'         => '#2e2f36',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost.small .title a',
			),
		) : null,

		/**
		 * Layout 5.
		 *
		 * @package Reactor
		 */

		// Section Title.
		( 'layout-5' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'reactor' ),
		) : null,

		( 'layout-5' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'reactor' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'reactor' ),
			'std'      => '1',
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'reactor' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'reactor' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'reactor' ),
				'center' => esc_html__( 'Center', 'reactor' ),
				'right'  => esc_html__( 'Right', 'reactor' ),
				'full'   => esc_html__( 'Full Width', 'reactor' ),
			),
			'std'        => 'center',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => reactor_get_settings( 'primary_color_scheme' ),
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'         => 'post_title_shadow' . $unique_id,
			'type'       => 'switch',
			'title'      => esc_html__( 'Box Shadow', 'reactor' ),
			'sub_desc'   => esc_html__( 'Use this button to show or hide box shadow in post container.', 'reactor' ),
			'std'        => '1',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'reactor' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '47px',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'reactor' ),
			'std'        => array(
				'top'    => '10px',
				'right'  => '50px',
				'bottom' => '10px',
				'left'   => '50px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'reactor' ),
			'sub_desc'   => esc_html__( 'Select border', 'reactor' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-5' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'reactor' ),
			'std'        => array(
				'preview-text'  => 'Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Roboto',
				'font-weight'   => '700',
				'font-size'     => '26px',
				'color'         => '#2e2f36',
				'css-selectors' => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Post Container.
		( 'layout-5' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'reactor' ),
		) : null,

		( 'layout-5' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'reactor' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'reactor' ),
			'sub_desc' => esc_html__( 'Select border', 'reactor' ),
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'reactor' ),
			'sub_desc' => esc_html__( 'Post margin.', 'reactor' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '50',
				'bottom' => '0',
			),
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'reactor' ),
			'sub_desc' => esc_html__( 'Post padding.', 'reactor' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'layout-5' === $posts_layout ) ? array(
			'id'    => 'small_post_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'reactor' ),
			'std'   => array(
				'preview-text'  => 'Post Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Roboto',
				'font-weight'   => '700',
				'font-size'     => '22px',
				'line-height'   => '30px',
				'color'         => '#2e2f36',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		) : null,

		/**
		 * Layout Partners.
		 *
		 * @package Reactor
		 */

		( 'layout-partners' === $posts_layout ) ? array(
			'id'        => 'partners_section_' . $unique_id,
			'type'      => 'group',
			'title'     => esc_html__( 'Partners Items', 'reactor' ),
			'groupname' => esc_html__( 'Partner Item', 'reactor' ),
			'subfields' => array(
				array(
					'id'    => 'partner_title',
					'type'  => 'text',
					'title' => esc_html__( 'Title', 'reactor' ),
				),
				array(
					'id'       => 'partner_image',
					'type'     => 'upload',
					'title'    => esc_html__( 'Image', 'reactor' ),
					'sub_desc' => esc_html__( 'Upload or select an image for partner. Recommended Size(190X70px)', 'reactor' ),
				),
				array(
					'id'       => 'partner_url',
					'type'     => 'text',
					'title'    => esc_html__( 'Link', 'reactor' ),
					'sub_desc' => esc_html__( 'Insert a link URL of partner', 'reactor' ),
					'std'      => '#',
				),
			),
		) : null,

		// Section Title.
		( 'layout-partners' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'reactor' ),
		) : null,

		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'reactor' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'reactor' ),
			'std'      => '1',
		) : null,

		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'partner_section_title_' . $unique_id,
			'type'       => 'text',
			'title'      => esc_html__( 'Section Title', 'reactor' ),
			'sub_desc'   => esc_html__( 'Partners section title.', 'reactor' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'partners_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Partners Title Font', 'reactor' ),
			'std'        => array(
				'preview-text'   => 'Partners Title Font',
				'preview-color'  => 'dark',
				'font-family'    => 'Oswald',
				'font-weight'    => '400',
				'font-size'      => '16px',
				'line-height'    => '19px',
				'color'          => '#2e2f36',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.article.layout-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'reactor' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'reactor' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'reactor' ),
				'center' => esc_html__( 'Center', 'reactor' ),
				'right'  => esc_html__( 'Right', 'reactor' ),
				'full'   => esc_html__( 'Full Width', 'reactor' ),
			),
			'std'        => 'full',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '#ffffff',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'post_title_shadow' . $unique_id,
			'type'       => 'switch',
			'title'      => esc_html__( 'Box Shadow', 'reactor' ),
			'sub_desc'   => esc_html__( 'Use this button to show or hide box shadow in post container.', 'reactor' ),
			'std'        => '1',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'reactor' ),
			'left'       => false,
			'right'      => false,
			'std'        => array(
				'top'    => '0',
				'bottom' => '-80px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'reactor' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'reactor' ),
			'std'        => array(
				'left'   => '40px',
				'top'    => '40px',
				'right'  => '40px',
				'bottom' => '40px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'reactor' ),
			'sub_desc'   => esc_html__( 'Select border', 'reactor' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Post Container.
		( 'layout-partners' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'reactor' ),
		) : null,

		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'reactor' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'reactor' ),
			'sub_desc' => esc_html__( 'Select border', 'reactor' ),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'reactor' ),
			'sub_desc' => esc_html__( 'Post margin.', 'reactor' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '0',
				'bottom' => '35px',
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'reactor' ),
			'sub_desc' => esc_html__( 'Post padding.', 'reactor' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		/**
		 * Layout Category.
		 *
		 * @package Reactor
		 */

		( 'layout-category' === $posts_layout ) ? array(
			'id'        => 'cat_section_' . $unique_id,
			'type'      => 'group',
			'title'     => esc_html__( 'Category items', 'reactor' ),
			'sub_desc'  => esc_html__( 'Add category Item from here', 'reactor' ),
			'groupname' => esc_html__( 'Category item', 'reactor' ),
			'subfields' => array(
				array(
					'id'    => 'cat_section_title',
					'type'  => 'text',
					'title' => esc_html__( 'Title', 'reactor' ),
				),
				array(
					'id'       => 'cat_section_category',
					'type'     => 'select',
					'title'    => esc_html__( 'Category', 'reactor' ),
					'sub_desc' => esc_html__( 'Select a category for this section', 'reactor' ),
					'data'     => 'category',
				),
				array(
					'id'       => 'cat_section_image',
					'type'     => 'upload',
					'title'    => esc_html__( 'Image', 'reactor' ),
					'sub_desc' => esc_html__( 'Upload or select an image for category. Recommended Size(365X287px)', 'reactor' ),
				),
				array(
					'id'    => 'cat_section_background',
					'type'  => 'color',
					'title' => esc_html__( 'Select overlay color for your category', 'reactor' ),
					'args'  => array( 'opacity' => true ),
					'std'   => 'rgba(0, 0, 0, 0.3)',
				),
				array(
					'id'    => 'cat_section_hover_background',
					'type'  => 'color',
					'title' => esc_html__( 'Select overlay hover color for your category', 'reactor' ),
					'args'  => array( 'opacity' => true ),
					'std'   => 'rgba(0, 0, 0, 0.6)',
				),
			),
		) : null,

		// Post Container.
		( 'layout-category' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'reactor' ),
		) : null,

		( 'layout-category' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'reactor' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-category' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'reactor' ),
			'sub_desc' => esc_html__( 'Select border', 'reactor' ),
		) : null,
		( 'layout-category' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'reactor' ),
			'sub_desc' => esc_html__( 'Post margin.', 'reactor' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '0',
				'bottom' => '35px',
			),
		) : null,
		( 'layout-category' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'reactor' ),
			'sub_desc' => esc_html__( 'Post padding.', 'reactor' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		/**
		 * Layout Subscribe.
		 *
		 * @package Reactor
		 */

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_size_' . $unique_id,
			'type'     => 'button_set',
			'title'    => esc_html__( 'Section Size', 'reactor' ),
			'sub_desc' => esc_html__( 'Select the size of subscribe widget.', 'reactor' ),
			'options'  => array(
				'full'      => esc_html__( 'Full', 'reactor' ),
				'container' => esc_html__( 'Container', 'reactor' ),
			),
			'std'      => 'full',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_alignment_' . $unique_id,
			'type'     => 'button_set',
			'title'    => esc_html__( 'Alignment', 'reactor' ),
			'sub_desc' => esc_html__( 'Alignment of subscribe widget content', 'reactor' ),
			'options'  => array(
				'left'   => esc_html__( 'Left', 'reactor' ),
				'center' => esc_html__( 'Center', 'reactor' ),
				'right'  => esc_html__( 'Right', 'reactor' ),
			),
			'std'      => 'center',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Title Typography', 'reactor' ),
			'std'   => array(
				'preview-text'  => 'Title Font',
				'preview-color' => 'dark',
				'font-family'   => 'Oswald',
				'font-weight'   => '500',
				'font-size'     => '36px',
				'color'         => '#ffffff',
				'css-selectors' => '.layout-' . $unique_id . ' .widget #wp-subscribe .title, .layout-' . $unique_id . ' .layout-subscribe .left-content h4',
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_input_background_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Input Fields Background Color', 'reactor' ),
			'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'reactor' ),
			'std'      => '#ffffff',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_input_size_' . $unique_id,
			'type'     => 'button_set',
			'title'    => esc_html__( 'Input Field Size', 'reactor' ),
			'sub_desc' => esc_html__( 'Select the size of input fields.', 'reactor' ),
			'options'  => array(
				'large' => esc_html__( 'Large', 'reactor' ),
				'small' => esc_html__( 'Small', 'reactor' ),
			),
			'std'      => 'large',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_input_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Input Fields Typography', 'reactor' ),
			'std'   => array(
				'preview-text'  => 'Input Fields Font',
				'preview-color' => 'dark',
				'font-family'   => 'Oswald',
				'font-weight'   => '400',
				'font-size'     => '18px',
				'color'         => '#2e2f36',
				'css-selectors' => '.layout-' . $unique_id . ' .layout-subscribe #wp-subscribe input.email-field, .layout-' . $unique_id . ' .layout-subscribe #wp-subscribe input.name-field',
			),
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_text_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Text Typography', 'reactor' ),
			'std'   => array(
				'preview-text'  => 'Text Font',
				'preview-color' => 'dark',
				'font-family'   => 'Oswald',
				'font-weight'   => '400',
				'font-size'     => '20px',
				'color'         => '#ffffff',
				'css-selectors' => '.layout-' . $unique_id . ' .layout-subscribe #wp-subscribe p.text, .layout-' . $unique_id . ' .subscribe-icons-container p, .layout-' . $unique_id . ' .layout-subscribe .left-content p',
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_small_text_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Small Text Typography', 'reactor' ),
			'std'   => array(
				'preview-text'  => 'Text Font',
				'preview-color' => 'dark',
				'font-family'   => 'Oswald',
				'font-weight'   => '300',
				'font-size'     => '13px',
				'color'         => '#ffffff',
				'css-selectors' => '.layout-' . $unique_id . ' .layout-subscribe #sidebar .wp-subscribe-wrap p.footer-text, .layout-' . $unique_id . ' .layout-subscribe #sidebar .widget .wp-subscribe .wps-consent-wrapper',
			),
		) : null,

		// Left Content.
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_left_content_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Subscribe Left Content', 'reactor' ),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_left_content_logo_' . $unique_id,
			'type'     => 'upload',
			'title'    => esc_html__( 'Left Content Logo', 'reactor' ),
			'sub_desc' => esc_html__( 'Select an image file for left content logo.', 'reactor' ),
			'return'   => 'url',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_left_content_title_' . $unique_id,
			'type'  => 'text',
			'title' => esc_html__( 'Left Content Title', 'reactor' ),
			'std'   => 'Know where to go!',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_left_content_text_' . $unique_id,
			'type'  => 'textarea',
			'title' => esc_html__( 'Left Content Text', 'reactor' ),
			'std'   => 'Sign up for our daily tips to make your best vacation.',
		) : null,

		// Social Icons.
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_icon_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Subscribe Social Icons', 'reactor' ),
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_social_icons_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Subscribe Social Icons', 'reactor' ),
			'sub_desc' => esc_html__( 'Enable or disable subscribe social icons with this option.', 'reactor' ),
			'std'      => '1',
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'         => 'subscribe_icon_title_' . $unique_id,
			'type'       => 'text',
			'title'      => esc_html__( 'Title', 'reactor' ),
			'sub_desc'   => esc_html__( 'Subscribe icon title.', 'reactor' ),
			'std'        => 'Follow Us',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'subscribe_social_icons_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'         => 'subscribe_social_' . $unique_id,
			'title'      => esc_html__( 'Footer Social Icons', 'reactor' ),
			'sub_desc'   => esc_html__( 'Add Social Media icons in footer nav section.', 'reactor' ),
			'type'       => 'group',
			'groupname'  => esc_html__( 'Social Icons', 'reactor' ), // Group name.
			'subfields'  => array(
				array(
					'id'    => 'subscribe_social_title',
					'type'  => 'text',
					'title' => esc_html__( 'Title', 'reactor' ),
				),
				array(
					'id'    => 'subscribe_social_icon',
					'type'  => 'icon_select',
					'title' => esc_html__( 'Icon', 'reactor' ),
				),
				array(
					'id'    => 'subscribe_social_link',
					'type'  => 'text',
					'title' => esc_html__( 'URL', 'reactor' ),
				),
				array(
					'id'    => 'subscribe_social_color',
					'type'  => 'color',
					'title' => esc_html__( 'Icon color', 'reactor' ),
				),
				array(
					'id'    => 'subscribe_social_hover_color',
					'type'  => 'color',
					'title' => esc_html__( 'Icon hover color', 'reactor' ),
				),
				array(
					'id'    => 'subscribe_social_margin',
					'type'  => 'margin',
					'title' => esc_html__( 'Margin', 'reactor' ),
				),
				array(
					'id'    => 'subscribe_social_padding',
					'type'  => 'margin',
					'title' => esc_html__( 'Padding', 'reactor' ),
				),
			),
			'std'        => array(
				'facebook'  => array(
					'group_title'                  => 'Facebook',
					'group_sort'                   => '1',
					'subscribe_social_title'       => 'Facebook',
					'subscribe_social_icon'        => 'facebook-square',
					'subscribe_social_link'        => '#',
					'subscribe_social_color'       => '#ffffff',
					'subscribe_social_hover_color' => reactor_get_settings( 'primary_color_scheme' ),
					'subscribe_social_margin'      => array(
						'top'    => '0',
						'right'  => '22px',
						'bottom' => '0',
						'left'   => '0',
					),
					'subscribe_social_padding'     => array(
						'top'    => '0',
						'right'  => '0',
						'bottom' => '0',
						'left'   => '0',
					),
				),
				'youtube'   => array(
					'group_title'                  => 'Youtube',
					'group_sort'                   => '1',
					'subscribe_social_title'       => 'Youtube',
					'subscribe_social_icon'        => 'youtube',
					'subscribe_social_link'        => '#',
					'subscribe_social_color'       => '#ffffff',
					'subscribe_social_hover_color' => reactor_get_settings( 'primary_color_scheme' ),
					'subscribe_social_margin'      => array(
						'top'    => '0',
						'right'  => '22px',
						'bottom' => '0',
						'left'   => '0',
					),
					'subscribe_social_padding'     => array(
						'top'    => '0',
						'right'  => '0',
						'bottom' => '0',
						'left'   => '0',
					),
				),
				'twitter'   => array(
					'group_title'                  => 'Twitter',
					'group_sort'                   => '3',
					'subscribe_social_title'       => 'Twitter',
					'subscribe_social_icon'        => 'twitter',
					'subscribe_social_link'        => '#',
					'subscribe_social_color'       => '#ffffff',
					'subscribe_social_hover_color' => reactor_get_settings( 'primary_color_scheme' ),
					'subscribe_social_margin'      => array(
						'top'    => '0',
						'right'  => '22px',
						'bottom' => '0',
						'left'   => '0',
					),
					'subscribe_social_padding'     => array(
						'top'    => '0',
						'right'  => '0',
						'bottom' => '0',
						'left'   => '0',
					),
				),
				'pinterest' => array(
					'group_title'                  => 'Pinterest',
					'group_sort'                   => '4',
					'subscribe_social_title'       => 'Pinterest',
					'subscribe_social_icon'        => 'pinterest',
					'subscribe_social_link'        => '#',
					'subscribe_social_color'       => '#ffffff',
					'subscribe_social_hover_color' => reactor_get_settings( 'primary_color_scheme' ),
					'subscribe_social_margin'      => array(
						'top'    => '0',
						'right'  => '22px',
						'bottom' => '0',
						'left'   => '0',
					),
					'subscribe_social_padding'     => array(
						'top'    => '0',
						'right'  => '0',
						'bottom' => '0',
						'left'   => '0',
					),
				),
				'instagram' => array(
					'group_title'                  => 'Instagram',
					'group_sort'                   => '5',
					'subscribe_social_title'       => 'Instagram',
					'subscribe_social_icon'        => 'instagram',
					'subscribe_social_link'        => '#',
					'subscribe_social_color'       => '#ffffff',
					'subscribe_social_hover_color' => reactor_get_settings( 'primary_color_scheme' ),
					'subscribe_social_margin'      => array(
						'top'    => '0',
						'right'  => '0',
						'bottom' => '0',
						'left'   => '0',
					),
					'subscribe_social_padding'     => array(
						'top'    => '0',
						'right'  => '0',
						'bottom' => '0',
						'left'   => '0',
					),
				),
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'subscribe_social_icons_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Post Container.
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'reactor' ),
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'reactor' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '#2e4257',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'reactor' ),
			'sub_desc' => esc_html__( 'Select border', 'reactor' ),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'reactor' ),
			'sub_desc' => esc_html__( 'Post margin.', 'reactor' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '0',
				'bottom' => '0',
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'reactor' ),
			'sub_desc' => esc_html__( 'Post padding.', 'reactor' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '55px',
				'right'  => '0',
				'bottom' => '15px',
			),
		) : null,

		/**
		 * Layout Ad.
		 *
		 * @package Reactor
		 */

		( 'layout-banner' === $posts_layout ) ? array(
			'id'       => 'adcode_' . $unique_id,
			'type'     => 'ace_editor',
			'mode'     => 'html',
			'title'    => esc_html__( 'Ad Code', 'reactor' ),
			'sub_desc' => esc_html__( 'Paste your Adsense, BSA or other ad code here to show ads.', 'reactor' ),
		) : null,

		// Post Container.
		( 'layout-banner' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'reactor' ),
		) : null,

		( 'layout-banner' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'reactor' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-banner' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'reactor' ),
			'sub_desc' => esc_html__( 'Select border', 'reactor' ),
		) : null,
		( 'layout-banner' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'reactor' ),
			'sub_desc' => esc_html__( 'Post margin.', 'reactor' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '40px',
				'bottom' => '0',
			),
		) : null,
		( 'layout-banner' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'reactor' ),
			'sub_desc' => esc_html__( 'Post padding.', 'reactor' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

	);
endforeach;
