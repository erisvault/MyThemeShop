<?php
/**
 * Navigation
 *
 * @package Reactor
 */

$menus['footer']['child']['footer-nav'] = array(
	'title' => esc_html__( 'Navigation Section', 'reactor' ),
	'desc'  => esc_html__( 'From here, you can control the Navigation Section.', 'reactor' ),
);

$sections['footer-nav'] = array(

	array(
		'id'       => 'footer_nav_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Navigation Section', 'reactor' ),
		'sub_desc' => esc_html__( 'Enable or disable Navigation Section with this option.', 'reactor' ),
		'std'      => '0',
	),

	array(
		'id'         => 'footer_nav_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Navigation Section Alignment', 'reactor' ),
		'sub_desc'   => esc_html__( 'Choose alignment of Navigation Section.', 'reactor' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'reactor' ),
			'center' => esc_html__( 'Center', 'reactor' ),
			'right'  => esc_html__( 'Right', 'reactor' ),
		),
		'std'        => 'left',
		'class'      => 'green',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_nav_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'reactor' ),
		'sub_desc'   => esc_html__( 'Navigation Section margin.', 'reactor' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '62px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'reactor' ),
		'sub_desc'   => esc_html__( 'Navigation Section padding.', 'reactor' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'reactor' ),
		'sub_desc'   => esc_html__( 'Select border', 'reactor' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_nav_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Footer Navigation', 'reactor' ),
		'std'        => array(
			'preview-text'   => 'Footer Navigation Font',
			'preview-color'  => 'dark',
			'font-family'    => 'Oswald',
			'font-weight'    => '500',
			'font-size'      => '16px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.footer-nav li a',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_menu_item_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Nav Menu items', 'reactor' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_menu_item_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Menu Items Margin', 'reactor' ),
		'sub_desc'   => esc_html__( 'Navigation Section menu item margin.', 'reactor' ),
		'top'        => false,
		'bottom'     => false,
		'std'        => array(
			'right' => '28px',
			'left'  => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_separator',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Nav Separator', 'reactor' ),
		'sub_desc'   => esc_html__( 'Enable or disable nav separator with this option.', 'reactor' ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_separator_content',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Separator', 'reactor' ),
		'sub_desc'   => esc_html__( 'Use any separator, ex: "-" "/" "|" "." ">"', 'reactor' ),
		'std'        => '|',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_separator',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_separator_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Separator Color', 'reactor' ),
		'sub_desc'   => esc_html__( 'Set nav separator color from here.', 'reactor' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_separator',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_separator_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Separator Margin', 'reactor' ),
		'sub_desc'   => esc_html__( 'Nav Separator margin.', 'reactor' ),
		'top'        => false,
		'bottom'     => false,
		'std'        => array(
			'right' => '25px',
			'left'  => '25px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_separator',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

);
