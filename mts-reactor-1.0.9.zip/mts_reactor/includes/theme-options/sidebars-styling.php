<?php
/**
 * Sidebars Styling
 *
 * @package Reactor
 */

$menus['sidebars-styling'] = array(
	'title' => esc_html__( 'Styling', 'reactor' ),
	'desc'  => esc_html__( 'From here, you can control the styling of sidebars.', 'reactor' ),
);

$sections['sidebars-styling'] = array(

	array(
		'id'    => 'mts_sidebar_title_styling_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Title Styling', 'reactor' ),
	),

	array(
		'id'       => 'mts_sidebar_title_styling_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Sidebar Title Styling Background', 'reactor' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => reactor_get_settings( 'primary_color_scheme' ),
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'mts_sidebar_title_styling_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Sidebar Title Margin', 'reactor' ),
		'sub_desc' => esc_html__( 'Set sidebar title margin from here.', 'reactor' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '25px',
		),
	),
	array(
		'id'       => 'mts_sidebar_title_styling_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Sidebar Title Padding', 'reactor' ),
		'sub_desc' => esc_html__( 'Set sidebar title padding from here.', 'reactor' ),
		'std'      => array(
			'top'    => '7px',
			'right'  => '25px',
			'bottom' => '8px',
			'left'   => '25px',
		),
	),
	array(
		'id'       => 'widget_title_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'reactor' ),
		'sub_desc' => esc_html__( 'Select border.', 'reactor' ),
	),

	array(
		'id'    => 'mts_sidebar_styling_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Sidebar Styling', 'reactor' ),
	),

	array(
		'id'       => 'mts_sidebar_styling_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Sidebar Styling Background', 'reactor' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'reactor' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'mts_sidebar_styling_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Sidebar Margin', 'reactor' ),
		'sub_desc' => esc_html__( 'Set sidebar margin from here.', 'reactor' ),
		'std'      => array(
			'left'   => '0',
			'top'    => '0',
			'right'  => '0',
			'bottom' => '72px',
		),
	),
	array(
		'id'       => 'mts_sidebar_styling_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Sidebar Padding', 'reactor' ),
		'sub_desc' => esc_html__( 'Set sidebar padding from here.', 'reactor' ),
		'std'      => array(
			'left'   => '0',
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
		),
	),
	array(
		'id'       => 'sidebar_styling_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'reactor' ),
		'sub_desc' => esc_html__( 'Select border', 'reactor' ),
	),

);
