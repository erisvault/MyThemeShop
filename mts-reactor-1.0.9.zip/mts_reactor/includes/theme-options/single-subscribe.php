<?php
/**
 * Single Subscribe
 *
 * @package Reactor
 */

$menus['single-subscribe'] = array(
	'title' => esc_html__( 'Subscribe Box', 'reactor' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of Subscribe box in single posts page.', 'reactor' ),
);

$sections['single-subscribe'] = array(

	array(
		'id'       => 'single_subscribe_box',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Subscribe box', 'reactor' ),
		'sub_desc' => esc_html__( 'Enable/Disable Subscribe box in the single post.', 'reactor' ),
		'std'      => '0',
	),
	array(
		'id'         => 'single_subscribe_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Subscribe box Settings', 'reactor' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Subscribe box Background', 'reactor' ),
		'sub_desc'   => esc_html__( 'Set background color, pattern and image for subscribe box from here.', 'reactor' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '#2e2f36',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'reactor' ),
		'sub_desc'   => esc_html__( 'Set Subscribe box margin from here.', 'reactor' ),
		'std'        => array(
			'top'    => '65px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'reactor' ),
		'sub_desc'   => esc_html__( 'Set Subscribe box padding from here.', 'reactor' ),
		'std'        => array(
			'top'    => '35px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_border_radius',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Border Radius', 'reactor' ),
		'sub_desc'   => esc_html__( 'Subscribe box border radius.', 'reactor' ),
		'std'        => '0',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'single_subscribe_title_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Subscribe box Title Settings', 'reactor' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_title_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Subscribe Title Font', 'reactor' ),
		'std'        => array(
			'preview-text'   => 'Subscribe Title Font',
			'preview-color'  => 'dark',
			'font-family'    => 'Oswald',
			'font-weight'    => '300',
			'font-size'      => '32px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.single-subscribe .widget #wp-subscribe .title',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_text_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Subscribe box Text Settings', 'reactor' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_text_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Subscribe Text Font', 'reactor' ),
		'std'        => array(
			'preview-text'  => 'Subscribe Text Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '300',
			'font-size'     => '18px',
			'line-height'   => '28px',
			'color'         => '#ffffff',
			'css-selectors' => '.single-subscribe .widget #wp-subscribe p.text, .single-subscribe .widget .wp-subscribe .wps-consent-wrapper label, .single-subscribe .widget .wp-subscribe-wrap .error, .single-subscribe .widget .wp-subscribe-wrap .thanks',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_input_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Subscribe box Input Settings', 'reactor' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_input_background',
		'type'       => 'color',
		'title'      => esc_html__( 'Background Color', 'reactor' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'reactor' ),
		'std'        => '#4d4e54',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_input_height',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Height', 'reactor' ),
		'sub_desc'   => esc_html__( 'Subscribe box input fields height.', 'reactor' ),
		'std'        => '64',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_input_border_radius',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Border Radius', 'reactor' ),
		'sub_desc'   => esc_html__( 'Subscribe box input fields border radius.', 'reactor' ),
		'std'        => '0',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_input_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'reactor' ),
		'sub_desc'   => esc_html__( 'Select border', 'reactor' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_input_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Subscribe Input Fields Font', 'reactor' ),
		'std'        => array(
			'preview-text'  => 'Subscribe Input Fields',
			'preview-color' => 'dark',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '20px',
			'color'         => '#a6a7aa',
			'css-selectors' => '.single-subscribe .widget #wp-subscribe input.email-field, .single-subscribe .widget #wp-subscribe input.name-field',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_submit_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Subscribe box Submit Settings', 'reactor' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_submit_backgroud',
		'type'       => 'color',
		'title'      => esc_html__( 'Background Color', 'reactor' ),
		'sub_desc'   => esc_html__( 'Submit button background color', 'reactor' ),
		'std'        => reactor_get_settings( 'primary_color_scheme' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_submit_border_radius',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Border Radius', 'reactor' ),
		'sub_desc'   => esc_html__( 'Subscribe box submit button border radius.', 'reactor' ),
		'std'        => '0',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_submit_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'reactor' ),
		'sub_desc'   => esc_html__( 'Select border', 'reactor' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_submit_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'reactor' ),
		'sub_desc'   => esc_html__( 'Set subscribe submit button padding from here.', 'reactor' ),
		'std'        => array(
			'top'    => '10px',
			'right'  => '0',
			'bottom' => '10px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_submit_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Subscribe Submit Button Font', 'reactor' ),
		'std'        => array(
			'preview-text'  => 'Subscribe Submit Button',
			'preview-color' => 'light',
			'font-family'   => 'Oswald',
			'font-weight'   => '500',
			'font-size'     => '21px',
			'color'         => '#2e2f36',
			'css-selectors' => '.single-subscribe .widget #wp-subscribe input.submit, #commentform input#submit, #mtscontact_submit, .widget #wp-subscribe input.submit',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_small_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Subscribe box small text Settings', 'reactor' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'single_subscribe_small_text_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Subscribe Small Text Font', 'reactor' ),
		'std'        => array(
			'preview-text'   => 'Subscribe Small Text',
			'preview-color'  => 'light',
			'font-family'    => 'Oswald',
			'font-weight'    => '400',
			'font-size'      => '13px',
			'line-height'    => '20px',
			'color'          => '#a6a7aa',
			'additional-css' => 'display: none;',
			'css-selectors'  => '.single-subscribe .widget .wp-subscribe-wrap p.footer-text',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'single_subscribe_box',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
);
