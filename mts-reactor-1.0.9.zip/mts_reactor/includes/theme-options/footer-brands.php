<?php
/**
 * Brands
 *
 * @package Reactor
 */

$menus['footer']['child']['footer-brands'] = array(
	'title' => esc_html__( 'Brands Section', 'reactor' ),
	'desc'  => esc_html__( 'From here, you can control the Brands Section.', 'reactor' ),
);

$sections['footer-brands'] = array(

	array(
		'id'       => 'footer_brands_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Brands Section', 'reactor' ),
		'sub_desc' => esc_html__( 'Enable or disable Brands Section with this option.', 'reactor' ),
		'std'      => '0',
	),

	array(
		'id'         => 'footer_brands_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Brands Section Alignment', 'reactor' ),
		'sub_desc'   => esc_html__( 'Choose alignment of Brands Section.', 'reactor' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'reactor' ),
			'center' => esc_html__( 'Center', 'reactor' ),
			'right'  => esc_html__( 'Right', 'reactor' ),
		),
		'std'        => 'center',
		'class'      => 'green',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'brands_section_title',
		'type'       => 'text',
		'title'      => esc_html__( 'Brands Title', 'reactor' ),
		'sub_desc'   => esc_html__( 'Enter brands title here.', 'reactor' ),
		'std'        => esc_html__( 'Our Brands:', 'reactor' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),

	),

	array(
		'id'         => 'footer_brands_items',
		'type'       => 'group',
		'title'      => esc_html__( 'Brands', 'reactor' ),
		'groupname'  => esc_html__( 'Brand', 'reactor' ), // Group name.
		'subfields'  => array(
			array(
				'id'       => 'brand_title',
				'type'     => 'text',
				'title'    => esc_html__( 'Title', 'reactor' ),
				'sub_desc' => esc_html__( 'The title will not be shown.', 'reactor' ),
			),
			array(
				'id'       => 'brand_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Image', 'reactor' ),
				'sub_desc' => esc_html__( 'Upload or select an image for brand', 'reactor' ),
			),
			array(
				'id'       => 'brand_url',
				'type'     => 'text',
				'title'    => esc_html__( 'Link', 'reactor' ),
				'sub_desc' => esc_html__( 'Insert a link URL of brand', 'reactor' ),
				'std'      => '#',
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'brands_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'reactor' ),
		'sub_desc'   => esc_html__( 'Brands Section margin.', 'reactor' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'brands_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'reactor' ),
		'sub_desc'   => esc_html__( 'Brands Section padding.', 'reactor' ),
		'std'        => array(
			'top'    => '40px',
			'right'  => '0',
			'bottom' => '27px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'brands_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'reactor' ),
		'sub_desc'   => esc_html__( 'Select border', 'reactor' ),
		'std'        => array(
			'direction' => 'top',
			'size'      => '1',
			'style'     => 'solid',
			'color'     => '#008b3e',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
);
