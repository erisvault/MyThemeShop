<?php
/**
 * HomePage Pagination
 *
 * @package Reactor
 */

$menus['home-pagination'] = array(
	'title' => esc_html__( 'Pagination', 'reactor' ),
	'desc'  => esc_html__( 'From here, you can control the elements of homepage pagination.', 'reactor' ),
);

$sections['home-pagination'] = array(

	array(
		'id'       => 'mts_pagenavigation_type',
		'type'     => 'radio',
		'title'    => esc_html__( 'Pagination Type', 'reactor' ),
		'sub_desc' => esc_html__( 'Select pagination type.', 'reactor' ),
		'options'  => array(
			'0' => esc_html__( 'Default (Next / Previous)', 'reactor' ),
			'1' => esc_html__( 'Numbered (1 2 3 4...)', 'reactor' ),
			'2' => esc_html__( 'AJAX (Load More Button)', 'reactor' ),
			'3' => esc_html__( 'AJAX (Auto Infinite Scroll)', 'reactor' ),
		),
		'std'      => '1',
	),

	array(
		'id'         => 'load_more_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Load More Alignment', 'reactor' ),
		'sub_desc'   => esc_html__( 'Choose the load more alignment from here.', 'reactor' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'reactor' ),
			'center' => esc_html__( 'Center', 'reactor' ),
			'right'  => esc_html__( 'Right', 'reactor' ),
			'full'   => esc_html__( 'Full Width', 'reactor' ),
		),
		'std'        => 'full',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'mts_pagenavigation_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination background color', 'reactor' ),
		'sub_desc'   => esc_html__( 'Select pagination background color.', 'reactor' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More background color', 'reactor' ),
		'sub_desc'   => esc_html__( 'Select background color for load more button.', 'reactor' ),
		'std'        => reactor_get_settings( 'primary_color_scheme' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_hover_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination background hover color', 'reactor' ),
		'sub_desc'   => esc_html__( 'Select pagination background hover color.', 'reactor' ),
		'std'        => reactor_get_settings( 'primary_color_scheme' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_hover_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More background hover color', 'reactor' ),
		'sub_desc'   => esc_html__( 'Select background hover color for load more button.', 'reactor' ),
		'std'        => '#2e2f36',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination color', 'reactor' ),
		'sub_desc'   => esc_html__( 'Select pagination color.', 'reactor' ),
		'std'        => '#abacad',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More color', 'reactor' ),
		'sub_desc'   => esc_html__( 'Select color for load more button.', 'reactor' ),
		'std'        => '#2e2f36',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_hover_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination hover color', 'reactor' ),
		'sub_desc'   => esc_html__( 'Select pagination hover color.', 'reactor' ),
		'std'        => '#1f1f23',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_hover_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More hover color', 'reactor' ),
		'sub_desc'   => esc_html__( 'Select hover color for load more button.', 'reactor' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'       => 'mts_pagenavigation_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Pagination Margin', 'reactor' ),
		'sub_desc' => esc_html__( 'Update pagination margin from here.', 'reactor' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '8px',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'         => 'mts_pagenavigation_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Pagination Padding', 'reactor' ),
		'sub_desc'   => esc_html__( 'Update pagination padding from here.', 'reactor' ),
		'std'        => array(
			'top'    => '10px',
			'right'  => '12px',
			'bottom' => '7px',
			'left'   => '12px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Load More Padding', 'reactor' ),
		'sub_desc'   => esc_html__( 'Update padding for load more button from here.', 'reactor' ),
		'std'        => array(
			'top'    => '30px',
			'right'  => '30px',
			'bottom' => '27px',
			'left'   => '30px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'       => 'mts_pagenavigation_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Pagination border radius', 'reactor' ),
		'sub_desc' => esc_html__( 'Update pagination border radius in px.', 'reactor' ),
		'std'      => '50',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'pagenavigation_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'reactor' ),
		'sub_desc' => esc_html__( 'Select border', 'reactor' ),
	),

);
