<?php
/**
 * Tweaks for the footer of the document.
 *
 * @package Reactor
 */

defined( 'WPINC' ) || exit;

/**
 * Tweaks for the <head> of the document.
 */
class Reactor_Footer extends Reactor_Base {

	/**
	 * Constructor
	 */
	public function __construct() {

		$this->add_action( 'wp_footer', 'tracking_field', 999 );
	}

	/**
	 * Add tracking field code
	 */
	public function tracking_field() {
		echo reactor_get_settings( 'mts_analytics_code' );
	}
}

/**
 * Init
 */
new Reactor_Footer;
