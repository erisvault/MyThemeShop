<?php
/**
 * Header Layout - 4
 *
 * @package Reactor
 */

?>

<header<?php reactor_attr( 'header' ); ?>>
	<?php if ( reactor_get_settings( 'mts_show_primary_nav' ) === 1 ) { ?>
		<div id="primary-nav">
			<div class="container clearfix">
				<div<?php reactor_attr( 'menu', 'primary' ); ?>>
					<nav class="navigation clearfix">
						<?php
						// Primary Navigation.
						if ( has_nav_menu( 'primary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'primary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new reactor_menu_walker(),
							));
						}
						?>
					</nav>
				</div>
			</div>
		</div>
	<?php } ?>

	<?php if ( reactor_get_settings( 'mts_sticky_nav' ) === 1 ) { ?>
	<div class="clear" id="catcher"></div>
	<div id="header" class="sticky-navigation">
	<?php } else { ?>
	<div id="header">
	<?php } ?>
		<div class="container">

			<?php
			// Header Social Icons.
			if ( ! empty( reactor_get_settings( 'mts_header_social' ) ) && is_array( reactor_get_settings( 'mts_header_social' ) ) ) {
				$header_icons = reactor_get_settings( 'mts_header_social' );
				reactor_social_icons( $header_icons, true );
			}
			?>

			<div class="logo-wrap">
				<?php reactor_logo(); ?>
			</div>

		</div><!--.container-->

		<div<?php reactor_attr( 'menu', 'secondary' ); ?>>
			<div class="container">
				<a href="#" id="pull" class="toggle-mobile-menu"><?php esc_html_e( 'Menu', 'reactor' ); ?></a>
				<?php if ( has_nav_menu( 'mobile' ) ) { ?>

					<nav class="navigation clearfix">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'secondary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new reactor_menu_walker(),
							));
						}
						?>
					</nav>
					<nav class="navigation mobile-only clearfix mobile-menu-wrapper">
						<?php
						// Mobile Navigation.
						if ( has_nav_menu( 'mobile' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'mobile',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new reactor_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } else { ?>

					<nav class="navigation clearfix mobile-menu-wrapper">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'secondary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new reactor_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } ?>

				<?php
				// Header Search icon.
				if ( ! empty( reactor_get_settings( 'mts_header_search' ) ) ) {
				?>
					<div class="header-search-icon"><i class="fa fa-search fa-flip-horizontal"></i></div>
				<?php } ?>
			</div><!--.container-->
		</div>


		<?php
		// Header Search.
		if ( ! empty( reactor_get_settings( 'mts_header_search' ) ) ) {
		?>
			<div class="close"><i class="fa fa-times"></i></div>
			<div class="full-overlay"></div>
			<div id="search-6" class="widget header-search">
				<div class="container">
					<?php get_search_form(); ?>
				</div>
			</div><!-- END #search-6 -->
		<?php } ?>

	</div>
</header>
<?php get_template_part( 'template-parts/header/header', 'nav-adcode' ); ?>
<?php get_template_part( 'template-parts/header/header', 'adcode' ); ?>
