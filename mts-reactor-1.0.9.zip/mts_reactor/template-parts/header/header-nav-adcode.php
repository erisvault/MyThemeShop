<?php if ( reactor_get_settings( 'navigation_ad' ) && reactor_get_settings( 'navigation_adcode' ) ) { ?>
	<div class="navigation-banner">
		<div class="container">
			<div style="<?php ad_size_value( reactor_get_settings( 'navigation_ad_size' ) ); ?>">
				<?php echo reactor_get_settings( 'navigation_adcode' ); ?>
			</div>
		</div>
	</div>
<?php } ?>
