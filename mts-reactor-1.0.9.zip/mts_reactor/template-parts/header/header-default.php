<?php
/**
 * Header Layout Default
 *
 * @package Reactor
 */

?>

<header<?php reactor_attr( 'header' ); ?>>
	<?php if ( reactor_get_settings( 'mts_show_primary_nav' ) === 1 ) { ?>
		<div id="primary-nav">
			<div class="container clearfix">
				<div<?php reactor_attr( 'menu', 'primary' ); ?>>
					<nav class="navigation clearfix">
						<?php
						// Pirmary Navigation.
						if ( has_nav_menu( 'primary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'primary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new reactor_menu_walker(),
							));
						}

						// Header Social Icons.
						if ( ! empty( reactor_get_settings( 'mts_header_social' ) ) && is_array( reactor_get_settings( 'mts_header_social' ) ) ) {
							$header_icons = reactor_get_settings( 'mts_header_social' );
							reactor_social_icons( $header_icons, true );
						}
						?>
					</nav>
				</div>
			</div>
		</div>
	<?php } ?>

	<div id="regular-header">
		<div class="container">
			<div class="logo-wrap">
					<?php reactor_logo(); ?>
			</div>

			<?php get_template_part( 'template-parts/header/header', 'adcode' ); ?>

		</div>
	</div>

	<?php if ( reactor_get_settings( 'mts_sticky_nav' ) === 1 ) { ?>
	<div class="clear" id="catcher"></div>
	<div id="header" class="sticky-navigation">
	<?php } else { ?>
	<div id="header">
	<?php } ?>
		<div class="container">
			<div<?php reactor_attr( 'menu', 'secondary' ); ?>>
				<a href="#" id="pull" class="toggle-mobile-menu"><?php _e( 'Menu', 'reactor' ); ?></a>
				<?php if ( has_nav_menu( 'mobile' ) ) { ?>

					<nav class="navigation clearfix">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'secondary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new reactor_menu_walker(),
							));
						}
						?>
					</nav>
					<nav class="navigation mobile-only clearfix mobile-menu-wrapper">
						<?php
						// Mobile Menu.
						if ( has_nav_menu( 'mobile' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'mobile',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new reactor_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } else { ?>

					<nav class="navigation clearfix mobile-menu-wrapper">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'secondary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new reactor_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } ?>
			</div>
		</div><!--.container-->
	</div>

	<?php get_template_part( 'template-parts/header/header', 'nav-adcode' ); ?>

</header>
