<?php
/**
 * Posts Layout - layout banner
 *
 * @package Reactor
 */
$featured = reactor()->featured_layouts;
if ( ! is_paged() ) {
?>
<div class="<?php reactor_article_class(); ?> <?php $featured->get_post_container_class(); ?>">
	<section class="<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">
		<?php if ( ! empty( reactor_get_settings( 'adcode_' . $featured->current['unique_id'] ) ) ) { ?>
			<div class="container">
				<div class="widget-banner"><?php echo reactor_get_settings( 'adcode_' . $featured->current['unique_id'] ); ?></div>
			</div>
		<?php } ?>
	</section><!--#latest-posts-->
</div>
<?php } ?>
