<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="page">
 *
 * @package Reactor
 */

?><!doctype html>
<html<?php reactor_attr( 'html' ); ?>>
<head<?php reactor_attr( 'head' ); ?>>
	<?php wp_head(); ?>
</head>

<body<?php reactor_attr( 'body' ); ?>>

	<?php get_template_part( 'template-parts/header/clickable', 'background' ); ?>

	<div<?php reactor_attr( 'main' ); ?>>

		<?php reactor_action( 'before_wrapper' ); ?>
