<?php
/**
 * The template for displaying all single posts.
 *
 * @package Reactor
 */

get_header(); ?>

	<div id="wrapper" class="<?php reactor_single_page_class(); ?>">

		<?php reactor_action( 'single_top' ); ?>

		<div class="container clearfix">

			<?php
			reactor_single_featured_image_effect();

			reactor_action( 'before_content' );

			reactor_single_sections();

			reactor_action( 'after_content' );

			get_sidebar();
			?>

		</div>

		<?php
		if ( 'full' === reactor_get_settings( 'related_posts_position' ) ) {
			reactor_related_posts();
		}
		?>

<?php
get_footer();
