<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Reactor
 */

get_template_part( 'template-parts/footer/footer', 'ad' );
?>
	</div><!--#wrapper-->

	<footer<?php reactor_attr( 'footer' ); ?>>

		<div class="container">
			<?php

			get_template_part( 'template-parts/footer/footer', 'logo' );

			if ( 'bottom' !== reactor_get_settings( 'footer_sections_position' ) ) {
				get_template_part( 'template-parts/footer/footer', 'sections' );
			}

			if ( reactor_get_settings( 'mts_top_footer' ) ) {
				reactor_footer_widget_columns();
			}

			if ( 'bottom' === reactor_get_settings( 'footer_sections_position' ) ) {
				get_template_part( 'template-parts/footer/footer', 'sections' );
			}
			?>
		</div>

		<?php reactor_footer_copyrights(); ?>

	</footer><!--#site-footer-->

</div><!--.main-container-->

<?php get_template_part( 'template-parts/footer/footer', 'detect-adblocker' ); ?>

<?php wp_footer(); ?>

</body>
</html>
