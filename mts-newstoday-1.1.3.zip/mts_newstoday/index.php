<?php
/**
 * The main template file.
 *
 * Used to display the homepage when home.php doesn't exist.
 */
$mts_options = get_option(MTS_THEME_NAME);

get_header(); ?>

<div id="page" class="clearfix">
	<div class="article">
		<div class="page-outer"></div>
		<div id="content_box">
			<?php if ( !is_paged() ) {

				$featured_categories = array();
				if ( !empty( $mts_options['mts_featured_categories'] ) ) {
					foreach ( $mts_options['mts_featured_categories'] as $section ) {
						$category_id = $section['mts_featured_category'];
						$featured_categories[] = $category_id;
						$posts_num = $section['mts_featured_category_postsnum'];
						$layout = isset( $section['mts_featured_category_layout'] ) ? $section['mts_featured_category_layout'] : 'three-column';

						if ( 'latest' == $category_id ) { ?>
							<div class="article-wrap">
								<?php if (isset($section['mts_featured_category_title']) && $section['mts_featured_category_title']) { ?>
									<h3 class="featured-category-title"><?php _e('Latest','newstoday'); ?></a></h3>
								<?php } ?>

								<?php switch ($layout) {
									case "four-column": // Four Grid
										echo '<div class="article-four-posts">';
									break;
									case "three-column": //Three Grid
										echo '<div class="article-three-posts">';
									break;
									case "highlight-post": //Highlight Layout
										echo '<div class="article-highlight-posts">';
									break;
									case "hero-post": //Hero Layout
										echo '<div class="article-hero-posts">';
									break;
									case "primary-slider": //Primary Slider
										echo '<div class="primary-slider-container clearfix loading">';
											echo '<div id="slider" class="primary-slider">';
									break;
									case "slider-with-thumb": //Slider with thumbnail
										echo '<div class="full-slider-container clearfix loading">';
											echo '<div class="big-image-container">';
												echo '<div id="big-image" class="slider-big-image owl-carousel loading">';
									break;
									default: // Four Grid
										echo '<div class="article-four-posts">';
								}

								$j = 1; if ( have_posts() ) : while ( have_posts() ) : the_post();
									get_template_part('home/section', $layout );
									++$j;
								endwhile; endif;

								if ( $layout == 'four-column' || $layout == 'three-column' || $layout == 'highlight-post' || $layout == 'hero-post' ) {
									if ( $j !== 0 ) { // No pagination if there is no posts
										mts_pagination();
									} ?> 
									</div>
								<?php }								
								if ( $layout == 'primary-slider' ) { //ending primary slider ?>
										</div>
									</div>
								<?php }
								if ( $layout == 'slider-with-thumb' ) { //ending slider with thumbnail ?>
											</div>
											<div class="slider-thumb loading">
												<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
													<div class="thumb-item"> 
													   <?php the_post_thumbnail('newstoday-highlights-small',array('title' => '')); ?> 
													   <div class="arrowTop"></div>
													</div>
												<?php endwhile; endif; wp_reset_postdata(); ?>
											</div>
										</div>
									</div>
								<?php } ?>								 
							</div>
							
						<?php } else { // if $category_id != 'latest': ?>
							<div class="article-wrap">
								<?php if (isset($section['mts_featured_category_title']) && $section['mts_featured_category_title']) { ?>
									<h3 class="featured-category-title"><a href="<?php echo esc_url( get_category_link( $category_id ) ); ?>" title="<?php echo esc_attr( get_cat_name( $category_id ) ); ?>"><?php echo esc_html( get_cat_name( $category_id ) ); ?></a></h3>
								<?php } ?>

								<?php switch ($layout) {
									case "four-column": // Four Grid
										echo '<div class="article-four-posts">';
									break;
									case "three-column": //Three Grid
										echo '<div class="article-three-posts">';
									break;
									case "highlight-post": //Highlight Layout
										echo '<div class="article-highlight-posts">';
									break;
									case "hero-post": //Hero Layout
										echo '<div class="article-hero-posts">';
									break;
									case "primary-slider": //Primary Slider
										echo '<div class="primary-slider-container clearfix loading">';
											echo '<div id="slider" class="primary-slider">';
									break;
									case "slider-with-thumb": //Slider with thumbnail
										echo '<div class="full-slider-container clearfix loading">';
											echo '<div class="big-image-container">';
												echo '<div id="big-image" class="slider-big-image owl-carousel loading">';
									break;
									default: // Four Grid
										echo '<div class="article-four-posts">';
								}

								$j = 1; $cat_query = new WP_Query('cat='.$category_id.'&posts_per_page='.$posts_num);

								if ( $cat_query->have_posts() ) : while ( $cat_query->have_posts() ) : $cat_query->the_post();
									get_template_part('home/section', $layout );
									++$j;
								endwhile; endif; wp_reset_postdata();

								if ( $layout == 'four-column' || $layout == 'three-column' || $layout == 'highlight-post' || $layout == 'hero-post' ) { ?>
									</div>
								<?php }
								if ( $layout == 'primary-slider' ) { ?>
										</div>
									</div>
								<?php }
								if ( $layout == 'slider-with-thumb' ) { ?>
											</div>
											<div class="slider-thumb loading">
												<?php $cat_query->rewind_posts();
												while ( $cat_query->have_posts() ) : $cat_query->the_post(); ?>
													<div class="thumb-item"> 
													   <?php the_post_thumbnail('newstoday-highlights-small',array('title' => '')); ?> 
													   <div class="arrowTop"></div>
													</div>
												<?php endwhile; wp_reset_postdata(); ?>
											</div>
										</div>
									</div>
								<?php } ?>
							</div>
						<?php }
					}
				} ?>

			<?php } else { //Paged ?>
					<?php foreach ( $mts_options['mts_featured_categories'] as $section ) {
					$category_id = $section['mts_featured_category'];
					$featured_categories[] = $category_id;
					$posts_num = $section['mts_featured_category_postsnum'];
					$layout = isset( $section['mts_featured_category_layout'] ) ? $section['mts_featured_category_layout'] : 'three-column';
					if ( 'latest' == $category_id ) { ?>
					<div class="article-wrap">
						<?php switch ($layout) {
							case "four-column": // Four Grid
								echo '<div class="article-four-posts">';
							break;
							case "three-column": //Three Grid
								echo '<div class="article-three-posts">';
							break;
							case "highlight-post": //Highlight Layout
								echo '<div class="article-highlight-posts">';
							break;
							case "hero-post": //Hero Layout
								echo '<div class="article-hero-posts">';
							break;
							default: // Four Grid
								echo '<div class="article-four-posts">';
						}

						$j = 1; if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
							<?php get_template_part('home/section', $layout ); ?>
						<?php ++$j; endwhile; endif;
						
						if ( $layout == 'four-column' || $layout == 'three-column' || $layout == 'highlight-post' || $layout == 'hero-post' ) {
							if ( $j !== 0 ) { // No pagination if there is no posts
								mts_pagination();
							} ?> 
							</div>
						<?php } ?>
					</div>	
					<?php }
				}
			} ?>
		</div>
	</div>
	<?php get_sidebar(); ?>
<?php get_footer(); ?>