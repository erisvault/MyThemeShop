<?php
$mts_options = get_option(MTS_THEME_NAME);
global $j; ?>

<article class="latestPost excerpt <?php echo ($j % 3 == 0) ? 'last' : ''; ?>">
	<?php mts_archive_post(); ?>
</article>