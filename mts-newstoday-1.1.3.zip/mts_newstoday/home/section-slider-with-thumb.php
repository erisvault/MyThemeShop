<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<?php if ( is_home() ) { ?>
	<div class="full-slider-item"> 
		<a href="<?php echo esc_url( get_the_permalink() ); ?>" class="slider-featured">
			<?php the_post_thumbnail('newstoday-sliderfull',array('title' => '')); ?>
			<div class="slide-caption">
				<p class="slide-title"><?php the_title(); ?> : <?php echo mts_excerpt(40); ?></p>	
			</div>	
		</a> 
	</div>
<?php }