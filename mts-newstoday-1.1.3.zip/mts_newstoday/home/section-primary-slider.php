<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<?php if ( is_home() ) { ?>
	<div class="primary-slider-item"> 
		<a href="<?php echo esc_url( get_the_permalink() ); ?>" class="slider-featured">
			<?php the_post_thumbnail('newstoday-slider',array('title' => '')); ?>
		</a> 
		<div class="slide-caption">
			<h2 class="slide-title"><a href="<?php echo esc_url( get_the_permalink() ); ?>"><?php echo mts_truncate( get_the_title(), 60 ); ?></a></h2>
			<?php if( $post->post_content != "" ) { ?>
				<div class="slide-content">
					<?php echo mts_excerpt(20); ?>
				</div>
			<?php  } ?>	
			<div class="slider-info">
				<div class="slider-numbers"></div>
				<div class="slider-readmore"><a href="<?php echo esc_url( get_the_permalink() ); ?>"><?php _e( 'Read More', 'newstoday' ); ?></a></div>
			</div>
		</div>
	</div>
<?php }