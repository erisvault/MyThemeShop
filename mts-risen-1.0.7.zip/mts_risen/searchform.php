<?php
/**
 * The template for displaying the search form.
 *
 * @package Risen
 */

$ajax_search = ! empty( risen_get_settings( 'mts_ajax_search' ) ) ? ' autocomplete="off"' : ''; ?>

<form method="get" id="searchform" class="search-form" action="<?php echo esc_attr( home_url() ); ?>" _lpchecked="1">
	<fieldset>
		<input type="text" name="s" id="s" value="<?php the_search_query(); ?>" placeholder="<?php esc_html_e( 'Search here...', 'risen' ); ?>" <?php echo $ajax_search; ?>>
		<button id="search-image" class="sbutton" type="submit" value=""><i class="fa fa-search fa-flip-horizontal"></i></button>
	</fieldset>
</form>
