<?php
/**
 * Before footer detect ad blocker notice.
 *
 */

if ( risen_get_settings( 'detect_adblocker' ) && ( 'popup' === risen_get_settings( 'detect_adblocker_type' ) || 'floating' === risen_get_settings( 'detect_adblocker_type' ) ) ) { ?>
	<?php if ( 'popup' === risen_get_settings( 'detect_adblocker_type' ) ) { ?>
		<div class="blocker-overlay"></div>
	<?php } ?>
	<?php echo detect_adblocker_notice(); ?>
<?php } ?>
