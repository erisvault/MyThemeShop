<?php
/**
 * Posts Layout - layout 3
 *
 * @package Risen
 */
$featured = risen()->featured_layouts;
?>
<div class="<?php risen_article_class(); ?> <?php $featured->get_post_container_class(); ?>">

	<div id="content_box">

		<?php risen_action( 'start_content_box' ); ?>

		<section id="latest-posts" class="<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">
			<?php
			$j = 0;
			while ( have_posts() ) :
				the_post();

				$featured_image = array();
				$post_meta_info = risen_get_settings( 'home_meta_info_' . $featured->current['unique_id'] );
				if ( has_post_thumbnail() ) {
					$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
				}
			?>
			<article class="latestPost excerpt" style="background-image: url('<?php echo isset( $featured_image[0] ) ? $featured_image[0] : 'background-color: #444;'; ?>');">

				<div class="container">

					<div class="wrapper">

						<div class="post-category">
							<?php
							if ( isset( $post_meta_info['category'] ) ) :
								printf( '<span class="thecategory">%s</span>', risen_get_the_category( ' ' ) );
							endif;
							?>
						</div>

						<header>

							<h2 class="title front-view-title">
								<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php the_title_attribute(); ?>"><?php echo the_title(); ?></a>
							</h2>

							<div class="post-info bottom">
								<?php
								if ( isset( $post_meta_info['author'] ) ) :
									printf( '<span class="theauthor"><span>%s</span></span>', get_the_author_posts_link() );
								endif;
								if ( isset( $post_meta_info['time'] ) ) :
									printf( '<span class="thetime date updated"><span>%s</span></span>', get_the_time( get_option( 'date_format' ) ) );
								endif;
								if ( isset( $post_meta_info['comment'] ) ) :
									printf( '<span class="thecomment">%s</span>', get_comments_number_text() );
								endif;
								?>
							</div>

						</header>

					</div>

				</div>

			</article>
			<?php
			endwhile;

			$featured->get_post_pagination();
			?>
		</section><!--#latest-posts-->

	</div>

</div>
