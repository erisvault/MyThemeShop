<?php
/**
 * Header featured post
 *
 */

$category      = risen_get_settings( 'featured_post_cat' );
$category_name = get_cat_name( $category );
$category_link = get_category_link( $category );

$h_query = new WP_Query( 'ignore_sticky_posts=1&category_name=' . $category_name . '&posts_per_page=1' );

if ( $h_query->have_posts() ) :
	while ( $h_query->have_posts() ) :
		$h_query->the_post();

		$featured_image = array();
		if ( has_post_thumbnail() ) {
			$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
		}
		?>

		<div class="featured-post" style="background-image: url('<?php echo isset( $featured_image[0] ) ? $featured_image[0] : ''; ?>');">

			<div class="container clearfix">

				<div class="logo-wrap">
					<?php risen_logo(); ?>
				</div>

				<div class="featured-content">

					<?php
					if ( $category ) :
						printf( '<a class="thecategory" href="%1$s">%2$s</a>', $category_link, $category_name );
					endif;
					?>

					<a class="title" href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php the_title_attribute(); ?>"><?php echo the_title(); ?></a>

				</div>

			</div>

		</div><!-- .featured-post -->

		<?php
	endwhile;
endif;
wp_reset_postdata();
?>
