<?php
/**
 * Header Layout Default
 *
 * @package Risen
 */

?>

<?php if ( risen_get_settings( 'show_sliding_nav' ) ) { ?>

	<div class="full-overlay"></div>

	<div id="primary-nav">

		<div class="close">
			<i class="fa fa-close"></i>
		</div>

		<div class="logo-wrap">
			<?php risen_logo( array(), 'sliding' ); ?>
		</div>

		<div id="sliding-menu" class="sliding-menu" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
			<nav class="navigation clearfix">
				<?php
				// Pirmary Navigation.
				if ( has_nav_menu( 'sliding-menu' ) ) {
					wp_nav_menu( array(
						'theme_location' => 'sliding-menu',
						'menu_class'     => 'menu clearfix',
						'container'      => '',
						'walker'         => new risen_menu_walker(),
					));
				}
				?>
			</nav>
		</div>

	</div>

<?php } ?>

<?php get_template_part( 'template-parts/header/header', 'adcode' ); ?>

<header id="site-header" class="main-header <?php echo esc_attr( risen_get_settings( 'header_styles' ) ); ?> clearfix" role="banner" itemscope itemtype="http://schema.org/WPHeader">

	<?php
	if ( is_front_page() && ! is_paged() ) {
		get_template_part( 'template-parts/header/header', 'featured-post' );
	}
	?>

	<?php if ( risen_get_settings( 'mts_sticky_nav' ) === 1 ) { ?>
	<div class="clear" id="catcher"></div>
	<div id="header" class="sticky-navigation">
	<?php } else { ?>
	<div id="header">
	<?php } ?>
		<div class="container">

			<?php
			if ( risen_get_settings( 'show_sliding_nav' ) ) {
			?>
				<div class="menu-icon">
					<span></span>
					<span></span>
					<span></span>
				</div>
			<?php
			}
			?>

			<div id="secondary-navigation" class="secondary-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
				<a href="#" id="pull" class="toggle-mobile-menu"><?php _e( 'Menu', 'risen' ); ?></a>
				<?php if ( has_nav_menu( 'mobile' ) ) { ?>

					<nav class="navigation clearfix">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'secondary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new risen_menu_walker(),
							));
						}
						?>
					</nav>
					<nav class="navigation mobile-only clearfix mobile-menu-wrapper">
						<?php
						// Mobile Menu.
						if ( has_nav_menu( 'mobile' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'mobile',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new risen_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } else { ?>

					<nav class="navigation clearfix mobile-menu-wrapper">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'secondary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new risen_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } ?>
			</div>

			<?php
			// Header Search.
			if ( ! empty( risen_get_settings( 'header_search_box' ) ) ) {
				?>
				<div class="header-search">
					<?php get_search_form(); ?>
				</div><!-- END #search-6 -->
			<?php } ?>

		</div><!--.container-->

	</div><!--#header-->

	<?php get_template_part( 'template-parts/header/header', 'nav-adcode' ); ?>

</header>
