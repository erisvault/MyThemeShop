<?php if ( risen_get_settings( 'navigation_ad' ) && risen_get_settings( 'navigation_adcode' ) ) { ?>
	<div class="navigation-banner">
		<div class="container">
			<div style="<?php ad_size_value( risen_get_settings( 'navigation_ad_size' ) ); ?>">
				<?php echo risen_get_settings( 'navigation_adcode' ); ?>
			</div>
		</div>
	</div>
<?php } ?>
