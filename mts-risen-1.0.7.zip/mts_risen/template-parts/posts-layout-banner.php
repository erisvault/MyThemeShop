<?php
/**
 * Posts Layout - layout banner
 *
 * @package Risen
 */
$featured = risen()->featured_layouts;
if ( ! is_paged() ) {
?>
<div class="<?php risen_article_class(); ?> <?php $featured->get_post_container_class(); ?>">
	<section class="<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">
		<?php if ( ! empty( risen_get_settings( 'adcode_' . $featured->current['unique_id'] ) ) ) { ?>
			<div class="container">
				<div class="widget-banner"><?php echo risen_get_settings( 'adcode_' . $featured->current['unique_id'] ); ?></div>
			</div>
		<?php } ?>
	</section><!--#latest-posts-->
</div>
<?php } ?>
