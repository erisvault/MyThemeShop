<?php
/**
 * Posts Layout - layout 4
 *
 * @package Risen
 */
$featured = risen()->featured_layouts;
?>
<div class="<?php risen_article_class(); ?> <?php $featured->get_post_container_class(); ?>">

	<div class="container">

		<?php $featured->get_section_title(); ?>

		<div id="content_box">

			<?php risen_action( 'start_content_box' ); ?>

			<section id="latest-posts" class="<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">
				<?php
				while ( have_posts() ) :
					the_post();
					$post_meta_info = risen_get_settings( 'home_meta_info_' . $featured->current['unique_id'] );
				?>
				<article class="latestPost excerpt">

					<?php $featured->get_post_thumbnail(); ?>

					<div class="wrapper">

						<div class="post-category">
							<?php
							if ( isset( $post_meta_info['category'] ) ) :
								printf( '<span class="thecategory">%s</span>', risen_get_the_category( ' ' ) );
							endif;
							?>
						</div>

						<?php $featured->get_post_title( false ); ?>

						<?php $featured->get_post_content(); ?>

						<div class="post-info bottom">
							<?php
							if ( isset( $post_meta_info['author'] ) ) :
								printf( '<span class="theauthor"><span>%s</span></span>', get_the_author_posts_link() );
							endif;
							if ( isset( $post_meta_info['time'] ) ) :
								printf( '<span class="thetime date updated"><span>%s</span></span>', get_the_time( get_option( 'date_format' ) ) );
							endif;
							if ( isset( $post_meta_info['comment'] ) ) :
								printf( '<span class="thecomment">%s</span>', get_comments_number_text() );
							endif;
							?>
						</div>

					</div>

				</article>
				<?php
				endwhile;

				$featured->get_post_pagination();
				?>
			</section><!--#latest-posts-->

		</div>

	</div>

</div>
