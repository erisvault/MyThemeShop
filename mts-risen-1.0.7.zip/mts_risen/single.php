<?php
/**
 * The template for displaying all single posts.
 *
 * @package Risen
 */

get_header(); ?>

	<div id="wrapper" class="<?php risen_single_page_class(); ?>">

		<?php risen_action( 'single_top' ); ?>

		<div class="container clearfix">

			<?php
			risen_single_featured_image_effect();

			risen_action( 'before_content' );

			risen_single_sections();

			risen_action( 'after_content' );

			get_sidebar();
			?>

		</div>

		<?php
		if ( 'full' === risen_get_settings( 'related_posts_position' ) ) {
			risen_related_posts();
		}
		?>

<?php
get_footer();
