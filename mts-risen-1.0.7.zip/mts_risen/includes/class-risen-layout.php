<?php
/**
 * Set risen layout according to options
 *
 * @package Risen
 */

defined( 'WPINC' ) || exit;

/**
 * Layout manager.
 */
class Risen_Layout extends Risen_Base {

	/**
	 * The Construct
	 */
	public function __construct() {
		$this->add_action( 'risen_before_wrapper', 'add_header' );
		$this->add_action( 'risen_single_top', 'full_single_post_header' );
		$this->add_action( 'risen_single_post_header', 'single_post_header' );
	}

	/**
	 * Add header
	 */
	public function add_header() {
		$hash   = array(
			'header-default' => 'default',
			'header-layout2' => 'layout2',
			'header-layout3' => 'layout3',
			'header-layout4' => 'layout4',
		);
		$layout = risen_get_settings( 'header_styles' );
		get_template_part( 'template-parts/header/header', isset( $hash[ $layout ] ) ? $hash[ $layout ] : $layout );
	}

	/**
	 * Single post header if fullwidth layout
	 */
	public function full_single_post_header() {
		$img_size       = risen_get_settings( 'featured_image_size' );
		$post_meta_info = risen_get_settings( 'single_meta_info' );

		if ( 'full' === $img_size ) {
		?>
			<header class="single-full-header clearfix">
				<?php
				if ( have_posts() ) :
					while ( have_posts() ) :
						the_post();

						if ( 1 === risen_get_settings( 'show_prev_next' ) ) {
						?>
							<div class="prev-next">
								<?php
								previous_post_link( '<div class="prev">%link</div>', '<i class="fa fa-angle-left"></i>', true );
								next_post_link( '<div class="next">%link</div>', '<i class="fa fa-angle-right"></i>', true );
								?>
							</div>
						<?php
						}
						?>
						<div class="content">
							<div class="container">
								<div class="full-header-wrapper clearfix">

									<div class="post-info top">
										<?php
										if ( isset( $post_meta_info['category'] ) ) :
											printf( '<span class="thecategory">%s</span>', risen_get_the_category( ' ' ) );
										endif;
										?>
									</div>

									<h1 class="title single-title entry-title"><?php the_title(); ?></h1>

								</div>
							</div>
						</div>
					<?php
					endwhile;
				endif; /* end loop */
				?>
			</header><!--.headline_area-->
		<?php
		}

	}

	/**
	 * Single post header
	 */
	public function single_post_header() {

		$img_size       = risen_get_settings( 'featured_image_size' );
		$post_meta_info = risen_get_settings( 'single_meta_info' );

		if ( 'default' === $img_size || 'full' === $img_size ) {
		?>
			<header>
				<?php
				if ( 'default' === $img_size ) {
				?>
					<div class="post-info top">
						<?php
						if ( isset( $post_meta_info['category'] ) ) :
							printf( '<span class="thecategory">%s</span>', risen_get_the_category( ' ' ) );
						endif;
						?>
					</div>

					<h1 class="title single-title entry-title"><?php the_title(); ?></h1>

					<?php
				}
				?>
				<div class="post-info bottom">
					<?php
					if ( isset( $post_meta_info['author'] ) ) :
						// Author gravatar.
						if ( function_exists( 'get_avatar' ) ) {
							echo get_avatar( get_the_author_meta( 'email' ), '40' ); // Gravatar size.
						}
						printf( '<span class="theauthor">%1$s<span>%2$s</span></span>', __( 'By ', 'risen' ), get_the_author_posts_link() );
					endif;
					if ( isset( $post_meta_info['time'] ) ) :
						printf( '<span class="thetime date updated">%1$s <span>%2$s</span></span>', __( 'on ', 'risen' ), get_the_time( get_option( 'date_format' ) ) );
					endif;
					if ( isset( $post_meta_info['comment'] ) ) :
						printf( '<span class="thecomment">%s</span>', get_comments_number_text() );
					endif;
					?>
				</div>
				<?php
				if ( risen_get_settings( 'mts_show_featured' ) ) {
					the_post_thumbnail( 'risen-layout-2', array( 'class' => 'single-featured-image' ) );
				}
				?>
			</header><!--.headline_area-->
		<?php
		}
	}
}

// Init.
new Risen_Layout;
