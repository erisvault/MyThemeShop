<?php
/**
 * HomePage Pagination
 *
 * @package Risen
 */

$menus['home-pagination'] = array(
	'title' => esc_html__( 'Pagination', 'risen' ),
	'desc'  => esc_html__( 'From here, you can control the elements of homepage pagination.', 'risen' ),
);

$sections['home-pagination'] = array(

	array(
		'id'       => 'mts_pagenavigation_type',
		'type'     => 'radio',
		'title'    => esc_html__( 'Pagination Type', 'risen' ),
		'sub_desc' => esc_html__( 'Select pagination type.', 'risen' ),
		'options'  => array(
			'0' => esc_html__( 'Default (Next / Previous)', 'risen' ),
			'1' => esc_html__( 'Numbered (1 2 3 4...)', 'risen' ),
			'2' => esc_html__( 'AJAX (Load More Button)', 'risen' ),
			'3' => esc_html__( 'AJAX (Auto Infinite Scroll)', 'risen' ),
		),
		'std'      => '1',
	),

	array(
		'id'         => 'load_more_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Load More Alignment', 'risen' ),
		'sub_desc'   => esc_html__( 'Choose the load more alignment from here.', 'risen' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'risen' ),
			'center' => esc_html__( 'Center', 'risen' ),
			'right'  => esc_html__( 'Right', 'risen' ),
			'full'   => esc_html__( 'Full Width', 'risen' ),
		),
		'std'        => 'full',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'mts_pagenavigation_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination background color', 'risen' ),
		'sub_desc'   => esc_html__( 'Select pagination background color.', 'risen' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More background color', 'risen' ),
		'sub_desc'   => esc_html__( 'Select background color for load more button.', 'risen' ),
		'std'        => risen_get_settings( 'primary_color_scheme' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_hover_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination background hover color', 'risen' ),
		'sub_desc'   => esc_html__( 'Select pagination background hover color.', 'risen' ),
		'std'        => risen_get_settings( 'primary_color_scheme' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_hover_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More background hover color', 'risen' ),
		'sub_desc'   => esc_html__( 'Select background hover color for load more button.', 'risen' ),
		'std'        => '#2e2f36',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination color', 'risen' ),
		'sub_desc'   => esc_html__( 'Select pagination color.', 'risen' ),
		'std'        => '#abacad',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More color', 'risen' ),
		'sub_desc'   => esc_html__( 'Select color for load more button.', 'risen' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_hover_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination hover color', 'risen' ),
		'sub_desc'   => esc_html__( 'Select pagination hover color.', 'risen' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_hover_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More hover color', 'risen' ),
		'sub_desc'   => esc_html__( 'Select hover color for load more button.', 'risen' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'       => 'mts_pagenavigation_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Pagination Margin', 'risen' ),
		'sub_desc' => esc_html__( 'Update pagination margin from here.', 'risen' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '8px',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'         => 'mts_pagenavigation_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Pagination Padding', 'risen' ),
		'sub_desc'   => esc_html__( 'Update pagination padding from here.', 'risen' ),
		'std'        => array(
			'top'    => '10px',
			'right'  => '12px',
			'bottom' => '7px',
			'left'   => '12px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Load More Padding', 'risen' ),
		'sub_desc'   => esc_html__( 'Update padding for load more button from here.', 'risen' ),
		'std'        => array(
			'top'    => '30px',
			'right'  => '30px',
			'bottom' => '27px',
			'left'   => '30px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'       => 'mts_pagenavigation_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Pagination border radius', 'risen' ),
		'sub_desc' => esc_html__( 'Update pagination border radius in px.', 'risen' ),
		'std'      => '0',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'pagenavigation_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'risen' ),
		'sub_desc' => esc_html__( 'Select border', 'risen' ),
	),

);
