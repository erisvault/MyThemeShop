<?php
/**
 * Header Tab
 *
 * @package Risen
 */

$menus['header'] = array(
	'icon'  => 'fa-header',
	'title' => esc_html__( 'Header', 'risen' ),
);

$menus['header']['child']['header-general'] = array(
	'title' => esc_html__( 'General', 'risen' ),
	'desc'  => esc_html__( 'From here, you can control the elements of header section.', 'risen' ),
);

$sections['header-general'] = array(

	array(
		'id'       => 'header_styles',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Header Styling', 'risen' ),
		'sub_desc' => wp_kses( __( 'Choose the <strong>Header design</strong> for your site.', 'risen' ), array( 'strong' => '' ) ),
		'options'  => array(
			'header-default' => array( 'img' => $uri . 'headers/header-default.jpg' ),
			'header-layout2' => array( 'img' => $uri . 'headers/header-layout2.jpg' ),
			'header-layout3' => array( 'img' => $uri . 'headers/header-layout3.jpg' ),
		),
		'std'      => 'header-default',
	),

	array(
		'id'         => 'featured_post_cat',
		'type'       => 'select',
		'data'       => 'category',
		'title'      => esc_html__( 'Featured Category', 'risen' ),
		'sub_desc'   => wp_kses( __( 'Select a category from the drop-down menu, latest article from this category will be shown <strong>in the featured area</strong>.', 'risen' ), array( 'strong' => '' ) ),
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-default',
				'comparison' => '==',
			),
			array(
				'field'      => 'header_styles',
				'value'      => 'header-layout2',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'featured_cat_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Category Color', 'risen' ),
		'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'risen' ),
		'std'      => risen_get_settings( 'primary_color_scheme' ),
	),

	array(
		'id'       => 'mts_sticky_nav',
		'type'     => 'switch',
		'title'    => esc_html__( 'Floating Navigation Menu', 'risen' ),
		// translators: Floating Navigation Menu with strong tag.
		'sub_desc' => sprintf( esc_html__( 'Use this button to enable %s.', 'risen' ), '<strong>' . esc_html__( 'Floating Navigation Menu', 'risen' ) . '</strong>' ),
		'std'      => '0',
	),

	array(
		'id'       => 'mts_header_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Header Margin', 'risen' ),
		'sub_desc' => esc_html__( 'Set header margin from here.', 'risen' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '10px',
			'bottom' => '0',
		),
	),
	array(
		'id'       => 'mts_header_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Header Padding', 'risen' ),
		'sub_desc' => esc_html__( 'Set header padding from here.', 'risen' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '0',
		),
	),

	array(
		'id'       => 'mts_header_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'risen' ),
		'sub_desc' => esc_html__( 'Select border.', 'risen' ),
	),

	array(
		'id'         => 'header_search_box',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Header Search Form', 'risen' ),
		'sub_desc'   => wp_kses( __( 'Use this button to Show or Hide the <strong>Header Search Form</strong> completely.', 'risen' ), array( 'strong' => '' ) ),
		'std'        => '1',
		// 'dependency' => array(
		// 	'relation' => 'or',
		// 	array(
		// 		'field'      => 'header_styles',
		// 		'value'      => 'header-layout3',
		// 		'comparison' => '==',
		// 	),
		// ),
	),

	// array(
	// 	'id'         => 'header_search_position',
	// 	'type'       => 'text',
	// 	'class'      => 'small-text',
	// 	'title'      => esc_html__( 'Search Position from Top', 'risen' ),
	// 	'sub_desc'   => esc_html__( 'Enter search position from top in px.', 'risen' ),
	// 	'std'        => '83',
	// 	'args'       => array( 'type' => 'number' ),
	// 	'dependency' => array(
	// 		'relation' => 'and',
	// 		array(
	// 			'field'      => 'header_styles',
	// 			'value'      => 'header-layout3',
	// 			'comparison' => '==',
	// 		),
	// 	),
	// ),

	array(
		'id'       => 'mts_header_section2',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Logo', 'risen' ),
		'sub_desc' => wp_kses( __( 'Use this button to Show or Hide the <strong>Logo</strong> completely.', 'risen' ), array( 'strong' => '' ) ),
		'std'      => '1',
	),

	array(
		'id'         => 'mts_header_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Header Background', 'risen' ),
		'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'header_styles',
				'value'      => 'header-default',
				'comparison' => '==',
			),
		),
	),

	// array(
	// 	'id'       => 'mts_main_navigation_background',
	// 	'type'     => 'background',
	// 	'title'    => esc_html__( 'Main Navigation Background', 'risen' ),
	// 	'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
	// 	'options'  => array(
	// 		'color'         => '',            // false to disable, not needed otherwise.
	// 		'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
	// 		'image_upload'  => '',            // false to disable, not needed otherwise.
	// 		'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
	// 		'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
	// 		'position'      => array(),       // false to disable, array of options to override default ( optional ).
	// 		'size'          => array(),       // false to disable, array of options to override default ( optional ).
	// 		'gradient'      => '',            // false to disable, not needed otherwise.
	// 		'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
	// 	),
	// 	'std'      => array(
	// 		'color'         => '#2e2f36',
	// 		'use'           => 'pattern',
	// 		'image_pattern' => 'nobg',
	// 		'image_upload'  => '',
	// 		'repeat'        => 'repeat',
	// 		'attachment'    => 'scroll',
	// 		'position'      => 'left top',
	// 		'size'          => 'cover',
	// 		'gradient'      => array(
	// 			'from'      => '#ffffff',
	// 			'to'        => '#000000',
	// 			'direction' => '0deg',
	// 		),
	// 		'parallax'      => '0',
	// 	),
	// ),
	array(
		'id'       => 'main_navigation_dropdown_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Color', 'risen' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'risen' ),
		'std'      => '#000000',
	),
	array(
		'id'       => 'main_navigation_dropdown_hover_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Hover Color', 'risen' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'risen' ),
		'std'      => '#a3a3a3',
	),

);
