<?php
/**
 * HomePage Posts
 *
 * @package Risen
 */

$features = risen_get_settings( 'mts_featured_categories' );
if ( empty( $features ) ) {
	return;
}
foreach ( $features as $feature ) :
	$title        = isset( $feature['mts_featured_title'] ) ? $feature['mts_featured_title'] : 'No Title';
	$posts_layout = isset( $feature['mts_thumb_layout'] ) ? $feature['mts_thumb_layout'] : '';
	if ( 'layout-default' === $posts_layout ) {
		$posts_layout = 'default';
	}
	$unique_id = isset( $feature['unique_id'] ) ? $feature['unique_id'] : '';

	$menus[ 'homepage-' . $unique_id ] = array(
		'title' => $title,
		// translators: description.
		'desc'  => sprintf( wp_kses_post( __( 'From here, you can control the elements of %s', 'risen' ) ), $title ),
	);

	$sections[ 'homepage-' . $unique_id ] = array(

		/**
		 * Layout Default Settings
		 *
		 * @package Risen
		 */

		// Section Title.
		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'risen' ),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'risen' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'risen' ),
			'std'      => '0',
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'risen' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'risen' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'risen' ),
				'center' => esc_html__( 'Center', 'risen' ),
				'right'  => esc_html__( 'Right', 'risen' ),
				'full'   => esc_html__( 'Full Width', 'risen' ),
			),
			'std'        => 'left',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'risen' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'risen' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'risen' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'risen' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'risen' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'risen' ),
			'sub_desc'   => esc_html__( 'Select border', 'risen' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'risen' ),
			'std'        => array(
				'preview-text'   => 'Title Font',
				'preview-color'  => 'light',
				'font-family'    => 'Roboto Condensed',
				'font-weight'    => '700',
				'font-size'      => '26px',
				'color'          => '#000000',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Meta info.
		( 'default' === $posts_layout ) ? array(
			'id'    => 'post_meta_info_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Meta Info', 'risen' ),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'home_meta_info_' . $unique_id,
			'type'     => 'multi_checkbox',
			'title'    => esc_html__( 'Post Meta Info', 'risen' ),
			'sub_desc' => esc_html__( 'Show or hide post meta info.', 'risen' ),
			'options'  => array(
				'author'   => esc_html__( 'Author Name', 'risen' ),
				'category' => esc_html__( 'Category', 'risen' ),
				'comment'  => esc_html__( 'Comments', 'risen' ),
				'time'     => esc_html__( 'Time/Date', 'risen' ),
			),
			'std'      => array(
				'category',
				'author',
				'time',
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'cat_background_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Category Background Color', 'risen' ),
			'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'risen' ),
			'std'      => risen_get_settings( 'primary_color_scheme' ),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'risen' ),
			'sub_desc' => esc_html__( 'Post Meta Info margin.', 'risen' ),
			'std'      => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'risen' ),
			'sub_desc' => esc_html__( 'Post Meta Info padding.', 'risen' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'    => 'meta_info_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Meta Info Typography', 'risen' ),
			'std'   => array(
				'preview-text'   => 'Post Meta Info Font',
				'preview-color'  => 'light',
				'font-family'    => 'Roboto',
				'font-weight'    => '300',
				'font-size'      => '14px',
				'color'          => '#c1c2c4',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .post-info.bottom, .layout-' . $unique_id . ' .latestPost .post-info.bottom a',
			),
		) : null,
		// Post Container.
		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'risen' ),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'risen' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'risen' ),
			'sub_desc' => esc_html__( 'Select border', 'risen' ),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'post_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'risen' ),
			'sub_desc' => esc_html__( 'Post margin.', 'risen' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '56px',
				'bottom' => '35px',
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'post_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'risen' ),
			'sub_desc' => esc_html__( 'Post padding.', 'risen' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'    => 'post_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'risen' ),
			'std'   => array(
				'preview-text'   => 'Post Title Font',
				'preview-color'  => 'light',
				'font-family'    => 'Anton',
				'font-weight'    => '400',
				'font-size'      => '36px',
				'line-height'    => '51px',
				'color'          => '#000000',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'    => 'post_excerpt_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Excerpt Font', 'risen' ),
			'std'   => array(
				'preview-text'  => 'Post Excerpt Font',
				'preview-color' => 'light',
				'font-family'   => 'Roboto',
				'font-weight'   => '300',
				'font-size'     => '16px',
				'line-height'   => '30px',
				'color'         => '#000000',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .front-view-content',
			),
		) : null,

		/**
		 * Layout 1.
		 *
		 * @package Risen
		 */

		// Section Title.
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'risen' ),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'risen' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'risen' ),
			'std'      => '0',
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'risen' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'risen' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'risen' ),
				'center' => esc_html__( 'Center', 'risen' ),
				'right'  => esc_html__( 'Right', 'risen' ),
				'full'   => esc_html__( 'Full Width', 'risen' ),
			),
			'std'        => 'center',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'risen' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'risen' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'risen' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'risen' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'risen' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'risen' ),
			'sub_desc'   => esc_html__( 'Select border', 'risen' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'risen' ),
			'std'        => array(
				'preview-text'   => 'Title Font',
				'preview-color'  => 'light',
				'font-family'    => 'Roboto Condensed',
				'font-weight'    => '700',
				'font-size'      => '26px',
				'color'          => '#000000',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Post Container.
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'risen' ),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'risen' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'risen' ),
			'sub_desc' => esc_html__( 'Select border', 'risen' ),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'post_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'risen' ),
			'sub_desc' => esc_html__( 'Post margin.', 'risen' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '0',
				'bottom' => '0',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'post_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'risen' ),
			'sub_desc' => esc_html__( 'Post padding.', 'risen' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'post_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'risen' ),
			'std'   => array(
				'preview-text'   => 'Post Title Font',
				'preview-color'  => 'light',
				'font-family'    => 'Roboto Condensed',
				'font-weight'    => '700',
				'font-size'      => '22px',
				'line-height'    => '24px',
				'color'          => '#000000',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		) : null,

		/**
		 * Layout 2.
		 *
		 * @package Risen
		 */

		// Section Title.
		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'risen' ),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'risen' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'risen' ),
			'std'      => '0',
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'risen' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'risen' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'risen' ),
				'center' => esc_html__( 'Center', 'risen' ),
				'right'  => esc_html__( 'Right', 'risen' ),
				'full'   => esc_html__( 'Full Width', 'risen' ),
			),
			'std'        => 'center',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'risen' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'risen' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'risen' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'risen' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'risen' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'risen' ),
			'sub_desc'   => esc_html__( 'Select border', 'risen' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'risen' ),
			'std'        => array(
				'preview-text'   => 'Title Font',
				'preview-color'  => 'light',
				'font-family'    => 'Roboto Condensed',
				'font-weight'    => '700',
				'font-size'      => '26px',
				'color'          => '#000000',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Meta info.
		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'post_meta_info_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Meta Info', 'risen' ),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'home_meta_info_' . $unique_id,
			'type'     => 'multi_checkbox',
			'title'    => esc_html__( 'Post Meta Info', 'risen' ),
			'sub_desc' => esc_html__( 'Show or hide post meta info.', 'risen' ),
			'options'  => array(
				'author'   => esc_html__( 'Author Name', 'risen' ),
				'category' => esc_html__( 'Category', 'risen' ),
				'comment'  => esc_html__( 'Comments', 'risen' ),
				'time'     => esc_html__( 'Time/Date', 'risen' ),
			),
			'std'      => array(
				'category',
				'author',
				'time',
			),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'cat_background_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Category Background Color', 'risen' ),
			'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'risen' ),
			'std'      => risen_get_settings( 'primary_color_scheme' ),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'risen' ),
			'sub_desc' => esc_html__( 'Post Meta Info margin.', 'risen' ),
			'std'      => array(
				'top'    => '21px',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'meta_info_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Meta Info Font', 'risen' ),
			'std'   => array(
				'preview-text'   => 'Post Meta Info Font',
				'preview-color'  => 'light',
				'font-family'    => 'Roboto',
				'font-weight'    => '300',
				'font-size'      => '14px',
				'color'          => '#c1c2c4',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .post-info.bottom, .layout-' . $unique_id . ' .latestPost .post-info.bottom a',
			),
		) : null,

		// Post Container.
		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'risen' ),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'risen' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'risen' ),
			'sub_desc' => esc_html__( 'Select border', 'risen' ),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'post_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'risen' ),
			'sub_desc' => esc_html__( 'Post margin.', 'risen' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '0',
				'bottom' => '0',
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'post_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'risen' ),
			'sub_desc' => esc_html__( 'Post padding.', 'risen' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'post_title_length_' . $unique_id,
			'type'     => 'text',
			'class'    => 'small-text',
			'title'    => esc_html__( 'Post Title Length(in words)', 'risen' ),
			'sub_desc' => esc_html__( 'Enter the post title length in words.', 'risen' ),
			'std'      => '3',
			'args'     => array( 'type' => 'number' ),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'post_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'risen' ),
			'std'   => array(
				'preview-text'   => 'Post Title Font',
				'preview-color'  => 'light',
				'font-family'    => 'Anton',
				'font-weight'    => '500',
				'font-size'      => '50px',
				'line-height'    => '74px',
				'color'          => '#000000',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'post_excerpt_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Excerpt Font', 'risen' ),
			'std'   => array(
				'preview-text'  => 'Post Excerpt Font',
				'preview-color' => 'light',
				'font-family'   => 'Roboto',
				'font-weight'   => '300',
				'font-size'     => '16px',
				'line-height'   => '32px',
				'color'         => '#000000',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .front-view-content',
			),
		) : null,

		/**
		 * Layout 3.
		 *
		 * @package Risen
		 */

		// Meta info.
		( 'layout-3' === $posts_layout ) ? array(
			'id'    => 'post_meta_info_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Meta Info', 'risen' ),
		) : null,

		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'home_meta_info_' . $unique_id,
			'type'     => 'multi_checkbox',
			'title'    => esc_html__( 'Post Meta Info', 'risen' ),
			'sub_desc' => esc_html__( 'Show or hide post meta info.', 'risen' ),
			'options'  => array(
				'author'   => esc_html__( 'Author Name', 'risen' ),
				'category' => esc_html__( 'Category', 'risen' ),
				'comment'  => esc_html__( 'Comments', 'risen' ),
				'time'     => esc_html__( 'Time/Date', 'risen' ),
			),
			'std'      => array(
				'category',
			),
		) : null,

		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'cat_background_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Category Background Color', 'risen' ),
			'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'risen' ),
			'std'      => risen_get_settings( 'primary_color_scheme' ),
		) : null,

		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'risen' ),
			'sub_desc' => esc_html__( 'Post Meta Info margin.', 'risen' ),
			'std'      => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'    => 'meta_info_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Meta Info Font', 'risen' ),
			'std'   => array(
				'preview-text'   => 'Post Meta Info Font',
				'preview-color'  => 'light',
				'font-family'    => 'Roboto',
				'font-weight'    => '300',
				'font-size'      => '14px',
				'color'          => '#c1c2c4',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .post-info.bottom, .layout-' . $unique_id . ' .latestPost .post-info.bottom a',
			),
		) : null,

		// Post Container.
		( 'layout-3' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'risen' ),
		) : null,

		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'risen' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'risen' ),
			'sub_desc' => esc_html__( 'Select border', 'risen' ),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'post_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'risen' ),
			'sub_desc' => esc_html__( 'Post margin.', 'risen' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '64',
				'bottom' => '0',
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'post_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'risen' ),
			'sub_desc' => esc_html__( 'Post padding.', 'risen' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'layout-3' === $posts_layout ) ? array(
			'id'    => 'post_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'risen' ),
			'std'   => array(
				'preview-text'   => 'Post Title Font',
				'preview-color'  => 'light',
				'font-family'    => 'Anton',
				'font-weight'    => '400',
				'font-size'      => '64px',
				'line-height'    => '68px',
				'color'          => '#000000',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		) : null,

		/**
		 * Layout 4.
		 *
		 * @package Risen
		 */

		// Section Title.
		( 'layout-4' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'risen' ),
		) : null,

		( 'layout-4' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'risen' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'risen' ),
			'std'      => '0',
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'risen' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'risen' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'risen' ),
				'center' => esc_html__( 'Center', 'risen' ),
				'right'  => esc_html__( 'Right', 'risen' ),
				'full'   => esc_html__( 'Full Width', 'risen' ),
			),
			'std'        => 'left',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'risen' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'risen' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'risen' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'risen' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'risen' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'risen' ),
			'sub_desc'   => esc_html__( 'Select border', 'risen' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-4' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'risen' ),
			'std'        => array(
				'preview-text'   => 'Title Font',
				'preview-color'  => 'light',
				'font-family'    => 'Roboto Condensed',
				'font-weight'    => '700',
				'font-size'      => '26px',
				'color'          => '#000000',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Meta info.
		( 'layout-4' === $posts_layout ) ? array(
			'id'    => 'post_meta_info_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Meta Info', 'risen' ),
		) : null,

		( 'layout-4' === $posts_layout ) ? array(
			'id'       => 'home_meta_info_' . $unique_id,
			'type'     => 'multi_checkbox',
			'title'    => esc_html__( 'Post Meta Info', 'risen' ),
			'sub_desc' => esc_html__( 'Show or hide post meta info.', 'risen' ),
			'options'  => array(
				'author'   => esc_html__( 'Author Name', 'risen' ),
				'category' => esc_html__( 'Category', 'risen' ),
				'comment'  => esc_html__( 'Comments', 'risen' ),
				'time'     => esc_html__( 'Time/Date', 'risen' ),
			),
			'std'      => array(
				'category',
				'author',
				'time',
			),
		) : null,

		( 'layout-4' === $posts_layout ) ? array(
			'id'       => 'cat_background_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Category Background Color', 'risen' ),
			'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'risen' ),
			'std'      => risen_get_settings( 'primary_color_scheme' ),
		) : null,

		( 'layout-4' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'risen' ),
			'sub_desc' => esc_html__( 'Post Meta Info margin.', 'risen' ),
			'std'      => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'risen' ),
			'sub_desc' => esc_html__( 'Post Meta Info padding.', 'risen' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'layout-4' === $posts_layout ) ? array(
			'id'    => 'meta_info_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Meta Info Typography', 'risen' ),
			'std'   => array(
				'preview-text'   => 'Post Meta Info Font',
				'preview-color'  => 'light',
				'font-family'    => 'Roboto',
				'font-weight'    => '300',
				'font-size'      => '14px',
				'color'          => '#c1c2c4',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .post-info.bottom, .layout-' . $unique_id . ' .latestPost .post-info.bottom a',
			),
		) : null,
		// Post Container.
		( 'layout-4' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'risen' ),
		) : null,

		( 'layout-4' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'risen' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'risen' ),
			'sub_desc' => esc_html__( 'Select border', 'risen' ),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'       => 'post_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'risen' ),
			'sub_desc' => esc_html__( 'Post margin.', 'risen' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '65px',
				'bottom' => '35px',
			),
		) : null,
		( 'layout-4' === $posts_layout ) ? array(
			'id'       => 'post_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'risen' ),
			'sub_desc' => esc_html__( 'Post padding.', 'risen' ),
			'std'      => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
		) : null,

		( 'layout-4' === $posts_layout ) ? array(
			'id'    => 'post_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'risen' ),
			'std'   => array(
				'preview-text'   => 'Post Title Font',
				'preview-color'  => 'light',
				'font-family'    => 'Anton',
				'font-weight'    => '400',
				'font-size'      => '40px',
				'line-height'    => '44px',
				'color'          => '#000000',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		) : null,

		( 'layout-4' === $posts_layout ) ? array(
			'id'    => 'post_excerpt_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Excerpt Font', 'risen' ),
			'std'   => array(
				'preview-text'  => 'Post Excerpt Font',
				'preview-color' => 'light',
				'font-family'   => 'Roboto',
				'font-weight'   => '300',
				'font-size'     => '16px',
				'line-height'   => '30px',
				'color'         => '#000000',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .front-view-content',
			),
		) : null,

		/**
		 * Layout 5.
		 *
		 * @package Risen
		 */

		// Section Title.
		( 'layout-5' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'risen' ),
		) : null,

		( 'layout-5' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'risen' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'risen' ),
			'std'      => '1',
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'risen' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'risen' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'risen' ),
				'center' => esc_html__( 'Center', 'risen' ),
				'right'  => esc_html__( 'Right', 'risen' ),
				'full'   => esc_html__( 'Full Width', 'risen' ),
			),
			'std'        => 'center',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'risen' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => risen_get_settings( 'primary_color_scheme' ),
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'         => 'post_title_shadow' . $unique_id,
			'type'       => 'switch',
			'title'      => esc_html__( 'Box Shadow', 'risen' ),
			'sub_desc'   => esc_html__( 'Use this button to show or hide box shadow in post container.', 'risen' ),
			'std'        => '1',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'risen' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'risen' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '47px',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'risen' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'risen' ),
			'std'        => array(
				'top'    => '10px',
				'right'  => '50px',
				'bottom' => '10px',
				'left'   => '50px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'risen' ),
			'sub_desc'   => esc_html__( 'Select border', 'risen' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-5' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'risen' ),
			'std'        => array(
				'preview-text'  => 'Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Roboto',
				'font-weight'   => '700',
				'font-size'     => '26px',
				'color'         => '#2e2f36',
				'css-selectors' => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Post Container.
		( 'layout-5' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'risen' ),
		) : null,

		( 'layout-5' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'risen' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'risen' ),
			'sub_desc' => esc_html__( 'Select border', 'risen' ),
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'       => 'post_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'risen' ),
			'sub_desc' => esc_html__( 'Post margin.', 'risen' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '50',
				'bottom' => '0',
			),
		) : null,
		( 'layout-5' === $posts_layout ) ? array(
			'id'       => 'post_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'risen' ),
			'sub_desc' => esc_html__( 'Post padding.', 'risen' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'layout-5' === $posts_layout ) ? array(
			'id'    => 'small_post_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'risen' ),
			'std'   => array(
				'preview-text'  => 'Post Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Roboto',
				'font-weight'   => '700',
				'font-size'     => '22px',
				'line-height'   => '30px',
				'color'         => '#2e2f36',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		) : null,

		/**
		 * Layout Partners.
		 *
		 * @package Risen
		 */

		( 'layout-partners' === $posts_layout ) ? array(
			'id'        => 'partners_section_' . $unique_id,
			'type'      => 'group',
			'title'     => esc_html__( 'Partners Items', 'risen' ),
			'groupname' => esc_html__( 'Partner Item', 'risen' ),
			'subfields' => array(
				array(
					'id'    => 'partner_title',
					'type'  => 'text',
					'title' => esc_html__( 'Title', 'risen' ),
				),
				array(
					'id'       => 'partner_image',
					'type'     => 'upload',
					'title'    => esc_html__( 'Image', 'risen' ),
					'sub_desc' => esc_html__( 'Upload or select an image for partner. Recommended Size(190X70px)', 'risen' ),
				),
				array(
					'id'       => 'partner_url',
					'type'     => 'text',
					'title'    => esc_html__( 'Link', 'risen' ),
					'sub_desc' => esc_html__( 'Insert a link URL of partner', 'risen' ),
					'std'      => '#',
				),
			),
		) : null,

		// Section Title.
		( 'layout-partners' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'risen' ),
		) : null,

		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'risen' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'risen' ),
			'std'      => '1',
		) : null,

		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'partner_section_title_' . $unique_id,
			'type'       => 'text',
			'title'      => esc_html__( 'Section Title', 'risen' ),
			'sub_desc'   => esc_html__( 'Partners section title.', 'risen' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'partners_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Partners Title Font', 'risen' ),
			'std'        => array(
				'preview-text'   => 'Partners Title Font',
				'preview-color'  => 'dark',
				'font-family'    => 'Anton',
				'font-weight'    => '400',
				'font-size'      => '16px',
				'line-height'    => '19px',
				'color'          => '#2e2f36',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.article.layout-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'risen' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'risen' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'risen' ),
				'center' => esc_html__( 'Center', 'risen' ),
				'right'  => esc_html__( 'Right', 'risen' ),
				'full'   => esc_html__( 'Full Width', 'risen' ),
			),
			'std'        => 'full',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'risen' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '#ffffff',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'post_title_shadow' . $unique_id,
			'type'       => 'switch',
			'title'      => esc_html__( 'Box Shadow', 'risen' ),
			'sub_desc'   => esc_html__( 'Use this button to show or hide box shadow in post container.', 'risen' ),
			'std'        => '1',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'risen' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'risen' ),
			'left'       => false,
			'right'      => false,
			'std'        => array(
				'top'    => '0',
				'bottom' => '-80px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'risen' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'risen' ),
			'std'        => array(
				'left'   => '40px',
				'top'    => '40px',
				'right'  => '40px',
				'bottom' => '40px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'risen' ),
			'sub_desc'   => esc_html__( 'Select border', 'risen' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Post Container.
		( 'layout-partners' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'risen' ),
		) : null,

		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'risen' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'risen' ),
			'sub_desc' => esc_html__( 'Select border', 'risen' ),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'post_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'risen' ),
			'sub_desc' => esc_html__( 'Post margin.', 'risen' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '0',
				'bottom' => '35px',
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'post_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'risen' ),
			'sub_desc' => esc_html__( 'Post padding.', 'risen' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		/**
		 * Layout Category.
		 *
		 * @package Risen
		 */

		( 'layout-category' === $posts_layout ) ? array(
			'id'        => 'cat_section_' . $unique_id,
			'type'      => 'group',
			'title'     => esc_html__( 'Category items', 'risen' ),
			'sub_desc'  => esc_html__( 'Add category Item from here', 'risen' ),
			'groupname' => esc_html__( 'Category item', 'risen' ),
			'subfields' => array(
				array(
					'id'    => 'cat_section_title',
					'type'  => 'text',
					'title' => esc_html__( 'Title', 'risen' ),
				),
				array(
					'id'       => 'cat_section_category',
					'type'     => 'select',
					'title'    => esc_html__( 'Category', 'risen' ),
					'sub_desc' => esc_html__( 'Select a category for this section', 'risen' ),
					'data'     => 'category',
				),
				array(
					'id'       => 'cat_section_image',
					'type'     => 'upload',
					'title'    => esc_html__( 'Image', 'risen' ),
					'sub_desc' => esc_html__( 'Upload or select an image for category. Recommended Size(365X287px)', 'risen' ),
				),
				array(
					'id'    => 'cat_section_background',
					'type'  => 'color',
					'title' => esc_html__( 'Select overlay color for your category', 'risen' ),
					'args'  => array( 'opacity' => true ),
					'std'   => 'rgba(0, 0, 0, 0.3)',
				),
				array(
					'id'    => 'cat_section_hover_background',
					'type'  => 'color',
					'title' => esc_html__( 'Select overlay hover color for your category', 'risen' ),
					'args'  => array( 'opacity' => true ),
					'std'   => 'rgba(0, 0, 0, 0.6)',
				),
			),
		) : null,

		// Post Container.
		( 'layout-category' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'risen' ),
		) : null,

		( 'layout-category' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'risen' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-category' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'risen' ),
			'sub_desc' => esc_html__( 'Select border', 'risen' ),
		) : null,
		( 'layout-category' === $posts_layout ) ? array(
			'id'       => 'post_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'risen' ),
			'sub_desc' => esc_html__( 'Post margin.', 'risen' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '0',
				'bottom' => '35px',
			),
		) : null,
		( 'layout-category' === $posts_layout ) ? array(
			'id'       => 'post_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'risen' ),
			'sub_desc' => esc_html__( 'Post padding.', 'risen' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		/**
		 * Layout Subscribe.
		 *
		 * @package Risen
		 */

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_size_' . $unique_id,
			'type'     => 'button_set',
			'title'    => esc_html__( 'Section Size', 'risen' ),
			'sub_desc' => esc_html__( 'Select the size of subscribe widget.', 'risen' ),
			'options'  => array(
				'full'      => esc_html__( 'Full', 'risen' ),
				'container' => esc_html__( 'Container', 'risen' ),
			),
			'std'      => 'full',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_alignment_' . $unique_id,
			'type'     => 'button_set',
			'title'    => esc_html__( 'Alignment', 'risen' ),
			'sub_desc' => esc_html__( 'Alignment of subscribe widget content', 'risen' ),
			'options'  => array(
				'left'   => esc_html__( 'Left', 'risen' ),
				'center' => esc_html__( 'Center', 'risen' ),
				'right'  => esc_html__( 'Right', 'risen' ),
			),
			'std'      => 'center',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Title Typography', 'risen' ),
			'std'   => array(
				'preview-text'   => 'Title Font',
				'preview-color'  => 'dark',
				'font-family'    => 'Anton',
				'font-weight'    => '400',
				'font-size'      => '64px',
				'line-height'    => '68px',
				'color'          => '#ffffff',
				'additional-css' => 'text-transform: uppercase!important;',
				'css-selectors'  => '.layout-' . $unique_id . ' #sidebar .widget #wp-subscribe .title',
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_input_background_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Input Fields Background Color', 'risen' ),
			'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'risen' ),
			'std'      => '#ffffff',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_input_size_' . $unique_id,
			'type'     => 'button_set',
			'title'    => esc_html__( 'Input Field Size', 'risen' ),
			'sub_desc' => esc_html__( 'Select the size of input fields.', 'risen' ),
			'options'  => array(
				'large' => esc_html__( 'Large', 'risen' ),
				'small' => esc_html__( 'Small', 'risen' ),
			),
			'std'      => 'large',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_input_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Input Fields Typography', 'risen' ),
			'std'   => array(
				'preview-text'   => 'Input Fields Font',
				'preview-color'  => 'dark',
				'font-family'    => 'Roboto Condensed',
				'font-weight'    => '300',
				'font-size'      => '18px',
				'color'          => '#000000',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .layout-subscribe #wp-subscribe input.email-field, .layout-' . $unique_id . ' .layout-subscribe #wp-subscribe input.name-field',
			),
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_text_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Text Typography', 'risen' ),
			'std'   => array(
				'preview-text'  => 'Text Font',
				'preview-color' => 'dark',
				'font-family'   => 'Roboto',
				'font-weight'   => '300',
				'font-size'     => '16px',
				'line-height'   => '30px',
				'color'         => '#ffffff',
				'css-selectors' => '.layout-' . $unique_id . ' .layout-subscribe #sidebar #wp-subscribe p.text, .layout-' . $unique_id . ' #sidebar .subscribe-icons-container p',
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_small_text_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Small Text Typography', 'risen' ),
			'std'   => array(
				'preview-text'  => 'Small Text Font',
				'preview-color' => 'dark',
				'font-family'   => 'Roboto',
				'font-weight'   => '300',
				'font-size'     => '13px',
				'color'         => '#ffffff',
				'css-selectors' => '.layout-' . $unique_id . ' .layout-subscribe #sidebar .wp-subscribe-wrap p.footer-text, .layout-' . $unique_id . ' .layout-subscribe #sidebar .widget .wp-subscribe .wps-consent-wrapper label',
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_submit_background_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Submit Button Background Color', 'risen' ),
			'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'risen' ),
			'std'      => '#2a3137',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_submit_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Submit Button Typography', 'risen' ),
			'std'   => array(
				'preview-text'  => 'Submit Button Font',
				'preview-color' => 'dark',
				'font-family'   => 'Roboto Condensed',
				'font-weight'   => '700',
				'font-size'     => '18px',
				'color'         => '#ffffff',
				'css-selectors' => '.layout-' . $unique_id . ' .widget #wp-subscribe input.submit',
			),
		) : null,

		// Post Container.
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'risen' ),
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'risen' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '#e52737',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'risen' ),
			'sub_desc' => esc_html__( 'Select border', 'risen' ),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'post_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'risen' ),
			'sub_desc' => esc_html__( 'Post margin.', 'risen' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '57px',
				'bottom' => '0',
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'post_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'risen' ),
			'sub_desc' => esc_html__( 'Post padding.', 'risen' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '110px',
				'right'  => '0',
				'bottom' => '93px',
			),
		) : null,

		/**
		 * Layout Ad.
		 *
		 * @package Risen
		 */

		( 'layout-banner' === $posts_layout ) ? array(
			'id'       => 'adcode_' . $unique_id,
			'type'     => 'ace_editor',
			'mode'     => 'html',
			'title'    => esc_html__( 'Ad Code', 'risen' ),
			'sub_desc' => esc_html__( 'Paste your Adsense, BSA or other ad code here to show ads.', 'risen' ),
		) : null,

		// Post Container.
		( 'layout-banner' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'risen' ),
		) : null,

		( 'layout-banner' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'risen' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-banner' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'risen' ),
			'sub_desc' => esc_html__( 'Select border', 'risen' ),
		) : null,
		( 'layout-banner' === $posts_layout ) ? array(
			'id'       => 'post_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'risen' ),
			'sub_desc' => esc_html__( 'Post margin.', 'risen' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '40px',
				'bottom' => '0',
			),
		) : null,
		( 'layout-banner' === $posts_layout ) ? array(
			'id'       => 'post_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'risen' ),
			'sub_desc' => esc_html__( 'Post padding.', 'risen' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

	);
endforeach;
