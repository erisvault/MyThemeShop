<?php
/**
 * Top Bar
 *
 * @package Risen
 */

$menus['header']['child']['header-sliding-nav'] = array(
	'title' => esc_html__( 'Sliding Menu', 'risen' ),
	'desc'  => esc_html__( 'From here, you can control the Sliding Menu.', 'risen' ),
);

$sections['header-sliding-nav'] = array(

	array(
		'id'       => 'show_sliding_nav',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Sliding Menu', 'risen' ),
		// translators: Sliding Navigation Menu with strong tag.
		'sub_desc' => sprintf( esc_html__( 'Use this button to enable %s.', 'risen' ), '<strong>' . esc_html__( 'Sliding Navigation Menu', 'risen' ) . '</strong>' ),
		'std'      => '0',
	),

	array(
		'id'         => 'mts_top_bar_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Sliding Menu Background', 'risen' ),
		'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_sliding_nav',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'sliding_navigation_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Sliding Navigation', 'risen' ),
		'std'        => array(
			'preview-text'   => 'Sliding Navigation Font',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto Condensed',
			'font-weight'    => '700',
			'font-size'      => '20px',
			'color'          => '#000000',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '#sliding-menu a',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_sliding_nav',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

);
