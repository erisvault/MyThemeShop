<?php
/**
 * Navigation
 *
 * @package Risen
 */

$menus['footer']['child']['footer-logo'] = array(
	'title' => esc_html__( 'Footer Logo Section', 'risen' ),
	'desc'  => esc_html__( 'From here, you can control footer logo and social icons.', 'risen' ),
);

$sections['footer-logo'] = array(

	array(
		'id'       => 'footer_logo_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Footer Logo and Social icons', 'risen' ),
		'sub_desc' => esc_html__( 'Enable or disable Footer Logo and Social icons with this option.', 'risen' ),
		'std'      => '1',
	),

	array(
		'id'         => 'footer_logo',
		'type'       => 'upload',
		'title'      => esc_html__( 'Footer Logo', 'risen' ),
		'sub_desc'   => esc_html__( 'Select an image file for your footer logo.', 'risen' ),
		'return'     => 'id',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_risen_logo',
		'type'       => 'typography',
		'title'      => esc_html__( 'Logo Font', 'risen' ),
		'std'        => array(
			'preview-text'  => 'Logo',
			'preview-color' => 'dark',
			'font-family'   => 'Anton',
			'font-weight'   => '700',
			'font-size'     => '38px',
			'color'         => '#ffffff',
			'css-selectors' => '.footer #logo a',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_social_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Social Icons', 'risen' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_logo_social_icons',
		'type'       => 'switch',
		'title'      => esc_html__( 'Social Icons', 'risen' ),
		'sub_desc'   => esc_html__( 'Enable or disable social icons with this option.', 'risen' ),
		'std'        => '1',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_logo_social',
		'title'      => esc_html__( 'Footer Social Icons', 'risen' ),
		'sub_desc'   => esc_html__( 'Add Social Media icons in footer logo section.', 'risen' ),
		'type'       => 'group',
		'groupname'  => esc_html__( 'Social Icons', 'risen' ), // Group name.
		'subfields'  => array(
			array(
				'id'    => 'footer_logo_social_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'risen' ),
			),
			array(
				'id'    => 'footer_logo_social_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Icon', 'risen' ),
			),
			array(
				'id'    => 'footer_logo_social_link',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'risen' ),
			),
			array(
				'id'    => 'footer_logo_social_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Background color', 'risen' ),
			),
			array(
				'id'    => 'footer_logo_social_hover_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Background hover color', 'risen' ),
			),
			array(
				'id'    => 'footer_logo_social_color',
				'type'  => 'color',
				'title' => esc_html__( 'Icon color', 'risen' ),
			),
			array(
				'id'    => 'footer_logo_social_hover_color',
				'type'  => 'color',
				'title' => esc_html__( 'Icon hover color', 'risen' ),
			),
			array(
				'id'    => 'footer_logo_social_margin',
				'type'  => 'margin',
				'title' => esc_html__( 'Margin', 'risen' ),
			),
			array(
				'id'    => 'footer_logo_social_padding',
				'type'  => 'margin',
				'title' => esc_html__( 'Padding', 'risen' ),
			),
			array(
				'id'    => 'footer_logo_social_border_radius',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Border radius', 'risen' ),
				'args'  => array( 'type' => 'number' ),
			),
			array(
				'id'    => 'footer_logo_social_border_size',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Border Size', 'risen' ),
				'args'  => array( 'type' => 'number' ),
			),
			array(
				'id'      => 'footer_logo_social_border_style',
				'type'    => 'select',
				'title'   => esc_html__( 'Border Style', 'risen' ),
				'options' => array(
					'none'   => esc_html__( 'None', 'risen' ),
					'solid'  => esc_html__( 'Solid', 'risen' ),
					'dotted' => esc_html__( 'Dotted', 'risen' ),
					'dashed' => esc_html__( 'Dashed', 'risen' ),
					'double' => esc_html__( 'Double', 'risen' ),
					'groove' => esc_html__( 'Groove', 'risen' ),
					'ridge'  => esc_html__( 'Ridge', 'risen' ),
					'inset'  => esc_html__( 'Inset', 'risen' ),
					'outset' => esc_html__( 'Outset', 'risen' ),
				),
			),
			array(
				'id'    => 'footer_logo_social_border_color',
				'type'  => 'color',
				'title' => esc_html__( 'Border Color', 'risen' ),
			),
		),
		'std'        => array(
			'facebook'  => array(
				'group_title'                      => 'Facebook',
				'group_sort'                       => '1',
				'footer_logo_social_title'         => 'Facebook',
				'footer_logo_social_icon'          => 'facebook-square',
				'footer_logo_social_link'          => '#',
				'footer_logo_social_bgcolor'       => '',
				'footer_logo_social_hover_bgcolor' => '',
				'footer_logo_social_color'         => risen_get_settings( 'primary_color_scheme' ),
				'footer_logo_social_hover_color'   => '#ffffff',
				'footer_logo_social_margin'        => array(
					'top'    => '0',
					'right'  => '22px',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_border_radius' => '0',
				'footer_logo_social_border_size'   => '1',
				'footer_logo_social_border_style'  => 'none',
				'footer_logo_social_border_color'  => '#dddddd',
			),
			'twitter'   => array(
				'group_title'                      => 'Twitter',
				'group_sort'                       => '2',
				'footer_logo_social_title'         => 'Twitter',
				'footer_logo_social_icon'          => 'twitter',
				'footer_logo_social_link'          => '#',
				'footer_logo_social_bgcolor'       => '',
				'footer_logo_social_hover_bgcolor' => '',
				'footer_logo_social_color'         => risen_get_settings( 'primary_color_scheme' ),
				'footer_logo_social_hover_color'   => '#ffffff',
				'footer_logo_social_margin'        => array(
					'top'    => '0',
					'right'  => '22px',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_border_radius' => '0',
				'footer_logo_social_border_size'   => '1',
				'footer_logo_social_border_style'  => 'none',
				'footer_logo_social_border_color'  => '#dddddd',
			),
			'instagram' => array(
				'group_title'                      => 'Instagram',
				'group_sort'                       => '3',
				'footer_logo_social_title'         => 'Instagram',
				'footer_logo_social_icon'          => 'instagram',
				'footer_logo_social_link'          => '#',
				'footer_logo_social_bgcolor'       => '',
				'footer_logo_social_hover_bgcolor' => '',
				'footer_logo_social_color'         => risen_get_settings( 'primary_color_scheme' ),
				'footer_logo_social_hover_color'   => '#ffffff',
				'footer_logo_social_margin'        => array(
					'top'    => '0',
					'right'  => '22px',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_border_radius' => '0',
				'footer_logo_social_border_size'   => '1',
				'footer_logo_social_border_style'  => 'none',
				'footer_logo_social_border_color'  => '#dddddd',
			),
			'youtube'   => array(
				'group_title'                      => 'Youtube',
				'group_sort'                       => '4',
				'footer_logo_social_title'         => 'Youtube',
				'footer_logo_social_icon'          => 'youtube',
				'footer_logo_social_link'          => '#',
				'footer_logo_social_bgcolor'       => '',
				'footer_logo_social_hover_bgcolor' => '',
				'footer_logo_social_color'         => risen_get_settings( 'primary_color_scheme' ),
				'footer_logo_social_hover_color'   => '#ffffff',
				'footer_logo_social_margin'        => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_logo_social_border_radius' => '0',
				'footer_logo_social_border_size'   => '1',
				'footer_logo_social_border_style'  => 'none',
				'footer_logo_social_border_color'  => '#dddddd',
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_social_icons',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'footer_logo_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_logo_social_font_size',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Font Size', 'risen' ),
		'sub_desc'   => esc_html__( 'Set font size of footer nav social icons in px.', 'risen' ),
		'std'        => '22',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_social_icons',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'footer_logo_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

);
