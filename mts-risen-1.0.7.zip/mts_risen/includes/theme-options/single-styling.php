<?php
/**
 * Single Styling
 *
 * @package Risen
 */

$menus['single-styling'] = array(
	'title' => esc_html__( 'Single Styling', 'risen' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of your single posts page.', 'risen' ),
);

$sections['single-styling'] = array(

	array(
		'id'    => 'single_title_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Single Titles Styling', 'risen' ),
	),

	array(
		'id'       => 'single_title_alignment',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Single Page Title Alignment', 'risen' ),
		'sub_desc' => esc_html__( 'Choose the single page title alignment', 'risen' ),
		'options'  => array(
			'left'   => esc_html__( 'Left', 'risen' ),
			'center' => esc_html__( 'Center', 'risen' ),
			'right'  => esc_html__( 'Right', 'risen' ),
		),
		'std'      => 'left',
	),

	array(
		'id'       => 'single_title_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Single Page Title Background Color', 'risen' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'risen' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'single_title_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Page Title Padding', 'risen' ),
		'sub_desc' => esc_html__( 'Set single page title padding from here.', 'risen' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_title_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'risen' ),
		'sub_desc' => esc_html__( 'Select border', 'risen' ),
	),
	array(
		'id'    => 'single_page_titles_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Section Title Typography', 'risen' ),
		'std'   => array(
			'preview-text'  => 'Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '700',
			'font-size'     => '20px',
			'line-height'   => '24px',
			'color'         => '#000000',
			'css-selectors' => '#respond h4, .total-comments',
		),
	),

	array(
		'id'    => 'mts_single_styling_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Single Styling', 'risen' ),
	),

	array(
		'id'       => 'single_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Background', 'risen' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image of Single, Page, Archive, Search, Category and 404 Page from here.', 'risen' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'mts_single_styling_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Margin', 'risen' ),
		'sub_desc' => esc_html__( 'Set single post margin from here.', 'risen' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '35px',
		),
	),
	array(
		'id'       => 'mts_single_styling_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Padding', 'risen' ),
		'sub_desc' => esc_html__( 'Set single post padding from here.', 'risen' ),
		'std'      => array(
			'top'    => '50px',
			'right'  => '65px',
			'bottom' => '35px',
			'left'   => '65px',
		),
	),
	array(
		'id'       => 'single_styling_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'risen' ),
		'sub_desc' => esc_html__( 'Select border', 'risen' ),
	),
	array(
		'id'    => 'mts_single_meta_info_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Single Meta Info Font', 'risen' ),
		'std'   => array(
			'preview-text'  => 'Post Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '500',
			'font-size'     => '14px',
			'color'         => '#000000',
			'css-selectors' => '.single_post .post-info.bottom, .single_post .post-info.bottom a, .single-full-header .post-info, .single-full-header .post-info.bottom a, .reply, #comments .ago',
		),
	),

);
