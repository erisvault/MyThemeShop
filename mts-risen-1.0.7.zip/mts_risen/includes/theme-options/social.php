<?php
/**
 * Social Tab
 *
 * @package Risen
 */

$menus['social'] = array(
	'icon'  => 'fa-users',
	'title' => esc_html__( 'Social Share', 'risen' ),
	'desc'  => esc_html__( 'Enable or disable social sharing buttons on single posts using these buttons.', 'risen' ),
);

$menus['social']['child']['social-general'] = array(
	'title' => esc_html__( 'General', 'risen' ),
	'desc'  => esc_html__( 'From here, you can control the elements of social sharing buttons.', 'risen' ),
);

$sections['social-general'] = array(

	array(
		'id'       => 'social_button_layout',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Social Sharing Buttons Layout', 'risen' ),
		'sub_desc' => wp_kses( __( 'Choose default <strong>social sharing buttons</strong> layout or modern <strong>social sharing buttons</strong> layout for your site. ', 'risen' ), array( 'strong' => array() ) ),
		'options'  => array(
			'default'  => array( 'img' => $uri . 'social/default.jpg' ),
			'standard' => array( 'img' => $uri . 'social/standard.jpg' ),
			'circular' => array( 'img' => $uri . 'social/circular.jpg' ),
		),
		'std'      => 'standard',
	),

	array(
		'id'       => 'mts_social_button_position',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Social Sharing Buttons Position', 'risen' ),
		'options'  => array(
			'top'      => esc_html__( 'Above Content', 'risen' ),
			'bottom'   => esc_html__( 'Below Content', 'risen' ),
			'floating' => esc_html__( 'Floating', 'risen' ),
		),
		'sub_desc' => esc_html__( 'Choose position for Social Sharing Buttons.', 'risen' ),
		'std'      => 'floating',
		'class'    => 'green',
	),

	array(
		'id'       => 'mts_social_buttons_on_pages',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Social Sharing Buttons on Pages', 'risen' ),
		'options'  => array(
			'0' => esc_html__( 'Off', 'risen' ),
			'1' => esc_html__( 'On', 'risen' ),
		),
		'sub_desc' => esc_html__( 'Enable the sharing buttons for pages too, not just posts.', 'risen' ),
		'std'      => '0',
	),

	array(
		'id'       => 'mts_social_buttons',
		'type'     => 'layout',
		'title'    => esc_html__( 'Social Media Buttons', 'risen' ),
		'sub_desc' => esc_html__( 'Organize how you want the social sharing buttons to appear on single posts', 'risen' ),
		'options'  => array(
			'enabled'  => array(
				'facebookshare' => esc_html__( 'Facebook Share', 'risen' ),
				'twitter'       => esc_html__( 'Twitter', 'risen' ),
				'pinterest'     => esc_html__( 'Pinterest', 'risen' ),
			),
			'disabled' => array(
				'facebook' => esc_html__( 'Facebook Like', 'risen' ),
				'linkedin' => esc_html__( 'LinkedIn', 'risen' ),
				'stumble'  => esc_html__( 'StumbleUpon', 'risen' ),
				'reddit'   => esc_html__( 'Reddit', 'risen' ),
				'gplus'    => esc_html__( 'Google Plus', 'risen' ),
			),
		),
		'std'      => array(
			'enabled'  => array(
				'facebookshare' => esc_html__( 'Facebook Share', 'risen' ),
				'twitter'       => esc_html__( 'Twitter', 'risen' ),
				'pinterest'     => esc_html__( 'Pinterest', 'risen' ),
			),
			'disabled' => array(
				'facebook' => esc_html__( 'Facebook Like', 'risen' ),
				'linkedin' => esc_html__( 'LinkedIn', 'risen' ),
				'stumble'  => esc_html__( 'StumbleUpon', 'risen' ),
				'reddit'   => esc_html__( 'Reddit', 'risen' ),
				'gplus'    => esc_html__( 'Google Plus', 'risen' ),
			),
		),
	),

);
