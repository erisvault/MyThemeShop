<?php
/**
 * Sidebar Tab
 *
 * @package Risen
 */

$menus['sidebars-general'] = array(
	'title' => esc_html__( 'Sidebars', 'risen' ),
	'icon'  => 'fa-columns',
	'desc'  => esc_html__( 'Now you have full control over the sidebars. Here you can manage sidebars and select one for each section of your site, or select a custom sidebar on a per-post basis in the post editor.', 'risen' ),
);

$sections['sidebars-general'] = array(

	array(
		'id'        => 'mts_custom_sidebars',
		'type'      => 'group', // Doesn't need to be called for callback fields.
		'title'     => esc_html__( 'Custom Sidebars', 'risen' ),
		'sub_desc'  => wp_kses( __( 'Add custom sidebars. <strong style="font-weight: 800;">You need to save the changes to use the sidebars in the dropdowns below.</strong><br />You can add content to the sidebars in Appearance &gt; Widgets.', 'risen' ), array(
			'strong' => '',
			'br'     => '',
		) ),
		'groupname' => esc_html__( 'Sidebar', 'risen' ), // Group name.
		'subfields' => array(
			array(
				'id'       => 'mts_custom_sidebar_name',
				'type'     => 'text',
				'title'    => esc_html__( 'Name', 'risen' ),
				'sub_desc' => esc_html__( 'Example: Homepage Sidebar', 'risen' ),
			),
			array(
				'id'       => 'mts_custom_sidebar_id',
				'type'     => 'text',
				'title'    => esc_html__( 'ID', 'risen' ),
				'sub_desc' => esc_html__( 'Enter a unique ID for the sidebar. Use only alphanumeric characters, underscores (_) and dashes (-), eg. "sidebar-home"', 'risen' ),
				'std'      => 'sidebar-',
			),
		),
	),

	array(
		'id'       => 'mts_sidebar_for_home',
		'type'     => 'select',
		'data'     => 'sidebars',
		'title'    => esc_html__( 'Homepage', 'risen' ),
		'sub_desc' => esc_html__( 'Select a sidebar for the homepage.', 'risen' ),
		'args'     => array(
			'allow_nosidebar' => false,
			'exclude'         => risen_excluded_sidebars(),
		),
		'std'      => '',
	),

	array(
		'id'       => 'mts_sidebar_for_post',
		'type'     => 'select',
		'data'     => 'sidebars',
		'title'    => esc_html__( 'Single Post', 'risen' ),
		'sub_desc' => esc_html__( 'Select a sidebar for the single posts. If a post has a custom sidebar set, it will override this.', 'risen' ),
		'args'     => array(
			'exclude' => risen_excluded_sidebars(),
		),
		'std'      => '',
	),

	array(
		'id'       => 'mts_sidebar_for_page',
		'type'     => 'select',
		'data'     => 'sidebars',
		'title'    => esc_html__( 'Single Page', 'risen' ),
		'sub_desc' => esc_html__( 'Select a sidebar for the single pages. If a page has a custom sidebar set, it will override this.', 'risen' ),
		'args'     => array(
			'exclude' => risen_excluded_sidebars(),
		),
		'std'      => '',
	),

	array(
		'id'       => 'mts_sidebar_for_archive',
		'type'     => 'select',
		'data'     => 'sidebars',
		'title'    => esc_html__( 'Archive', 'risen' ),
		'sub_desc' => esc_html__( 'Select a sidebar for the archives. Specific archive sidebars will override this setting (see below).', 'risen' ),
		'args'     => array(
			'allow_nosidebar' => false,
			'exclude'         => risen_excluded_sidebars(),
		),
		'std'      => '',
	),

	array(
		'id'       => 'mts_sidebar_for_category',
		'type'     => 'select',
		'data'     => 'sidebars',
		'title'    => esc_html__( 'Category Archive', 'risen' ),
		'sub_desc' => esc_html__( 'Select a sidebar for the category archives.', 'risen' ),
		'args'     => array(
			'allow_nosidebar' => false,
			'exclude'         => risen_excluded_sidebars(),
		),
		'std'      => '',
	),

	array(
		'id'       => 'mts_sidebar_for_tag',
		'type'     => 'select',
		'data'     => 'sidebars',
		'title'    => esc_html__( 'Tag Archive', 'risen' ),
		'sub_desc' => esc_html__( 'Select a sidebar for the tag archives.', 'risen' ),
		'args'     => array(
			'allow_nosidebar' => false,
			'exclude'         => risen_excluded_sidebars(),
		),
		'std'      => '',
	),

	array(
		'id'       => 'mts_sidebar_for_date',
		'type'     => 'select',
		'data'     => 'sidebars',
		'title'    => esc_html__( 'Date Archive', 'risen' ),
		'sub_desc' => esc_html__( 'Select a sidebar for the date archives.', 'risen' ),
		'args'     => array(
			'allow_nosidebar' => false,
			'exclude'         => risen_excluded_sidebars(),
		),
		'std'      => '',
	),

	array(
		'id'       => 'mts_sidebar_for_author',
		'type'     => 'select',
		'data'     => 'sidebars',
		'title'    => esc_html__( 'Author Archive', 'risen' ),
		'sub_desc' => esc_html__( 'Select a sidebar for the author archives.', 'risen' ),
		'args'     => array(
			'allow_nosidebar' => false,
			'exclude'         => risen_excluded_sidebars(),
		),
		'std'      => '',
	),

	array(
		'id'       => 'mts_sidebar_for_search',
		'type'     => 'select',
		'data'     => 'sidebars',
		'title'    => esc_html__( 'Search', 'risen' ),
		'sub_desc' => esc_html__( 'Select a sidebar for the search results.', 'risen' ),
		'args'     => array(
			'allow_nosidebar' => false,
			'exclude'         => risen_excluded_sidebars(),
		),
		'std'      => '',
	),

	array(
		'id'       => 'mts_sidebar_for_notfound',
		'type'     => 'select',
		'data'     => 'sidebars',
		'title'    => esc_html__( '404 Error', 'risen' ),
		'sub_desc' => esc_html__( 'Select a sidebar for the 404 Not found pages.', 'risen' ),
		'args'     => array(
			'allow_nosidebar' => false,
			'exclude'         => risen_excluded_sidebars(),
		),
		'std'      => '',
	),

	array(
		'id'       => 'mts_sidebar_for_shop',
		'type'     => 'select',
		'data'     => 'sidebars',
		'title'    => esc_html__( 'Shop Pages', 'risen' ),
		'sub_desc' => wp_kses( __( 'Select a sidebar for Shop main page and product archive pages (WooCommerce plugin must be enabled). Default is <strong>Shop Page Sidebar</strong>.', 'risen' ), array( 'strong' => '' ) ),
		'args'     => array(
			'allow_nosidebar' => false,
			'exclude'         => risen_excluded_sidebars(),
		),
		'std'      => '',
	),

	array(
		'id'       => 'mts_sidebar_for_product',
		'type'     => 'select',
		'data'     => 'sidebars',
		'title'    => esc_html__( 'Single Product', 'risen' ),
		'sub_desc' => wp_kses( __( 'Select a sidebar for single products (WooCommerce plugin must be enabled). Default is <strong>Single Product Sidebar</strong>.', 'risen' ), array( 'strong' => '' ) ),
		'args'     => array(
			'allow_nosidebar' => false,
			'exclude'         => risen_excluded_sidebars(),
		),
		'std'      => '',
	),
);
