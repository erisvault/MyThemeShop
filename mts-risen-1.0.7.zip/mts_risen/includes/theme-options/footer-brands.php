<?php
/**
 * Brands
 *
 * @package Risen
 */

$menus['footer']['child']['footer-brands'] = array(
	'title' => esc_html__( 'Brands Section', 'risen' ),
	'desc'  => esc_html__( 'From here, you can control the Brands Section.', 'risen' ),
);

$sections['footer-brands'] = array(

	array(
		'id'       => 'footer_brands_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Brands Section', 'risen' ),
		'sub_desc' => esc_html__( 'Enable or disable Brands Section with this option.', 'risen' ),
		'std'      => '0',
	),

	array(
		'id'         => 'footer_brands_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Brands Section Alignment', 'risen' ),
		'sub_desc'   => esc_html__( 'Choose alignment of Brands Section.', 'risen' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'risen' ),
			'center' => esc_html__( 'Center', 'risen' ),
			'right'  => esc_html__( 'Right', 'risen' ),
		),
		'std'        => 'center',
		'class'      => 'green',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'brands_section_title',
		'type'       => 'text',
		'title'      => esc_html__( 'Brands Title', 'risen' ),
		'sub_desc'   => esc_html__( 'Enter brands title here.', 'risen' ),
		'std'        => esc_html__( 'Our Brands:', 'risen' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),

	),

	array(
		'id'         => 'footer_brands_items',
		'type'       => 'group',
		'title'      => esc_html__( 'Brands', 'risen' ),
		'groupname'  => esc_html__( 'Brand', 'risen' ), // Group name.
		'subfields'  => array(
			array(
				'id'       => 'brand_title',
				'type'     => 'text',
				'title'    => esc_html__( 'Title', 'risen' ),
				'sub_desc' => esc_html__( 'The title will not be shown.', 'risen' ),
			),
			array(
				'id'       => 'brand_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Image', 'risen' ),
				'sub_desc' => esc_html__( 'Upload or select an image for brand', 'risen' ),
			),
			array(
				'id'       => 'brand_url',
				'type'     => 'text',
				'title'    => esc_html__( 'Link', 'risen' ),
				'sub_desc' => esc_html__( 'Insert a link URL of brand', 'risen' ),
				'std'      => '#',
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'brands_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'risen' ),
		'sub_desc'   => esc_html__( 'Brands Section margin.', 'risen' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'brands_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'risen' ),
		'sub_desc'   => esc_html__( 'Brands Section padding.', 'risen' ),
		'std'        => array(
			'top'    => '40px',
			'right'  => '0',
			'bottom' => '27px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'brands_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'risen' ),
		'sub_desc'   => esc_html__( 'Select border', 'risen' ),
		'std'        => array(
			'direction' => 'top',
			'size'      => '1',
			'style'     => 'solid',
			'color'     => '#008b3e',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
);
