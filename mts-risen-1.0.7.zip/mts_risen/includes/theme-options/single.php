<?php
/**
 * Single Tab
 *
 * @package Risen
 */

$menus['single-general'] = array(
	'title' => esc_html__( 'General', 'risen' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of your single posts page.', 'risen' ),
);

$sections['single-general'] = array(

	array(
		'id'       => 'mts_show_featured',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Featured image', 'risen' ),
		'sub_desc' => esc_html__( 'Enable/Disable the Featured images in the single post.', 'risen' ),
		'std'      => '1',
	),
	array(
		'id'       => 'featured_image_size',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Header Size', 'risen' ),
		'sub_desc' => esc_html__( 'Choose the featured image size', 'risen' ),
		'options'  => array(
			'default' => esc_html__( 'Content Size', 'risen' ),
			'full'    => esc_html__( 'Full Width', 'risen' ),
		),
		'std'      => 'default',
	),
	array(
		'id'         => 'featured_image_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Header Image Margin', 'risen' ),
		'sub_desc'   => esc_html__( 'Set header image margin from here.', 'risen' ),
		'std'        => array(
			'top'    => '-35px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'featured_text_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Alignment', 'risen' ),
		'sub_desc'   => esc_html__( 'Choose the featured image text alignment', 'risen' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'risen' ),
			'center' => esc_html__( 'Center', 'risen' ),
			'right'  => esc_html__( 'Right', 'risen' ),
		),
		'std'        => 'left',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'show_prev_next',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show preview and next article buttons', 'risen' ),
		'sub_desc'   => esc_html__( 'Use this button to show or hide preview and next article buttons.', 'risen' ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_single_post_layout',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Post Layout', 'risen' ),
		'sub_desc' => esc_html__( 'Customize the look of single posts', 'risen' ),
		'options'  => array(
			'enabled'  => array(
				'content' => array(
					'label'     => esc_html__( 'Post Content', 'risen' ),
					'subfields' => array(),
				),
				'tags'    => array(
					'label'     => esc_html__( 'Tags', 'risen' ),
					'subfields' => array(),
				),
				'author'  => array(
					'label'     => esc_html__( 'Author Box', 'risen' ),
					'subfields' => array(),
				),
				'related' => array(
					'label'     => esc_html__( 'Related Posts', 'risen' ),
					'subfields' => array(
						array(
							'id'       => 'related_post_title',
							'type'     => 'text',
							'title'    => esc_html__( 'Related Posts Title', 'risen' ),
							'sub_desc' => esc_html__( 'Enter the title text to show in the related posts section.', 'risen' ),
							'std'      => 'See More Posts',

						),
						array(
							'id'       => 'mts_related_posts_taxonomy',
							'type'     => 'switch',
							'title'    => esc_html__( 'Related Posts Taxonomy', 'risen' ),
							'options'  => array(
								'tags'       => esc_html__( 'Tags', 'risen' ),
								'categories' => esc_html__( 'Categories', 'risen' ),
							),
							'class'    => 'green',
							'sub_desc' => esc_html__( 'Related Posts based on tags or categories.', 'risen' ),
							'std'      => 'categories',
						),
					),
				),
			),
			'disabled' => array(
				'subscribe' => array(
					'label'     => esc_html__( 'Subscribe Box', 'risen' ),
					'subfields' => array(),
				),
			),
		),
	),

	array(
		'id'       => 'single_meta_info',
		'type'     => 'multi_checkbox',
		'title'    => esc_html__( 'Single Post Meta Info', 'schema' ),
		'sub_desc' => esc_html__( 'Select single post meta info from here.', 'schema' ),
		'options'  => array(
			'author'   => esc_html__( 'Author Name', 'schema' ),
			'comment'  => esc_html__( 'Comments', 'schema' ),
			'time'     => esc_html__( 'Time/Date', 'schema' ),
			'category' => esc_html__( 'Category', 'schema' ),
		),
		'std'      => array(
			'author',
			'comment',
			'category',
		),
	),

	array(
		'id'       => 'mts_breadcrumb',
		'type'     => 'switch',
		'title'    => esc_html__( 'Breadcrumbs', 'risen' ),
		'sub_desc' => esc_html__( 'Breadcrumbs are a great way to make your site more user-friendly. You can enable them by checking this box.', 'risen' ),
		'std'      => '0',
	),

	array(
		'id'         => 'breadcrumb_icon',
		'type'       => 'icon_select',
		'title'      => esc_html__( 'Icon', 'risen' ),
		'sub_desc'   => esc_html__( 'Select divider icons from here.', 'risen' ),
		'std'        => 'angle-right',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'breadcrumb_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Breadcrumbs Font', 'risen' ),
		'std'        => array(
			'preview-text'  => 'Breadcrumbs',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'color'         => '#2e2f36',
			'css-selectors' => '.breadcrumb, .rank-math-breadcrumb',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_author_comment',
		'type'     => 'switch',
		'title'    => esc_html__( 'Highlight Author Comment', 'risen' ),
		'sub_desc' => esc_html__( 'Use this button to highlight author comments.', 'risen' ),
		'std'      => '1',
	),

	array(
		'id'       => 'mts_comment_date',
		'type'     => 'switch',
		'title'    => esc_html__( 'Date in Comments', 'risen' ),
		'sub_desc' => esc_html__( 'Use this button to show the date for comments.', 'risen' ),
		'std'      => '1',
	),
);
