<?php
/**
 * Single Subscribe
 *
 * @package Risen
 */

$menus['single-authorbox'] = array(
	'title' => esc_html__( 'Author Box', 'risen' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of Author box in single posts page.', 'risen' ),
);

$mts_patterns = array(
	'nobg' => array( 'img' => $uri . 'bg-patterns/nobg.png' ),
);
for ( $i = 0; $i <= 52; $i++ ) {
	$mts_patterns[ 'pattern' . $i ] = array( 'img' => $uri . 'bg-patterns/pattern' . $i . '.png' );
}

for ( $i = 1; $i <= 29; $i++ ) {
	$mts_patterns[ 'hbg' . $i ] = array( 'img' => $uri . 'bg-patterns/hbg' . $i . '.png' );
}

$sections['single-authorbox'] = array(

	array(
		'id'    => 'single_authorbox_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Author box Settings', 'risen' ),
	),
	array(
		'id'       => 'single_authorbox_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Author box Background', 'risen' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image for subscribe box from here.', 'risen' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'author_box_title',
		'type'     => 'text',
		'title'    => esc_html__( 'Author Box Title', 'risen' ),
		'sub_desc' => esc_html__( 'Enter author box title.', 'risen' ),
		'std'      => '',
	),
	array(
		'id'       => 'single_authorbox_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Margin', 'risen' ),
		'sub_desc' => esc_html__( 'Set Author box margin from here.', 'risen' ),
		'std'      => array(
			'top'    => '35px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_authorbox_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'risen' ),
		'sub_desc' => esc_html__( 'Set Author box padding from here.', 'risen' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_authorbox_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'risen' ),
		'sub_desc' => esc_html__( 'Author box border radius.', 'risen' ),
		'std'      => '0',
		'args'     => array( 'type' => 'number' ),
	),

	array(
		'id'    => 'single_authorbox_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Author Box Title Font', 'risen' ),
		'std'   => array(
			'preview-text'  => 'Author Box Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '700',
			'font-size'     => '20px',
			'line-height'   => '24px',
			'color'         => '#000000',
			'css-selectors' => '.postauthor h4',
		),
	),
	array(
		'id'    => 'single_authorbox_author_name_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Author Box Name Font', 'risen' ),
		'std'   => array(
			'preview-text'  => 'Author Box Name Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '700',
			'font-size'     => '22px',
			'line-height'   => '24px',
			'color'         => '#959595',
			'css-selectors' => '.postauthor h5, .postauthor h5 a',
		),
	),
	array(
		'id'    => 'single_authorbox_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Author Box Text Font', 'risen' ),
		'std'   => array(
			'preview-text'  => 'Author Box Text Font',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '24px',
			'color'         => '#959595',
			'css-selectors' => '.postauthor p',
		),
	),

	array(
		'id'    => 'single_author_img_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Author Image Settings', 'risen' ),
	),
	array(
		'id'       => 'single_author_image_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Margin', 'risen' ),
		'sub_desc' => esc_html__( 'Set Author image margin from here.', 'risen' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '26px',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_author_image_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'risen' ),
		'sub_desc' => esc_html__( 'Author image border radius.', 'risen' ),
		'std'      => '100',
		'args'     => array( 'type' => 'number' ),
	),

);
