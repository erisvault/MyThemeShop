	</form>

	<?php
		risen_action( 'options-page_after_form' );
		risen_action( 'options_page_after_form_' . $this->args['opt_name'] );
	?>

	<div class="clear"></div>

</div><!--/wrap-->
