<?php
/**
 * Tweaks for the footer of the document.
 *
 * @package Risen
 */

defined( 'WPINC' ) || exit;

/**
 * Tweaks for the <head> of the document.
 */
class Risen_Footer extends Risen_Base {

	/**
	 * Constructor
	 */
	public function __construct() {

		$this->add_action( 'wp_footer', 'tracking_field', 999 );
	}

	/**
	 * Add tracking field code
	 */
	public function tracking_field() {
		echo risen_get_settings( 'mts_analytics_code' );
	}
}

/**
 * Init
 */
new Risen_Footer;
