<?php
/**
 * The template for displaying search results pages.
 *
 * @package Risen
 */

get_header(); ?>

	<div id="wrapper">

		<div class="container">

			<div class="article">

				<?php risen_action( 'before_content' ); ?>

				<div id="content_box">

					<?php if ( have_posts() ) : ?>

						<h1 class="page-title">
							<?php
							// translators: search query.
							printf( esc_html__( 'Search Results for: %s', 'risen' ), '<span>' . get_search_query() . '</span>' );
							?>
						</h1>
					<?php else : ?>
						<h1 class="page-title"><?php esc_html_e( 'Nothing Found', 'risen' ); ?></h1>
					<?php endif; ?>

					<?php
					if ( 'above' === risen_get_settings( 'search_position' ) ) {
						get_search_form();
					}

					$j = 0;
					if ( have_posts() ) {
						while ( have_posts() ) {
							the_post();
							risen_blog_articles( 'default' );
						}
					} else {
						get_template_part( 'template-parts/no', 'results' );
					}

					if ( 0 !== $j ) {
						risen_pagination( risen_get_settings( 'mts_pagenavigation_type' ) );
					}

					if ( 'below' === risen_get_settings( 'search_position' ) ) {
						get_search_form();
					}
					?>
				</div>

				<?php risen_action( 'after_content' ); ?>

			</div>

			<?php get_sidebar(); ?>

		</div>

<?php
get_footer();
