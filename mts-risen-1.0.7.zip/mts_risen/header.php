<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="page">
 *
 * @package Risen
 */

?><!doctype html>
<html<?php risen_attr( 'html' ); ?>>
<head<?php risen_attr( 'head' ); ?>>
	<?php wp_head(); ?>
</head>

<body<?php risen_attr( 'body' ); ?>>

	<?php get_template_part( 'template-parts/header/clickable', 'background' ); ?>

	<div<?php risen_attr( 'main' ); ?>>

		<?php risen_action( 'before_wrapper' ); ?>
