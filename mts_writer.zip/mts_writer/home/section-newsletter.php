<?php $mts_options = get_option(MTS_THEME_NAME); ?>

<section class="newsletter clearfix" style="<?php echo mts_get_background_styles( 'mts_subscription_box_background' ); ?> color: <?php echo $mts_options['mts_subscription_box_text_color']; ?>">
	<div class="container clearfix">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar( 'homepage' ) ) : ?><?php endif; ?>
	</div>
	<svg class="svg-content" viewBox="0 0 500 450" preserveAspectRatio="xMinYMin meet" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" style="position: absolute; top: 0; right: -4px; height: 755px; opacity: 0.1;">
		<g class="grid y-grid" id="yGrid">
			<line x1="1" x2="500" y1="1" y2="1"></line>
			<line x1="1" x2="500" y1="50" y2="50"></line>
			<line x1="1" x2="500" y1="100" y2="100"></line>
			<line x1="1" x2="500" y1="150" y2="150"></line>
			<line x1="1" x2="500" y1="200" y2="200"></line>
			<line x1="1" x2="500" y1="250" y2="250"></line>
			<line x1="1" x2="500" y1="300" y2="300"></line>
			<line x1="1" x2="500" y1="350" y2="350"></line>
			<line x1="1" x2="500" y1="400" y2="400"></line>
			<line x1="1" x2="500" y1="449" y2="449"></line>
		</g>
		<path id="traffic-line" fill="transparent" stroke="#666" stroke-width="3" stroke-miterlimit="10" d="M0,292 L50,287 L150,332 L250,259 L350,216 L450,125 L500,30" style="stroke-dashoffset: 0px; stroke-dasharray: 635.133, 635.133;"></path>
		<g class="svg-group" id="traffic-group" style="opacity: 1;">
			<circle fill="#FFFFFF" stroke="#666" stroke-width="3" stroke-miterlimit="10" cx="50" cy="287" r="6.5"></circle>
			<circle fill="#FFFFFF" stroke="#666" stroke-width="4" stroke-miterlimit="10" cx="150" cy="332" r="10.5"></circle>
			<circle fill="#FFFFFF" stroke="#666" stroke-width="3" stroke-miterlimit="10" cx="250" cy="259" r="6.5"></circle>
			<circle fill="#FFFFFF" stroke="#666" stroke-width="3" stroke-miterlimit="10" cx="350" cy="216" r="6.5"></circle>
			<circle fill="#FFFFFF" stroke="#666" stroke-width="4" stroke-miterlimit="10" cx="450" cy="125" r="10.5"></circle>
		</g>
	</svg>
</section>