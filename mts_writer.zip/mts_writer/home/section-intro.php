<?php $mts_options = get_option(MTS_THEME_NAME); ?>

<section class="intro clearfix" style="<?php echo mts_get_background_styles( 'mts_intro_background' ); ?>">
	<div class="container clearfix" style="background-image: url('<?php echo $mts_options['mts_intro_image']; ?>')">
		<div class="intro-text">
			<h2 style="color:<?php echo $mts_options['mts_intro_heading_color']; ?>"><?php echo $mts_options['mts_intro_heading']; ?></h2>
			<p style="color:<?php echo $mts_options['mts_intro_sub_heading_color']; ?>"><?php echo $mts_options['mts_intro_sub_heading']; ?></p>
		</div>
	</div>
</section>