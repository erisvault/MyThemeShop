<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly.


if ( ! function_exists( 'wre_create_user' ) ) {

	/**
	 * Create a new customer.
	 *
	 * @param  string $user_email Customer email.
	 * @param  string $username Customer username.
	 * @param  string $password Customer password.
	 * @return int|WP_Error Returns WP_Error on failure, Int (user ID) on success.
	 */
	function wre_create_user( $user_email, $username = '', $password = '' ) {
		global $current_user;
		$flag = false;
		$message = '';

		if ( empty( $user_email ) ) {
			$message = __( 'Invalid email address.', 'wp-real-estate' );
		} else if ( ! is_email( $user_email ) ) {
			$message = __( 'Your email address isn&#8217;t correct.', 'wp-real-estate' );
		} else if ( email_exists( $user_email ) ) {
			$message = __( 'This email is already registered, please choose another one.', 'wp-real-estate' );
		} else {
			if( ! empty( $username ) ) {
				if ( empty( $username ) || ! validate_username( $username ) ) {
					$message = __( 'Please enter a valid account username.', 'wp-real-estate' );
				}

				if ( username_exists( $username ) ) {
					$message =  __( 'An account is already registered with that username. Please choose another.', 'wp-real-estate' );
				}
			} else {
				$username = sanitize_user( current( explode( '@', $user_email ) ) );

				// Ensure username is unique
				$append     = 1;
				$o_username = $username;

				while ( username_exists( $username ) ) {
					$username = $o_username . $append;
					$append ++;
				}
			}
		}

		if( $message == '' ) {
			$email    = apply_filters( 'user_registration_email', sanitize_email( $user_email ) );
			$password = wp_generate_password();
			// Create account
			$new_user = array(
				'user_login' => $username,
				'user_pass'  => $password,
				'user_email' => $email,
				'role'       => 'subscriber',
			);
			$user_id = wp_insert_user( apply_filters( 'wre_create_account_data', $new_user ) );
			if ( is_wp_error( $user_id ) ) {
				$message = $user_id->get_error_message();
			} else {

				/**
				 * Send notification to new users.
				 *
				 * @since 1.28.0
				 *
				 * @param  int         $user_id
				 * @param  string|bool $password
				 * @param  array       $new_user {
				 *     Information about the new user.
				 *
				 *     @type string $user_login Username for the user.
				 *     @type string $user_pass  Password for the user (may be blank).
				 *     @type string $user_email Email for the new user account.
				 *     @type string $role       New user's role.
				 * }
				 */
				wp_new_user_notification( $user_id, null, 'both' );
				// Login
				wp_set_auth_cookie( $user_id, true, is_ssl() );
				$current_user = get_user_by( 'id', $user_id );
				$flag = true;
				$message = __( 'You are currently signed in as ', 'wp-real-estate' ).$username;
			}
		}

		$user_data = array( 'flag' => $flag, 'message' => $message );
		return $user_data;
	}
}

if ( ! function_exists( 'wre_get_account_menu_items' ) ) {
	/**
	 * Get My Account menu items.
	 * @return array
	 */
	function wre_get_account_menu_items() {
		$my_account_link = wre_get_account_page_link();
		$query_vars = array(
			'edit-account'			=> wre_get_account_endpoint('edit_account'),
			'edit-profile'			=> wre_get_account_endpoint('edit_profile'),
			'subscription-details'	=> wre_get_account_endpoint('subscription')
		);
		$items = array(
			'dashboard'       => array( 'endpoint' => 'dashboard', 'text' => __( 'Dashboard', 'wp-real-estate' ), 'link' => $my_account_link ),
			'my-listings'       => array( 'endpoint' => 'my-listings', 'text' => __( 'My Listings', 'wp-real-estate' ), 'link' => get_permalink(wre_option('wre_my_listings')) ),
			'add-new-listing'       => array( 'endpoint' => 'add-new-listing', 'text' => __( 'Add New Listing', 'wp-real-estate' ), 'link' => get_permalink(wre_option('submit_listings')) ),
			'edit-account'       => array( 'endpoint' => $query_vars['edit-account'], 'text' => __( 'Edit Account', 'wp-real-estate' ), 'link' => wre_get_account_endpoint_page_link('edit_account') ),
			'edit-profile'       => array( 'endpoint' => $query_vars['edit-profile'], 'text' => __( 'Edit Profile', 'wp-real-estate' ), 'link' => wre_get_account_endpoint_page_link('edit_profile') ),
			'customer-logout' => array( 'endpoint' => 'customer-logout', 'text' => __( 'Logout', 'wp-real-estate' ), 'link' => wp_logout_url( $my_account_link ) ),
		);
		if( wre_is_subscriber() ) {
			$subscription_details = array( 'endpoint' => $query_vars['subscription-details'], 'text' => __( 'Subscription', 'wp-real-estate' ), 'link' => wre_get_account_endpoint_page_link('subscription') );
			array_splice($items, 2, 0, array($subscription_details));
		}
		return apply_filters( 'wre_account_menu_items', $items );
	}
}

if ( ! function_exists( 'wre_get_account_page_link' ) ) {
	/**
	 * Get My Account page link.
	 * @return array
	 */
	function wre_get_account_page_link() {
		$my_account_page = wre_option('wre_account_page');
		$permalink = 0 < $my_account_page ? get_permalink( $my_account_page ) : get_home_url();
		return apply_filters( 'wre_get_account_page_permalink', $permalink );
	}
}

if ( ! function_exists( 'wre_get_account_endpoint_page_link' ) ) {
	/**
	 * Get My Account endpoint page link.
	 * @return array
	 */
	function wre_get_account_endpoint_page_link( $endpoint_name ) {
		$my_account_page = wre_option('wre_account_page');
		$permalink = wre_get_account_page_link().wre_get_account_endpoint($endpoint_name);
		return apply_filters( 'wre_get_'.$endpoint_name.'_permalink', $permalink );
	}
}

if ( ! function_exists( 'wre_get_account_endpoint' ) ) {
	/**
	 * Get My Account endpoint.
	 * @return array
	 */
	function wre_get_account_endpoint( $endpoint_name ) {
		$endpoint = wre_option('wre_account_endpoint_'.$endpoint_name);
		return apply_filters( 'wre_get_account_endpoint_'.$endpoint_name, $endpoint );
	}
}

/**
 * Get account menu item classes.
 *
 */
function wre_get_account_menu_item_classes( $endpoint ) {
	global $wp;

	$classes = array(
		'wre-account-navigation-link',
		'wre-account-navigation-link-' . $endpoint,
	);

	// Set current item class.
	$current = isset( $wp->query_vars[ $endpoint ] );
	if ( 'dashboard' === $endpoint && ( isset( $wp->query_vars['page'] ) || empty( $wp->query_vars ) ) ) {
		$current = true; // Dashboard is not an endpoint, so needs a custom check.
	}

	if ( $current ) {
		$classes[] = 'is-active';
	}

	$classes = apply_filters( 'wre_account_menu_item_classes', $classes, $endpoint );

	return implode( ' ', array_map( 'sanitize_html_class', $classes ) );
}