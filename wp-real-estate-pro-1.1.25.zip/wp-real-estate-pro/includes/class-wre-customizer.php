<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

if (!class_exists('WRE_Customizer')) :

	/**
	 * WRE Customizer
	 * @version 0.1.0
	 */
	class WRE_Customizer {

		protected static $_instance = null;
		private $capability = 'edit_theme_options';
		private $type = 'option';

		public static function instance($wp_customize) {

			if (is_null(self::$_instance)) {
				self::$_instance = new self();
			}
			self::$_instance->init_hooks();
			self::$_instance->set_options($wp_customize);

			return self::$_instance;
		}

		private function set_options($wp_customize) {

			$options = $this->get_options();
			$i = 0;
			$capability = $this->capability;
			$type = $this->type;
			if ($options) {

				foreach ($options as $option) {

					// Add panel
					if ($option['type'] == 'panel') {

						$priority = ( isset($option['priority']) ) ? $option['priority'] : $i + 10;
						$theme_supports = ( isset($option['theme_supports']) ) ? $option['theme_supports'] : '';
						$title = ( isset($option['title']) ) ? esc_attr($option['title']) : __('Untitled Panel', 'wp-real-estate');
						$description = ( isset($option['description']) ) ? esc_attr($option['description']) : '';

						$wp_customize->add_panel($option['id'], array(
							'priority' => $priority,
							'capability' => $capability,
							'theme_supports' => $theme_supports,
							'title' => $title,
							'description' => $description,
						));
					}

					// Add sections
					if ($option['type'] == 'section') {

						$priority = ( isset($option['priority']) ) ? $option['priority'] : $i + 10;
						$theme_supports = ( isset($option['theme_supports']) ) ? $option['theme_supports'] : '';
						$title = ( isset($option['title']) ) ? esc_attr($option['title']) : __('Untitled Section', 'wp-real-estate');
						$description = ( isset($option['description']) ) ? esc_attr($option['description']) : '';
						$panel = ( isset($option['panel']) ) ? esc_attr($option['panel']) : '';

						$wp_customize->add_section(esc_attr($option['id']), array(
							'priority' => $priority,
							'capability' => $capability,
							'theme_supports' => $theme_supports,
							'title' => $title,
							'description' => $description,
							'panel' => $panel,
						));
					}

					// Add controls
					if ($option['type'] == 'control') {

						$priority = ( isset($option['priority']) ) ? $option['priority'] : $i + 10;
						$section = ( isset($option['section']) ) ? esc_attr($option['section']) : '';
						$default = ( isset($option['default']) ) ? $option['default'] : '';
						$transport = ( isset($option['transport']) ) ? esc_attr($option['transport']) : 'refresh';
						$title = ( isset($option['title']) ) ? esc_attr($option['title']) : __('Untitled Section', 'wp-real-estate');
						$description = ( isset($option['description']) ) ? esc_attr($option['description']) : '';
						$form_field = ( isset($option['option']) ) ? esc_attr($option['option']) : 'option';
						$sanitize_callback = ( isset($option['sanitize_callback']) ) ? esc_attr($option['sanitize_callback']) : '';
						$placeholder = ( isset($option['placeholder']) ) ? esc_attr($option['placeholder']) : '';

						// Add control settings
						$wp_customize->add_setting(esc_attr($option['id']), array(
							'default' => $default,
							'type' => $type,
							'capability' => $capability,
							'transport' => $transport,
							'sanitize_callback' => $sanitize_callback,
						));
						// Add form field
						switch ($form_field) {

							// Customize Icons Field
							case 'custom-icons':

								$choices = ( isset($option['choices']) ) ? $option['choices'] : array();
								$wp_customize->add_control(new WP_Customize_Icons_Control($wp_customize, esc_attr($option['id']), array(
									'priority' => $priority,
									'section' => $section,
									'label' => $title,
									'description' => $description,
									'choices' => $choices
								)));

								break;

							// Select Field
							case 'select':
								$choices = ( isset($option['choices']) ) ? $option['choices'] : array();

								$wp_customize->add_control(esc_attr($option['id']), array(
									'type' => 'select',
									'priority' => $priority,
									'section' => $section,
									'label' => $title,
									'description' => $description,
									'choices' => $choices,
								));
								break;

							// Color Picker Field
							case 'color':
								$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, esc_attr($option['id']), array(
									'priority' => $priority,
									'section' => $section,
									'label' => $title,
									'description' => $description,
								)));
								break;

							// Number Field
							case 'number':
								$wp_customize->add_control(esc_attr($option['id']), array(
									'type' => 'number',
									'priority' => $priority,
									'section' => $section,
									'label' => $title,
									'description' => $description,
									'min' => 2,
									'max' => 5,
								));
								break;

							default :
								$wp_customize->add_control(esc_attr($option['id']), array(
									'type' => 'text',
									'priority' => $priority,
									'section' => $section,
									'label' => $title,
									'description' => $description,
									'input_attrs' => array(
										'placeholder' => $placeholder,
									)
								));
						}
					}
				}
			}
		}

		private function get_options() {
			/**
			 * Here we will set the options we are going to have in the customizer.
			 */
			$options = array(); // If you delete this line, the sky will fall down! So you better don't.

			/* ------------------------ Panels ------------------------ */

			$options[] = array(
				'title' => __('WP Real Estate Listings', 'wp-real-estate'), // Panel name
				'id' => 'wre_listings', // unique ID
				'priority' => 10,
				'theme_supports' => '',
				'type' => 'panel'
			);

			/* ------------------------ Sections ------------------------ */

			$options[] = array(
				'title' => __('Appearance', 'wp-real-estate'), // Section name
				'panel' => 'wre_listings', // panel
				'id' => 'wre_appearance', // unique ID
				'theme_supports' => '',
				'type' => 'section'
			);

			$options[] = array(
				'title' => __('Listing Statuses', 'wp-real-estate'), // Section name
				'panel' => 'wre_listings', // panel
				'id' => 'wre_listing_statuses', // unique ID
				'theme_supports' => '',
				'type' => 'section'
			);

			$options[] = array(
				'title' => __('Gallery Settings', 'wp-real-estate'), // Section name
				'panel' => 'wre_listings', // panel
				'id' => 'wre_gallery_settings', // unique ID
				'theme_supports' => '',
				'type' => 'section'
			);

			$options[] = array(
				'title' => __('Icons', 'wp-real-estate'), // Section name
				'panel' => 'wre_listings', // panel
				'id' => 'wre_icons', // unique ID
				'theme_supports' => '',
				'type' => 'section'
			);

			/* ------------------------ Controllers ------------------------ */

			// Icons Color
			$options[] = array(
				'title' => __('Icon Color', 'wp-real-estate'), // Controller label
				'section' => 'wre_appearance', // section
				'id' => 'wre_icons_color', // unique ID
				'default' => $this->wre_get_default_color('wre_icons_color'), // HEX
				'option' => 'color',
				'sanitize_callback' => 'sanitize_hex_color',
				'type' => 'control',
			);

			// Sidebar Headings
			$options[] = array(
				'title' => __('Sidebar Headings', 'wp-real-estate'), // Controller label
				'section' => 'wre_appearance', // section
				'id' => 'wre_sidebar_headings_color', // unique ID
				'default' => $this->wre_get_default_color('wre_sidebar_headings_color'), // HEX
				'option' => 'color',
				'sanitize_callback' => 'sanitize_hex_color',
				'type' => 'control',
			);

			// Button Background
			$options[] = array(
				'title' => __('Button Background', 'wp-real-estate'), // Controller label
				'section' => 'wre_appearance', // section
				'id' => 'wre_button_bg', // unique ID
				'default' => $this->wre_get_default_color('wre_button_bg'), // HEX
				'option' => 'color',
				'sanitize_callback' => 'sanitize_hex_color',
				'type' => 'control',
			);

			// Button Background Hover
			$options[] = array(
				'title' => __('Button Background Hover', 'wp-real-estate'), // Controller label
				'section' => 'wre_appearance', // section
				'id' => 'wre_button_bg_hover', // unique ID
				'default' => $this->wre_get_default_color('wre_button_bg_hover'), // HEX
				'option' => 'color',
				'sanitize_callback' => 'sanitize_hex_color',
				'type' => 'control',
			);

			// Button Text Color
			$options[] = array(
				'title' => __('Button Text Color', 'wp-real-estate'), // Controller label
				'section' => 'wre_appearance', // section
				'id' => 'wre_button_text_color', // unique ID
				'default' => $this->wre_get_default_color('wre_button_text_color'), // HEX
				'option' => 'color',
				'sanitize_callback' => 'sanitize_hex_color',
				'type' => 'control',
			);

			// Button Text Hover Color
			$options[] = array(
				'title' => __('Button Text Hover Color', 'wp-real-estate'), // Controller label
				'section' => 'wre_appearance', // section
				'id' => 'wre_button_text_hover', // unique ID
				'default' => $this->wre_get_default_color('wre_button_text_hover'), // HEX
				'option' => 'color',
				'sanitize_callback' => 'sanitize_hex_color',
				'type' => 'control',
			);

			// Box Background Color
			$options[] = array(
				'title' => __('Search Box Background Color', 'wp-real-estate'), // Controller label
				'section' => 'wre_appearance', // section
				'id' => 'wre_search_bg', // unique ID
				'default' => $this->wre_get_default_color('search_bg'), // HEX
				'option' => 'color',
				'sanitize_callback' => 'sanitize_hex_color',
				'type' => 'control',
			);

			// Title Color
			$options[] = array(
				'title' => __('Title Color', 'wp-real-estate'), // Controller label
				'section' => 'wre_appearance', // section
				'id' => 'wre_title_color', // unique ID
				'default' => $this->wre_get_default_color('wre_title_color'), // HEX
				'option' => 'color',
				'sanitize_callback' => 'sanitize_hex_color',
				'type' => 'control',
			);

			// Tagline Color
			$options[] = array(
				'title' => __('Tagline Color', 'wp-real-estate'), // Controller label
				'section' => 'wre_appearance', // section
				'id' => 'wre_tagline_color', // unique ID
				'default' => $this->wre_get_default_color('wre_tagline_color'), // HEX
				'option' => 'color',
				'sanitize_callback' => 'sanitize_hex_color',
				'type' => 'control',
			);

			// Address Color
			$options[] = array(
				'title' => __('Address Color', 'wp-real-estate'), // Controller label
				'section' => 'wre_appearance', // section
				'id' => 'wre_address_color', // unique ID
				'default' => $this->wre_get_default_color('wre_address_color'), // HEX
				'option' => 'color',
				'sanitize_callback' => 'sanitize_hex_color',
				'type' => 'control',
			);

			// Price Color
			$options[] = array(
				'title' => __('Price Color', 'wp-real-estate'), // Controller label
				'section' => 'wre_appearance', // section
				'id' => 'wre_price_color', // unique ID
				'default' => $this->wre_get_default_color('wre_price_color'), // HEX
				'option' => 'color',
				'sanitize_callback' => 'sanitize_hex_color',
				'type' => 'control',
			);

			// Auto Slide Images
			$options[] = array(
				'title' => __('Auto Slide Images', 'wp-real-estate'), // Controller label
				'description' => __('Should images start to slide automatically?', 'wp-real-estate'),
				'section' => 'wre_gallery_settings', // section
				'id' => 'wre_auto_slide', // unique ID
				'default' => 'yes',
				'option' => 'select',
				'choices' => array(
					'yes' => 'Yes',
					'no' => 'No',
				),
				'sanitize_callback' => 'wre_sanitize_select',
				'type' => 'control',
			);

			// Transition Delay
			$options[] = array(
				'title' => __('Transition Delay', 'wp-real-estate'), // Controller label
				'description' => __('The time (in ms) between each auto transition', 'wp-real-estate'),
				'section' => 'wre_gallery_settings', // section
				'id' => 'wre_transition_delay', // unique ID
				'default' => '2000',
				'option' => 'number',
				'sanitize_callback' => 'absint',
				'type' => 'control',
			);

			// Transition Duration
			$options[] = array(
				'title' => __('Transition Duration', 'wp-real-estate'), // Controller label
				'description' => __('Transition duration (in ms)', 'wp-real-estate'),
				'section' => 'wre_gallery_settings', // section
				'id' => 'wre_transition_duration', // unique ID
				'default' => '1000',
				'option' => 'number',
				'sanitize_callback' => 'absint',
				'type' => 'control',
			);

			// Thumbnails Shown
			$options[] = array(
				'title' => __('Thumbnails Shown', 'wp-real-estate'), // Controller label
				'description' => __('Number of thumbnails shown below main image', 'wp-real-estate'),
				'section' => 'wre_gallery_settings', // section
				'id' => 'wre_thumbnails_shown', // unique ID
				'default' => '6',
				'option' => 'number',
				'sanitize_callback' => 'absint',
				'type' => 'control',
			);

			// Transition Type
			$options[] = array(
				'title' => __('Transition Type', 'wp-real-estate'), // Controller label
				'description' => __('Should images slide or fade?', 'wp-real-estate'),
				'section' => 'wre_gallery_settings', // section
				'id' => 'wre_gallery_mode', // unique ID
				'default' => 'fade',
				'option' => 'select',
				'choices' => array(
					'fade' => 'Fade',
					'slide' => 'Slide',
				),
				'sanitize_callback' => 'wre_sanitize_select',
				'type' => 'control',
			);

			$options[] = array(
				'title' => __('Arrow Icon', 'wp-real-estate'), // Controller label
				'description' => __('The icon to show on Slider.', 'wp-real-estate'),
				'section' => 'wre_gallery_settings', // section
				'id' => 'wre_arrow_icon', // unique ID
				'default' => 'arrow-2',
				'option' => 'custom-icons',
				'choices' => array(
					'arrow-1' => '<i class="wre-icon-arrow-1"></i>',
					'arrow-2' => '<i class="wre-icon-arrow-2"></i>',
					'arrow-3' => '<i class="wre-icon-arrow-3"></i>',
					'arrow-4' => '<i class="wre-icon-arrow-4"></i>',
					'arrow-5' => '<i class="wre-icon-arrow-5"></i>',
					'arrow-6' => '<i class="wre-icon-arrow-6"></i>',
					'arrow-7' => '<i class="wre-icon-arrow-7"></i>',
				),
				'sanitize_callback' => 'wre_sanitize_select',
				'type' => 'control',
			);

			// Icons
			$options[] = array(
				'title' => __('Tick Icon', 'wp-real-estate'), // Controller label
				'description' => __('The icon to show next to each feature on the External & Internal Feature list.', 'wp-real-estate'),
				'section' => 'wre_icons', // section
				'id' => 'wre_tick_icon', // unique ID
				'default' => 'tick-7',
				'option' => 'custom-icons',
				'choices' => array(
					'tick-1' => '<i class="wre-icon-tick-1"></i>',
					'tick-2' => '<i class="wre-icon-tick-2"></i>',
					'tick-3' => '<i class="wre-icon-tick-3"></i>',
					'tick-4' => '<i class="wre-icon-tick-4"></i>',
					'tick-5' => '<i class="wre-icon-tick-5"></i>',
					'tick-6' => '<i class="wre-icon-tick-6"></i>',
					'tick-7' => '<i class="wre-icon-tick-7"></i>',
					'none' => __('No Icon', 'wp-real-estate'),
				),
				'sanitize_callback' => 'wre_sanitize_select',
				'type' => 'control',
			);

			$options[] = array(
				'title' => __('Bedroom Icon', 'wp-real-estate'), // Controller label
				'description' => __('The icon to show next to each feature on the External & Internal Feature list.', 'wp-real-estate'),
				'section' => 'wre_icons', // section
				'id' => 'wre_bedroom_icon', // unique ID
				'default' => 'bed-2',
				'option' => 'custom-icons',
				'choices' => array(
					'bed-1' => '<i class="wre-icon-bed-1"></i>',
					'bed-2' => '<i class="wre-icon-bed-2"></i>',
					'bed-3' => '<i class="wre-icon-bed-3"></i>',
					'bed-4' => '<i class="wre-icon-bed-4"></i>',
					'bed-5' => '<i class="wre-icon-bed-5"></i>',
					'bed-6' => '<i class="wre-icon-bed-6"></i>',
					'bed-7' => '<i class="wre-icon-bed-7"></i>',
					'none' => __('"Bedrooms"', 'wp-real-estate'),
				),
				'sanitize_callback' => 'wre_sanitize_select',
				'type' => 'control',
			);

			$options[] = array(
				'title' => __('Bathroom Icon', 'wp-real-estate'), // Controller label
				'description' => __('The icon to show next to each feature on the External & Internal Feature list.', 'wp-real-estate'),
				'section' => 'wre_icons', // section
				'id' => 'wre_bathroom_icon', // unique ID
				'default' => 'bath-2',
				'option' => 'custom-icons',
				'choices' => array(
					'bath-1' => '<i class="wre-icon-bath-1"></i>',
					'bath-2' => '<i class="wre-icon-bath-2"></i>',
					'bath-3' => '<i class="wre-icon-bath-3"></i>',
					'bath-4' => '<i class="wre-icon-bath-4"></i>',
					'bath-5' => '<i class="wre-icon-bath-5"></i>',
					'bath-6' => '<i class="wre-icon-bath-6"></i>',
					'bath-7' => '<i class="wre-icon-bath-7"></i>',
					'none' => __('"Bathrooms"', 'wp-real-estate'),
				),
				'sanitize_callback' => 'wre_sanitize_select',
				'type' => 'control',
			);

			$options[] = array(
				'title' => __('Car Space Icon', 'wp-real-estate'), // Controller label
				'description' => __('The icon to show next to each feature on the External & Internal Feature list.', 'wp-real-estate'),
				'section' => 'wre_icons', // section
				'id' => 'wre_car_space_icon', // unique ID
				'default' => 'car-4',
				'option' => 'custom-icons',
				'choices' => array(
					'car-1' => '<i class="wre-icon-car-1"></i>',
					'car-2' => '<i class="wre-icon-car-2"></i>',
					'car-3' => '<i class="wre-icon-car-3"></i>',
					'car-4' => '<i class="wre-icon-car-4"></i>',
					'car-5' => '<i class="wre-icon-car-5"></i>',
					'car-6' => '<i class="wre-icon-car-6"></i>',
					'car-7' => '<i class="wre-icon-car-7"></i>',
					'none' => __('"Car Spaces"', 'wp-real-estate'),
				),
				'sanitize_callback' => 'wre_sanitize_select',
				'type' => 'control',
			);

			// Listing Statuses Controllers
			$statuses = self::wre_listing_statuses();
			$icon_classes = array();
			$icons = array(
				'auction-1', 'auction-2', 'auction-3',
				'sold-1', 'sold-2', 'sold-3', 'house',
				'car-1', 'car-2', 'car-3', 'car-4', 'car-5', 'car-6', 'car-7',
				'arrow-1', 'arrow-2', 'arrow-3', 'arrow-4', 'arrow-5', 'arrow-6', 'arrow-7',
				'tick-1', 'tick-2', 'tick-3', 'tick-4', 'tick-5', 'tick-6', 'tick-7',
				'next', 'heart', 'marker', 'link', 'star'
			);
			foreach ($icons as $icon) {
				$icon_classes[$icon] = ucwords($icon);
			}
			if ($statuses) {

				foreach ($statuses as $status) {
					$default_class = '';
					$status_slug = strtolower(str_replace(' ', '-', $status));
					if( $status_slug == 'under-offer' ) { 
						$default_class = 'house';
					} else if( $status_slug == 'sold' ) { 
						$default_class = 'sold-1';
					} else if( $status_slug == 'active' ) {
						$default_class = 'auction-1';
					}
					$options[] = array(
						'title' => $status . ' Background Color', // Controller label
						'description' => '', // Controller description
						'section' => 'wre_listing_statuses', // section
						'id' => 'wre_status_' . $status_slug . '_bg_color', // unique ID
						'default' => $this->wre_get_default_color('wre_status_' . $status_slug . '_bg_color'), // HEX
						'option' => 'color',
						'sanitize_callback' => 'sanitize_hex_color',
						'type' => 'control',
					);

					$options[] = array(
						'title' => $status . ' Text Color', // Controller label
						'description' => '', // Controller description
						'section' => 'wre_listing_statuses', // section
						'id' => 'wre_status_' . $status_slug . '_text_color', // unique ID
						'default' => $this->wre_get_default_color('wre_status_' . $status_slug . '_text_color'), // HEX
						'option' => 'color',
						'sanitize_callback' => 'sanitize_hex_color',
						'type' => 'control',
					);

					$options[] = array(
						'title' => $status . ' Icon Class', // Controller label
						'description' => '', // Controller description
						'section' => 'wre_listing_statuses', // section
						'id' => 'wre_status_' . $status_slug . '_icon_class', // unique ID
						'default' => $default_class,
						'option' => 'select',
						'choices' => $icon_classes,
						'sanitize_callback' => 'wre_sanitize_select',
						'type' => 'control',
					);
				}
			}
			return $options;
		}

		private static function wre_listing_statuses() {
			$statuses_data = get_option('wre_options');
			return $statuses = isset($statuses_data['listing_status']) ? $statuses_data['listing_status'] : '';
		}

		/**
		 * Hook into actions and filters.
		 * @since  1.0.0
		 */
		private function init_hooks() {
			/**
			 * Rewuire custom control class
			 */
			include_once( 'class-wre-customize-controller.php' );
		}

		public static function wre_get_default_color($key) {
			$default_colors = self::wre_default_colors();
			if (isset($default_colors[$key])) {
				return $default_colors[$key];
			}
			return '';
		}
		
		/**
		 * Set default colors for icons and statuses.
		 *
		 * @param $colors
		 *
		 * @return array
		 */
		public static function wre_default_colors() {
			
			$default_colors_lists = array(
				'wre_search_bg' => '#eee',
				'wre_icons_color' => '#fff',
				'wre_sidebar_headings_color' => '#282828',
				'wre_button_bg' => '#3C90BE',
				'wre_button_bg_hover' => '#3C90BE',
				'wre_button_text_color' => '#fff',
				'wre_button_text_hover' => '#fff',
				'wre_title_color' => '#282828',
				'wre_tagline_color' => '#282828',
				'wre_address_color' => '#4e4e4e',
				'wre_price_color' => '#26a0f2'
			);

			$statuses = self::wre_listing_statuses();
			if ($statuses) {
				foreach ($statuses as $status) {
					$status_slug = strtolower(str_replace(' ', '-', $status));
					$default_colors_lists['wre_status_' . $status_slug . '_text_color'] = '#fff';
					$default_colors_lists['wre_status_' . $status_slug . '_bg_color'] = '#3C90BE';
				}
			}

			$defaultColors = apply_filters('wre_default_colors', $default_colors_lists);

			return $defaultColors;
		}

		/**
		 * Add some inline CSS
		 *
		 */
		public static function add_inline_css() {
			$css = '';
			$defaultColors = self::wre_default_colors();
			$wre_search_bg = get_option('wre_search_bg') ? sanitize_hex_color(get_option('wre_search_bg')) : self::wre_get_default_color('wre_search_bg');
			$wre_icons_color = get_option('wre_icons_color') ? sanitize_hex_color(get_option('wre_icons_color')) : self::wre_get_default_color('wre_icons_color');
			$wre_sidebar_headings_color = get_option('wre_sidebar_headings_color') ? sanitize_hex_color(get_option('wre_sidebar_headings_color')) : self::wre_get_default_color('wre_sidebar_headings_color');
			$wre_button_bg = get_option('wre_button_bg') ? sanitize_hex_color(get_option('wre_button_bg')) : self::wre_get_default_color('wre_button_bg');
			$wre_button_bg_hover = get_option('wre_button_bg_hover') ? sanitize_hex_color(get_option('wre_button_bg_hover')) : self::wre_get_default_color('wre_button_bg_hover');
			$wre_button_text_color = get_option('wre_button_text_color') ? sanitize_hex_color(get_option('wre_button_text_color')) : self::wre_get_default_color('wre_button_text_color');
			$wre_button_text_hover = get_option('wre_button_text_hover') ? sanitize_hex_color(get_option('wre_button_text_hover')) : self::wre_get_default_color('wre_button_text_hover');
			$wre_title_color = get_option('wre_title_color') ? sanitize_hex_color(get_option('wre_title_color')) : self::wre_get_default_color('wre_title_color');
			$wre_tagline_color = get_option('wre_tagline_color') ? sanitize_hex_color(get_option('wre_tagline_color')) : self::wre_get_default_color('wre_tagline_color');
			$wre_address_color = get_option('wre_address_color') ? sanitize_hex_color(get_option('wre_address_color')) : self::wre_get_default_color('wre_address_color');
			$wre_price_color = get_option('wre_price_color') ? sanitize_hex_color(get_option('wre_price_color')) : self::wre_get_default_color('wre_price_color');

			$css .= '[class^="wre-icon-"], [class*=" wre-icon-"] { color: ' . $wre_icons_color . '; }';
			$css .= '.wre .wre-sidebar h2, .wre .bottom h3 { color: ' . $wre_sidebar_headings_color . '; }';
			$css .= '.wre #wre_contact_form .button-primary, .wre #wre-search-form .button, .wre .wre-pagination ul li span.page-numbers.current, .wre .wre-pagination ul li a.page-numbers:hover, .wre #wre-listings-form-wrapper .wre-submit-listing, .wre .wre-compare-listings a.compare-lists-btn, .wre .wre-map-wrapper .map-controls .control:hover, .wre-button.button, #wre-account-wrapper .wre-navigation li.is-active { background-color: ' . $wre_button_bg . '; border-color: ' . $wre_button_bg . '; color: #fff; }';
			$css .= '.wre #wre_contact_form .button-primary:hover, .wre #wre-search-form .button:hover { background-color: ' . $wre_button_bg_hover . '; }';
			$css .= '.wre ##wre_contact_form .button-primary, .wre #wre-search-form .button { color: ' . $wre_button_text_color . '; }';
			$css .= '.wre #wre_contact_form .button-primary:hover, .wre #wre-search-form .button:hover { color: ' . $wre_button_text_hover . '; }';
			$css .= '.wre .wre-search-form { background-color: ' . $wre_search_bg . '; }';
			$css .= '.wre .wre-items .title a, .wre .wre-single .title { color: ' . $wre_title_color . '; }';
			$css .= '.wre .wre-items .tagline, .wre .wre-single .tagline { color: ' . $wre_tagline_color . '; }';
			$css .= '.wre .wre-items .address, .wre .wre-single .address { color: ' . $wre_address_color . '; }';
			$css .= '.wre .wre-items .price, .wre .wre-single .price { color: ' . $wre_price_color . '; }';
			?>
			<style>
				<?php echo $css; ?>
			</style>
			<?php
		}

	}

	add_action('customize_register', array('WRE_Customizer', 'instance'));
	// Output custom CSS to live site
	add_action('wp_head', array('WRE_Customizer', 'add_inline_css'));

endif;