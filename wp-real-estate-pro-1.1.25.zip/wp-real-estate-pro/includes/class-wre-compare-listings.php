<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

class WRE_Compare_Listings_Shortcodes {

	public function __construct() {

		add_filter('wp', array($this, 'has_shortcode'));
		add_shortcode('wre_compare_listings', array($this, 'wre_compare_listings'));
	}

	/**
	 * Check if we have the shortcode displayed
	 */
	public function has_shortcode() {
		global $post;
		if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'wre_compare_listings')) {
			add_filter('is_wre', array($this, 'is_wre'));
		}
	}

	/**
	 * Add this as a listings_wp page
	 *
	 * @param bool $return
	 * @return bool
	 */
	public function is_wre($return) {
		return true;
	}

	/**
	 * The shortcode
	 *
	 * @param array $atts
	 * @return string
	 */
	public function wre_compare_listings($atts) {
		ob_start();
		do_action( 'wre_compare_listings_data' );
		do_action( 'wre_enqueue_plugin_scripts' );
		return ob_get_clean();
	}

}

return new WRE_Compare_Listings_Shortcodes();