<?php
// Exit if accessed directly
defined('ABSPATH') || exit;

if (!class_exists('WRE_Agency_Admin')) :

	/**
	 * The main class
	 *
	 * @since 1.0.0
	 */
	class WRE_Agency_Admin {

		public $parent_none = '';

		/**
		 * Main constructor
		 *
		 * @since 1.0.0
		 */
		public function __construct() {

			$this->parent_none = __('No Parent Agency', 'wp-real-estate');

			// Hook into actions & filters
			$this->hooks();
		}

		/**
		 * Hook in to actions & filters
		 *
		 * @since 1.0.0
		 */
		public function hooks() {
			add_filter('is_wre_admin', array($this, 'is_wre_admin'));
			add_filter('page_attributes_dropdown_pages_args', array($this, 'page_attributes'), 10, 2);
			add_filter('quick_edit_dropdown_pages_args', array($this, 'quick_edit_page_attributes'));
		}

		/**
		 * Adds our screens to the admin body class filter so that we can load the default CSS
		 *
		 */
		public function is_wre_admin($return) {

			$post_type = get_post_type();
			$screen = get_current_screen();
			$return = false;
			if (in_array($post_type, array('agency'))) {
				$return = true;
			}

			if (in_array($screen->id, array('agency', 'edit-agency'))) {
				$return = true;
			}
			return $return;
		}

		/**
		 * Dropdown for no parent
		 */
		public function page_attributes($dropdown_args, $post) {
			if( $this->is_wre_admin( false ) ){
				$dropdown_args['show_option_none'] = $this->parent_none;
			}
			return $dropdown_args;
		}

		/**
		 * Quick edit dropdown for no parent
		 */
		public function quick_edit_page_attributes($dropdown_args) {
			if( $this->is_wre_admin( false ) ){
				$dropdown_args['show_option_none'] = $this->parent_none;
			} else {
				$dropdown_args['show_option_none'] = __('No Parent', 'wp-real-estate');
			}
			return $dropdown_args;
		}

	}

	endif;

return new WRE_Agency_Admin();
