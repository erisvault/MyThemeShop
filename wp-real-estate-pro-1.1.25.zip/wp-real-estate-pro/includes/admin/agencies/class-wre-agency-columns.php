<?php
// Exit if accessed directly
if (!defined('ABSPATH'))
	exit;

if (!class_exists('WRE_Agency_Columns')) :

	/**
	 * Admin columns
	 * @version 0.1.0
	 */
	class WRE_Agency_Columns {

		/**
		 * Constructor
		 * @since 0.1.0
		 */
		public function __construct() {
			return $this->hooks();
		}

		public function hooks() {
			add_filter('manage_agency_posts_columns', array($this, 'agency_columns'));
			add_action('manage_agency_posts_custom_column', array($this, 'agency_data'), 10, 2);

			// sorting
			add_filter('manage_edit-agency_sortable_columns', array($this, 'table_sorting'));
			add_filter('request', array($this, 'agency_orderby_email'));
			add_filter('request', array($this, 'agency_orderby_phone'));
			add_filter('request', array($this, 'agency_orderby_website'));
		}

		/**
		 * Set columns for agency
		 */
		public function agency_columns($defaults) {

			$post_type = $_GET['post_type'];

			$columns = array();
			$taxonomies = array();

			/* Get taxonomies that should appear in the manage posts table. */
			$taxonomies = get_object_taxonomies($post_type, 'objects');
			$taxonomies = wp_filter_object_list($taxonomies, array('show_admin_column' => true), 'and', 'name');

			/* Allow devs to filter the taxonomy columns. */
			$taxonomies = apply_filters("manage_taxonomies_for_wre_{$post_type}_columns", $taxonomies, $post_type);
			$taxonomies = array_filter($taxonomies, 'taxonomy_exists');

			/* Loop through each taxonomy and add it as a column. */
			foreach ($taxonomies as $taxonomy) {
				$columns['taxonomy-' . $taxonomy] = get_taxonomy($taxonomy)->labels->name;
			}
			$date = $defaults['date'];
			unset($defaults['date']);

			$defaults['agents'] = __('Agents', 'wp-real-estate');
			$defaults['email'] = __('Email', 'wp-real-estate');
			$defaults['phone'] = __('Phone', 'wp-real-estate');
			$defaults['website'] = __('Website', 'wp-real-estate');
			$defaults['address'] = __('Address', 'wp-real-estate');
			$defaults['logo'] = __('Logo', 'wp-real-estate');
			$defaults['id'] = __('ID', 'wp-real-estate');
			$defaults['date'] = $date;

			return $defaults;
		}

		public function agency_data($column_name, $post_id) {

			if ($column_name == 'id') {
				echo '<span class="id">#' . esc_html($post_id) . '</div>';
			}

			if ($column_name == 'email') {
				$email = wre_agency_meta('email', $post_id);
				if (!$email)
					return;

				echo esc_html($email);
			}

			if ($column_name == 'phone') {
				$phone = wre_agency_meta('phone', $post_id);
				if (!$phone)
					return;

				echo esc_html($phone);
			}

			if ($column_name == 'website') {
				$website = wre_agency_meta('website', $post_id);
				if (!$website)
					return;

				echo esc_html($website);
			}

			if ($column_name == 'agents') {
				$agents = wre_agency_meta('agents', $post_id);
				if (!$agents)
					return;

				$count = count($agents);
				$i = 0;
				foreach ($agents as $agent => $id) {
					if ($i > 1)
						continue;
					echo get_the_author_meta('display_name', $id) . '<br>';
					$i++;
				}
				if ($count > 2) {
					printf(__('+ %s more', 'wp-real-estate'), ( $count - $i));
				}
			}


			if ($column_name == 'address') {
				$address = wre_agency_meta('displayed_address', $post_id);
				if (!$address)
					return;

				echo esc_html($address);
			}

			if ($column_name == 'logo') {
				$logo = wre_agency_meta('logo', $post_id);
				if (!$logo)
					return;

				echo '<img src="' . esc_url($logo) . '" height="50" />';
			}
		}

		/*
		 * Sorting the table
		 */

		function table_sorting($columns) {
			$columns['email'] = 'email';
			$columns['phone'] = 'phone';
			$columns['website'] = 'website';
			return $columns;
		}

		function agency_orderby_email($vars) {
			if (isset($vars['orderby']) && 'email' == $vars['orderby']) {
				$vars = array_merge($vars, array(
					'meta_key' => '_wre_agency_email',
					'orderby' => 'meta_value'
				));
			}
			return $vars;
		}

		function agency_orderby_phone($vars) {
			if (isset($vars['orderby']) && 'phone' == $vars['orderby']) {
				$vars = array_merge($vars, array(
					'meta_key' => '_wre_agency_phone',
					'orderby' => 'meta_value'
				));
			}
			return $vars;
		}

		function agency_orderby_website($vars) {
			if (isset($vars['orderby']) && 'website' == $vars['orderby']) {
				$vars = array_merge($vars, array(
					'meta_key' => '_wre_agency_website',
					'orderby' => 'meta_value'
				));
			}
			return $vars;
		}

	}

	new WRE_Agency_Columns;

endif;