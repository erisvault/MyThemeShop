<?php
// Exit if accessed directly
if (!defined('ABSPATH'))
	exit;

if (!class_exists('WRE_Agency_Metaboxes')) :

	/**
	 * CMB2 Theme Options
	 * @version 0.1.0
	 */
	class WRE_Agency_Metaboxes {

		/**
		 * Post type
		 * @var string
		 */
		public $type = 'agency';

		/**
		 * Metabox prefix
		 * @var string
		 */
		public $prefix = '_wre_agency_';
		public $agency_label = '';

		/**
		 * Constructor
		 * @since 0.1.0
		 */
		public function __construct() {
			$this->agency_label = __('Agency', 'wp-real-estate');

			add_action('cmb2_admin_init', array($this, 'register_metaboxes'));
		}

		/**
		 * Add the options metabox to the array of metaboxes
		 * @since  0.1.0
		 */
		public function register_metaboxes() {

			/**
			 * Load the metaboxes for agency post type
			 */
			$this->description();
			$this->images();
			$this->agents();
			$this->address();
			$this->contact();
			$this->membership_packages();
		}
		
		/*==================== Membership Packages ====================*/
		public function membership_packages() {

			$box = new_cmb2_box( array(
					'id'			=> '_wre_package_details',
					'title'			=> '<span class="dashicons dashicons-admin-home"></span> ' . sprintf( __( "Package Details", 'wp-real-estate' ) ),
					'object_types'	=> array( 'memberships' ), 
			) );

			$fields = array();

			$fields[11] = array(
				'name'			=> __( 'Package Subscription Period', 'wp-real-estate' ),
				'desc'			=> __( 'Subscription valid for X days, weeks, month or years.', 'wp-real-estate' ),
				'id'			=> '_wre_package_subscription_period',
				'type'			=> 'text',
				'attributes'	=> array(
					'type'	=> 'number',
					'min'	=> '0',
					'step'	=> '0.5',
				),
			);
			$fields[12] = array(
				'name'			=> __( 'Package Subscription Unit', 'wp-real-estate' ),
				'desc'			=> '',
				'id'			=> '_wre_package_subscription_unit',
				'type'			=> 'select',
				'options'		=> apply_filters( 'wre_subscription_unit',  array(
					'years'		=> __( 'Years', 'wp-real-estate' ),
					'months'	=> __( 'Months', 'wp-real-estate' ),
					'weeks'		=> __( 'Weeks', 'wp-real-estate' ),
					'days'		=> __( 'Days', 'wp-real-estate' ),
				) )
			);
			$fields[13] = array(
				'name'			=> __( 'Allowed Listings', 'wp-real-estate' ),
				'desc'			=> __( 'Enter -1 for unlimited listings', 'wp-real-estate' ),
				'id'			=> '_wre_package_allowed_listings',
				'type'			=> 'text',
				'attributes'	=> array(
					'type'	=> 'number',
					'min'	=> '-1',
					'step'	=> '1',
				),
			);
			$fields[14] = array(
				'name'			=> __( 'Package Price', 'wp-real-estate' ),
				'desc'			=> __( 'Enter 0 for free or no price', 'wp-real-estate' ),
				'id'			=> '_wre_package_price',
				'type'			=> 'text',
				'attributes'	=> array(
					'type'	=> 'number',
					'min'	=> '0',
					'step'	=> '0.01',
				),
			);
			$fields[15] = array(
				'name'			=> __( 'Unique Stripe Package ID', 'wp-real-estate' ),
				'id'			=> '_wre_package_stripe_id',
				'type'			=> 'text'
			);

			// filter the fields
			$fields = apply_filters( 'wre_metabox_details', $fields );

			// sort numerically
			ksort( $fields );

			// loop through ordered fields and add them to the metabox
			if( $fields ) {
				foreach ($fields as $key => $value) {
					$fields[$key] = $box->add_field( $value );
				}
			}

		}

		/* ======================================================================================
		  Agency Description
		  ====================================================================================== */

		public function description() {

			$box = new_cmb2_box(array(
				'id' => $this->prefix . 'description',
				'title' => '<span class="dashicons dashicons-welcome-write-blog"></span> ' . sprintf(__("%s Description", 'wp-real-estate'), $this->agency_label),
				'object_types' => array($this->type),
					));

			$fields = array();

			$fields[10] = array(
				'name' => __('Tagline', 'wp-real-estate'),
				'desc' => '',
				'id' => $this->prefix . 'tagline',
				'type' => 'text',
			);
			$fields[20] = array(
				'name' => __('Main Description', 'wp-real-estate'),
				'desc' => '',
				'id' => 'content',
				'type' => 'wysiwyg',
				'options' => array(
					'wpautop' => true, // use wpautop?
					'media_buttons' => false, // show insert/upload button(s)
					'textarea_rows' => get_option('default_post_edit_rows', 3), // rows="..."
					'teeny' => true, // output the minimal editor config used in Press This
					'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
					'quicktags' => false // load Quicktags, can be used to pass settings directly to Quicktags using an array()
				),
			);

			// filter the fields
			$fields = apply_filters('wre_agency_metabox_description', $fields);

			// sort numerically
			ksort($fields);

			// loop through ordered fields and add them to the metabox
			if ($fields) {
				foreach ($fields as $key => $value) {
					$fields[$key] = $box->add_field($value);
				}
			}
		}

		/* ======================================================================================
		  Agency Page Images
		  ====================================================================================== */

		public function images() {

			$box = new_cmb2_box(array(
				'id' => $this->prefix . 'images',
				'title' => '<span class="dashicons dashicons-images-alt2"></span> ' . sprintf(__("%s Page Images", 'wp-real-estate'), $this->agency_label),
				'object_types' => array($this->type),
					));

			$fields = array();

			$fields[10] = array(
				'name' => __('Logo', 'wp-real-estate'),
				'desc' => __('Should be at least 300px wide in jpg, gif or png format.', 'wp-real-estate'),
				'id' => $this->prefix . 'logo',
				'type' => 'file',
			);

			$fields[20] = array(
				'name' => __('Main Cover Image', 'wp-real-estate'),
				'desc' => __('Should be at least 1200px wide in jpg, gif or png format.', 'wp-real-estate'),
				'id' => $this->prefix . 'cover',
				'type' => 'file',
			);

			// filter the fields
			$fields = apply_filters('wre_agency_metabox_images', $fields);

			// sort numerically
			ksort($fields);

			// loop through ordered fields and add them to the metabox
			if ($fields) {
				foreach ($fields as $key => $value) {
					$fields[$key] = $box->add_field($value);
				}
			}
		}

		/* ======================================================================================
		  Agency Agents
		  ====================================================================================== */

		public function agents() {

			$box = new_cmb2_box(array(
				'id' => $this->prefix . 'agents',
				'title' => '<span class="dashicons dashicons-admin-home"></span> ' . sprintf(__("%s Agents", 'wp-real-estate'), $this->agency_label),
				'object_types' => array($this->type),
					));

			$fields = array();

			$fields[10] = array(
				'name' => __('Agents', 'wp-real-estate'),
				'desc' => ' ',
				'id' => $this->prefix . 'agents',
				'type' => 'multicheck',
				'options_cb' => 'wre_admin_agency_get_agents',
			);

			// filter the fields
			$fields = apply_filters('wre_agency_metabox_agents', $fields);

			// sort numerically
			ksort($fields);

			// loop through ordered fields and add them to the metabox
			if ($fields) {
				foreach ($fields as $key => $value) {
					$fields[$key] = $box->add_field($value);
				}
			}
		}

		/* ======================================================================================
		  Agency Address
		  ====================================================================================== */

		public function address() {

			$box = new_cmb2_box(array(
				'id' => $this->prefix . 'address',
				'title' => '<span class="dashicons dashicons-location-alt"></span> ' . sprintf(__("%s Address", 'wp-real-estate'), $this->agency_label),
				'object_types' => array($this->type),
				'context' => 'side',
					));

			$fields = array();

			$fields[10] = array(
				'name' => __('Find Address', 'wp-real-estate'),
				'desc' => '',
				'id' => "wre-geocomplete",
				'type' => 'text',
				'after_row' => 'wre_admin_map',
				'attributes' => array(
					'placeholder' => __('Type your address...', 'wp-real-estate'),
				),
			);
			$fields[11] = array(
				'name' => __('Displayed Address', 'wp-real-estate'),
				'desc' => '',
				'id' => $this->prefix . 'displayed_address',
				'type' => 'text',
				'attributes' => array(
					'data-geo' => 'formatted_address',
				),
			);
			$fields[12] = array(
				'name' => __('Street Number', 'wp-real-estate'),
				'desc' => '',
				'id' => $this->prefix . 'street_number',
				'type' => 'text',
				'attributes' => array(
					'data-geo' => 'street_number',
				),
			);
			$fields[13] = array(
				'name' => __('Street Name', 'wp-real-estate'),
				'desc' => '',
				'id' => $this->prefix . 'route',
				'type' => 'text',
				'attributes' => array(
					'data-geo' => 'route',
				),
			);
			$fields[14] = array(
				'name' => __('City / Town / Locality', 'wp-real-estate'),
				'desc' => '',
				'id' => $this->prefix . 'city',
				'type' => 'text',
				'attributes' => array(
					'data-geo' => 'locality',
				),
			);
			$fields[15] = array(
				'name' => __('Zip / Postal Code', 'wp-real-estate'),
				'desc' => '',
				'id' => $this->prefix . 'zip',
				'type' => 'text',
				'attributes' => array(
					'data-geo' => 'postal_code',
				),
			);
			$fields[16] = array(
				'name' => __('State', 'wp-real-estate'),
				'desc' => '',
				'id' => $this->prefix . 'state',
				'type' => 'text',
				'attributes' => array(
					'data-geo' => 'administrative_area_level_1',
				),
			);
			$fields[17] = array(
				'name' => __('Country', 'wp-real-estate'),
				'desc' => '',
				'id' => $this->prefix . 'country',
				'type' => 'text',
				'attributes' => array(
					'data-geo' => 'country',
				),
			);
			$fields[18] = array(
				'name' => __('Latitude', 'wp-real-estate'),
				'desc' => '',
				'id' => $this->prefix . 'lat',
				'type' => 'text',
				'attributes' => array(
					'data-geo' => 'lat',
				),
			);
			$fields[19] = array(
				'name' => __('Longitude', 'wp-real-estate'),
				'desc' => '',
				'id' => $this->prefix . 'lng',
				'type' => 'text',
				'attributes' => array(
					'data-geo' => 'lng',
				),
			);

			// filter the fields
			$fields = apply_filters('wre_agency_metabox_address', $fields);

			// sort numerically
			ksort($fields);

			// loop through ordered fields and add them to the metabox
			if ($fields) {
				foreach ($fields as $key => $value) {
					$fields[$key] = $box->add_field($value);
				}
			}
		}

		/* ======================================================================================
		  Agency Contact
		  ====================================================================================== */

		public function contact() {

			$box = new_cmb2_box(array(
				'id' => $this->prefix . 'contact',
				'title' => '<span class="dashicons dashicons-phone"></span> ' . sprintf(__("%s Contact", 'wp-real-estate'), $this->agency_label),
				'object_types' => array($this->type),
				'context' => 'side',
					));

			$fields = array();

			$fields[10] = array(
				'name' => __('Phone', 'wp-real-estate'),
				'desc' => '',
				'id' => $this->prefix . 'phone',
				'type' => 'text',
			);
			$fields[11] = array(
				'name' => __('Fax', 'wp-real-estate'),
				'desc' => '',
				'id' => $this->prefix . 'fax',
				'type' => 'text',
			);
			$fields[12] = array(
				'name' => __('Email', 'wp-real-estate'),
				'desc' => '',
				'id' => $this->prefix . 'email',
				'type' => 'text',
			);
			$fields[13] = array(
				'name' => __('Website', 'wp-real-estate'),
				'desc' => '',
				'id' => $this->prefix . 'website',
				'type' => 'text_url',
			);

			// filter the fields
			$fields = apply_filters('wre_agency_metabox_contact', $fields);

			// sort numerically
			ksort($fields);

			// loop through ordered fields and add them to the metabox
			if ($fields) {
				foreach ($fields as $key => $value) {
					$fields[$key] = $box->add_field($value);
				}
			}
		}

	}

	new WRE_Agency_Metaboxes();

endif;