<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

add_action('cmb2_admin_init', 'wre_options_page');

function wre_options_page() {

	$listing_label = __('Listing', 'wp-real-estate');
	$listings_label = __('Listings', 'wp-real-estate');
	// the options key fields will be saved under
	$opt_key = 'wre_options';

	// the show_on parameter for configuring the CMB2 box, this is critical!
	$show_on = array('key' => 'wre-options-page', 'value' => array($opt_key));

	// an array to hold our boxes
	$boxes = array();

	// an array to hold some tabs
	$tabs = array();

	/*
	 * Tabs - an array of configuration arrays.
	 */
	$tabs[] = array(
		'id' => 'general',
		'title' => __('General', 'wp-real-estate'),
		'desc' => '',
		'boxes' => array(
			'wre_display_settings',
			'wre_enable_premium_badge',
			'google_maps',
			'search',
		),
	);

	$tabs[] = array(
		'id' => 'listings',
		'title' => sprintf(__('%s', 'wp-real-estate'), $listings_label),
		'desc' => '',
		'boxes' => array(
			'listing_setup',
			'listing_attributes',
			'listing_features',
			'listing_statuses',
			'related_listings_data',
			'currency_options'
		),
	);

	$tabs[] = array(
		'id' => 'agents-listings',
		'title' => __('Agents', 'wp-real-estate'),
		'desc' => '',
		'boxes' => array(
			'agents_archive_data',
			'agents_listing_data',
		),
	);

	$tabs[] = array(
		'id' => 'agencies',
		'title' => __('Agencies', 'wp-real-estate'),
		'desc' => '',
		'boxes' => array(
			'agency_setup',
		),
	);

	$tabs[] = array(
		'id' => 'contact',
		'title' => __( 'Contact Form', 'wp-real-estate' ),
		'desc' => '',
		'boxes' => array(
			'contact_form',
			'contact_form_email',
			'contact_form_messages',
		),
	);

	$tabs[] = array(
		'id' => 'idx-settings',
		'title' => __( 'IDX', 'wp-real-estate' ),
		'desc' => '',
		'boxes' => array(
			'idx_import_options',
			'idx_imported_listings',
		),
	);

	$tabs[] = array(
		'id' => 'listing-submit',
		'title' => __( 'My Listings', 'wp-real-estate' ),
		'desc' => '',
		'boxes' => array(
			'wre_my_listings',
			'wre_submit_listing',
			'wre_bacs_payment',
			'wre_paypal_payment',
			'wre_stripe_payment',
			'wre_submit_listing_email_notifications'
		),
	);
	
	$tabs[] = array(
		'id' => 'my-account',
		'title' => __('My Account', 'wp-real-estate'),
		'desc' => '',
		'boxes' => array(
			'wre_my_account',
			'wre_account_endpoints',
			'wre_account_email_notifications'
		),
	);

	$tabs[] = array(
		'id' => 'advanced',
		'title' => __('Advanced', 'wp-real-estate'),
		'desc' => '',
		'boxes' => array(
			'template_html',
			'uninstall',
		),
	);
	
	// display-setttings
	$cmb = new_cmb2_box(array(
		'id' => 'wre_display_settings',
		'title' => __('Display Settings', 'wp-real-estate'),
		'show_on' => $show_on,
	));
	$cmb->add_field(array(
		'name' => __('Archive Display Mode', 'wp-real-estate'),
		'desc' => '',
		'id' => 'wre_default_display_mode',
		'type' => 'select',
		'default' => 'grid-view',
		'options' => array(
			'grid-view' => __('Grid Mode', 'wp-real-estate'),
			'list-view' => __('List Mode', 'wp-real-estate'),
		),
	));
	$cmb->add_field(array(
		'name' => __('Archive Grid Columns', 'wp-real-estate'),
		'desc' => __('The number of columns to display on the archive page, when viewing listings in grid mode.', 'wp-real-estate'),
		'id' => 'wre_grid_columns',
		'type' => 'select',
		'default' => '3',
		'options' => array(
			'2' => __('2 columns', 'wp-real-estate'),
			'3' => __('3 columns', 'wp-real-estate'),
			'4' => __('4 columns', 'wp-real-estate'),
		),
	));
	$cmb->add_field( array(
		'name' => __('Number of Listings/Agencies', 'wp-real-estate'),
		'desc' => __('The max number of listings/agencies to show in archive page.', 'wp-real-estate') . '<br>' . __('Could show less than this if not enough listings/agencies are found.', 'wp-real-estate'),
		'id'   => 'archive_listing_number',
		'type' => 'text',
		'default' => '9',
		'attributes' => array(
			'type' => 'number',
			'min'	=> 1
		),
	) );
	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	// premium-badge-setttings
	$cmb = new_cmb2_box(array(
		'id' => 'wre_enable_premium_badge',
		'title' => __('Premium Badges', 'wp-real-estate'),
		'desc' 	=> __('These badges will be added for Paid listings and agencies/agenets who have paid listings.','wp-real-estate'),
		'show_on' => $show_on,
	));
	$cmb->add_field(array(
		'name' => __('Enable Premium Badge for Listings', 'wp-real-estate'),
		'desc' => __('Add Premium badge for Listings', 'wp-real-estate'),
		'id' => 'wre_premium_badge_listings',
		'type' => 'checkbox',
		'default' => '',
	));
	$cmb->add_field(array(
		'name' => __('Premium Badge Text for Listings', 'wp-real-estate'),
		'desc' => '',
		'id' => 'wre_premium_badge_text_listings',
		'type' => 'text',
		'default' => 'Premium',
	));
	$cmb->add_field(array(
		'name' => __('Enable Premium Badge for Agents', 'wp-real-estate'),
		'desc' => __('Add Premium badge for Agents', 'wp-real-estate'),
		'id' => 'wre_premium_badge_agents',
		'type' => 'select',
		'type' => 'checkbox',
		'default' => '',
	));
	$cmb->add_field(array(
		'name' => __('Premium Badge Text for Agents', 'wp-real-estate'),
		'desc' => '',
		'id' => 'wre_premium_badge_text_agents',
		'type' => 'text',
		'default' => 'Premium',
	));
	$cmb->add_field(array(
		'name' => __('Enable Premium Badge for Agencies', 'wp-real-estate'),
		'desc' => __('Add Premium badge for Agencies', 'wp-real-estate'),
		'id' => 'wre_premium_badge_agencies',
		'type' => 'select',
		'type' => 'checkbox',
		'default' => '',
	));
	$cmb->add_field(array(
		'name' => __('Premium Badge Text for Agencies', 'wp-real-estate'),
		'desc' => '',
		'id' => 'wre_premium_badge_text_agencies',
		'type' => 'text',
		'default' => 'Premium',
	));
	$cmb->object_type('options-page');
	$boxes[] = $cmb;
	
	// maps
	$cmb = new_cmb2_box(array(
		'id' => 'google_maps',
		'title' => __('Google Maps', 'wp-real-estate'),
		'show_on' => $show_on,
	));
	$cmb->add_field(array(
		'name' => __('API Key', 'wp-real-estate'),
		'before_row' => sprintf(__('A Google Maps API Key is required to be able to show the maps. It\'s free and you can get yours %s.', 'wp-real-estate'), '<strong><a target="_blank" href="https://developers.google.com/maps/documentation/javascript/get-api-key">here</a></strong>').'<br />'. __('You can add a configurable map to pinpoint your listings on the front end using [wre_map] shortcode.', 'wp-real-estate'),
		'id' => 'maps_api_key',
		'type' => 'text',
	));
	$cmb->add_field(array(
		'name' => __('Map Zoom', 'wp-real-estate'),
		'desc' => '',
		'id' => 'map_zoom',
		'type' => 'text',
		'default' => '14',
		'attributes' => array(
			'type' => 'number',
		),
	));
	$cmb->add_field(array(
		'name' => __('Map Height', 'wp-real-estate'),
		'desc' => '',
		'id' => 'map_height',
		'type' => 'text',
		'default' => '300',
		'attributes' => array(
			'type' => 'number',
		),
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	// maps
	$cmb = new_cmb2_box(array(
		'id' => 'search',
		'title' => __('Search', 'wp-real-estate'),
		'show_on' => $show_on,
	));
	$cmb->add_field(array(
		'name' => __('Distance Measurement', 'wp-real-estate'),
		'before_row' => __('These settings relate to the [wre_search] shortcode.', 'wp-real-estate'),
		'desc' => __('Choose miles or kilometers for the radius.', 'wp-real-estate'),
		'id' => 'distance_measurement',
		'type' => 'select',
		'options' => array(
			'miles' => __('Miles', 'wp-real-estate'),
			'kilometers' => __('Kilometers', 'wp-real-estate'),
		),
	));

	$cmb->add_field(array(
		'name' => __('Radius', 'wp-real-estate'),
		'desc' => __('Show listings that are within this distance (mi or km as selected above).', 'wp-real-estate'),
		'id' => 'search_radius',
		'type' => 'text',
		'default' => '20',
		'atributes' => array(
			'type' => 'number',
			'placeholder' => '20',
		),
	));
	$cmb->add_field(array(
		'name' => __('Country', 'wp-real-estate'),
		'desc' => sprintf(__('Country name or two letter %s country code.', 'wp-real-estate'), '<a target="_blank" href="https://en.wikipedia.org/wiki/ISO_3166-1">ISO 3166-1</a>'),
		'id' => 'search_country',
		'type' => 'text',
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	/* ==================== Listing Options ==================== */

	// listings setup
	$cmb = new_cmb2_box(array(
		'id' => 'listing_setup',
		'title' => __('Listing Setup', 'wp-real-estate'),
		'show_on' => $show_on,
	));
	$cmb->add_field(array(
		'name' => __('Rent / Sell', 'wp-real-estate'),
		'desc' => __('Are your listings only for rent or only for sale? Or both?', 'wp-real-estate'),
		'id' => 'display_purpose',
		'type' => 'select',
		'default' => 'both',
		'options' => array(
			'both' => __('Both', 'wp-real-estate'),
			'rent' => __('Rent Only', 'wp-real-estate'),
			'sell' => __('Sell Only', 'wp-real-estate'),
		),
	));
	$cmb->add_field(array(
		'name' => __('Default Listing Type', 'wp-real-estate'),
		'desc' => __('If the above is set to "Both", which type would you like to display as the default on the listings page?', 'wp-real-estate'),
		'id' => 'display_default',
		'type' => 'select',
		'options' => array(
			'Sell' => __('Sell', 'wp-real-estate'),
			'Rent' => __('Rent', 'wp-real-estate'),
		),
	));
	$cmb->add_field(array(
		'name' => __('Listings Page', 'wp-real-estate'),
		'desc' => __('The main page to display your listings.', 'wp-real-estate'),
		'id' => 'archives_page',
		'type' => 'select',
		'options_cb' => 'wre_get_pages',
	));
	$cmb->add_field(array(
		'name' => __('Compare Listings Page', 'wp-real-estate'),
		'desc' => __('The page to display compare listings data. This page must have an [wre_compare_listings] shortcode.', 'wp-real-estate'),
		'id' => 'compare_listings',
		'type' => 'select',
		'options_cb' => 'wre_get_pages',
	));
	$cmb->add_field(array(
		'name' => __('Force Listings Page Title', 'wp-real-estate'),
		'desc' => __('If your page title is not displaying correctly, you can force the page title here.', 'wp-real-estate') . '<br>' . __('(Some themes may be using incorrect template tags to display the archive title. This forces the title within the page)', 'wp-real-estate'),
		'id' => 'archives_page_title',
		'type' => 'select',
		'default' => 'no',
		'options' => array(
			'no' => __('No', 'wp-real-estate'),
			'yes' => __('Yes', 'wp-real-estate'),
		),
	));

	$cmb->add_field(array(
		'name' => __('Single Listing URL', 'wp-real-estate'),
		'desc' => __('The single listing URL (or slug).', 'wp-real-estate'),
		'id' => 'single_url',
		'type' => 'text',
		'default' => 'listing',
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	// listing types
	$cmb = new_cmb2_box(array(
		'id' => 'listing_features',
		'title' => sprintf(__('%s Features', 'wp-real-estate'), $listing_label),
		'show_on' => $show_on,
	));
	$cmb->add_field(array(
		'name' => __('Internal Features', 'wp-real-estate'),
		'before_row' => __('Once Features have been added here, they are then available as checkboxes when adding or editing a listing.', 'wp-real-estate'),
		'after' => '<p class="cmb2-metabox-description">' . sprintf(__('Internal Features such as Open Fireplace, Gas Heating, Dishwasher etc.', 'wp-real-estate'), $listing_label) . '</p>',
		'id' => 'internal_feature',
		'type' => 'text',
		'repeatable' => true,
		'text' => array(
			'add_row_text' => __('Add Feature', 'wp-real-estate'),
		),
	));
	$cmb->add_field(array(
		'name' => __('External Features', 'wp-real-estate'),
		'after' => '<p class="cmb2-metabox-description">' . sprintf(__('External Features such as Balcony, Shed, Outdoor Entertaining etc.', 'wp-real-estate'), $listing_label) . '</p>',
		'id' => 'external_feature',
		'type' => 'text',
		'repeatable' => true,
		'text' => array(
			'add_row_text' => __('Add Feature', 'wp-real-estate'),
		),
	));
	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	$cmb = new_cmb2_box(array(
		'id' => 'listing_statuses',
		'title' => sprintf(__('%s Statuses', 'wp-real-estate'), $listing_label),
		'show_on' => $show_on,
	));

	$cmb->add_field(array(
		'name' => __('Statuses', 'wp-real-estate'),
		'before_row' => __('Once Statuses have been added here, they are then available in the Status dropdown field when adding or editing a listing. Statuses appear in a styled box over the listing\'s image.', 'wp-real-estate'),
		'after' => '<p class="cmb2-metabox-description">' . sprintf(__('Listing Statuses such as Under Offer, Sold, Available etc.', 'wp-real-estate'), $listing_label) . '</p>',
		'id' => 'listing_status',
		'type' => 'text',
		'repeatable' => true,
		'text' => array(
			'add_row_text' => __('Add Status', 'wp-real-estate'),
		),
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	/* ==================== Related Listings Options ==================== */

	// template html
	$cmb = new_cmb2_box(array(
		'id' => 'related_listings_data',
		'title' => __('Related Listings', 'wp-real-estate'),
		'show_on' => $show_on,
	));

	$cmb->add_field(array(
		'name' => __('Show Related Listings', 'wp-real-estate'),
		'desc' => __('Should the related listings be shown on single-listings page.', 'wp-real-estate'),
		'id' => 'rl_show_listings',
		'type' => 'select',
		'default' => 'yes',
		'options' => array(
			'yes' => __('Yes', 'wp-real-estate'),
			'no' => __('No', 'wp-real-estate'),
		),
	));

	$cmb->add_field(array(
		'name' => __('Related Listings Mode', 'wp-real-estate'),
		'desc' => '',
		'id' => 'rl_mode',
		'type' => 'select',
		'default' => 'grid-view',
		'options' => array(
			'grid-view' => __('Grid Mode', 'wp-real-estate'),
			'list-view' => __('List Mode', 'wp-real-estate'),
		),
	));

	$cmb->add_field(array(
		'name' => __('Related Listings Columns', 'wp-real-estate'),
		'desc' => __('The number of columns to display on the single-listing page, when viewing related listings in grid mode.', 'wp-real-estate'),
		'id' => 'rl_columns',
		'type' => 'select',
		'default' => '3',
		'options' => array(
			'2' => __('2 columns', 'wp-real-estate'),
			'3' => __('3 columns', 'wp-real-estate'),
			'4' => __('4 columns', 'wp-real-estate'),
		),
	));

	$cmb->add_field(array(
		'name' => __('Distance Measurement', 'wp-real-estate'),
		'desc' => __('Choose miles or kilometers for the radius.', 'wp-real-estate'),
		'id' => 'rl_distance_measurement',
		'type' => 'select',
		'options' => array(
			'miles' => __('Miles', 'wp-real-estate'),
			'kilometers' => __('Kilometers', 'wp-real-estate'),
		),
	));

	$cmb->add_field(array(
		'name' => __('Radius', 'wp-real-estate'),
		'desc' => __('Show related listings that are within this distance (mi or km as selected above).', 'wp-real-estate'),
		'id' => 'rl_search_radius',
		'type' => 'text',
		'default' => '50',
		'atributes' => array(
			'type' => 'number',
			'placeholder' => '50',
		),
	));

	$cmb->add_field(array(
		'name' => __('Max Listings', 'wp-real-estate'),
		'desc' => __('The max number of related listings to show', 'wp-real-estate') . '<br>' . __('Could show less than this if not enough related listings are found.', 'wp-real-estate'),
		'id' => 'rl_max_listings',
		'type' => 'select',
		'default' => '3',
		'options' => array( '', 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 )
	));

	$cmb->add_field(array(
		'name' => __('Order', 'wp-real-estate'),
		'desc' => __('The order that related listings are displayed', 'wp-real-estate'),
		'after_row' => '<hr />',
		'id' => 'rl_order',
		'type' => 'select',
		'options' => array(
			'rand'          => __( 'Random', 'wp-real-estate' ),
			'title-asc'     => __( 'Title (A to Z)', 'wp-real-estate' ),
			'title'         => __( 'Title (Z to A)', 'wp-real-estate' ),
			'date-desc'      => __( 'Newest to oldest', 'wp-real-estate' ),
			'date'          => __( 'Oldest to newest', 'wp-real-estate' ),
			'price-asc'     => __( 'Price (low to high)', 'wp-real-estate' ),
			'price-desc'    => __( 'Price (high to low)', 'wp-real-estate' ),
		),
	));

	$cmb->add_field(array(
		'name' => __('Address Fields', 'wp-real-estate'),
		'before_row' => __('Below you can further filter listings based on address and price.', 'wp-real-estate') . '<br />' . __('This is useful if you have a lot of listings.', 'wp-real-estate'),
		'desc' => __('Only show listings that share the same City, State and/or Postcode.', 'wp-real-estate'),
		'id' => 'rl_address_filter',
		'type' => 'multicheck_inline',
		'default' => '',
		'options' => array(
			'city' => __('City', 'wp-real-estate'),
			'state' => __('State', 'wp-real-estate'),
			'zip' => __('Zip/Postcode', 'wp-real-estate'),
		),
	));

	$cmb->add_field(array(
		'name' => __('Price', 'wp-real-estate'),
		'desc' => __('Only show listings with closely related prices?', 'wp-real-estate'),
		'id' => 'rl_price_filter',
		'type' => 'select',
		'default' => 'no',
		'options' => array(
			'yes' => __('Yes', 'wp-real-estate'),
			'no' => __('No', 'wp-real-estate'),
		),
	));

	$cmb->add_field(array(
		'name' => __('Price Range', 'wp-real-estate'),
		'desc' => __('How far either side of the price should we look?', 'wp-real-estate'),
		'id' => 'rl_price_range',
		'type' => 'text',
		'default' => '50000',
		'atributes' => array(
			'type' => 'number',
			'placeholder' => '50000',
		),
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;
	
	// Currency Options
	$currency_code_options = get_wre_currencies();

	foreach ( $currency_code_options as $code => $name ) {
		$currency_code_options[ $code ] = $name . ' (' . get_wre_currency_symbol( $code ) . ')';
	}
	$cmb = new_cmb2_box(array(
		'id' => 'currency_options',
		'title' => __('Currency options', 'wp-real-estate'),
		'show_on' => $show_on,
	));
	$cmb->add_field(array(
		'name' => __('Currency', 'wp-real-estate'),
		'before_row' => __('The following options affect how prices are displayed on the frontend.', 'wp-real-estate'),
		'id' => 'currency_symbol',
		'type' => 'select',
		'options' => $currency_code_options,
		'default'    => 'USD'
	));
	$cmb->add_field( array(
        'name'       => __( 'Currency Position', 'wp-real-estate' ),
        'desc'       => __( 'This controls the position of the currency symbol', 'wp-real-estate' ),
        'id'         => 'currency_position',
        'type'       => 'select',
        'options' => array(
            'left'          => __( 'Left ($100)', 'wp-real-estate' ),
            'right'         => __( 'Right (100$)', 'wp-real-estate' ),
            'left_space'    => __( 'Left with space ($ 100)', 'wp-real-estate' ),
            'right_space'   => __( 'Right with space (100 $)', 'wp-real-estate' ),
        ),
    ));
    $cmb->add_field( array(
        'name'       => __( 'Thousand Separator', 'wp-real-estate' ),
        'desc'       => __( 'This sets the thousand seperator of displayed prices', 'wp-real-estate' ),
        'id'         => 'thousand_separator',
        'type'       => 'text',
        'default'    => ',',
    ));
    $cmb->add_field( array(
        'name'       => __( 'Include Decimals', 'wp-real-estate' ),
        'id'         => 'include_decimals',
        'type'       => 'select',
        'options' => array(
            'no'      => __( 'No, do not include decimals in price', 'wp-real-estate' ),
            'yes'     => __( 'Yes, include decimals in price', 'wp-real-estate' ),
        ),
        'default'    => 'no',
    ));
    $cmb->add_field( array(
        'name'       => __( 'Decimal Separator', 'wp-real-estate' ),
        'desc'       => __( 'This sets the decimal seperator of displayed prices', 'wp-real-estate' ),
        'id'         => 'decimal_separator',
        'type'       => 'text',
        'default'    => '.',
    ));
    $cmb->add_field( array(
        'name'       => __( 'Number of Decimals', 'wp-real-estate' ),
        'desc'       => __( 'This sets the number of decimal points shown in displayed prices', 'wp-real-estate' ),
        'id'         => 'decimals',
        'type'       => 'text',
        'default'    => '2',
    ));
	
	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	/* ==================== Agency Setup ==================== */
	$cmb = new_cmb2_box(array(
		'id' => 'agency_setup',
		'title' => __('Agency Setup', 'wp-real-estate-listings'),
		'show_on' => $show_on
	));
	$cmb->add_field(array(
		'name' => __('Agencies Page', 'wp-real-estate-listings'),
		'desc' => '',
		'id' => 'agency_archives_page',
		'type' => 'select',
		'options_cb' => 'wre_get_pages',
	));
	$cmb->add_field(array(
		'name' => __('Single Agency URL', 'wp-real-estate-listings'),
		'desc' => '',
		'id' => 'single_agency_url',
		'type' => 'text',
		'default' => 'agency',
	));
	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	/* ==================== Contact Form ==================== */

	// contact form
	$cmb = new_cmb2_box(array(
		'id' => 'contact_form',
		'title' => __('Contact Form Settings', 'wp-real-estate'),
		'show_on' => $show_on,
	));
	$cmb->add_field(array(
		'name' => __('Email From', 'wp-real-estate'),
		'desc' => __('The "from" address for all enquiry emails that are sent to Agents.', 'wp-real-estate'),
		'id' => 'email_from',
		'type' => 'text_email',
		'default' => get_bloginfo('admin_email'),
		'before_row' => '<p class="cmb2-metabox-description">' . __('Contact form enquiries are sent directly to the selected Agent on that listing.', 'wp-real-estate') . '</p>',
	));
	$cmb->add_field(array(
		'name' => __('Email From Name', 'wp-real-estate'),
		'desc' => __('The "from" name for all enquiry emails that are sent to Agents.', 'wp-real-estate'),
		'id' => 'email_from_name',
		'type' => 'text',
		'default' => get_bloginfo('name'),
	));
	$cmb->add_field(array(
		'name' => __('CC', 'wp-real-estate'),
		'desc' => __('Extra email addresses that are CC\'d on every enquiry (comma separated).', 'wp-real-estate'),
		'id' => 'contact_form_cc',
		'type' => 'text',
		'attributes' => array(
			'placeholder' => 'somebody@somewhere.com',
		),
	));
	$cmb->add_field(array(
		'name' => __('BCC', 'wp-real-estate'),
		'desc' => __('Extra email addresses that are BCC\'d on every enquiry (comma separated).', 'wp-real-estate'),
		'id' => 'contact_form_bcc',
		'type' => 'text',
		'attributes' => array(
			'placeholder' => 'somebody@somewhere.com',
		),
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	// contact form email
	$cmb = new_cmb2_box(array(
		'id' => 'contact_form_email',
		'title' => __('Contact Form Email', 'wp-real-estate'),
		'show_on' => $show_on,
		'desc' => '',
	));

	$cmb->add_field(array(
		'name' => __('Email Type', 'wp-real-estate'),
		'desc' => '',
		'id' => 'contact_form_email_type',
		'type' => 'select',
		'options' => array(
			'html_email' => __('HTML', 'wp-real-estate'),
			'text_email' => __('Plain Text', 'wp-real-estate'),
		),
		'default' => 'html_email',
	));
	$cmb->add_field(array(
		'name' => __('Email Subject', 'wp-real-estate'),
		'desc' => '',
		'id' => 'contact_form_subject',
		'type' => 'text',
		'default' => __('New enquiry on listing #{listing_id}', 'wp-real-estate'),
	));
	$cmb->add_field(array(
		'name' => __('Email Message', 'wp-real-estate'),
		'desc' => __('Content of the email that is sent to the agent (and other email addresses above). ' .
				'Available tags are:<br>' .
				'{agent_name}<br>' .
				'{listing_title}<br>' .
				'{listing_id}<br>' .
				'{enquiry_name}<br>' .
				'{enquiry_email}<br>' .
				'{enquiry_phone}<br>' .
				'{enquiry_message}<br>'
				, 'wp-real-estate'),
		'default' => __('Hi {agent_name},', 'wp-real-estate') . "\r\n" .
		__('There has been a new enquiry on <strong>{listing_title}</strong>', 'wp-real-estate') . "\r\n" .
		'<hr>' . "\r\n" .
		__('Name: {enquiry_name}', 'wp-real-estate') . "\r\n" .
		__('Email: {enquiry_email}', 'wp-real-estate') . "\r\n" .
		__('Phone: {enquiry_phone}', 'wp-real-estate') . "\r\n" .
		__('Message: {enquiry_message}', 'wp-real-estate') . "\r\n" .
		'<hr>',
		'id' => 'contact_form_message',
		'type' => 'textarea',
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	// contact form messages
	$cmb = new_cmb2_box(array(
		'id' => 'contact_form_messages',
		'title' => __('Contact Form Messages', 'wp-real-estate'),
		'show_on' => $show_on,
		'desc' => '',
	));

	$cmb->add_field(array(
		'name' => __('Consent Field Label', 'wp-real-estate'),
		'desc' => __('Add Consent Field.', 'wp-real-estate'),
		'id' => 'contact_form_consent_label',
		'type' => 'text',
		'default' => ''
	));

	$cmb->add_field(array(
		'name' => __('Consent Description', 'wp-real-estate'),
		'desc' => __('Add Consent Description.', 'wp-real-estate'),
		'id' => 'contact_form_consent_desc',
		'type' => 'wysiwyg',
		'options' => array( 'teeny' => true, 'quicktags' => false, 'media_buttons' => false, 'textarea_rows' => 5 ),
		'default' => ''
	));

	$cmb->add_field(array(
		'name' => __('Success Message', 'wp-real-estate'),
		'desc' => __('The message that is displayed to users upon successfully sending a message.', 'wp-real-estate'),
		'id' => 'contact_form_success',
		'type' => 'text',
		'default' => __('Thank you, the agent will be in touch with you soon.', 'wp-real-estate'),
	));
	$cmb->add_field(array(
		'name' => __('Error Message', 'wp-real-estate'),
		'desc' => __('The message that is displayed if there is an error sending the message.', 'wp-real-estate'),
		'id' => 'contact_form_error',
		'type' => 'text',
		'default' => __('There was an error. Please try again.', 'wp-real-estate'),
	));
	$cmb->add_field(array(
		'name' => __('Include Error Code', 'wp-real-estate'),
		'desc' => __('Should the error code be shown with the error. Can be helpful for troubleshooting.', 'wp-real-estate'),
		'id' => 'contact_form_include_error',
		'type' => 'select',
		'options' => array(
			'yes' => __('Yes', 'wp-real-estate'),
			'no' => __('No', 'wp-real-estate'),
		),
		'default' => 'yes',
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	/* ==================== Agents Listings Options ==================== */

	$cmb = new_cmb2_box(array(
		'id' => 'agents_archive_data',
		'title' => __('Agents Archive', 'wp-real-estate'),
		'show_on' => $show_on,
	));
	$cmb->add_field(array(
		'name' => __('Agents Archive Listing Style', 'wp-real-estate'),
		'desc' => '',
		'id' => 'wre_agents_mode',
		'type' => 'select',
		'default' => 'grid-view',
		'options' => array(
			'grid-view' => __('Grid Mode', 'wp-real-estate'),
			'list-view' => __('List Mode', 'wp-real-estate'),
		),
	));
	$cmb->add_field(array(
		'name' => __('Agents Archive Grid Columns', 'wp-real-estate'),
		'desc' => __('The number of columns to display, when viewing agents in grid mode.', 'wp-real-estate'),
		'id' => 'wre_archive_agents_columns',
		'type' => 'select',
		'default' => '3',
		'options' => array(
			'2' => __('2 columns', 'wp-real-estate'),
			'3' => __('3 columns', 'wp-real-estate'),
			'4' => __('4 columns', 'wp-real-estate'),
		),
	));
	$cmb->add_field( array(
		'name' => __('Agents Archive Number of Agents', 'wp-real-estate'),
		'desc' => __('The max number of agents to show', 'wp-real-estate') . '<br>' . __('Could show less than this if not enough agents are found.', 'wp-real-estate'),
		'id'   => 'agents_archive_max_agents',
		'type' => 'text',
		'default' => '10',
		'attributes' => array(
			'type' => 'number',
			'min'	=> 1
		),
	) );
	$cmb->add_field(array(
		'name' => __('Agents Archive Allow Pagination', 'wp-real-estate'),
		'desc' => '',
		'id' => 'agents_archive_allow_pagination',
		'type' => 'select',
		'default' => 'yes',
		'options' => array(
			'yes' => __('Yes', 'wp-real-estate'),
			'no' => __('No', 'wp-real-estate'),
		),
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	// template html
	$cmb = new_cmb2_box(array(
		'id' => 'agents_listing_data',
		'title' => __('Agent Single', 'wp-real-estate'),
		'show_on' => $show_on,
	));
	$cmb->add_field(array(
		'name' => __('Show Agent Listings', 'wp-real-estate'),
		'desc' => __('Should the agent listings be shown below the content.', 'wp-real-estate'),
		'id' => 'show_agents_listings',
		'type' => 'select',
		'default' => 'yes',
		'options' => array(
			'yes' => __('Yes', 'wp-real-estate'),
			'no' => __('No', 'wp-real-estate'),
		),
	));
	$cmb->add_field(array(
		'name' => __('Single Agent Page Listing Style', 'wp-real-estate'),
		'desc' => '',
		'id' => 'wre_agent_mode',
		'type' => 'select',
		'default' => 'grid-view',
		'options' => array(
			'grid-view' => __('Grid Mode', 'wp-real-estate'),
			'list-view' => __('List Mode', 'wp-real-estate'),
		),
	));
	$cmb->add_field(array(
		'name' => __('Single Agent Page Grid Columns', 'wp-real-estate'),
		'desc' => __('The number of columns to display, when viewing agent listings in grid mode.', 'wp-real-estate'),
		'id' => 'wre_agent_columns',
		'type' => 'select',
		'default' => '3',
		'options' => array(
			'2' => __('2 columns', 'wp-real-estate'),
			'3' => __('3 columns', 'wp-real-estate'),
			'4' => __('4 columns', 'wp-real-estate'),
		),
	));
	$cmb->add_field( array(
		'name' => __('Single Agent Page Max Listings', 'wp-real-estate'),
		'desc' => __('The max number of agent listings to show', 'wp-real-estate') . '<br>' . __('Could show less than this if not enough agent listings are found.', 'wp-real-estate'),
		'id'   => 'agent_max_listings',
		'type' => 'text',
		'default' => '3',
		'attributes' => array(
			'type' => 'number',
			'min'	=> 1
		),
	) );
	$cmb->add_field(array(
		'name' => __('Single Agent Page', 'wp-real-estate'),
		'desc' => __('Single agent page, used when Theme Compatibility is enabled.', 'wp-real-estate'),
		'id' => 'wre_single_agent',
		'type' => 'select',
		'options_cb' => 'wre_get_pages',
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	/* ==================== Advanced Options ==================== */

	// template html
	$cmb = new_cmb2_box(array(
		'id' => 'template_html',
		'title' => __('Template HTML', 'wp-real-estate'),
		'show_on' => $show_on,
	));
	$cmb->add_field(array(
		'name' => __('Theme Compatibility', 'wp-real-estate'),
		'desc' => __('If enabled, add [wre_archive_listings], [wre_archive_agencies] & [wre_archive_agent] shortcode on there respective pages and remove it if disabled.', 'wp-real-estate'),
		'id' => 'wre_theme_compatibility',
		'type' => 'select',
		'default' => 'enable',
		'options' => array(
			'enable' => __('Enabled', 'wp-real-estate'),
			'disable' => __('Disabled', 'wp-real-estate'),
		),
	));
	$cmb->add_field(array(
		'name' => __('Opening HTML Tag(s)', 'wp-real-estate'),
		'desc' => __('Used for theme compatability, this option will override the opening HTML for all Listings pages.', 'wp-real-estate') . '<br>' . __('This can help you to match the HTML with your current theme.', 'wp-real-estate'),
		'id' => 'opening_html',
		'type' => 'textarea',
		'attributes' => array(
			'placeholder' => '<div class=&quot;container&quot;><div class=&quot;main-content&quot;>',
			'rows' => 2,
		),
		'before_row' => '<p class="cmb2-metabox-description"></p>',
	));
	$cmb->add_field(array(
		'name' => __('Closing HTML Tag(s)', 'wp-real-estate'),
		'desc' => __('Used for theme compatability, this option will override the closing HTML for all Listings pages.', 'wp-real-estate') . '<br>' .
		__('This can help you to match the HTML with your current theme.', 'wp-real-estate'),
		'id' => 'closing_html',
		'type' => 'textarea',
		'attributes' => array(
			'placeholder' => '</div></div>',
			'rows' => 2,
		),
	));
	$cmb->add_field(array(
		'name' => __('Hide In-content sidebar page', 'wp-real-estate'),
		'desc' => __('Used for removing in-content sidebar on single-listing page.', 'wp-real-estate'),
		'id' => 'wre_hide_in_content_sidebar',
		'type' => 'select',
		'default' => 'no',
		'options' => array(
			'yes' => __('Yes', 'wp-real-estate'),
			'no' => __('No', 'wp-real-estate'),
		),
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	// uninstall
	$cmb = new_cmb2_box(array(
		'id' => 'uninstall',
		'title' => __('Uninstall', 'wp-real-estate'),
		'show_on' => $show_on,
	));
	$cmb->add_field(array(
		'name' => __('Delete Data', 'wp-real-estate'),
		'desc' => __('Should all plugin data be deleted upon uninstalling this plugin?', 'wp-real-estate'),
		'id' => 'delete_data',
		'type' => 'select',
		'default' => 'no',
		'options' => array(
			'yes' => __('Yes', 'wp-real-estate'),
			'no' => __('No', 'wp-real-estate'),
		),
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	/* ==================== IDX Settings ==================== */

	$cmb = new_cmb2_box(array(
		'id' => 'idx_imported_listings',
		'title' => __('IDX Imported Listings', 'wp-real-estate'),
		'description' => '<p class="cmb2-metabox-description">' . __('These settings apply to any imported IDX listings. Imported listings are updated via the latest API response twice daily.', 'wp-real-estate') . '</p>',
		'show_on' => $show_on,
	));
	$cmb->add_field(array(
		'name' => __('Update Listings', 'wp-real-estate'),
		'before_row' => '<p class="cmb2-metabox-description">' . __('These settings apply to any imported IDX listings. Imported listings are updated via the latest API response twice daily.', 'wp-real-estate') . '</p>',
		'id' => 'wre_update_listings',
		'type' => 'radio_inline',
		'default' => 'update_noimage',
		'options' => array(
			'update_all' => __('Update All', 'wp-real-estate') . '<p class="cmb2-metabox-description">'.__('Excludes Post Title and Post Content', 'wp-real-estate').')</span>',
			'update_noimage' => __('Update Excluding Images', 'wp-real-estate') . '<p class="cmb2-metabox-description">'.__('Also excludes Post Title and Post Content', 'wp-real-estate').')</p>',
			'update_none' => __('Do Not Update', 'wp-real-estate') . '<p class="cmb2-metabox-description"> <b>'.__( 'Not recommended as displaying inaccurate MLS data may violate your IDX agreement.', 'wp-real-estate' ).'</b><br />'.__('Listing will be changed to sold status if it exists in the sold data feed.', 'wp-real-estate').'</p>',
		),
	));
	$cmb->add_field(array(
		'name' => __('Sold Listings', 'wp-real-estate'),
		'id' => 'wre_sold_listings',
		'type' => 'radio',
		'default' => 'keep_sold',
		'options' => array(
			'keep_sold' => __('Keep All', 'wp-real-estate') . '<p class="cmb2-metabox-description">'.__('This will keep all imported listings published with the status changed to reflect as sold.', 'wp-real-estate').'</p>',
			'draft_sold' => __('Keep as Draft', 'wp-real-estate') . '<p class="cmb2-metabox-description">'.__('This will keep all imported listings that have been sold, but they will be changed to draft status in WordPress.', 'wp-real-estate').'</p>',
			'delete_sold' => __('Delete Sold', 'wp-real-estate') . '<p class="cmb2-metabox-description"><b>'.__( 'Not recommended.', 'wp-real-estate' ).'</b><br />'.__('This will delete all sold listings and attached featured images from your WordPress database and media library.', 'wp-real-estate').'</p>',
		),
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	$cmb = new_cmb2_box(array(
		'id' => 'idx_import_options',
		'title' => __('Import IDX Listings', 'wp-real-estate'),
		'show_on' => $show_on,
	));
	$cmb->add_field( array(
		'name' => __('Enter Your API Key:', 'wp-real-estate'),
		'desc' => __('Enter your API key to continue', 'wp-real-estate'),
		'before_row' => '<p class="cmb2-metabox-description">' . sprintf (__( 'If you do not have an %s account, please contact the IDX Broker team at 800-421-9668.', 'wp-real-estate' ), '<a href="https://idxbroker.com" target="_blank">'. __( 'IDX Broker', 'wp-real-estate' ) .'</a>') .' </p>',
		'id'   => 'wre_idx_api_key',
		'type' => 'text',
		'default' => '',
	) );
	$cmb->add_field( array(
		'name' => __('Automatically Import New Listings?', 'wp-real-estate'),
		'desc' => '',
		'id'   => 'wre_auto_import_idx_listings',
		'type' => 'checkbox',
	) );
	$cmb->add_field( array(
		'name'				=> __('Imported Listings Title', 'wp-real-estate'),
		'desc'				=> __( 'By default, imported listings use the street address as the title and permalink.', 'wp-real-estate' ),
		'id'				=> 'wre_idx_listing_title',
		'type'				=> 'select',
		'default'			=> 'address',
		'options'			=> array(
				'listingid'	=> __( 'Listing Id', 'wp-real-estate' ),
				'address'	=> __( 'Address', 'wp-real-estate' ),
				'city'		=> __( 'City', 'wp-real-estate' ),
				'state'		=> __( 'State', 'wp-real-estate' ),
				'zipcode'	=> __( 'Zipcode', 'wp-real-estate' ),
		),
	) );
	$cmb->add_field(array(
		'name' => __('Select an author to use when importing listings ', 'wp-real-estate'),
		'desc' => '',
		'id' => 'wre_idx_listings_author',
		'type' => 'select',
		'options_cb' => 'wre_admin_get_agents',
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	/* ==================== My Listings Settings ==================== */

	$cmb = new_cmb2_box(array(
		'id' => 'wre_my_listings',
		'title' => __('My Listings', 'wp-real-estate'),
		'description' => '',
		'show_on' => $show_on,
	));
	$cmb->add_field(array(
		'name' => __('My Listings Mode', 'wp-real-estate'),
		'desc' => '',
		'id' => 'my_listings_mode',
		'type' => 'select',
		'default' => 'grid-view',
		'options' => array(
			'grid-view' => __('Grid Mode', 'wp-real-estate'),
			'list-view' => __('List Mode', 'wp-real-estate'),
		),
	));
	$cmb->add_field(array(
		'name' => __('My Listings Columns', 'wp-real-estate'),
		'desc' => __('The number of columns to display on the my-listings page, when viewing listings in grid mode.', 'wp-real-estate'),
		'id' => 'my_listings_columns',
		'type' => 'select',
		'default' => '3',
		'options' => array(
			'2' => __('2 columns', 'wp-real-estate'),
			'3' => __('3 columns', 'wp-real-estate'),
			'4' => __('4 columns', 'wp-real-estate'),
		),
	));
	$cmb->add_field(array(
		'name' => __('My Listings Page', 'wp-real-estate'),
		'desc' => __('The page to display logged in users listings. This page must have an [wre_my_listings] shortcode.', 'wp-real-estate'),
		'id' => 'wre_my_listings',
		'type' => 'select',
		'options_cb' => 'wre_get_pages',
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	$cmb = new_cmb2_box(array(
		'id' => 'wre_submit_listing',
		'title' => __('Submit Listings', 'wp-real-estate'),
		'description' => '',
		'show_on' => $show_on,
	));
	$cmb->add_field(array(
		'name' => __('Submit Listings Page', 'wp-real-estate'),
		'desc' => __('The page to display create listings form. This page must have an [wre_submit_listing] shortcode.', 'wp-real-estate'),
		'id' => 'submit_listings',
		'type' => 'select',
		'options_cb' => 'wre_get_pages',
	));
	$cmb->add_field(array(
		'name' => __('User Subscription Page', 'wp-real-estate'),
		'desc' => __('The page to display packages. This page must have an [wre_membership_packages] shortcode.', 'wp-real-estate'),
		'id' => 'wre_user_packages',
		'type' => 'select',
		'options_cb' => 'wre_get_pages',
	));
	$cmb->add_field( array(
		'name' => __('Disable Listing Submit for User Role Subscriber', 'wp-real-estate'),
		'desc' => __('If checked, only agents and admins are able to submit listings', 'wp-real-estate'),
		'id'   => 'wre_disable_listing_submission',
		'type' => 'checkbox',
	) );
	$cmb->add_field( array(
		'name' => __('Auto Publish Listings on Payment Completion', 'wp-real-estate'),
		'desc' => __('If disabled, you have to publish listings manually.', 'wp-real-estate'),
		'id'   => 'wre_auto_publish_listings',
		'type' => 'checkbox',
	) );
	$cmb->add_field(array(
		'name' => __('After Expiration', 'wp-real-estate'),
		'desc' => __('Set what to do with listings when user subscription expires.', 'wp-real-estate'),
		'id' => 'wre_after_expiration',
		'type' => 'select',
		'default' => 'draft',
		'options' => array(
			'draft' => __('Move Listing to Draft', 'wp-real-estate'),
			'mark-free' => __('Mark Listinga as Free', 'wp-real-estate'),
		),
	));
	$cmb->add_field( array(
		'name' => __('Currency Code', 'wp-real-estate'),
		'desc' => __( 'Enter the currency code you wish to use. E.g. for US dollars enter USD. Your gateway must support your input currency for payments to work.', 'wp-real-estate' ),
		'id'   => 'wre_currency_code',
		'type' => 'text',
		'default' => 'USD'
	) );
	$cmb->add_field(array(
		'name' => __('Consent Field Label', 'wp-real-estate'),
		'desc' => __('Add Consent Field.', 'wp-real-estate'),
		'id' => 'submit_listing_consent_label',
		'type' => 'text',
		'default' => ''
	));

	$cmb->add_field(array(
		'name' => __('Consent Description', 'wp-real-estate'),
		'desc' => __('Add Consent Description.', 'wp-real-estate'),
		'id' => 'submit_listing_consent_desc',
		'type' => 'wysiwyg',
		'options' => array( 'teeny' => true, 'quicktags' => false, 'media_buttons' => false, 'textarea_rows' => 5 ),
		'default' => ''
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	$cmb = new_cmb2_box(array(
		'id' => 'wre_submit_listing_email_notifications',
		'title' => __('Submit Listings Email Notifications', 'wp-real-estate'),
		'description' => '',
		'show_on' => $show_on,
	));
	$cmb->add_field( array(
		'name' => __('Send Email Notification To', 'wp-real-estate'),
		'desc' => __('Get notified about listing submit via email', 'wp-real-estate'),
		'id'   => 'wre_new_listing_notification',
		'type' => 'text',
		'default' => get_bloginfo('admin_email')
	) );
	$cmb->add_field(array(
		'name' => __('New Listing Email Subject', 'wp-real-estate'),
		'desc' => '',
		'id' => 'wre_new_listing_email_subject',
		'type' => 'text',
		'default' => __('New listing #{listing_id}', 'wp-real-estate'),
	));
	$cmb->add_field(array(
		'name' => __('New Listing Email Message', 'wp-real-estate'),
		'desc' => __('Content of the email that is sent to the agent (and other email addresses above). ' .
				'Available tags are:<br>' .
				'{user_name}<br>' .
				'{listing_name}<br>' .
				'{listing_id}<br>' .
				'{user_email}<br>'
				, 'wp-real-estate'),
		'default' => __('Hi,', 'wp-real-estate') . "\r\n" .
		__('A new listing has been submitted by <strong>{user_name}</strong>', 'wp-real-estate') . "\r\n" .
		'<hr>' . "\r\n" .
		__('Name: {listing_name}', 'wp-real-estate') . "\r\n" .
		__('Email: {user_email}', 'wp-real-estate') . "\r\n" .
		'<hr>',
		'id' => 'wre_new_listing_email_message',
		'after_row' => '<br />',
		'type' => 'wysiwyg',
		'options' => array(
			'wpautop' => true, // use wpautop?
			'media_buttons' => false, // show insert/upload button(s)
			'textarea_rows' => get_option('default_post_edit_rows',3), // rows="..."
			'teeny' => true, // output the minimal editor config used in Press This
			'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
			'quicktags' => false // load Quicktags, can be used to pass settings directly to Quicktags using an array()
		),
	));

	$cmb->add_field(array(
		'name' => __('Email Subject', 'wp-real-estate'),
		'desc' => '',
		'id' => 'wre_payment_received_email_subject',
		'type' => 'text',
		'before_row' => '<hr /><br /><h3>'.__( 'Email to sent when payment is received', 'wp-real-estate' ).'</h3>',
		'default' => __('Payment Received #{listing_id}', 'wp-real-estate'),
	));

	$cmb->add_field(array(
		'name' => __('Email Message', 'wp-real-estate'),
		'desc' => __('Content of the email that is sent to the andmin (or other email address above). ' .
				'Available tags are:<br>' .
				'{listing_name}<br>' .
				'{listing_id}<br>' .
				'{payment_received}<br>' .
				'{actual_payment}<br>'
				, 'wp-real-estate'),
		'default' => __('Hi,', 'wp-real-estate') . "\r\n" .
		__('Payment has been received in full for Listing #{listing_id} - this listing has been automatically approved.', 'wp-real-estate') . "\r\n" .
		'<hr>' . "\r\n" .
		__('Listing Id: {listing_id}', 'wp-real-estate') . "\r\n" .
		'<hr>',
		'id' => 'wre_payment_received_email_message',
		'after_row' => '<br />',
		'type' => 'wysiwyg',
		'options' => array(
			'wpautop' => true, // use wpautop?
			'media_buttons' => false, // show insert/upload button(s)
			'textarea_rows' => get_option('default_post_edit_rows',3), // rows="..."
			'teeny' => true, // output the minimal editor config used in Press This
			'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
			'quicktags' => false // load Quicktags, can be used to pass settings directly to Quicktags using an array()
		),
	));

	$cmb->add_field(array(
		'name' => __('Email Subject', 'wp-real-estate'),
		'desc' => '',
		'id' => 'wre_payment_received_admin_approval_email_subject',
		'type' => 'text',
		'before_row' => '<hr /><br /><h3>'.__( 'Email to sent when payment is received and needs admin approval', 'wp-real-estate' ).'</h3>',
		'default' => __('Payment Received #{listing_id}', 'wp-real-estate'),
	));

	$cmb->add_field(array(
		'name' => __('Email Message', 'wp-real-estate'),
		'desc' => __('Content of the email that is sent to the andmin (or other email address above). ' .
				'Available tags are:<br>' .
				'{listing_name}<br>' .
				'{listing_id}<br>' .
				'{payment_received}<br>' .
				'{actual_payment}<br>'
				, 'wp-real-estate'),
		'default' => __('Hi,', 'wp-real-estate') . "\r\n" .
		__('Payment has been received in full for Listing #{listing_id} - this listing is ready for admin approval.', 'wp-real-estate') . "\r\n" .
		'<hr>' . "\r\n" .
		__('Listing Id: {listing_id}', 'wp-real-estate') . "\r\n" .
		'<hr>',
		'id' => 'wre_payment_received_admin_approval_email_message',
		'after_row' => '<br />',
		'type' => 'wysiwyg',
		'options' => array(
			'wpautop' => true, // use wpautop?
			'media_buttons' => false, // show insert/upload button(s)
			'textarea_rows' => get_option('default_post_edit_rows',3), // rows="..."
			'teeny' => true, // output the minimal editor config used in Press This
			'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
			'quicktags' => false // load Quicktags, can be used to pass settings directly to Quicktags using an array()
		),
	));

	$cmb->add_field(array(
		'name' => __('Email Subject', 'wp-real-estate'),
		'desc' => '',
		'id' => 'wre_new_subscription_email_subject',
		'type' => 'text',
		'before_row' => '<hr /><br /><h3>'.__( 'Email to sent when new user subscribe', 'wp-real-estate' ).'</h3>',
		'default' => __('New Subscription #{user_id}', 'wp-real-estate'),
	));
	$cmb->add_field(array(
		'name' => __('Email Message', 'wp-real-estate'),
		'desc' => __('Content of the email that is sent to the andmin (or other email address above). ' .
				'Available tags are:<br>' .
				'{user_name}<br>' .
				'{user_email}<br>' .
				'{package_name}<br>'
				, 'wp-real-estate'),
		'default' => __('Hi,', 'wp-real-estate') . "\r\n" .
		__('A new user has been subscribed <strong>{user_name}</strong>', 'wp-real-estate') . "\r\n" .
		'<hr>' . "\r\n" .
		__('Name: {user_name}', 'wp-real-estate') . "\r\n" .
		__('Email: {user_email}', 'wp-real-estate') . "\r\n" .
		__('Package: {package_name}', 'wp-real-estate') . "\r\n" .
		'<hr>',
		'id' => 'wre_new_subscription_email_message',
		'after_row' => '<br />',
		'type' => 'wysiwyg',
		'options' => array(
			'wpautop' => true, // use wpautop?
			'media_buttons' => false, // show insert/upload button(s)
			'textarea_rows' => get_option('default_post_edit_rows',3), // rows="..."
			'teeny' => true, // output the minimal editor config used in Press This
			'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
			'quicktags' => false // load Quicktags, can be used to pass settings directly to Quicktags using an array()
		),
	));

	$cmb->add_field(array(
		'name' => __('Email Subject', 'wp-real-estate'),
		'desc' => '',
		'id' => 'wre_payment_mismatch_email_subject',
		'type' => 'text',
		'before_row' => '<hr /><br /><h3>'.__( 'Email to sent when payment mismatch', 'wp-real-estate' ).'</h3>',
		'default' => __('Payment Mismatch #{listing_id}', 'wp-real-estate'),
	));

	$cmb->add_field(array(
		'name' => __('Email Message', 'wp-real-estate'),
		'desc' => __('Content of the email that is sent to the andmin (or other email address above). ' .
				'Available tags are:<br>' .
				'{listing_id}<br>' .
				'{payment_received}<br>' .
				'{actual_payment}<br>'
				, 'wp-real-estate'),
		'default' => __('Hi,', 'wp-real-estate') . "\r\n" .
		__('The PayPal amount recieved does not match the listing fee - please manually check payment before approving this listing. The listing has *not* been automatically approved.', 'wp-real-estate') . "\r\n" .
		'<hr>' . "\r\n" .
		__('Listing Id: {listing_id}', 'wp-real-estate') . "\r\n" .
		__('Actual Payment: {actual_payment}', 'wp-real-estate') . "\r\n" .
		__('Package: {payment_received}', 'wp-real-estate') . "\r\n" .
		'<hr>',
		'id' => 'wre_payment_mismatch_email_message',
		'after_row' => '<br />',
		'type' => 'wysiwyg',
		'options' => array(
			'wpautop' => true, // use wpautop?
			'media_buttons' => false, // show insert/upload button(s)
			'textarea_rows' => get_option('default_post_edit_rows',3), // rows="..."
			'teeny' => true, // output the minimal editor config used in Press This
			'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
			'quicktags' => false // load Quicktags, can be used to pass settings directly to Quicktags using an array()
		),
	));

	$cmb->add_field(array(
		'name' => __('Email Subject', 'wp-real-estate'),
		'desc' => '',
		'id' => 'wre_pending_payment_email_subject',
		'type' => 'text',
		'before_row' => '<hr /><br /><h3>'.__( 'Email to sent when payment is pending', 'wp-real-estate' ).'</h3>',
		'default' => __('Pending Payment #{listing_id}', 'wp-real-estate'),
	));

	$cmb->add_field(array(
		'name' => __('Email Message', 'wp-real-estate'),
		'desc' => __('Content of the email that is sent to the andmin (or other email address above). ' .
				'Available tags are:<br>' .
				'{listing_id}<br>' .
				'{actual_payment}<br>'
				, 'wp-real-estate'),
		'default' => __('Hi,', 'wp-real-estate') . "\r\n" .
		__('PayPal payment is pending for Listing {listing_id} - this listing has *not* been automatically approved.', 'wp-real-estate') . "\r\n" .
		'<hr>' . "\r\n" .
		__('Listing Id: {listing_id}', 'wp-real-estate') . "\r\n" .
		'<hr>',
		'id' => 'wre_pending_payment_email_message',
		'after_row' => '<br />',
		'type' => 'wysiwyg',
		'options' => array(
			'wpautop' => true, // use wpautop?
			'media_buttons' => false, // show insert/upload button(s)
			'textarea_rows' => get_option('default_post_edit_rows',3), // rows="..."
			'teeny' => true, // output the minimal editor config used in Press This
			'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
			'quicktags' => false // load Quicktags, can be used to pass settings directly to Quicktags using an array()
		),
	));
	
	$cmb->add_field(array(
		'name' => __('Email Subject', 'wp-real-estate'),
		'desc' => '',
		'id' => 'wre_customer_invoice_email_subject',
		'type' => 'text',
		'before_row' => '<hr /><br /><h3>'.__( 'Customer Invoice Email', 'wp-real-estate' ).'</h3>',
		'default' => __('Thank you for subscribing', 'wp-real-estate'),
	));

	$cmb->add_field(array(
		'name' => __('Email Message', 'wp-real-estate'),
		'desc' => __('Content of the email that is sent to the andmin (or other email address above). ' .
				'Available tags are:<br>' .
				'{transaction_id}<br>' .
				'{payment_method}<br>' .
				'{price}<br>' .
				'{package_name}<br>'
				, 'wp-real-estate'),
		'default' => __('Hi,', 'wp-real-estate') . "\r\n" .
		__('Your payment has been received and is now being processed. Your subscription details are shown below for your reference:', 'wp-real-estate') . "\r\n" .
		'<hr>' . "\r\n" .
		__('Transaction Id: {transaction_id}', 'wp-real-estate') . "\r\n" .
		__('Package Name: {package_name}', 'wp-real-estate') . "\r\n" .
		__('Price: {price}', 'wp-real-estate') . "\r\n" .
		__('Payment Method: {payment_method}', 'wp-real-estate') . "\r\n" .
		'<hr>',
		'id' => 'wre_customer_invoice_email_message',
		'after_row' => '<br />',
		'type' => 'wysiwyg',
		'options' => array(
			'wpautop' => true, // use wpautop?
			'media_buttons' => false, // show insert/upload button(s)
			'textarea_rows' => get_option('default_post_edit_rows',3), // rows="..."
			'teeny' => true, // output the minimal editor config used in Press This
			'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
			'quicktags' => false // load Quicktags, can be used to pass settings directly to Quicktags using an array()
		),
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;
	
	$cmb = new_cmb2_box(array(
		'id' => 'wre_paypal_payment',
		'title' => __('PayPal Settings', 'wp-real-estate'),
		'show_on' => $show_on,
	));
	$cmb->add_field( array(
		'name' => __('Enable/Disable', 'wp-real-estate'),
		'desc' => __('Enable PayPal Standard', 'wp-real-estate'),
		'before_row' => __( 'PayPal Standard sends customers to PayPal to enter their payment information.', 'wp-real-estate' ),
		'id'   => 'wre_enable_paypal',
		'type' => 'checkbox'
	) );
	$cmb->add_field( array(
		'name' => __('Title', 'wp-real-estate'),
		'desc' => __('The title which the user sees during checkout.', 'wp-real-estate'),
		'id'   => 'wre_paypal_title',
		'default'     => __( 'PayPal', 'wp-real-estate' ),
		'type' => 'text'
	) );
	$cmb->add_field( array(
		'name' => __('Description', 'wp-real-estate'),
		'desc' => __('The description which the user sees during checkout.', 'wp-real-estate'),
		'id'   => 'wre_paypal_description',
		'default'	=> __( 'Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.', 'wp-real-estate' ),
		'type' => 'textarea',
		'attributes' => array(
				'rows' => 3
			),
	) );
	$cmb->add_field( array(
		'name' => __('Enable PayPal Sandbox for Testing', 'wp-real-estate'),
		'desc' => __('Disable to process live transactions.', 'wp-real-estate'),
		'id'   => 'wre_paypal_enable_sandbox',
		'type' => 'checkbox',
	) );
	$cmb->add_field( array(
		'name' => __('PayPal Email Address', 'wp-real-estate'),
		'id'   => 'wre_paypal_merchant_id',
		'type' => 'text'
	) );
	$cmb->add_field( array(
		'name' => __('Paypal PDT Token', 'wp-real-estate'),
		'desc' => __('Optionally enable "Payment Data Transfer" (Profile > Profile and Settings > My Selling Tools > Website Preferences) and then copy your identity token here. This will allow payments to be verified without the need for PayPal IPN.', 'wp-real-estate'),
		'id'   => 'wre_paypal_pdt_token',
		'type' => 'text'
	) );
	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	$cmb = new_cmb2_box(array(
		'id' => 'wre_bacs_payment',
		'title' => __('BACS', 'wp-real-estate'),
		'show_on' => $show_on,
	));
	$cmb->add_field( array(
		'name' => __('Enable/Disable', 'wp-real-estate'),
		'desc' => __('Enable bank transfer.', 'wp-real-estate'),
		'before_row' => __( 'Allows payments by BACS, more commonly known as direct bank/wire transfer.', 'wp-real-estate'),
		'id'   => 'wre_enable_bacs',
		'type' => 'checkbox'
	) );
	$cmb->add_field( array(
		'name' => __('Title', 'wp-real-estate'),
		'desc' => __('The title which the user sees during checkout.', 'wp-real-estate'),
		'id'   => 'wre_bacs_title',
		'default'     => __( 'Direct bank transfer', 'wp-real-estate' ),
		'type' => 'text'
	) );
	$cmb->add_field( array(
		'name' => __('Description', 'wp-real-estate'),
		'desc' => __('The description which the user sees during checkout.', 'wp-real-estate'),
		'id'   => 'wre_bacs_description',
		'default'	=> __( 'Make your payment directly into our bank account. Please use your Transaction ID as the payment reference. Your subscription will not be activated until the funds have cleared in our account.', 'wp-real-estate' ),
		'type' => 'textarea',
		'attributes' => array(
				'rows' => 3
			),
	) );
	$group_id = $cmb->add_field( array(
		'name' => __('Account Details', 'wp-real-estate'),
		'desc' => '',
		'id'   => 'wre_account_details',
		'default'	=> __( 'Make your payment directly into our bank account. Please use your Transaction ID as the payment reference. Your subscription will not be activated until the funds have cleared in our account.', 'wp-real-estate' ),
		'type' => 'group',
		'options'           => array(
			'group_title'   => 'Account {#}',
			'add_button'    => 'Add account',
			'remove_button' => 'Remove account',
			'sortable'      => true
		)
	) );
	$cmb->add_group_field( $group_id, array(
		'id'            => 'wre_account_name',
		'name'          => __('Account Name', 'wp-real-estate'),
		'type'          => 'text'
	) );
	$cmb->add_group_field( $group_id, array(
		'id'            => 'wre_account_number',
		'name'          => __('Account Number', 'wp-real-estate'),
		'type'          => 'text'
	) );
	$cmb->add_group_field( $group_id, array(
		'id'	=> 'wre_bank_name',
		'name'	=> __('Bank Name', 'wp-real-estate'),
		'type'	=> 'text'
	) );
	$cmb->add_group_field( $group_id, array(
		'id'	=> 'wre_bsb',
		'name'	=> __('BSB', 'wp-real-estate'),
		'type'	=> 'text'
	) );
	$cmb->add_group_field( $group_id, array(
		'id'	=> 'wre_iban',
		'name'	=> __('IBAN', 'wp-real-estate'),
		'type'	=> 'text'
	) );
	$cmb->add_group_field( $group_id, array(
		'id'	=> 'wre_swift',
		'name'	=> __('BIC / Swift', 'wp-real-estate'),
		'type'	=> 'text'
	) );

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	$cmb = new_cmb2_box(array(
		'id' => 'wre_paypal_payment',
		'title' => __('PayPal Settings', 'wp-real-estate'),
		'show_on' => $show_on,
	));
	$cmb->add_field( array(
		'name' => __('Enable/Disable', 'wp-real-estate'),
		'desc' => __('Enable PayPal Standard', 'wp-real-estate'),
		'before_row' => __( 'PayPal Standard sends customers to PayPal to enter their payment information.', 'wp-real-estate' ),
		'id'   => 'wre_enable_paypal',
		'type' => 'checkbox'
	) );
	$cmb->add_field( array(
		'name' => __('Title', 'wp-real-estate'),
		'desc' => __('The title which the user sees during checkout.', 'wp-real-estate'),
		'id'   => 'wre_paypal_title',
		'default'     => __( 'PayPal', 'wp-real-estate' ),
		'type' => 'text'
	) );
	$cmb->add_field( array(
		'name' => __('Description', 'wp-real-estate'),
		'desc' => __('The description which the user sees during checkout.', 'wp-real-estate'),
		'id'   => 'wre_paypal_description',
		'default'	=> __( 'Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.', 'wp-real-estate' ),
		'type' => 'textarea',
		'attributes' => array(
				'rows' => 3
			),
	) );
	$cmb->add_field( array(
		'name' => __('Enable PayPal Sandbox for Testing', 'wp-real-estate'),
		'desc' => __('Disable to process live transactions.', 'wp-real-estate'),
		'id'   => 'wre_paypal_enable_sandbox',
		'type' => 'checkbox',
	) );
	$cmb->add_field( array(
		'name' => __('PayPal Email Address', 'wp-real-estate'),
		'id'   => 'wre_paypal_merchant_id',
		'type' => 'text'
	) );
	$cmb->add_field( array(
		'name' => __('Paypal PDT Token', 'wp-real-estate'),
		'desc' => __('Optionally enable "Payment Data Transfer" (Profile > Profile and Settings > My Selling Tools > Website Preferences) and then copy your identity token here. This will allow payments to be verified without the need for PayPal IPN.', 'wp-real-estate'),
		'id'   => 'wre_paypal_pdt_token',
		'type' => 'text'
	) );
	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	$cmb = new_cmb2_box(array(
		'id' => 'wre_stripe_payment',
		'title' => __('Stripe Settings', 'wp-real-estate'),
		'show_on' => $show_on,
	));
	$cmb->add_field( array(
		'name' => __('Enable/Disable', 'wp-real-estate'),
		'desc' => __('Enable Stripe.', 'wp-real-estate'),
		'before_row' => sprintf( __( 'Stripe works by adding credit card fields on the checkout and then sending the details to Stripe for verification.%s %s  for a Stripe account, and %s', 'wp-real-estate' ), '<br />', '<a href="https://dashboard.stripe.com/register" target="_blank">'.__( 'Sign up', 'wp-real-estate' ).'</a>', '<a href="https://dashboard.stripe.com/account/apikeys" target="_blank">'.__( 'get your Stripe account keys', 'wp-real-estate' ).'</a>' ),
		'id'   => 'wre_enable_stripe',
		'type' => 'checkbox'
	) );
	$cmb->add_field( array(
		'name' => __('Title', 'wp-real-estate'),
		'desc' => __('The title which the user sees during checkout.', 'wp-real-estate'),
		'id'   => 'wre_stripe_title',
		'default'     => __( 'Credit Card (Stripe)', 'wp-real-estate' ),
		'type' => 'text'
	) );
	$cmb->add_field( array(
		'name' => __('Description', 'wp-real-estate'),
		'desc' => __('The description which the user sees during checkout.', 'wp-real-estate'),
		'id'   => 'wre_stripe_description',
		'default'	=> __( 'Pay with your credit card via Stripe.', 'wp-real-estate' ),
		'type' => 'textarea',
		'attributes' => array(
				'rows' => 3
			),
	) );
	$cmb->add_field( array(
		'name' => __('Enable Test Mode', 'wp-real-estate'),
		'desc' => __('Enable Test Mode.', 'wp-real-estate'),
		'id'   => 'wre_stripe_enable_testmode',
		'type' => 'checkbox',
	) );
	$cmb->add_field( array(
		'name' => __('Secret Key', 'wp-real-estate'),
		'desc' => __('Get your Secret Key from your stripe account.', 'wp-real-estate'),
		'id'   => 'wre_stripe_secret_key',
		'type' => 'text'
	) );
	$cmb->add_field( array(
		'name' => __('Publishable Key', 'wp-real-estate'),
		'desc' => __('Get your Publishable Key from your stripe account.', 'wp-real-estate'),
		'id'   => 'wre_stripe_publishable_key',
		'type' => 'text'
	) );

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	// box 3, in sidebar of our two-column layout
	$cmb = new_cmb2_box(array(
		'id' => 'side_metabox',
		'title' => __('Save Options', 'wp-real-estate'),
		'show_on' => $show_on,
		'context' => 'side',
	));
	$cmb->add_field(array(
		'name' => __('Publish?', 'wp-real-estate'),
		'desc' => __('Save Changes', 'wp-real-estate'),
		'id' => 'wre_save_button',
		'type' => 'wre_options_save_button',
		'show_names' => false,
	));
	$cmb->object_type('options-page');
	$boxes[] = $cmb;
	
	/* ==================== MY ACCOUNTS SETTINGS ==================== */

	$cmb = new_cmb2_box(array(
		'id' => 'wre_my_account',
		'title' => __('My Account', 'wp-real-estate'),
		'description' => '',
		'show_on' => $show_on,
	));
	$cmb->add_field(array(
		'name' => __('My Account Page', 'wp-real-estate'),
		'desc' => __('These pages need to be set so that WP Real Estate knows where to send users to access account related functionality. This page must have an [wre_my_account] shortcode.', 'wp-real-estate'),
		'id' => 'wre_account_page',
		'type' => 'select',
		'options_cb' => 'wre_get_pages',
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	$cmb = new_cmb2_box(array(
		'id' => 'wre_account_endpoints',
		'title' => __('My account endpoints', 'wp-real-estate'),
		'show_on' => $show_on,
	));
	$cmb->add_field( array(
		'name' => __('Edit Account', 'wp-real-estate'),
		'desc' => __( 'Endpoint for the My Account >> Edit Account page.', 'wp-real-estate' ),
		'before_row' => __( 'Endpoints are appended to your page URLs to handle specific actions on the accounts page. They should be unique.', 'wp-real-estate' ),
		'id'   => 'wre_account_endpoint_edit_account',
		'type' => 'text',
		'default' => 'edit-account'
	) );
	$cmb->add_field( array(
		'name' => __('Lost Password', 'wp-real-estate'),
		'desc' => __( 'Endpoint for the My Account >> Lost Password page.', 'wp-real-estate' ),
		'id'   => 'wre_account_endpoint_lost_password',
		'type' => 'text',
		'default' => 'lost-password'
	) );
	$cmb->add_field( array(
		'name' => __('Edit Profile', 'wp-real-estate'),
		'desc' => __( 'Endpoint for the My Account >> Edit Profile page.', 'wp-real-estate' ),
		'id'   => 'wre_account_endpoint_edit_profile',
		'type' => 'text',
		'default' => 'edit-profile'
	) );
	$cmb->add_field( array(
		'name' => __('Subscription', 'wp-real-estate'),
		'desc' => __( 'Endpoint for the My Account >> Subscription page.', 'wp-real-estate' ),
		'id'   => 'wre_account_endpoint_subscription',
		'type' => 'text',
		'default' => 'subscription-details'
	) );

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	$cmb = new_cmb2_box(array(
		'id' => 'wre_account_email_notifications',
		'title' => __('My Account Email Notifications', 'wp-real-estate'),
		'description' => '',
		'show_on' => $show_on,
	));
	$cmb->add_field(array(
		'name' => __('Lost Password Email Subject', 'wp-real-estate'),
		'desc' => '',
		'id' => 'wre_lost_password_email_subject',
		'type' => 'text',
		'default' => sprintf( __('Password reset for %s', 'wp-real-estate'), get_bloginfo('name') ),
	));
	$cmb->add_field(array(
		'name' => __('Lost Password Email Message', 'wp-real-estate'),
		'id' => 'wre_lost_password_email_message',
		'desc' => __('Content of the email that is sent to the agent (and other email addresses above). ' .
				'Available tags are:<br>' .
				'{user_name}<br>' .
				'{reset_password_link}<br>'
				, 'wp-real-estate'),
		'default' => '<p style="text-align: center;"><strong>Password reset instructions</strong></p>
			Someone requested that the password be reset for the following account:

			Username: {user_name}

			If this was a mistake, just ignore this email and nothing will happen.

			To reset your password, visit the following address: {reset_password_link}',
		'after_row' => '<br />',
		'type' => 'wysiwyg',
		'options' => array(
			'wpautop' => true, // use wpautop?
			'media_buttons' => false, // show insert/upload button(s)
			'textarea_rows' => get_option('default_post_edit_rows',3), // rows="..."
			'teeny' => true, // output the minimal editor config used in Press This
			'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
			'quicktags' => false // load Quicktags, can be used to pass settings directly to Quicktags using an array()
		),
	));

	$cmb->object_type('options-page');
	$boxes[] = $cmb;

	// Arguments array. See the arguments page for more detail
	$args = array(
		'key' => $opt_key,
		'title' => __('WRE Settings', 'wp-real-estate'),
		'topmenu' => 'edit.php',
		'postslug' => 'listing',
		'boxes' => $boxes,
		'tabs' => $tabs,
		'cols' => 2,
		'savetxt' => '',
	);

	new Cmb2_Metatabs_Options(apply_filters('wre_admin_options', $args, $cmb));
}