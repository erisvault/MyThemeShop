<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

add_filter('post_class', 'wre_listing_post_class', 20, 3);

/**
 * Content Wrappers.
 *
 */
add_action('wre_before_main_content', 'wre_output_content_wrapper', 10);
add_action('wre_after_main_content', 'wre_output_content_wrapper_end', 10);

/**
 * Sidebar.
 *
 */
add_action('wre_sidebar', 'wre_get_sidebar', 10);

/**
 * Before listings
 *
 */
add_action('wre_archive_page_content', 'wre_listing_archive_title', 10);
add_action('wre_archive_page_content', 'wre_listing_archive_content', 20);

add_action('wre_before_listings_loop', 'wre_comparison', 10);
add_action('wre_shortcode_before_listings_loop', 'wre_comparison', 10);
add_action('wre_before_listings_loop', 'wre_ordering', 10);
add_action('wre_before_listings_loop', 'wre_view_switcher', 20);
add_action('wre_before_listings_loop', 'wre_pagination', 30);

add_action('wre_after_listings_loop', 'wre_pagination', 10);

/**
 * Listing Loop Items.
 *
 */
add_action('wre_before_listings_loop_item_summary', 'wre_template_loop_image', 10);
add_action('wre_before_listings_loop_image', 'wre_template_loop_shortlisted', 10);
add_action('wre_before_listings_loop_image', 'wre_template_loop_premium', 20);
add_action('wre_before_listings_loop_item_wrapper', 'wre_before_listings_loop_item_wrapper', 10);
add_action('wre_after_listings_loop_item_wrapper', 'wre_after_listings_loop_item_wrapper', 10);

add_action('wre_listings_loop_item', 'wre_template_loop_title', 10);
add_action('wre_listings_loop_item', 'wre_template_loop_price', 20);
add_action('wre_listings_loop_item', 'wre_template_loop_address', 30);
add_action('wre_listings_loop_item', 'wre_template_loop_at_a_glance', 40);
add_action('wre_listings_loop_item', 'wre_template_loop_description', 50);
add_action('wre_listings_loop_item', 'wre_template_loop_compare', 60);

/**
 * Single Listing
 *
 */
add_action('wre_single_listing_gallery', 'wre_template_single_gallery', 10);

add_action('wre_single_listing_summary', 'wre_template_single_title', 10);
add_action('wre_single_listing_summary', 'wre_template_single_price', 20);
add_action('wre_single_listing_summary', 'wre_template_single_listing_status', 30);
add_action('wre_single_listing_summary', 'wre_template_single_address', 40);
add_action('wre_single_listing_summary', 'wre_template_single_at_a_glance', 50);
add_action('wre_single_listing_summary', 'wre_template_single_sizes', 60);
add_action('wre_single_listing_summary', 'wre_template_single_mls_number', 70);
add_action('wre_single_listing_summary', 'wre_template_single_open_for_inspection', 80);

add_action('wre_single_listing_content', 'wre_template_single_tagline', 10);
add_action('wre_single_listing_content', 'wre_template_single_description', 20);
add_action('wre_single_listing_content', 'wre_template_single_neighborhood', 30);
add_action('wre_single_listing_content', 'wre_template_single_internal_features', 40);
add_action('wre_single_listing_content', 'wre_template_single_external_features', 50);
add_action('wre_single_listing_content', 'wre_template_single_social_share', 60);
add_action('wre_single_listing_bottom', 'wre_template_single_related_listings', 30);

add_action('wre_single_listing_sidebar', 'wre_template_single_map', 10);
add_action('wre_single_listing_sidebar', 'wre_template_single_agent_details', 20);
add_action('wre_single_listing_sidebar', 'wre_template_single_contact_form', 30);

/**
 * Single Agent
 *
 */
add_action('wre_single_agent_intro', 'wre_template_agent_avatar', 10);
add_action('wre_single_agent_intro', 'wre_template_agent_social', 20);
add_action('wre_single_agent_summary', 'wre_template_agent_name', 10);
add_action('wre_single_agent_summary', 'wre_template_agent_title_position', 20);
add_action('wre_single_agent_summary', 'wre_template_agent_contact', 30);


add_action('wre_single_agent_content', 'wre_template_agent_description', 10);
add_action('wre_single_agent_content', 'wre_template_agent_specialties', 20);
add_action('wre_single_agent_content', 'wre_template_agent_awards', 30);

add_action('wre_single_agent_sidebar', 'wre_template_agent_listings', 10);

add_action('wre_single_agent_bottom', 'wre_template_agent_bottom', 10);

/**
 * Before & after agencies
 *
 */
add_action('wre_agency_archive_page_content', 'wre_agency_archive_content', 10);

add_action('wre_before_agency_loop', 'wre_agency_ordering', 10);
add_action('wre_before_agency_loop', 'wre_view_switcher', 20);
add_action('wre_before_agency_loop', 'wre_pagination', 30);

add_action('wre_after_agency_loop', 'wre_pagination', 10);

/**
 * Agency Loop Items.
 *
 */
add_action('wre_before_agency_loop_item_summary', 'wre_template_agency_loop_image', 10);
add_action('wre_before_agency_loop_item_summary', 'wre_template_agency_loop_premium', 20);

add_action('wre_agency_loop_item', 'wre_template_agency_loop_title', 10);
add_action('wre_agency_loop_item', 'wre_template_agency_loop_address', 20);
add_action('wre_agency_loop_item', 'wre_template_agency_loop_logo', 30);
add_action('wre_agency_loop_item', 'wre_template_agency_loop_description', 40);


/**
 * Single Agency
 *
 */
add_action('wre_single_agency_cover', 'wre_template_agency_cover', 10);
add_action('wre_single_agency_cover', 'wre_template_agency_loop_premium', 20);

add_action('wre_single_agency_summary', 'wre_template_agency_title', 10);

add_action('wre_single_agency_content', 'wre_template_agency_tagline', 10);
add_action('wre_single_agency_content', 'wre_template_agency_description', 20);

add_action('wre_single_agency_sidebar', 'wre_template_agency_logo', 10);
add_action('wre_single_agency_sidebar', 'wre_template_agency_address', 20);
add_action('wre_single_agency_sidebar', 'wre_template_agency_contact_details', 20);
add_action('wre_single_agency_sidebar', 'wre_template_agency_map', 30);

add_action('wre_single_agency_bottom', 'wre_template_agency_listings', 10);
add_action('wre_single_agency_bottom', 'wre_template_agency_agents', 20);

add_action('wre_shortcode_listings_pagination', 'wre_shortcode_listings_pagination_callback', 10, 2);

/**
 * My Account
 *
 */
add_action('wre_listings_loop_my_listings', 'wre_template_loop_my_listings', 10);
add_action('wre_my_listings_actions', 'wre_my_listings_actions_callback', 10);
add_action( 'wre_subscription_details', 'wre_subscription_details_callback', 10 );
add_action( 'wre_package_details', 'wre_package_details_callback', 10 );
add_action( 'wre_compare_listings_data', 'wre_compare_listings_data_callback', 10 );
add_action( 'wre_submit_listing_form', 'wre_submit_listing_form_callback', 10 );

add_action( 'wre_account_navigation', 'wre_account_navigation' );

add_action( 'wre_my_account_login_form', 'wre_my_account_login_form_callback', 10 );
add_action( 'wre_my_account_registration_form', 'wre_my_account_registration_form_callback', 10 );

/**
 * Archive Agents
 *
 */

add_action( 'wre_archive_agents', 'wre_archive_agents_callback', 10, 2 );

add_action( 'wre_agents_loop_summary', 'wre_agents_loop_image_callback', 10, 1 );
add_action( 'wre_agents_loop_summary', 'wre_agents_loop_social_share_callback', 20, 1 );
add_action( 'wre_agents_loop_summary', 'wre_agents_loop_premium_callback', 30, 1 );

add_action( 'wre_agents_loop_description', 'wre_agents_loop_name_callback', 10, 1 );
add_action( 'wre_agents_loop_description', 'wre_agents_loop_position_callback', 20, 1 );
add_action( 'wre_agents_loop_description', 'wre_agents_loop_contact_details_callback', 30, 1 );
add_action( 'wre_agents_loop_description', 'wre_agents_loop_description_callback', 40, 1 );

add_action( 'wre_after_agents_loop_item_wrapper', 'wre_after_agents_loop_item_pagination_callback', 10, 2 );
