<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

class WRE_Membership {

	public function __construct() {
		$this->current_user_id = get_current_user_id();
		add_filter('wp', array($this, 'has_shortcode'));
		add_shortcode( 'wre_membership_packages', array( $this, 'wre_membership_packages_callback' ) );
		add_action( 'wp_ajax_wre_free_package_subscription', array( $this, 'wre_free_package_subscription_callback' ) );
		add_action( 'wp_ajax_wre_bacs_package_subscription', array( $this, 'wre_bacs_package_subscription_callback' ) );
	}

	/**
	 * Check if we have the shortcode displayed
	 */
	public function has_shortcode() {
		global $post;
		if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'wre_membership_packages')) {
			add_filter('is_wre', array($this, 'is_wre'));
		}
	}

	/**
	 * Add this as a listings_wp page
	 *
	 * @param bool $return
	 * @return bool
	 */
	public function is_wre($return) {
		return true;
	}

	public function wre_bacs_package_subscription_callback() {
		$package = $_POST['package_id'];
		$membership_details = array( 'package_id' => $package, 'payment_type' => 'bacs', 'payment_date' => current_time( 'mysql' ), 'payment_status' => 'pending' );
		WRE_SPL_Gateway::wre_update_membership_details( $membership_details );
		echo true;
		die();
	}

	public function wre_free_package_subscription_callback() {
		$package = $_POST['package_id'];
		$membership_details = array( 'package_id' => $package );
		WRE_SPL_Gateway::wre_update_membership_details( $membership_details );
		echo true;
		die();
	}

	/**
	 * WRE Membership Packages shortcode.
	 *
	 * @param array $atts
	 * @return string
	 */
	public function wre_membership_packages_callback( $atts ) {
		do_action('wre_package_details');
		do_action( 'wre_enqueue_stripe_scripts' );
		do_action( 'wre_enqueue_plugin_scripts' );
		return ob_get_clean();
	}

}

return new WRE_Membership();