<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

class WRE_My_Account {
	
	/**
	 * Query vars to add to wp.
	 *
	 * @var array
	 */
	public $query_vars = array();
	
	public function __construct() {
		add_filter('wp', array($this, 'has_shortcode'));
		add_shortcode('wre_my_account', array($this, 'wre_my_account'));
		add_filter( 'lostpassword_url',  array($this, 'wre_lostpassword_url'), 10, 1 );

		add_action( 'wp_ajax_nopriv_wre_login_form', array($this, 'wre_login_form_callback') ); //Login
		add_action( 'wp_ajax_nopriv_wre_register_form', array($this, 'wre_register_form_callback') ); //Register
		add_action( 'wp_ajax_nopriv_wre_lost_password', array($this, 'wre_lost_password_callback') ); //Lost-Password
		add_action( 'wp_ajax_nopriv_wre_reset_password', array($this, 'wre_reset_password_callback') ); //Reset Password
		add_action( 'wp_ajax_wre_edit_account_details', array($this, 'wre_edit_account_details_callback') ); //Account Details
		add_action( 'wp_ajax_wre_edit_profile', array($this, 'wre_edit_profile_callback') ); //Edit Profile
		add_action( 'wre_reset_password_notification', array($this, 'wre_reset_password_notification'), 10, 2 );
		add_action( 'template_redirect', array( $this, 'redirect_reset_password_link' ) );
		add_action('wre_after_subscription_details', array($this, 'wre_after_subscription_details_callback'), 10);
		$this->init_query_vars();
	}
	
	function wre_after_subscription_details_callback() {
		$subscription_details = wre_get_membership_details();
		if( $subscription_details['payment_type'] == 'bacs' && $subscription_details['payment_status'] == 'pending' ) {
			// Output the bank-details page
			$account_details = wre_option('wre_account_details');
			$bacs_accounts = apply_filters( 'wre_bacs_accounts', $account_details );
			wre_get_template( 'my-account/bank-details.php', array( 'bacs_accounts' => $bacs_accounts ) );
		}
	}

	/**
	 * Remove key and login from query string, set cookie, and redirect to account page to show the form.
	 */
	public static function redirect_reset_password_link() {
		if ( ! empty( $_GET['key'] ) && ! empty( $_GET['login'] ) ) {
			$value = sprintf( '%s:%s', wp_unslash( $_GET['login'] ), wp_unslash( $_GET['key'] ) );
			self::set_reset_password_cookie( $value );

			wp_safe_redirect( add_query_arg( 'show-reset-form', 'true', wp_lostpassword_url() ) );
			exit;
		}
	}

	/**
	 * Set or unset the cookie.
	 *
	 * @param string $value
	 */
	public static function set_reset_password_cookie( $value = '' ) {
		$rp_cookie = 'wp-resetpass-' . COOKIEHASH;
		$rp_path   = current( explode( '?', wp_unslash( $_SERVER['REQUEST_URI'] ) ) );

		if ( $value ) {
			setcookie( $rp_cookie, $value, 0, $rp_path, COOKIE_DOMAIN, is_ssl(), true );
		} else {
			setcookie( $rp_cookie, ' ', time() - YEAR_IN_SECONDS, $rp_path, COOKIE_DOMAIN, is_ssl(), true );
		}
	}

	/**
	 * Reset Password Notification.
	 *
	 * @param string $user_login
	 * @param string $reset_key
	 */
	public function wre_reset_password_notification($user_login, $reset_key) {
		if ( $user_login && $reset_key ) {
			$user = get_user_by( 'login', $user_login );
			$reset_key  = $reset_key;
			$recipient = stripslashes( $user->data->user_email );
			$reset_password_link =  esc_url( add_query_arg( array( 'key' => $reset_key, 'login' => $user_login ), wre_get_account_endpoint_page_link('lost-password')));
			$subject = wre_option('wre_lost_password_email_subject');
			$message = wre_option('wre_lost_password_email_message');
			$message = str_replace("{user_name}", $user_login, $message);
			$message = str_replace("{reset_password_link}", $reset_password_link, $message);
			$message = wpautop($message);
			wp_mail( $recipient, $subject, $message );
		}
	}

	public function wre_lostpassword_url( $default_url = '' ) {
		// Don't redirect to the wp-real-estate endpoint on global network admin lost passwords.
		if ( is_multisite() && isset( $_GET['redirect_to'] ) && false !== strpos( $_GET['redirect_to'], network_admin_url() ) ) {
			return $default_url;
		}
		$my_account_page = wre_option('wre_account_page');
		if( is_page($my_account_page) || wp_doing_ajax() ) {
			return wre_get_account_endpoint_page_link('lost_password');
		}
		return $default_url;
	}

	/**
	 * Init query vars by loading options.
	 */
	public function init_query_vars() {
		$mask = $this->get_endpoints_mask();
		// Query vars to add to WP.
		$this->query_vars = array(
			'edit-account'			=> wre_get_account_endpoint('edit_account'),
			'edit-profile'			=> wre_get_account_endpoint('edit_profile'),
			'subscription-details'	=> wre_get_account_endpoint('subscription'),
			'lost-password'			=> wre_get_account_endpoint('lost_password')
		);
		foreach ( $this->query_vars as $key => $var ) {
			if ( ! empty( $var ) ) {
				add_rewrite_endpoint( $var, $mask );
			}
		}
	}

	/**
	 * Endpoint mask describing the places the endpoint should be added.
	 */
	public function get_endpoints_mask() {
		if ( 'page' === get_option( 'show_on_front' ) ) {
			$page_on_front     = get_option( 'page_on_front' );
			$myaccount_page_id = wre_option( 'wre_account_page' );
			if ( $page_on_front == $myaccount_page_id ) {
				return EP_ROOT | EP_PAGES;
			}
		}
		return EP_PAGES;
	}

	/**
	 * Check if we have the shortcode displayed
	 */
	public function has_shortcode() {
		global $post;
		if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'wre_my_account') ) {
			add_filter('is_wre', array($this, 'is_wre'));
		}
	}

	/**
	 * Add this as a listings_wp page
	 *
	 * @param bool $return
	 * @return bool
	 */
	public function is_wre($return) {
		return true;
	}

	public function wre_validate_form($data) {
		$error_messages = array();
		$message = '';
		if ( isset( $data['wre-login-nonce'] ) && ( empty( $data['wre-login-nonce'] ) || ! wp_verify_nonce( $data['wre-login-nonce'], 'wre-login' ) ) ) {
			$error_messages[] = __( 'We were unable to process your request, please try again.', 'wp-real-estate' );
		}
		if ( isset( $data['wre-register-nonce'] ) && ( empty( $data['wre-register-nonce'] ) || ! wp_verify_nonce( $data['wre-register-nonce'], 'wre-register' ) ) ) {
			$error_messages[] = __( 'We were unable to process your request, please try again.', 'wp-real-estate' );
		}
		if( isset($data['username']) && $data['username'] == '' ) {
			$error_messages[] = __( 'Username or Email is a required field.', 'wp-real-estate' );
		}
		if( ! isset($data['password']) || $data['password'] == '' ) {
			$error_messages[] = __( 'User Password is a required field.', 'wp-real-estate' );
		}
		if( !empty($error_messages) ) {
			foreach( $error_messages as $error_message ) {
				$message .= '<span>'.$error_message.'</span>';
			}
		}
		return $message;
	}
	
	/**
	 * Handles resetting the user's password.
	 *
	 * @param object $user The user
	 * @param string $new_pass New password for the user in plaintext
	 */
	public static function reset_password( $user, $new_pass ) {
		do_action( 'password_reset', $user, $new_pass );

		wp_set_password( $new_pass, $user->ID );
		self::set_reset_password_cookie();

		wp_password_change_notification( $user );
	}

	/**
	 * AJAX callback for lost-password form.
	 */
	public function wre_reset_password_callback() {
		$message = '';
		$redirect_url = '';
		parse_str($_POST['data'], $details);

		$posted_fields = array( 'wre_reset_password', 'password_1', 'password_2', 'reset_key', 'reset_login', '_wpnonce' );

		foreach ( $posted_fields as $field ) {
			if ( ! isset( $details[ $field ] ) ) {
				$message .= '<span>'.sprintf(__( '%s is a required field', 'wp-real-estate' ), $field).'</span>';
			}
			$posted_fields[ $field ] = $details[ $field ];
		}

		if ( ! wp_verify_nonce( $posted_fields['_wpnonce'], 'reset_password' ) ) {
			$message .= '<span>'.__( 'We were unable to process your request, please try again.', 'wp-real-estate' ).'</span>';
		}

		$user = self::check_password_reset_key( $posted_fields['reset_key'], $posted_fields['reset_login'] );

		if ( $user instanceof WP_User ) {
			if ( empty( $posted_fields['password_1'] ) ) {
				$message .= '<span>'.__( 'Please enter your password.', 'wp-real-estate' ).'</span>';
			}

			if ( $posted_fields['password_1'] !== $posted_fields['password_2'] ) {
				$message .= '<span>'.__( 'Passwords do not match.', 'wp-real-estate' ).'</span>';
			}

			$errors = new WP_Error();

			do_action( 'validate_password_reset', $errors, $user );

			if ( is_wp_error( $errors ) && $errors->get_error_messages() ) {
				foreach ( $errors->get_error_messages() as $error ) {
					$message .= '<span>'.$error.'</span>';
				}
			}

			if ( $message == '' ) {
				self::reset_password( $user, $posted_fields['password_1'] );

				do_action( 'wre_customer_reset_password', $user );

				$redirect_url = add_query_arg( 'password-reset', 'true', wre_get_account_page_link() );
			}
		}
		echo wp_send_json(array('message' => $message, 'redirect_url' => $redirect_url));
	}
	
	/**
	 * AJAX callback for lost-password form.
	 */
	public function wre_lost_password_callback() {
		parse_str($_POST['data'], $details);
		$redirect_url = '';
		$messages = array();
		if ( isset( $details['user_login'] ) && isset( $details['_wpnonce'] ) && wp_verify_nonce( $details['_wpnonce'], 'lost_password' ) ) {

			$login = trim( $details['user_login'] );

			if ( empty( $login ) ) {
				$messages[] = __( 'Enter a username or email address.', 'wp-real-estate' );
			} else {
				// Check on username first, as customers can use emails as usernames.
				$user_data = get_user_by( 'login', $login );
				// If no user found, check if it login is email and lookup user based on email.
				if ( ! $user_data && is_email( $login ) ) {
					$user_data = get_user_by( 'email', $login );
				}

				if( $user_data ) {
					// redefining user_login ensures we return the right case in the email
					$user_login = $user_data->user_login;
					$allow = apply_filters( 'allow_password_reset', true, $user_data->ID );
					if ( ! $allow ) {
						$messages[] = __( 'Password reset is not allowed for this user.', 'wp-real-estate' );
					} elseif ( is_wp_error( $allow ) ) {
						$messages[] = $allow->get_error_message();
					}
				} else {
					$messages[] = __( 'Invalid username or email.', 'wp-real-estate' );
				}
			}

			if( empty($messages) ) {
				$message = '';
				// Get password reset key (function introduced in WordPress 4.4).
				$key = get_password_reset_key( $user_data );
				do_action( 'wre_reset_password_notification', $user_login, $key );
				$redirect_url = add_query_arg( 'reset-link-sent', 'true', wre_get_account_endpoint_page_link('lost_password') );
			} else {
				foreach($messages as $error_message) {
					$message .= '<span>'.$error_message.'</span>';
				}
			}
		}
		echo wp_send_json(array('message' => $message, 'redirect_url' => $redirect_url));
		die();
	}
	
	/**
	 * Save the profile details.
	 */
	public function wre_edit_profile_callback() {

		$flag = false;
		$message = '';
		parse_str($_POST['data'], $account_details);
		if ( empty( $account_details['_wpnonce'] ) || ! wp_verify_nonce( $account_details['_wpnonce'], 'save_profile_details' ) ) {
			$message = __( 'We were unable to process your request, please try again.', 'wp-real-estate' );
		} else {

			$user_id = (int) get_current_user_id();

			if ( $user_id > 0 ) {
				$agent = new WRE_Agent();
				$save_fields = $agent->get_customer_meta_fields();
				foreach ( $save_fields as $fieldset ) {

					foreach ( $fieldset['fields'] as $key => $field ) {

						if ( isset( $account_details[ $key ] ) ) {

							$value = $account_details[ $key ];
							if ( $field['type'] == 'text' ) :
									$value = sanitize_text_field( $value ); 
							elseif ( $field['type'] == 'textarea' ) :
									$value = sanitize_textarea_field( $value ); 
							elseif ( $field['type'] == 'url' ) :
									$value = esc_url_raw( $value ); 
							elseif ( $field['type'] == 'number' ) :
									$value = $value;
									if ( ! $value ) :
											$value = '';
									endif;
							else :
									$value = sanitize_text_field( $value ); 
							endif;

							update_user_meta( $user_id, $key, $value );

							$flag = true;
							$message = __( 'Profile changed successfully.', 'wp-real-estate' );
						}
					}
					
					if( isset( $_FILES['agent-image']) && $_FILES['agent-image'] != '' ) {
						$files = array_filter( $_FILES['agent-image'] );
						$this->set_gravatar_image($files, $user_id);
					} elseif( isset($account_details['wre_upload_meta']) && isset($account_details['wre_upload_edit_meta']) ) {
						$upload_url = $account_details['wre_upload_meta'];
						$upload_edit_url = $account_details['wre_upload_edit_meta'];
						update_user_meta( $user_id, 'wre_upload_meta', $upload_url );
						update_user_meta( $user_id, 'wre_upload_edit_meta', $upload_edit_url );
					}

				}
			} else {
				$message = __( 'Invalid User!', 'wp-real-estate' );
			}
		}
		$message = '<span>'.$message.'</span>';
		echo wp_send_json( array( 'flag' => $flag, 'message' => $message ) );
	}
	
	public function set_gravatar_image($files, $user_id) {
		$file_data = array();
		if( !empty($files) ) {
			$file_data['name'] = $files['name'][0];
			$file_data['type'] = $files['type'][0];
			$file_data['tmp_name'] = $files['tmp_name'][0];
			$file_data['error'] = $files['error'][0];
			$file_data['size'] = $files['size'][0];
			if( wre_check_image_file( $file_data['name'] ) ) {

				$file_return = wp_handle_upload( $file_data, array('test_form' => false ) );
				if( ! isset( $file_return['error'] ) && ! isset( $file_return['upload_error_handler'] ) ) {

					$filename = $file_return['file'];
					$attachment = array(
						'post_mime_type' => $file_return['type'],
						'post_title' => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
						'post_content' => '',
						'post_status' => 'inherit',
						'guid' => $file_return['url']
					);
					$attachment_id = wp_insert_attachment( $attachment, $file_return['url'] );
					if($attachment_id) {
						$attachment_data = wp_generate_attachment_metadata( $attachment_id, $filename );
						wp_update_attachment_metadata( $attachment_id, $attachment_data );
						update_user_meta( $user_id, 'wre_upload_meta', wp_get_attachment_url($attachment_id) );
						update_user_meta( $user_id, 'wre_upload_edit_meta', '/wp-admin/post.php?post='.$attachment_id.'&action=edit&image-editor' );
					}
				}

			}
		}
	}

	/**
	 * Save the password/account details.
	 */
	public function wre_edit_account_details_callback() {
		
		$flag = false;
		$messages = array();
		parse_str($_POST['data'], $account_details);
		if ( empty( $account_details['_wpnonce'] ) || ! wp_verify_nonce( $account_details['_wpnonce'], 'save_account_details' ) ) {
			$messages[] = __( 'We were unable to process your request, please try again.', 'wp-real-estate' );
		} else {

			$errors       = new WP_Error();
			$user         = new stdClass();

			$user->ID     = (int) get_current_user_id();
			$current_user = get_user_by( 'id', $user->ID );

			if ( $user->ID <= 0 ) {
				return;
			}

			$account_first_name = ! empty( $account_details['account_first_name'] ) ? wre_clean( $account_details['account_first_name'] ) : '';
			$account_last_name  = ! empty( $account_details['account_last_name'] ) ? wre_clean( $account_details['account_last_name'] ) : '';
			$account_email      = ! empty( $account_details['account_email'] ) ? wre_clean( $account_details['account_email'] ) : '';
			$pass_cur           = ! empty( $account_details['password_current'] ) ? $account_details['password_current'] : '';
			$pass1              = ! empty( $account_details['password_1'] ) ? $account_details['password_1'] : '';
			$pass2              = ! empty( $account_details['password_2'] ) ? $account_details['password_2'] : '';
			$save_pass          = true;

			$user->first_name   = $account_first_name;
			$user->last_name    = $account_last_name;

			// Prevent emails being displayed, or leave alone.
			$user->display_name = is_email( $current_user->display_name ) ? $user->first_name : $current_user->display_name;

			// Handle required fields
			$required_fields = apply_filters( 'wre_save_account_details_required_fields', array(
				'account_first_name' => __( 'First name', 'wp-real-estate' ),
				'account_last_name'  => __( 'Last name', 'wp-real-estate' ),
				'account_email'      => __( 'Email address', 'wp-real-estate' ),
			) );

			foreach ( $required_fields as $field_key => $field_name ) {
				if ( empty( $account_details[ $field_key ] ) ) {
					$messages[] = sprintf(__( '%s is a required field.', 'wp-real-estate' ), '<strong>' . esc_html( $field_name ) . '</strong>');
				}
			}

			if ( $account_email ) {
				$account_email = sanitize_email( $account_email );
				if ( ! is_email( $account_email ) ) {
					$messages[] = __( 'Please provide a valid email address.', 'wp-real-estate' );
				} elseif ( email_exists( $account_email ) && $account_email !== $current_user->user_email ) {
					$messages[] = __( 'This email address is already registered.', 'wp-real-estate' );
				}
				$user->user_email = $account_email;
			}

			if ( ! empty( $pass_cur ) && empty( $pass1 ) && empty( $pass2 ) ) {
				$messages[] = __( 'Please fill out all password fields.', 'wp-real-estate' );
				$save_pass = false;
			} elseif ( ! empty( $pass1 ) && empty( $pass_cur ) ) {
				$messages[] = __( 'Please enter your current password.', 'wp-real-estate' );
				$save_pass = false;
			} elseif ( ! empty( $pass1 ) && empty( $pass2 ) ) {
				$messages[] = __( 'Please re-enter your password.', 'wp-real-estate' );
				$save_pass = false;
			} elseif ( ( ! empty( $pass1 ) || ! empty( $pass2 ) ) && $pass1 !== $pass2 ) {
				$messages[] = __( 'New passwords do not match.', 'wp-real-estate' );
				$save_pass = false;
			} elseif ( ! empty( $pass1 ) && ! wp_check_password( $pass_cur, $current_user->user_pass, $current_user->ID ) ) {
				$messages[] = __( 'Your current password is incorrect.', 'wp-real-estate' );
				$save_pass = false;
			}

			if ( $pass1 && $save_pass ) {
				$user->user_pass = $pass1;
			}

			// Allow plugins to return their own errors.
			do_action_ref_array( 'wre_save_account_details_errors', array( &$errors, &$user ) );

			if ( $errors->get_error_messages() ) {
				foreach ( $errors->get_error_messages() as $error ) {
					$messages[] = $error;
				}
			}
		}
		if ( empty($messages) ) {
			wp_update_user( $user );
			$messages[] = __( 'Account details changed successfully.', 'wp-real-estate' );
			do_action( 'wre_save_account_details', $user->ID );
			$flag = true;
		}
		if( !empty($messages) ) {
			$message = '';
			foreach($messages as $error_message) {
				$message .= '<span>'.$error_message.'</span>';
			}
		}

		echo wp_send_json( array( 'flag' => $flag, 'message' => $message ) );

	}

	public function wre_login_form_callback() {
		$flag = false;
		$message = '';
		parse_str($_POST['data'], $login_details);
		$validate_form = $this->wre_validate_form( $login_details );
		if( $validate_form != '' ) {
			$message = $validate_form;
		} else {
			$creds = array(
				'user_password' => $login_details['password'],
				'remember'      => isset( $login_details['rememberme'] ),
			);
			$username = trim( $login_details['username'] );
			if ( is_email( $username ) ) {
				$user = get_user_by( 'email', $username );
				if ( ! $user ) {
					$user = get_user_by( 'login', $username );
				}
				if ( isset( $user->user_login ) ) {
					$creds['user_login'] = $user->user_login;
				} else {
					$message .= '<span>'.__( 'A user could not be found with this email address.', 'wp-real-estate' ).'</span>';
				}
			} else {
				$creds['user_login'] = $username;
			}
			// On multisite, ensure user exists on current site, if not add them before allowing login.
			if ( is_multisite() ) {
				$user_data = get_user_by( 'login', $username );

				if ( $user_data && ! is_user_member_of_blog( $user_data->ID, get_current_blog_id() ) ) {
					add_user_to_blog( get_current_blog_id(), $user_data->ID, 'subscriber' );
				}
			}
			// Perform the login
			$user = wp_signon( apply_filters( 'wre_login_credentials', $creds ), is_ssl() );
			
			if ( is_wp_error( $user ) ) {
				$error_message = $user->get_error_message();
				$message .= '<span>'.str_replace( '<strong>' . esc_html( $creds['user_login'] ) . '</strong>', '<strong>' . esc_html( $username ) . '</strong>', $error_message ).'</span>';
			}
		}
		echo $message;
		exit;
	}

	public function wre_register_form_callback() {
		$flag = false;
		$message = '';
		parse_str($_POST['data'], $registration_details);
		$validate_form = $this->wre_validate_form( $registration_details );
		if( $validate_form != '' ) {
			$message = $validate_form;
		} else {
			$email = $registration_details['email'];
			$username = $registration_details['username'];
			$password = $registration_details['password'];
			$new_user = wre_create_user( sanitize_email( $email ), wre_clean( $username ), $password );
			if( ! $new_user['flag'] ) {
				$message .= '<span>'.$new_user['message'].'</span>';
			}
		}
		echo $message;
		exit;
	}

	public function wre_my_account() {
		global $wp;
		ob_start();
		echo '<div id="wre-account-wrapper">';
			do_action('wre_payment_action');
			echo wre_se_message('');
			if ( ! is_user_logged_in() ) {
				// After password reset, add confirmation message.
				if ( ! empty( $_GET['password-reset'] ) ) {
					echo wre_se_message( __( 'Your password has been reset successfully.', 'wp-real-estate' ), 'success' );
				}
				if ( isset( $wp->query_vars[$this->query_vars['lost-password']] ) ) {
					self::lost_password();
				} else {
					do_action('wre_my_account_login_form');
					do_action('wre_my_account_registration_form');
				}
			} else {
				do_action( 'wre_account_navigation' );
				echo '<div class="wre-account-content-container">';
					if( isset( $wp->query_vars[$this->query_vars['edit-account']] ) ) {
						self::edit_account();
					} else if( isset( $wp->query_vars[$this->query_vars['edit-profile']] ) ) {
						self::edit_profile();
					} else if( isset( $wp->query_vars[$this->query_vars['subscription-details']] ) ) {
						self::subscription_details();
					} else {
						// Output the new account page
						wre_get_template( 'my-account/my-account.php', array( 'current_user' => get_user_by( 'id', get_current_user_id() ) ) );
					}
				echo '</div>';
			}
		echo '</div>';
		do_action( 'wre_enqueue_plugin_scripts' );
		ob_end_flush();
	}

	/**
	 * Lost password page handling.
	 */
	public static function lost_password() {
		/**
		 * After sending the reset link, don't show the form again.
		 */
		if ( ! empty( $_GET['reset-link-sent'] ) ) {
			return wre_get_template( 'my-account/lost-password-confirmation.php' );

		/**
		 * Process reset key / login from email confirmation link
		 */
		} elseif ( ! empty( $_GET['show-reset-form'] ) ) {
			if ( isset( $_COOKIE[ 'wp-resetpass-' . COOKIEHASH ] ) && 0 < strpos( $_COOKIE[ 'wp-resetpass-' . COOKIEHASH ], ':' ) ) {
				list( $rp_login, $rp_key ) = array_map( 'wre_clean', explode( ':', wp_unslash( $_COOKIE[ 'wp-resetpass-' . COOKIEHASH ] ), 2 ) );
				$user = self::check_password_reset_key( $rp_key, $rp_login );

				// reset key / login is correct, display reset password form with hidden key / login values
				if ( is_object( $user ) ) {
					return wre_get_template( 'my-account/form-reset-password.php', array(
						'key'   => $rp_key,
						'login' => $rp_login,
					) );
				}
			}
		}

		// Show lost password form by default
		wre_get_template( 'my-account/form-lost-password.php', array(
			'form'  => 'lost_password',
		) );
	}

	/**
	 * Retrieves a user row based on password reset key and login.
	 *
	 * @uses $wpdb WordPress Database object
	 *
	 * @param string $key Hash to validate sending user's password
	 * @param string $login The user login
	 * @return WP_User|bool User's database row on success, false for invalid keys
	 */
	public static function check_password_reset_key( $key, $login ) {
		// Check for the password reset key.
		// Get user data or an error message in case of invalid or expired key.
		$user = check_password_reset_key( $key, $login );

		if ( is_wp_error( $user ) ) {
			$message = wre_se_message( __( 'This key is invalid or has already been used. Please reset your password again if needed.', 'wp-real-estate' ) );
			return false;
		}

		return $user;
	}

	/**
	 * Display subscription details page.
	 */
	public static function subscription_details() {
		if( wre_is_subscriber() ) {
			$subscription_details = wre_get_membership_details();
			wre_get_template( 'my-account/subscription-details.php', array( 'subscription' => $subscription_details ) );
		} else {
			_e('You are not allowed to view this page.', 'wp-real-estate');
		}
	}

	/**
	 * Edit account details page.
	 */
	public static function edit_account() {
		wre_get_template( 'my-account/form-edit-account.php', array( 'user' => get_user_by( 'id', get_current_user_id() ) ) );
	}
	
	/**
	 * Edit profile page.
	 */
	public static function edit_profile() {
		wre_get_template( 'my-account/form-edit-profile.php', array( 'user_id' => get_current_user_id() ) );
	}

}

return new WRE_My_Account();