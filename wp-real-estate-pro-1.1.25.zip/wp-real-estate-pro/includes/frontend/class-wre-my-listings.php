<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

class WRE_My_Listings {

	public function __construct() {
		$this->current_user_id = get_current_user_id();
		add_filter('wp', array($this, 'has_shortcode'));
		add_shortcode('wre_my_listings', array($this, 'wre_my_listings'));
		add_shortcode('wre_subscription_details', array($this, 'wre_subscription_details_callback'));
		add_action( 'wp_ajax_wre_delete_listings', array( $this, 'wre_delete_listings_callback' ) );
	}

	/**
	 * Check if we have the shortcode displayed
	 */
	public function has_shortcode() {
		global $post;
		if (is_a($post, 'WP_Post') && ( has_shortcode($post->post_content, 'wre_my_listings') || has_shortcode($post->post_content, 'wre_subscription_details') )) {
			add_filter('is_wre', array($this, 'is_wre'));
		}
	}
	
	/**
	 * Delete Listing
	 *
	 * @return boolean
	 */
	public function wre_delete_listings_callback() {
		$listing_id = $_POST['listing_id'];
		wp_delete_post( $listing_id );
		echo true;
		die();
	}

	/**
	 * Add this as a listings_wp page
	 *
	 * @param bool $return
	 * @return bool
	 */
	public function is_wre($return) {
		return true;
	}

	public function wre_subscription_details_callback() {
		ob_start();
		do_action( 'wre_payment_action' );
		echo '<div class="wre-subscription-details">';
			do_action( 'wre_subscription_details' );
		echo '</div>';
		return ob_get_clean();
	}

	public function wre_my_listings() {
		ob_start();
		do_action('wre_listings_loop_my_listings');
		do_action( 'wre_enqueue_stripe_scripts' );
		do_action( 'wre_enqueue_plugin_scripts' );
		return ob_get_clean();
	}

}

return new WRE_My_Listings();