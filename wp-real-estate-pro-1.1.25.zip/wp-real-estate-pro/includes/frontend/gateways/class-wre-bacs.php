<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Bank Transfer Payment Gateway.
 */
class WRE_Gateway_BACS {

	/**
	 * Constructor for the gateway.
	 */
	public function __construct() {}

	/**
	 * Get bank details and place into a list format.
	 *
	 * @param int $subscription_id
	 */
	public static function bank_details( $subscription_id = '' ) {

		
		$account_details = wre_option( 'wre_account_details' );
		if ( empty( $account_details ) ) {
			return;
		}
		// Get sortcode label in the $locale array and use appropriate one
		$sortcode = __( 'Sort code', 'wp-real-estate' );

		$bacs_accounts = apply_filters( 'wre_bacs_accounts', $account_details );
		if ( ! empty( $bacs_accounts ) ) {
			$account_html = '';
			$has_details  = false;

			foreach ( $bacs_accounts as $bacs_account ) {
				$bacs_account = (object) $bacs_account;

				if ( $bacs_account->wre_account_name ) {
					$account_html .= '<h3 class="wre-bacs-bank-details-account-name">' . wp_kses_post( wp_unslash( $bacs_account->wre_account_name ) ) . ':</h3>' . PHP_EOL;
				}

				$account_html .= '<ul class="wre-bacs-bank-details subscription_details bacs_details">' . PHP_EOL;

				// BACS account fields shown on the thanks page and in emails
				$account_fields = apply_filters( 'wre_bacs_account_fields', array(
					'bank_name' => array(
						'label' => __( 'Bank', 'wp-real-estate' ),
						'value' => $bacs_account->wre_bank_name,
					),
					'account_number' => array(
						'label' => __( 'Account number', 'wp-real-estate' ),
						'value' => $bacs_account->wre_account_number,
					),
					'sort_code'	=> array(
						'label' =>  apply_filters( 'wre_bacs_sort_code', $sortcode ),
						'value' => $bacs_account->wre_bsb,
					),
					'iban'          => array(
						'label' => __( 'IBAN', 'wp-real-estate' ),
						'value' => $bacs_account->wre_iban,
					),
					'bic'           => array(
						'label' => __( 'BIC', 'wp-real-estate' ),
						'value' => $bacs_account->wre_swift,
					),
				), $subscription_id );

				foreach ( $account_fields as $field_key => $field ) {
					if ( ! empty( $field['value'] ) ) {
						$account_html .= '<li class="' . esc_attr( $field_key ) . '">' . wp_kses_post( $field['label'] ) . ': <strong>' . wp_kses_post( wptexturize( $field['value'] ) ) . '</strong></li>' . PHP_EOL;
						$has_details   = true;
					}
				}

				$account_html .= '</ul>';
			}

			if ( $has_details ) {
				return '<section class="wre-bacs-bank-details"><h2 class="wre-bacs-bank-details-heading">' . __( 'Our bank details', 'wp-real-estate' ) . '</h2>' . PHP_EOL . $account_html . '</section>';
			}
		}

	}
}