<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

/**
 * All Stylesheets And Scripts
 * 
 * @return void
 */
function wre_enqueue_styles_scripts() {

	$url = WRE_PLUGIN_URL;
	$ver = WRE_VERSION;

	$css_dir = 'assets/css/';
	$js_dir = 'assets/js/';
	
	
	wp_register_style('wp-real-estate-lightslider', $url . $css_dir . 'lightslider.css', array(), $ver, 'all');
	wp_register_script('wp-real-estate-lightslider', $url . $js_dir . 'lightslider.js', array('jquery'), $ver, true);
	
	wp_register_script('wp-real-estate', $url . $js_dir . 'wp-real-estate.js', array('jquery'), $ver, true);
	
	/*
	 * Localize our script
	 */
	$localized_array = array();

	if (is_single_wre()) {
		$slider_localize_data = array(
		   'gallery_mode' => get_option('wre_gallery_mode') ? get_option('wre_gallery_mode') : 'fade',
		   'auto_slide' => get_option('wre_auto_slide') == 'no' ? false : true,
		   'slide_delay' => get_option('wre_transition_delay') ? get_option('wre_transition_delay') : 3000,
		   'slide_duration' => get_option('wre_transition_duration') ? get_option('wre_transition_duration') : 3000,
		   'thumbs_shown' => get_option('wre_thumbnails_shown') ? get_option('wre_thumbnails_shown') : 6,
		   'gallery_prev' => get_option('wre_arrow_icon') ? '<i class="prev wre-icon-' . get_option('wre_arrow_icon') . '"></i>' : '',
		   'gallery_next' => get_option('wre_arrow_icon') ? '<i class="next wre-icon-' . get_option('wre_arrow_icon') . '"></i>' : '',
		);
		wp_localize_script('wp-real-estate-lightslider', 'wre_slider', apply_filters('wre_localized_script', $slider_localize_data));

		$localized_array = array(
			'map_width' => wre_option('map_width'),
			'map_height' => wre_option('map_height'),
			'map_zoom' => wre_option('map_zoom'),
			'lat' => wre_meta('lat', wre_get_ID()),
			'lng' => wre_meta('lng', wre_get_ID()),
			'address' => wre_meta('displayed_address', wre_get_ID())
	   );
   }

	if (get_post_type() == 'agency') {
	   $localized_array = array(
		   'map_width' => wre_option('map_width'),
		   'map_height' => wre_option('map_height'),
		   'map_zoom' => wre_option('map_zoom'),
		   'lat' => wre_agency_meta('lat'),
		   'lng' => wre_agency_meta('lng'),
		   'address' => wre_agency_meta('displayed_address')
	   );
	}
	$localized_array['ajax_url'] = admin_url('admin-ajax.php');
	$localized_array['publishable_key'] = wre_option( 'wre_stripe_publishable_key' );
	wp_localize_script('wp-real-estate', 'wre', apply_filters('wre_localized_script', $localized_array));
	
	wp_register_style( 'wre-icons', WRE_PLUGIN_URL . 'assets/css/wp-real-estate-icons.css', $ver );
	wp_register_style('wp-real-estate', $url . $css_dir . 'wp-real-estate.css', array(), $ver, 'all');
	wp_register_style('wp-real-estate-rtl', $url . $css_dir . 'wp-real-estate-rtl.css', array(), $ver, 'all');
	wp_register_script( 'wre-geocomplete-map', $url . 'includes/admin/assets/js/wre-admin-geocomplete.js', array(), WRE_VERSION, true );

	if ( is_wre() ) {

		if( is_singular( 'listing' ) ) {
			wp_enqueue_style('wp-real-estate-lightslider');
			wp_enqueue_script('wp-real-estate-lightslider');
		}
		do_action( 'wre_enqueue_plugin_scripts' );
	}
}

add_action('wp_enqueue_scripts', 'wre_enqueue_styles_scripts', 13 );

function wre_enqueue_plugin_scripts_callback() {
	wp_enqueue_script('wp-real-estate');
	wp_enqueue_style( 'wre-icons');
	wp_enqueue_style('wp-real-estate');
	if (is_rtl()) {
		wp_enqueue_style('wp-real-estate-rtl');
	}
}

add_action( 'wre_enqueue_plugin_scripts', 'wre_enqueue_plugin_scripts_callback' );