<?php
/**
 * WPshed Customizer custom control classes
 */
if ( !class_exists( 'WP_Customize_Control' ) ) {
	return;
}

/**
 * Add Icons control
 */
class WP_Customize_Icons_Control extends WP_Customize_Control {

	public $choices	 = false;

	public function __construct( $manager, $id, $args = array(), $options = array() ) {

		$this->choices = $args['choices'];
		parent::__construct( $manager, $id, $args );
	}

	// Render the content
	public function render_content() {

		if ( empty( $this->choices ) ) {
			return;
		}
		?>

		<label class="customize-control-select">
			<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<?php if ( !empty( $this->description ) ) : ?>
				<span class="description customize-control-description"><?php echo $this->description; ?></span>
			<?php endif;
						
			foreach ( $this->choices as $value => $label ) :
			
			?>
				<label>
					<input type="radio" value="<?php echo esc_attr( $value ); ?>" name="<?php echo esc_attr( $this->id ); ?>" <?php $this->link(); checked( $this->value(), $value ); ?> />
					<?php echo $label; ?><br/>
				</label>
			<?php endforeach; ?>
		</label>
		<?php
	}

}