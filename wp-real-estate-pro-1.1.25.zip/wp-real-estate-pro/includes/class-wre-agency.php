<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

class WRE_Agencies {

	public function __construct() {

		add_filter('wp', array($this, 'has_shortcode'));
		add_shortcode('wre_archive_agencies', array($this, 'wre_archive_agencies'));
	}

	/**
	 * Check if we have the shortcode displayed
	 */
	public function has_shortcode() {
		global $post;
		if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'wre_archive_agencies')) {
			add_filter('is_wre', array($this, 'is_wre'));
		}
	}

	/**
	 * Add this as a listings_wp page
	 *
	 * @param bool $return
	 * @return bool
	 */
	public function is_wre($return) {
		return true;
	}

	public function wre_archive_agencies() {
		
		if( ! wre_is_theme_compatible() ) return;
		
		$archive_agency_page = wre_option('agency_archives_page');

		if( ! is_page($archive_agency_page) ) {
			return __( 'You cannot use this shortcode on this page.', 'wp-real-estate' );
		}
		
		ob_start();
		/**
		 * @hooked wre_output_content_wrapper (outputs opening divs for the content)
		 *
		 */
		do_action('wre_before_main_content');

		$agency_query = $this->build_query();
		/**
		 * @hooked wre_listing_archive_description (displays any content, including shortcodes, within the main content editor of your chosen listing archive page)
		 * 
		 */
		do_action('wre_agency_archive_page_content');

		if ($agency_query->have_posts()) :

			/**
			 * @hooked wre_ordering (the ordering dropdown)
			 * @hooked wre_pagination (the pagination)
			 * 
			 */
			do_action('wre_before_agency_loop');
			$default_listing_mode = wre_default_display_mode();
			echo '<div id="wre-archive-wrapper">';
				echo '<ul class="wre-items '. esc_attr( $default_listing_mode ) .'">';

					while ($agency_query->have_posts()) : $agency_query->the_post();
						wre_get_part('content-agency.php');
					endwhile;

				echo '</ul>';
				echo '<div class="wre-orderby-loader"><img src="'. WRE_PLUGIN_URL .'assets/images/loading.svg" /></div>';
			echo '</div>';
			/**
			 * @hooked wre_pagination (the pagination)
			 * 
			 */
			do_action('wre_after_agency_loop');

		else :
			?>

			<p class="alert wre-no-results"><?php _e('Sorry, no agenices were found.', 'wp-real-estate'); ?></p>

		<?php
		endif;

		/**
		 * @hooked wre_output_content_wrapper_end (outputs closing divs for the content)
		 *
		 */
		do_action('wre_after_main_content');
		do_action( 'wre_enqueue_plugin_scripts' );
		return ob_get_clean();
	}

	public function build_query() {
		$orderby = $order = '';
		if (isset($_GET['wre-orderby'])) {
			// Get order + orderby args from string
			$orderby_value = explode('-', $_GET['wre-orderby']);
			$orderby = esc_attr($orderby_value[0]);
			if ($orderby == 'date') {
				$order = 'desc';
			} else {
				$order = !empty($orderby_value[1]) ? $orderby_value[1] : 'asc';
				$orderby = strtolower($orderby);
				$order = strtoupper($order);
			}
		}
		$posts_per_page = wre_default_posts_number();
		$agency_args = array(
			'post_type' => 'agency',
			'post_status' => 'publish',
			'posts_per_page' => $posts_per_page,
			'paged' => ( get_query_var('paged') ) ? get_query_var('paged') : 1,
			'orderby' => $orderby,
			'order' => $order
		);
		return $agency_query = new WP_Query($agency_args);
	}

}

return new WRE_Agencies();