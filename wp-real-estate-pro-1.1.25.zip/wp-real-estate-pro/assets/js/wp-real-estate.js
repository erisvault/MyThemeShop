/*  jQuery Nice Select - v1.0
    https://github.com/hernansartorio/jquery-nice-select
    Made by Hernán Sartorio  */
!function(e){e.fn.niceSelect=function(t){function s(t){t.after(e("<div></div>").addClass("nice-select").addClass(t.attr("class")||"").addClass(t.attr("disabled")?"disabled":"").attr("tabindex",t.attr("disabled")?null:"0").html('<span class="current"></span><ul class="list"></ul>'));var s=t.next(),n=t.find("option"),i=t.find("option:selected");s.find(".current").html(i.data("display")||i.text()),n.each(function(t){var n=e(this),i=n.data("display");s.find("ul").append(e("<li></li>").attr("data-value",n.val()).attr("data-display",i||null).addClass("option"+(n.is(":selected")?" selected":"")+(n.is(":disabled")?" disabled":"")).html(n.text()))})}if("string"==typeof t)return"update"==t?this.each(function(){var t=e(this),n=e(this).next(".nice-select"),i=n.hasClass("open");n.length&&(n.remove(),s(t),i&&t.next().trigger("click"))}):"destroy"==t?(this.each(function(){var t=e(this),s=e(this).next(".nice-select");s.length&&(s.remove(),t.css("display",""))}),0==e(".nice-select").length&&e(document).off(".nice_select")):console.log('Method "'+t+'" does not exist.'),this;this.hide(),this.each(function(){var t=e(this);t.next().hasClass("nice-select")||s(t)}),e(document).off(".nice_select"),e(document).on("click.nice_select",".nice-select",function(t){var s=e(this);e(".nice-select").not(s).removeClass("open"),s.toggleClass("open"),s.hasClass("open")?(s.find(".option"),s.find(".focus").removeClass("focus"),s.find(".selected").addClass("focus")):s.focus()}),e(document).on("click.nice_select",function(t){0===e(t.target).closest(".nice-select").length&&e(".nice-select").removeClass("open").find(".option")}),e(document).on("click.nice_select",".nice-select .option:not(.disabled)",function(t){var s=e(this),n=s.closest(".nice-select");n.find(".selected").removeClass("selected"),s.addClass("selected");var i=s.data("display")||s.text();n.find(".current").text(i),n.prev("select").val(s.data("value")).trigger("change")}),e(document).on("keydown.nice_select",".nice-select",function(t){var s=e(this),n=e(s.find(".focus")||s.find(".list .option.selected"));if(32==t.keyCode||13==t.keyCode)return s.hasClass("open")?n.trigger("click"):s.trigger("click"),!1;if(40==t.keyCode){if(s.hasClass("open")){var i=n.nextAll(".option:not(.disabled)").first();i.length>0&&(s.find(".focus").removeClass("focus"),i.addClass("focus"))}else s.trigger("click");return!1}if(38==t.keyCode){if(s.hasClass("open")){var l=n.prevAll(".option:not(.disabled)").first();l.length>0&&(s.find(".focus").removeClass("focus"),l.addClass("focus"))}else s.trigger("click");return!1}if(27==t.keyCode)s.hasClass("open")&&s.trigger("click");else if(9==t.keyCode&&s.hasClass("open"))return!1});var n=document.createElement("a").style;return n.cssText="pointer-events:auto","auto"!==n.pointerEvents&&e("html").addClass("no-csspointerevents"),this}}(jQuery);

/*
 * WP Real Estate plugin by MyThemeShop
 * https://wordpress.com/plugins/wp-real-estate/
 */
(function ($) {
	/**
	 * Archive page
	 */
	wp_real_estate_view_switcher();
	wp_real_estate_ordering();
	wp_real_estate_buy_sell();

	/**
	 * Single listing
	 */
	if ($('body').hasClass('wre')) {
		if ($('body').find('#wre-map').length > 0) {
			wp_real_estate_google_map();
		}
	}
	$('.wre select').niceSelect();

	/**
	 * Ordering
	 */
	function wp_real_estate_ordering() {
		$('.wre-ordering').on('change', 'select.listings-orderby', function () {
			var orderby = $(this).val();
			var search_form_data = $(this).closest('form').serialize();
			wre_orderby_ajax_filter( 'wre_orderby_value', orderby, search_form_data );
		});
		$('.wre-ordering').on('change', 'select.agencies-orderby', function () {
			var orderby = $(this).val();
			var paged = $(this).parents('form').find('input#paged').val();
			wre_orderby_ajax_filter( 'wre_agency_orderby_value', orderby, paged );
		});
	}

	function wre_orderby_ajax_filter( action, orderby, formdata ) {

		$('#wre-archive-wrapper').find('.wre-orderby-loader').addClass('in');
		$.ajax({
			type: 'POST',
			url: wre.ajax_url,
			data: {
				'action': action,
				'order_by': orderby,
				'search_data': formdata
			},
			success: function (response) {
				$('#wre-archive-wrapper').find('.wre-items').html(response);
				$('#wre-archive-wrapper').find('.wre-orderby-loader').removeClass('in')
				var newurl = window.location.pathname;
				if( window.location.search == '' ) {
					newurl = newurl+'?wre-orderby='+orderby;
				} else {
					var search_string = window.location.search;
					if (search_string.indexOf("wre-orderby") <= 0) {
						newurl = window.location.href+'&wre-orderby='+orderby;
					} else {
						var search_parameters = search_string.split('&');
						jQuery.each(search_parameters, function(key, value){
							if (value.indexOf("wre-orderby") >= 0) {
								var orderby_value = value.split('=');
								newurl = newurl+orderby_value[0]+'='+orderby;
							} else {
								newurl = newurl+value;
							}
							if( search_parameters.length < (key+1) ) {
								newurl = newurl + '&';
							}
						});
					}
				}
				$('body').find('.wre-pagination').attr('data-orderby', orderby);
				window.history.pushState({path:newurl},'',newurl);
			}
		});

	}

	$('.wre-pagination a').on('click', function(e){
		e.preventDefault();
		var url = $(this).attr('href');
		var orderby = $(this).parents('.wre-pagination').attr('data-orderby');
		if( orderby != '' && orderby != undefined )
			url = url+'&wre-orderby='+orderby;

		window.location.href = url;
		return false;
	});

	/**
	 * Buy/Sell option
	 */
	function wp_real_estate_buy_sell() {
		$('.wre-search-form').on('change', 'select.purpose', function () {
			if ($(this).parents('.widget').length == 0) {
				$(this).closest('form').submit();
			}
		});
	}

	/**
	 * View switcher
	 */
	function wp_real_estate_view_switcher() {

		$('.wre-view-switcher div').click(function () {
			var view = $(this).attr('id');
			switch_view(view);
		});

		function switch_view(to) {

			var from = (to == 'list') ? 'grid' : 'list';

			var wre_items = $('.wre-items li');
			$.each(wre_items, function (index, listing) {
				if ($(this).parents('.widget').length == 0) {
					$(this).parents('.wre-items').removeClass(from + '-view');
					$(this).parents('.wre-items').addClass(to + '-view');
				}

			});
		}

	}
	/**
	 * Google map
	 */
	function wp_real_estate_google_map() {
		if (wre.lat) {
			var lat = wre.lat;
			var lng = wre.lng;
			var options = {
				center: new google.maps.LatLng(lat, lng),
				zoom: parseInt(wre.map_zoom),
			}
			var mapClass = $('.wre-map');

			$.each(mapClass, function (key, value) {
				wre_map = new google.maps.Map(mapClass[key], options);
				var position = new google.maps.LatLng(lat, lng);
				var set_marker = new google.maps.Marker({
					icon: ' ',
					label: {
						fontFamily: 'wrewp',
						text: "\140",
						fontSize: '60px',
						color: '#44a3d3'
					},
					map: wre_map,
					position: position
				});
			});

		}

	}

	$('.wre-contact-form .cmb-form').on('submit', function (e) {

		e.preventDefault();
		var $form = $(this);
		$form.addClass('in');
		var speed = 700;
		$('html, body').animate({scrollTop: $form.parent().offset().top}, speed);
		$.ajax({
			type: 'POST',
			url: wre.ajax_url,
			data: {
				'action': 'wre_contact_form',
				'data': $(this).serialize(),
			},
			success: function (response) {

				$form.removeClass('in');
				$form.parent().find('.message-wrapper').html(response.message);
				$('html, body').animate({scrollTop: $form.parent().offset().top - 150}, speed);
				$form.find('input#_wre_enquiry_name').val('');
				$form.find('input#_wre_enquiry_email').val('');
				$form.find('input#_wre_enquiry_phone').val('');
				$form.find('textarea#_wre_enquiry_message').val('');
				$form.find('#_wre_consent:checked').removeAttr("checked");

			}
		}).error(function () {
			var html = '<p class="alert error warning alert-warning alert-error">There was an error. Please try again.</p>';
			$form.removeClass('in');
			$form.parent().find('.message-wrapper').html(html);
			$('html, body').animate({scrollTop: $form.parent().offset().top - 150}, speed);
		});
		return false;

	});

	if ($('.search-text-wrap .get-current-location').length > 0) {

		$("input.search-input").geocomplete();

		$('.get-current-location').on('click', function (e) {
			e.preventDefault();
			var $this = $(this);
			if (navigator.geolocation) {

				var geocoder = new google.maps.Geocoder();
				navigator.geolocation.getCurrentPosition(function (position) {

					var lat = position.coords.latitude;
					var lng = position.coords.longitude;
					var latlng = new google.maps.LatLng(lat, lng);
					geocoder.geocode({'latLng': latlng}, function (results, status) {
						if (status == google.maps.GeocoderStatus.OK) {
							if (results[1]) {
								$this.parent().find('.search-input').focus().val(results[0].formatted_address);
							} else {
								alert("No results found");
							}
						} else {
							alert("Geocoder failed due to: " + status);
						}
					});

				});

			}

			return false;
		});

	}

	if ($('.nearby-listings-wrapper').length > 0) {
		var lat, lng;
		if (navigator.geolocation) {
			navigator.geolocation.getCurrentPosition(function (position) {

				lat = position.coords.latitude;
				lng = position.coords.longitude;
				$('.nearby-listings-wrapper').each(function () {

					var $this = $(this);
					var view = $this.attr('data-listing-view');
					var data = {};
					data['current_lat'] = position.coords.latitude;
					data['current_lng'] = position.coords.longitude;
					data['measurement'] = $this.attr('data-distance');
					data['radius'] = $this.attr('data-radius');
					data['number'] = $this.attr('data-number');
					data['compact'] = $this.attr('data-compact');
					data['view'] = view;

					$.ajax({
						type: 'POST',
						url: wre.ajax_url,
						data: {
							'action': 'wre_nearby_listings',
							'data': data
						},
						success: function (response) {


							var columns = $this.attr('data-columns');
							$this.html(response.data);
							$this.find('ul.wre-items').addClass(view);
							if (view == 'grid-view')
								$this.find('ul.wre-items li.compact').removeClass('compact');

							$this.find('ul.wre-items li').removeClass(function (index, className) {
								return (className.match(/(^|\s)col-\S+/g) || []).join(' ');
							}).addClass('col-' + columns);

							$this.removeAttr('data-distance data-radius data-number data-compact data-listing-view data-columns');

						}
					}).error(function () {
						$this.html('No listings near your location');
					});

				});
			});
		}
	}
	var preventClick = false;
	$('body').on('click', '.compare-wrapper .add-to-compare', function(e){
		e.preventDefault();
		if( !preventClick ) {
			preventClick = true;
			var $this = $(this);
			$this.find('.wre-icon-compare').addClass('wre-spin');
			var listing_id = $this.attr('data-id');
			$('body').find('.wre-compare-listings .wre-message-box.in').removeClass('in');
			$.ajax({
				type: 'POST',
				url: wre.ajax_url,
				data: {
					'action': 'wre_compare_listings',
					'listing_id': listing_id
				},
				success: function (response) {
					if( response.flag ) {
						$this.addClass('hide').parent('.compare-wrapper').find('.compare-output').addClass('in');
						$('body').find('.wre-compare-listings').slideDown();
						$('body').find('ul.wre-compare-lists').append(response.message);
					} else {
						$('body').find('.wre-compare-listings').find('.wre-message-box').addClass('in').find('span').html(response.message);
					}
					$this.find('.wre-icon-compare').removeClass('wre-spin');
					$("body, html").animate({
						scrollTop: $('.wre-compare-listings').offset().top
					}, 600);
					preventClick = false;
				}

			});
		}
		return false;
	});

	$(document).on( 'click', '.wre-compare-lists a.remove-listing', function(e) {

		e.preventDefault();
		var $this = $(this);
		$this.find('.wre-icon-close').addClass('wre-spin');
		var listing_id = $this.attr('data-id');
		$.ajax({
			type: 'POST',
			url: wre.ajax_url,
			data: {
				'action': 'wre_remove_compare_listings',
				'listing_id': listing_id
			},
			success: function (response) {
				$this.parent('li').remove();
				$('body').find('a.add-to-compare[data-id="'+ listing_id +'"]').removeClass('hide').parent('.compare-wrapper').find('.compare-output.in').removeClass('in');
				$('body').find('.wre-compare-listings').find('.wre-message-box').removeClass('in').find('span').html('');
				if( $('body').find('ul.wre-compare-lists li').length <= 0 ) {
					$('body').find('.wre-compare-listings').removeClass('in').slideUp();
				}
			}
		});
		return false;
	});

	$('body').on('click', '.wre-shortlist-button', function(e){
		e.preventDefault();
		var $this = $(this);;
		var listing_id = $this.attr('data-id');
		set_listings_shortlist( $this, listing_id, '' );
		return false;
	});

	$('body').on('click', '.wre-remove-shortlist', function(e){
		e.preventDefault();
		var $this = $(this);;
		var listing_id = $this.attr('data-id');
		set_listings_shortlist( $this, listing_id, 'remove' );
		return false;
	});

	function set_listings_shortlist( $this, $listing_id, $remove ) {
		$.ajax({
			type: 'POST',
			url: wre.ajax_url,
			data: {
				'action': 'wre_shortlisted_listings',
				'listing_id': $listing_id
			},
			success: function (response) {
				if( $remove == '' ) {
					if( response )
						$this.addClass('in');
					else
						$this.removeClass('in');
				} else {
					$this.parents('li').remove();
				}
			}
		});
	}

	if( $('body').find( 'form#wre-listings-form' ).length > 0 ) {

		$('body').on( 'submit', 'form#wre-listings-form', function(e) {
			e.preventDefault();
			var $this = $(this);
			$this.find('.wre-submit-listing').attr('disabled', 'disabled');
			$this.find('.wre-submit-loader').show();
			$this.find( '.wre-message-box' ).hide();
			var payment_method = $this.find('input[name=wre_payment_method]:checked').val();
			var proceed = false;
			if( payment_method == 'stripe' && $this.find('.stripe_token').length == 0 ) {
				Stripe.setPublishableKey( wre.publishable_key );
				var card = $( '#stripe-card-number' ).val(),
				cvc = $( '#stripe-card-cvc' ).val(),
				expires = $( '#stripe-card-expiry' ).payment( 'cardExpiryVal' ),
				data = {
					number    : card,
					cvc       : cvc,
					exp_month : expires.month,
					exp_year  : expires.year
				};
				Stripe.createToken( data, function( status, response ){
					if( status == 200 ) {
						$this.append( "<input type='hidden' class='stripe_token' name='stripe_token' value='" + response.id + "'/>" )
						$this.submit();
						proceed = true;
					} else {
						wre_submit_listing_message( response.error.message, $this, true );
					}
				});
			} else {
				proceed = true;
			}
			if( proceed ) {
				var $fd = new FormData();
				var file_obj = $this.find('input[type="file"]');
				var files = file_obj[0].files;
				jQuery.each(files, function(i, file){
					$fd.append("files["+i+"]", file);
				});
				var $formData = $this.serialize();
				$fd.append('action', 'wre_add_listings');
				$fd.append('formData', $formData);
				jQuery.ajax({
					type: 'POST',
					url: wre.ajax_url,
					processData: false,
					contentType: false,
					data: $fd,
					success: function (response) {
						if( response.flag ) {
							if( response.redirect_url ) {
								window.location = response.redirect_url;
							} else {
								wre_submit_listing_message( response.message, $this );
								$this.find('#object_id').val(response.listing_id);
							}
						} else {
							wre_submit_listing_message( response.message, $this, true );
						}

					}
				});
			}

			return false;

		});

		function wre_submit_listing_message( message, $this, is_error = '' ) {
			$this.parents('#wre-listings-form-wrapper').find( '.wre-message-box' ).html(message).show();
			if( is_error ) {
				$this.parents('#wre-listings-form-wrapper').find( '.wre-message-box' ).addClass('error');
			} else {
				$this.parents('#wre-listings-form-wrapper').find( '.wre-message-box' ).removeClass('error');
			}
			$('html, body').animate({
				scrollTop: $('#wre-listings-form-wrapper').offset().top - 10
			}, 'slow');
			$this.find('.wre-submit-listing').removeAttr('disabled');
			$this.find('.wre-submit-loader').hide();
		}

	}

	$('body').on( 'click', '.wre-my-listings-icons li.wre-delete a', function(e) {
		e.preventDefault();
		var $this = $(this);
		var listing_id = $this.attr('data-listing-id');
		$this.parents('.inner-container').addClass('deleting');
		$.ajax({
			type: 'POST',
			url: wre.ajax_url,
			data: {
				'action': 'wre_delete_listings',
				'listing_id': listing_id
			},
			success: function (response) {
				$this.parents('li.listing').fadeOut(500, function() {
					$this.remove();
				});
			},
			error: function() {
				$this.parents('.inner-container').removeClass('deleting');
				alert('Something went wrong. Please try again later');
			}
		});
		return false;
	})

	$( document ).on('click', '.wre-share-networks .wre-pinterest-share', function(e) {
		e.preventDefault();
		var href = $(this).attr('data-href');
		window.open(href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');
		return false;
	});

	//	MORTGAGE CALCULATOR
	if( $('body').find('#wre_mcalc_form').length > 0 ) {
		wre_mcalc_call();
		$('#wre_mcalc_form').on( 'change', 'input', function() {
			wre_mcalc_onchange_input($(this));
		});

		function wre_mcalc_onchange_input(sender) {

			var down_payment_type = '0';
			var tax_type = '0';
			var insurance_type = '0';

			var input_id = $(sender).attr('id');
			if(input_id == 'wre_mcalc_total_price') {
				if(down_payment_type == '0' || down_payment_type == '2')
					wre_mcalc_update_amt_percent('dp', 0);
				else
					wre_mcalc_update_amt_percent('dp', 1);

				if(tax_type == '0' || tax_type == '2')
					wre_mcalc_update_amt_percent('tax', 0);
				else
					wre_mcalc_update_amt_percent('tax', 1);

				if(insurance_type == '0' || insurance_type == '2')
					wre_mcalc_update_amt_percent('ins', 0);
				else
					wre_mcalc_update_amt_percent('ins', 1);

			} else if(input_id == 'wre_mcalc_down_payment') {
				wre_mcalc_update_amt_percent('dp', 1);
			} else if(input_id == 'wre_mcalc_down_payment_percent') {
				wre_mcalc_update_amt_percent('dp', 0);
			} else if(input_id == 'wre_mcalc_property_tax') {
				wre_mcalc_update_amt_percent('tax', 1);
			} else if(input_id == 'wre_mcalc_property_tax_percent') {
				wre_mcalc_update_amt_percent('tax', 0);
			} else if(input_id == 'wre_mcalc_property_insurance') {
				wre_mcalc_update_amt_percent('ins', 1);
			} else if(input_id == 'wre_mcalc_property_insurance_percent') {
				wre_mcalc_update_amt_percent('ins', 0);
			}

			wre_mcalc_call();
		}

		function wre_mcalc_update_amt_percent(opt, val_changed) {
			if(opt == 'dp') {
				amt_input = "wre_mcalc_down_payment";
				percent_input = "wre_mcalc_down_payment_percent";
			} else if(opt == 'tax') {
				amt_input = "wre_mcalc_property_tax";
				percent_input = "wre_mcalc_property_tax_percent";
			} else if(opt == 'ins') {
				amt_input = "wre_mcalc_property_insurance";
				percent_input = "wre_mcalc_property_insurance_percent";
			}
			total_price = $("#wre_mcalc_total_price").val();
			if(total_price == '' || total_price == '0') {
				$("#"+percent_input).val('');
				return;
			}
			if(val_changed == '0') {
				percent_val =  $("#"+percent_input).val();
				amt_val =  (total_price * percent_val)/100;
				amt_val =  wre_mcalc_round_number(amt_val, 2);
				if(amt_val == 0) amt_val = '';
				$("#"+amt_input).val(amt_val);
			} else if(val_changed == '1') {
				amt_val = $("#"+amt_input).val();
				percent_val = (amt_val * 100)/total_price;
				percent_val = wre_mcalc_round_number(percent_val, 2);
				if(percent_val == 0) percent_val = '';
				$("#"+percent_input).val(percent_val);
			}
		}

		function wre_mcalc_round_number(num, dec) {
			if(typeof calc === 'undefined')
				dec = 2;

			var result = Math.round(num*Math.pow(10, dec))/Math.pow(10, dec);
			return result;
		}

		function wre_mcalc_call() {
			var total_price = $("#wre_mcalc_total_price").val();
			var down_payment = $("#wre_mcalc_down_payment").val();
			var loan_term = $("#wre_mcalc_loan_term").val();
			var interest_rate = $("#wre_mcalc_interest_rate").val();
			var tax = $("#wre_mcalc_property_tax").val();
			var insurance = $("#wre_mcalc_property_insurance").val();

			if(total_price == '' || total_price == '0') {
				$(".wre-payment-response").html('');
				$('.wre_pay_per_month').hide();
				return;
			}

			var loan = (total_price-down_payment); // Loan Amount
			var i = interest_rate/(12 * 100); // Interest Rate
			var n = loan_term * 12; // No. of Months

			var p1  = ( i * Math.pow((1 + i), n) );
			var p2  = ( Math.pow((1 + i), n) - 1 );

			var monthly = ( loan * (p1 / p2) );

			if(parseFloat(tax) > 0) {
				monthly += (tax / 12);
			}
			if(parseFloat(insurance) > 0) {
				monthly += (insurance / 12);
			}
			monthly = wre_mcalc_round_number(monthly, 2);
			if(monthly == 'NaN')
				monthly = '';
			$('.wre_pay_per_month').show();
			$(".wre-payment-response").html(monthly);
		}

	}

	$( '.wre-sign-in' ).on( 'click', function(e) {
		e.preventDefault();
		$('body').find('.wre-login-wrapper').slideToggle();
		return false;
	});

	$('input[type=radio][name=wre_payment_method]').change(function() {
		$( 'div.wre_payment_box' ).filter( ':visible' ).slideUp( 250 );
		if ( $( this ).is( ':checked' ) ) {
			$( 'div.wre_payment_box.' + $( this ).attr( 'ID' ) ).slideDown( 250 );
		}
	});

	$('#wre-select-membership').on('change', function(e){
		wre_payment_display();
		$('#wre-subscription-details').addClass('in');
		var package_id = $(this).val();
		$.ajax({
			type: 'POST',
			url: wre.ajax_url,
			data: {
				'action': 'wre_subscription_details',
				package_id: package_id
			},
			success: function (response) {
				$('#wre-subscription-details').html(response);
				$('#wre-subscription-details').removeClass('in');
			}
		});
	});

	$('select#wre-listing-status').on('change', function(e){
		wre_payment_display();
	});

	function wre_payment_display() {
		var status = $('select#wre-listing-status').val();
		var membership = $('select#wre-select-membership').val();
		var package_amount = jQuery('select#wre-select-membership').find('option[value="'+membership+'"]').attr('data-package-amount');
		if( package_amount > 0 ) {
			$('#wre-payment-wrapper').show();
		} else {
			$('#wre-payment-wrapper').hide();
		}
	}

	$('body').on('click', '#wre-gallery-wrapper #wre-remove-image', function(e){
		e.preventDefault();
		$(this).parent().remove();
		return false;
	});

	$('#wre-login-form').on('submit', function(e){
		e.preventDefault();
		var $this = $(this);
		var parent_id = '#wre-account-wrapper';
		if($this.parents('#wre-account-wrapper').length == 0) {
			parent_id = '#wre-listings-form-wrapper';
		}
		$this.addClass('in');
		$this.parents(parent_id).find('.wre-message-box').removeClass('error').hide();
		var $formData = $this.serialize();
		jQuery.ajax({
			type: 'POST',
			url: wre.ajax_url,
			data: {
				'action': 'wre_login_form',
				'data': $formData,
			},
			success: function (response) {
				if( response ) {
					$this.parents(parent_id).find('.wre-message-box').addClass('error').html(response).show();
					$('html, body').animate({scrollTop:$this.parents(parent_id).offset().top}, 500);
					$this.removeClass('in');
				} else {
					location.reload();
				}
			}
		});
		return false;
	});

	$('#wre-register-form').on('submit', function(e){
		e.preventDefault();
		var $this = $(this);
		$this.addClass('in');
		$this.parents('#wre-account-wrapper').find('.wre-message-box').hide();
		var $formData = $this.serialize();
		jQuery.ajax({
			type: 'POST',
			url: wre.ajax_url,
			data: {
				'action': 'wre_register_form',
				'data': $formData,
			},
			success: function (response) {
				if( response ) {
					$this.parents('#wre-account-wrapper').find('.wre-message-box').html(response).show();
					$this.removeClass('in');
					$('html, body').animate({scrollTop:$this.parents('#wre-account-wrapper').offset().top}, 500);
				} else {
					location.reload();
				}
			}
		});
		return false;
	});

	$('#wre-lost-password').on('submit', function(e){
		e.preventDefault();
		var $this = $(this);
		$this.addClass('in');
		$this.parents('#wre-account-wrapper').find('.wre-message-box').hide();
		var $formData = $this.serialize();
		jQuery.ajax({
			type: 'POST',
			url: wre.ajax_url,
			data: {
				'action': 'wre_lost_password',
				'data': $formData,
			},
			success: function (response) {
				if( response.message != '' ) {
					$this.parents('#wre-account-wrapper').find('.wre-message-box').html(response.message).show();
					$this.removeClass('in');
					$('html, body').animate({scrollTop:$this.parents('#wre-account-wrapper').offset().top}, 500);
				} else {
					window.location.href = response.redirect_url;
				}
			}
		});
		return false;
	});

	$('#wre-reset-password').on('submit', function(e){
		e.preventDefault();
		var $this = $(this);
		$this.addClass('in');
		$this.parents('#wre-account-wrapper').find('.wre-message-box').hide();
		var $formData = $this.serialize();
		jQuery.ajax({
			type: 'POST',
			url: wre.ajax_url,
			data: {
				'action': 'wre_reset_password',
				'data': $formData,
			},
			success: function (response) {
				if( response.message != '' ) {
					$this.parents('#wre-account-wrapper').find('.wre-message-box').html(response.message).show();
					$this.removeClass('in');
					$('html, body').animate({scrollTop:$this.parents('#wre-account-wrapper').offset().top}, 500);
				} else {
					window.location.href = response.redirect_url;
				}
			}
		});
		return false;
	});

	$('#wre-edit-form').on('submit', function(e){
		e.preventDefault();
		var $this = $(this);
		$this.addClass('in');
		$this.parents('#wre-account-wrapper').find('.wre-message-box').hide();
		var $formData = $this.serialize();
		jQuery.ajax({
			type: 'POST',
			url: wre.ajax_url,
			data: {
				'action': 'wre_edit_account_details',
				'data': $formData,
			},
			success: function (response) {
				if(response.flag) {
					$this.parents('#wre-account-wrapper').find('.wre-message-box').removeClass('error').addClass('success');
				} else {
					$this.parents('#wre-account-wrapper').find('.wre-message-box').removeClass('success').addClass('error');
				}
				$this.parents('#wre-account-wrapper').find('.wre-message-box').html(response.message).show();
				$this.removeClass('in');
				$('html, body').animate({scrollTop:$this.parents('#wre-account-wrapper').offset().top}, 500);
			}
		});
		return false;
	});

	$('#wre-edit-profile').on('submit', function(e){
		e.preventDefault();
		var $this = $(this);
		$this.addClass('in');
		$this.parents('#wre-account-wrapper').find('.wre-message-box').hide();
		var $fd = new FormData();
		var file_obj = $this.find('input[type="file"]');
		var files = file_obj[0].files[0];
		var $formData = $this.serialize();
		$fd.append("agent-image[]", files);
		$fd.append('action', 'wre_edit_profile');
		$fd.append('data', $formData);
		jQuery.ajax({
			type: 'POST',
			url: wre.ajax_url,
			processData: false,
			contentType: false,
			data: $fd,
			success: function (response) {
				if(response.flag) {
					location.reload();
				} else {
					$this.parents('#wre-account-wrapper').find('.wre-message-box').removeClass('success').addClass('error');
					$this.parents('#wre-account-wrapper').find('.wre-message-box').html(response.message).show();
					$this.removeClass('in');
					$('html, body').animate({scrollTop:$this.parents('#wre-account-wrapper').offset().top}, 500);
				}

			}
		});
		return false;
	});

	$('body').on( 'click', '.wre-free-package', function(e) {
		e.preventDefault();
		jQuery('body').find('.wre-overlay-blocker').addClass('in');
		var package_id = $(this).attr('data-package-id');
		$.ajax({
			type: 'POST',
			url: wre.ajax_url,
			data: {
				'action': 'wre_free_package_subscription',
				'package_id': package_id
			},
			success: function (response) {
				location.reload();
			}
		});
		return false;
	});

	$('.wre-bacs-subscribe-button').on('click', function(e){
		e.preventDefault();
		jQuery('body').find('.wre-overlay-blocker').addClass('in');
		var package_id = $(this).attr('data-package-id');
		$.ajax({
			type: 'POST',
			url: wre.ajax_url,
			data: {
				'action': 'wre_bacs_package_subscription',
				'package_id': package_id
			},
			success: function (response) {
				location.reload();
			}
		});
		return false;
	});

})(jQuery);
