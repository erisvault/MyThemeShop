<?php
/**
 * The Template for displaying agency content in the content-agency.php template
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/content-agency.php.
 *
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

$columns = wre_default_grid_columns();
?>

<li <?php post_class('col-' . $columns); ?>>
	<?php do_action('wre_before_listings_loop_item_wrapper'); ?>
	<?php
	/**
	 * wre_before_listings_loop_item hook.
	 *
	 * @hooked wre_template_loop_product_link_open - 10
	 */
	do_action('wre_before_agency_loop_item_summary');
	?>

	<div class="summary">

		<?php
		do_action('wre_before_agency_loop_item');

		/**
		 * wre_before_listings_loop_item_title hook.
		 *
		 * @hooked wre_show_product_loop_sale_flash - 10
		 * @hooked wre_template_loop_product_thumbnail - 10
		 */
		do_action('wre_agency_loop_item');


		/**
		 * wre_after_listings_loop_item hook.
		 *
		 * @hooked wre_template_loop_product_link_close - 5
		 * @hooked wre_template_loop_add_to_cart - 10
		 */
		do_action('wre_after_agency_loop_item');
		?>

	</div>

		<?php
		/**
		 * wre_after_listings_loop_item hook.
		 *
		 * @hooked wre_template_loop_product_link_close - 5
		 * @hooked wre_template_loop_add_to_cart - 10
		 */
		do_action('wre_after_agency_loop_item_summary');
		
		do_action('wre_after_listings_loop_item_wrapper');
		?>
</li>