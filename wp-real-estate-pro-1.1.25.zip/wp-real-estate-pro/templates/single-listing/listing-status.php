<?php
/**
 * Single listing status
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/single-listing/listing-status.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$status = wre_get_status();
if( empty( $status ) )
	return;
?>

<h4 class="wre-listing-status">
	<?php if( $status ) { ?>
		<span style="color:<?php echo esc_attr( $status['bg_color'] ); ?>; ?>" class="status <?php echo esc_attr( strtolower( str_replace( ' ', '-', $status['status']) ) ); ?>">
			<?php if( $status['icon'] ) { ?>
					<i class="wre-icon-<?php echo esc_attr( $status['icon'] ); ?>"></i>
			<?php } ?>
			<?php echo esc_html( $status['status'] ); ?>
		</span>
	<?php } ?>
</h4>