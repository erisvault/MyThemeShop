<?php
/**
 * Single listing related listings
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/single-listing/related.php.
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

$rl_view = wre_option('rl_mode') ? wre_option('rl_mode') : 'grid-view';
$rl_columns = wre_option('rl_columns') ? wre_option('rl_columns') : '3';
$related_listings = wre_get_related_listings(); 
if ( $related_listings->have_posts() ) {
?>
	<h3 class="related"><?php echo __('Related Listings', 'wp-real-estate'); ?></h3>
	<ul class="listings-wp-items wre-items <?php echo esc_attr( $rl_view ); ?>">
		<?php
		while ($related_listings->have_posts()) {
			$related_listings->the_post();
			?>
			<li <?php post_class('col-'.$rl_columns); ?> itemscope itemtype="http://schema.org/House">
				<?php do_action('wre_before_listings_loop_item_wrapper'); ?>
					<?php do_action('wre_before_listings_loop_item_summary'); ?>

					<div class="summary">
						<?php
						do_action('wre_before_listings_loop_item');
						do_action('wre_listings_loop_item');
						do_action('wre_after_listings_loop_item');
						?>
					</div>

					<?php do_action('wre_after_listings_loop_item_summary'); ?>
				<?php do_action('wre_after_listings_loop_item_wrapper'); ?>
			</li>
	<?php
		}
		wp_reset_postdata();
	?>
	</ul>
<?php }