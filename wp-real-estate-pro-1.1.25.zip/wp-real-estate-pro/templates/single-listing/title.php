<?php
/**
 * Single listing title
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/single-listing/title.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>

<h1 class="title entry-title"><?php the_title(); ?></h1>