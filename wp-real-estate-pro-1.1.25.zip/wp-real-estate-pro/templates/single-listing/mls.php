<?php
/**
 * Single listing MLS number
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/single-listing/mls.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$mls_number = wre_meta( 'mls' );

if( empty( $mls_number ) )
	$mls_number = __( 'ID#', 'wp-real-estate' ).' '.get_the_ID();
else
	$mls_number = __( 'MLS#', 'wp-real-estate' ).' '.$mls_number;
?>
<div class="mls-wrapper">
	<?php echo esc_html( $mls_number ); ?>
</div>