<?php
/**
 * Single listing neighborhood
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/single-listing/neighborhood.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$neighborhood = wre_meta( 'neighborhood' );

if( empty( $neighborhood ) )
	return;
?>
<div class="neighborhood">
	<h3><?php esc_html_e( 'Neighborhood', 'wp-real-estate' ); ?></h3>
	<p><?php esc_html_e( $neighborhood ); ?></p>
</div>