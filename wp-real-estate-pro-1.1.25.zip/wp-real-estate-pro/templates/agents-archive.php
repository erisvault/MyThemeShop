<?php
/**
 * The Template for displaying the agents archive
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/agents-archive.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
if( ! empty( $agent_details ) ) {
	$attributes = '';
	if( $atts['view'] == 'carousel' ) {
		$attributes = json_encode( $atts, true );
	}
?>
	<div class="wre-agents-container">
		<?php do_action('wre_before_agents_loop_item_wrapper'); ?>
		<div class="agents-wrapper agents-<?php echo esc_attr( $atts['view'] ).' '.esc_attr( $atts['agents-view'] ); ?>" data-value='<?php echo $attributes; ?>'>
			<?php foreach( $agent_details as $key => $user ) { ?>
				<div class="wre-col col-<?php echo esc_attr( $atts['agent-columns'] ); ?>">
					<?php do_action('wre_before_agents_loop_item'); ?>
						<div class="agent-inner-wrap">

							<div class="agent-image-wrapper wre-social-icons-wrapper">
								<?php
								/**
								 * @hooked wre_template_image
								 * @hooked wre_template_social_share
								 */
								do_action( 'wre_agents_loop_summary', $user );
								?>
							</div>

							<div class="wre-agent-details content">
								<?php
								/**
								 * @hooked wre_template_name
								 * @hooked wre_template_position
								 * @hooked wre_template_contact_details
								 * @hooked wre_template_description
								 */
								do_action( 'wre_agents_loop_description', $user );
								if( $atts['view'] == 'lists' ) {
									remove_action( 'wre_agents_loop_description', 'wre_agents_loop_description_callback', 40, 1 );
								}
								?>
							</div>

						</div>
					<?php do_action('wre_after_agents_loop_item'); ?>
				</div>
		<?php } ?>
		</div>
		<?php do_action('wre_after_agents_loop_item_wrapper', $agent_details, $atts); ?>
	</div>
<?php } else {
	echo wre_se_message( __( 'No agent found.','wp-real-estate' ) );
}