<?php
/**
 * Single agent specialties
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/agent/specialties.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

wre_get_agent_specialities_data( wre_agent_ID() );