<?php
/**
 * Single agent title/position
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/agent/title-position.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
wre_agent_title_position( wre_agent_ID() );