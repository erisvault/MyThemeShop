<?php
/**
 * Single agent contact
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/agent/contact.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

wre_get_agent_contact_details( wre_agent_ID() );