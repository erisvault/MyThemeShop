<?php
/**
 * Loop description
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/agency-loop/description.php.
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

$description = wre_agency_meta('content');
if (empty($description))
	return;
$trimmed = wp_trim_words($description, 25, '...');
?>

<div class="description"><?php echo wp_kses_post($trimmed); ?></div>