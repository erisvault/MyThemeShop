<?php
/**
 * Loop agency image
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/agency-loop/image.php.
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

$image = wre_agency_image();
?>

<div class="image">
	<a href="<?php esc_url(the_permalink()); ?>" title="<?php esc_attr(the_title()); ?>">
		<img alt="<?php echo esc_attr($image['alt']); ?>" src="<?php echo esc_url($image['sml']); ?>" />
	</a>
</div>