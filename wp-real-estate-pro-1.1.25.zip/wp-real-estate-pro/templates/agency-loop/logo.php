<?php
/**
 * Loop logo
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/agency-loop/logo.php.
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
$logo = wre_agency_meta('logo');
if (empty($logo) )
	return;
?>

<div class="logo">
	<img width="100" src="<?php echo esc_url( $logo ); ?>" />
</div>