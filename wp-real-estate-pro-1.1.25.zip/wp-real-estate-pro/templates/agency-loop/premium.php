<?php
/**
 * Loop agency-premium
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/agency-loop/premium.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$is_premium = wre_is_premium_agency(wre_get_ID());
if( ! $is_premium ) return;
$premium_text = !empty(wre_option('wre_premium_badge_text_agencies')) ? wre_option('wre_premium_badge_text_agencies') : __( 'Premium', 'wp-real-estate' );
?>
<div class="wre-premium-wrapper"><?php echo esc_html($premium_text); ?></div>