<?php
/**
 * Loop tagline
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/agency-loop/tagline.php.
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

$tagline = wre_agency_meta('tagline');
if (empty($tagline))
	return;
?>

<h4 class="tagline"><?php echo esc_html($tagline); ?></h4>