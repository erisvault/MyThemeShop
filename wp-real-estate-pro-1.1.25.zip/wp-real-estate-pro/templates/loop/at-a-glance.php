<?php
/**
 * Loop at a glance
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/loop/at-a-glance.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$bedrooms = wre_meta( 'bedrooms' );
$bathrooms = wre_meta( 'bathrooms' );
$cars = wre_meta( 'car_spaces' );
$bed_icon = get_option( 'wre_bedroom_icon' );
$bath_icon = get_option( 'wre_bathroom_icon' );
$car_icon = get_option( 'wre_car_space_icon' );

if( empty( $bedrooms ) &&  empty( $bathrooms ) &&  empty( $cars ) )
	return;
?>

<div class="glance">

	<?php if( $bedrooms ) { ?>
		<div class="beds">
			<span class="count" itemprop="numberOfRooms"><?php echo esc_html( $bedrooms ); ?></span> <?php echo $bed_icon != 'none' ? '<i class="wre-icon-' . esc_attr( $bed_icon ) . '"></i>' : __( 'Bedroom', 'wp-real-estate' ); ?>
		</div>
	<?php } ?>

	<?php if( $bathrooms ) { ?>
		<div class="baths">
			<span class="count"><?php echo esc_html( $bathrooms ); ?></span> <?php echo $bath_icon != 'none' ? '<i class="wre-icon-' . esc_attr( $bath_icon ) . '"></i>' : __( 'Bathroom', 'wp-real-estate' ); ?>
		</div>
	<?php } ?>

	<?php if( $cars ) { ?>
		<div class="cars">
			<span class="count"><?php echo esc_html( $cars ); ?></span> <?php echo $car_icon != 'none' ? '<i class="wre-icon-' . esc_attr( $car_icon ) . '"></i>' : __( 'Car Spaces', 'wp-real-estate' ); ?>
		</div>
	<?php } ?>

</div>