<?php
/**
 * Loop shortlisted
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/loop/shortlisted.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$listing_id = wre_get_ID();
$shortlisted_listings = wre_get_shortlisted_listings();
$shortlisted_class = '';
if( is_array( $shortlisted_listings ) && in_array($listing_id, $shortlisted_listings) )
	$shortlisted_class = 'in';
?>
<a href="#" class="wre-shortlist-button <?php echo esc_attr( $shortlisted_class ); ?>" title="<?php _e( 'Added to shortlist', 'wp-real-estate' ); ?>" data-id="<?php echo esc_attr( get_the_ID() ) ?>">
	<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 21">
		<path class="rh_svg" d="M1089.48,1923.98a6.746,6.746,0,0,1,9.54,9.54L1089,1943l-10.02-9.48a6.746,6.746,0,0,1,9.54-9.54A0.641,0.641,0,0,0,1089.48,1923.98Z" transform="translate(-1077 -1922)"></path>
	</svg>
</a>
<?php if( $shortlisted_class != '' && ! is_singular( 'listing' ) ) { ?>
	<a href="#" class="wre-remove-shortlist" title="<?php _e( 'Remove from shortlist', 'wp-real-estate' ); ?>" data-id="<?php echo esc_attr( get_the_ID() ) ?>">
		<i class="wre-icon-trash-empty"></i>
	</a>
<?php }