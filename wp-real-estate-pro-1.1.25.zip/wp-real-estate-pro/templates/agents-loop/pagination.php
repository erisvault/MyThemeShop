<?php
/**
 * Agents Archive pagination
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/agents-loop/pagination.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
if( empty( $atts ) )
	return;
$total_agents = '';
if( isset( $atts['total_agents'] ) )
	$total_agents = $atts['total_agents'];

$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
if( $atts['allow_pagination'] == 'yes' && $atts['view'] == 'lists' ) { ?>
	<nav class="wre-pagination">
		<?php
			$pl_args = array(
				'base'		=>	add_query_arg('paged','%#%'),
				'format'	=>	'',
				'total'		=>	ceil( $total_agents / $atts['number'] ),
				'current'	=>	max( 1, $paged ),
				'prev_text'	=>	'&larr;',
				'next_text'	=>	'&rarr;',
				'type'		=>	'list',
				'end_size'	=>	3,
			);
			echo paginate_links($pl_args);
		?>
	</nav>
<?php }