<?php
/**
 * Agents Archive image
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/agents-loop/image.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
if( empty( $user ) )
	return;

$agent_id	= $user->ID;
$agent_url = get_author_posts_url( $agent_id );
$gravatar_url = wre_get_agent_attachment_url($agent_id);
?>
<div class="avatar-wrap">
	<a href="<?php echo esc_url( $agent_url ); ?>">
		<img src="<?php echo esc_url( $gravatar_url ); ?>" />
	</a>
</div>