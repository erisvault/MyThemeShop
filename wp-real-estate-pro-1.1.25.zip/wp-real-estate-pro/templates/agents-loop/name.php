<?php
/**
 * Agents Archive name
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/agents-loop/name.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
if( empty( $user ) )
	return;

$agent_id	= $user->ID;
$agent_url = get_author_posts_url( $agent_id );
$agent_name = $user->display_name;
?>

<h4 class="name">
	<a href="<?php echo esc_url( $agent_url ); ?>">
		<?php echo esc_html( $agent_name ); ?>
	</a>
</h4>