<?php
/**
 * Agents Archive social-share
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/agents-loop/social-share.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
if( empty( $user ) )
	return;

$agent_id	= $user->ID;

wre_get_agent_social_share_data( $agent_id );