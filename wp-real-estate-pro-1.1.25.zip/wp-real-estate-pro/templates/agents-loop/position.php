<?php
/**
 * Agents Archive position
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/agents-loop/position.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
if( empty( $user ) )
	return;

$agent_id	= $user->ID;
$position = get_the_author_meta( 'title_position', $agent_id );

if( $position ) { ?>
	<p class="position"><?php echo esc_html( $position ); ?></p>
<?php }