<?php
/**
 * Agents Archive description
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/agents-loop/description.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
if( empty( $user ) )
	return;

$agent_id	= $user->ID;
$agent_description = strip_tags( get_the_author_meta( 'description', $agent_id ) );
$agent_description = wp_trim_words( $agent_description, 20 );

if( $agent_description ) { ?>
	<div class="description"><?php echo esc_html( $agent_description ); ?></div>
<?php }