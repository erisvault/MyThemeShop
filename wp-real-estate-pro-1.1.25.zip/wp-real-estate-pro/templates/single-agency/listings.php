<?php
/**
 * Single agency listings
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/single-agency/listings.php.
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
?>

<h3 class="listings"><?php echo __('Our Recent Listings', 'wp-real-estate'); ?></h3>

<?php
$query = wre_get_agency_listings();
if ($query->have_posts()) {

	echo '<ul class="wre-items grid-view">';
		while ($query->have_posts()) : $query->the_post();

			// set up our data for the related listings
			$columns = wre_default_grid_columns();
			?>
				<li <?php post_class('related-listing col-' . $columns); ?> >
					<?php do_action('wre_before_listings_loop_item_wrapper'); ?>
						<?php do_action('wre_before_listings_loop_item_summary'); ?>

						<div class="summary">
							<?php
							do_action('wre_before_listings_loop_item');
							do_action('wre_listings_loop_item');
							do_action('wre_after_listings_loop_item');
							?>
						</div>

						<?php do_action('wre_after_listings_loop_summary'); ?>
					<?php do_action('wre_after_listings_loop_item_wrapper'); ?>
				</li>
			<?php
		endwhile;
	echo '</ul>';
} else {
	echo wre_se_message( __('Sorry, there are no current listings', 'wp-real-estate') );
}

wp_reset_query();