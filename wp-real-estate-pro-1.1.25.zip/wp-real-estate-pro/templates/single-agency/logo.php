<?php
/**
 * Single agency logo
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/single-agency/logo.php.
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

$logo_id = wre_agency_meta('logo_id');
if (empty($logo_id))
	return;

$alt = get_post_meta($logo_id, '_wp_attachment_image_alt', true);
?>

<div class="logo">
	<img alt="<?php echo esc_attr($alt); ?>" src="<?php echo esc_url( wp_get_attachment_url( $logo_id ) ); ?>" />
</div>