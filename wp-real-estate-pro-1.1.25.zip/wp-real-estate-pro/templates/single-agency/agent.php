<?php
/**
 * Single agency agent
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/single-agency/agent.php.
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

// $id is getting past through from the include function: wre_get_part()

$agent_id = $id;
$mobile = get_the_author_meta('mobile', $agent_id );
$office_phone = get_the_author_meta('office_phone', $agent_id );
$email = get_the_author_meta('email', $agent_id );
$agent_image = wre_get_agent_attachment_url( $agent_id );
$agent_url = get_author_posts_url( $agent_id );
$column = wre_option( 'wre_archive_agents_columns' );
?>

<li class="agent col-<?php echo esc_attr($column); ?>">
	<div class="agent-inner-container">
		<div class="image">
			<a href="<?php echo esc_url( $agent_url ); ?>">
				<img src="<?php echo esc_url( $agent_image ); ?>" />
			</a>
		</div>
		<div class="contact-details">
			<h4 class="name">
				<a href="<?php echo esc_url( $agent_url ); ?>">
					<?php esc_html(the_author_meta('display_name', $agent_id)); ?>
				</a>
			</h4>

			<?php if( $mobile || $office_phone || $email ) { ?>
				<ul class="contact">
					<?php if($mobile) { ?>
						<li class="mobile">
							<i class="wre-icon-phone"></i>
							<?php esc_html_e( $mobile ); ?>
						</li>
					<?php } ?>
					<?php if($office_phone) { ?>
						<li class="phone">
							<i class="wre-icon-old-phone"></i>
							<?php esc_html_e( $office_phone ); ?>
						</li>
					<?php } ?>
					<?php if($email) { ?>
						<li class="email">
							<i class="wre-icon-email"></i>
							<a href="mailto:<?php echo esc_attr($email); ?>"><?php esc_html_e( $email ); ?></a>
						</li>
					<?php } ?>
				</ul>
			<?php } ?>
		</div>
	</div>
</li>