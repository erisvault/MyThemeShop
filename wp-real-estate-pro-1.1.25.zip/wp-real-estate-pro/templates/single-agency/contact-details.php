<?php
/**
 * Single agency contact-details
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/single-agency/contact-details.php.
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

$phone = wre_agency_meta('phone');
$fax = wre_agency_meta('fax');
$email = wre_agency_meta('email');
$website = wre_agency_meta('website');
?>

<ul class="contact">
<?php if ($website) { ?>
	<li class="website">
		<i class="wre-icon-website"></i>
		<a href="<?php echo esc_url( $website ); ?>" target="_blank">
			<?php esc_html_e($website); ?>
		</a>
	</li>
	<?php } ?>
	<?php if ($email) { ?>
		<li class="email">
			<i class="wre-icon-email"></i>
			<a href="mailto:<?php echo esc_attr( $email ); ?>">
				<?php esc_html_e($email); ?>
			</a>
		</li>
	<?php } ?>
	<?php if ($phone) { ?>
		<li class="phone"><i class="wre-icon-old-phone"></i><?php esc_html_e($phone); ?></li>
	<?php } ?>
	<?php if ($fax) { ?>
		<li class="fax"><i class="wre-icon-fax"></i><?php esc_html_e($fax); ?></li>
	<?php } ?>
</ul>