<?php
/**
 * Single agency cover
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/single-agency/cover.php.
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

$cover = wre_agency_meta('cover');
if (empty($cover))
	return;

$id = wre_agency_meta('cover_id');
$alt = get_post_meta($id, '_wp_attachment_image_alt', true);
?>

<div class="cover">
	<img alt="<?php echo esc_attr($alt); ?>" src="<?php echo esc_url($cover); ?>" />
</div>