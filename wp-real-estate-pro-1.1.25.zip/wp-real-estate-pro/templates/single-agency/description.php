<?php
/**
 * Single agency description
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/single-agency/description.php.
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

$description = wre_agency_meta('content');
if (empty($description))
	return;
?>

<div class="description"><?php echo wp_kses_post(wpautop($description)); ?></div>