<?php
/**
 * Single listing address
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/single-agency/address.php.
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

$address = wre_agency_meta('displayed_address');
if (empty($address))
	return;
?>

<div class="address"><?php echo esc_html($address); ?></div>