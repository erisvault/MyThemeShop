<?php
/**
 * Sidebar
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/global/sidebar.php.
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

get_sidebar( 'listings' );