<?php
/**
 * Lost password reset form.
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/my-account/form-reset-password.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<form method="post" class="wre-form wre-user-form" id="wre-reset-password">

	<p><?php echo apply_filters( 'wre_reset_password_message', __( 'Enter a new password below.', 'wp-real-estate' ) ); ?></p>

	<p class="wre-form-row">
		<label for="password_1"><?php _e( 'New password', 'wp-real-estate' ); ?> <span class="required">*</span></label>
		<input type="password" class="wre-text" name="password_1" id="password_1" />
	</p>
	<p class="wre-form-row">
		<label for="password_2"><?php _e( 'Re-enter new password', 'wp-real-estate' ); ?> <span class="required">*</span></label>
		<input type="password" class="wre-text" name="password_2" id="password_2" />
	</p>

	<input type="hidden" name="reset_key" value="<?php echo esc_attr( $args['key'] ); ?>" />
	<input type="hidden" name="reset_login" value="<?php echo esc_attr( $args['login'] ); ?>" />

	<div class="clear"></div>

	<?php do_action( 'wre_resetpassword_form' ); ?>

	<p class="wre-form-row wre-submit-row">
		<input type="hidden" name="wre_reset_password" value="true" />
		<input type="submit" class="wre-button" value="<?php esc_attr_e( 'Save', 'wp-real-estate' ); ?>" />
	</p>

	<?php wp_nonce_field( 'reset_password' ); ?>

</form>
