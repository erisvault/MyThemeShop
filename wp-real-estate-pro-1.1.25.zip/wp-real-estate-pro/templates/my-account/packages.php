<?php
/**
 * My Account packages
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/my-account/packages.php.
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

$packages = get_posts(array('post_type' => 'memberships', 'posts_per_page' => -1));

if (!empty($packages)) {

	do_action('wre_payment_action');
	$current_user_package = wre_get_membership_details('', 'id');
	$subscription_status = wre_get_membership_details('', 'payment_status');
	echo '<div class="wre-packages-wrapper">';
		foreach ($packages as $package) {

			$selected = '';
			if ($package->ID == $current_user_package && $subscription_status != 'cancelled' && $subscription_status != 'expired') {
				$selected = 'selected';
			}
			$submit_listings_page = wre_option('submit_listings');
			$package_amount = wre_package_meta('price', $package->ID);
			$allowed_listings = wre_package_meta('allowed_listings', $package->ID);
			$stripe_package_id = wre_package_meta('stripe_id', $package->ID);

			if ($allowed_listings == -1) {
				$allowed_listings = __('Unlimited Listings', 'wp-real-estate');
			} else {
				$allowed_listings = $allowed_listings . ' ' . __('Listings', 'wp-real-estate');
			}
			?>

			<div class="wre-package-container">
				<div class="wre-package-content-container">
					<div class="wre-plan"><?php echo esc_html($package->post_title); ?></div>
					<div class="wre-price"><?php echo wre_package_rate($package->ID); ?></div>

					<div class="wre-package-item"><?php echo $allowed_listings; ?></div>
					<div class="wre-package-item"><?php echo wpautop($package->post_content); ?></div>
					<?php if( wre_is_subscriber() ) { ?>
						<div class="wre-cta">
							<?php if (!is_user_logged_in()) { ?>
								<a class="wre-button wre-login" href="<?php echo esc_url(get_the_permalink($submit_listings_page)); ?>?package=<?php echo $package->ID; ?>">
									<?php _e('Subscribe', 'wp-real-estate'); ?>
								</a>
							<?php } else {
								if ($selected) {
							?>
									<span class="wre-button selected">
										<?php _e('Subscribed', 'wp-real-estate'); ?>
									</span>
							<?php } else { ?>
									<?php if ($package_amount == 0) { ?>
										<a class="wre-button wre-login wre-free-package" href="#" data-package-id="<?php echo esc_attr($package->ID); ?>">
											<?php _e('Subscribe', 'wp-real-estate'); ?>
										</a>
									<?php } else {
										if (wre_option('wre_enable_paypal')) {
											$paypal_link = wre_get_paypal_payment_link('', $package->ID);
									?>
											<a class="wre-button" href="<?php echo esc_url($paypal_link); ?>">
												<i class="wre-icon-paypal"></i>
												<?php _e('Subscribe', 'wp-real-estate'); ?>
											</a>
										<?php }
										if (wre_option('wre_enable_stripe')) {
										?>
											<a class="wre-stripe-subscribe-button wre-button" href="#" data-package="<?php echo esc_attr($package->ID); ?>" data-package-amount="<?php echo esc_attr($package_amount); ?>">
												<i class="wre-icon-stripe"></i>
												<?php _e('Subscribe', 'wp-real-estate'); ?>
											</a>
										<?php
										}
										if(wre_option('wre_enable_bacs')) {
										?>
											<a class="wre-bacs-subscribe-button wre-button" href="#" data-package-id="<?php echo esc_attr($package->ID); ?>">
												<?php _e('Subscribe using BACS', 'wp-real-estate'); ?>
											</a>
										<?php
										}
									}
								}
							}
							?>
						</div>
					<?php } ?>
				</div>
			</div>

		<?php
		}
		echo '<div class="wre-overlay-blocker"></div>';
	echo '</div>';
} else {
	echo wre_se_message( __('No packages found.', 'wp-real-estate') );
}