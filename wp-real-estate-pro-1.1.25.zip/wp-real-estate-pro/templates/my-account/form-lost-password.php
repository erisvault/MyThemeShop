<?php
/**
 * Lost password form
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/my-account/form-lost-password.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<form method="post" class="wre-form wre-user-form" id="wre-lost-password">

	<p><?php echo apply_filters( 'wre_lost_password_message', __( 'Lost your password? Please enter your username or email address. You will receive a link to create a new password via email.', 'wp-real-estate' ) ); ?></p>

	<p class="wre-form-row">
		<label for="user_login"><?php _e( 'Username or email', 'wp-real-estate' ); ?></label>
		<input class="wre-text" type="text" name="user_login" id="user_login" />
	</p>

	<div class="clear"></div>

	<?php do_action( 'wre_lostpassword_form' ); ?>

	<p class="wre-form-row wre-submit-row">
		<input type="submit" value="<?php esc_attr_e( 'Reset password', 'wp-real-estate' ); ?>" />
	</p>

	<?php wp_nonce_field( 'lost_password' ); ?>

</form>