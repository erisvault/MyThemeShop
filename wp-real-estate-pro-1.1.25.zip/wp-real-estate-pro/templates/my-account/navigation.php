<?php
/**
 * My Account navigation
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/my-account/navigation.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

do_action( 'wre_before_account_navigation' );
?>

<nav class="wre-navigation">
	<ul>
		<?php foreach ( wre_get_account_menu_items() as $endpoint => $item ) : ?>
			<li class="<?php echo wre_get_account_menu_item_classes( $item['endpoint'] ); ?>">
				<a href="<?php echo esc_url($item['link']); ?>"><?php echo esc_html( $item['text'] ); ?></a>
			</li>
		<?php endforeach; ?>
	</ul>
</nav>

<?php do_action( 'wre_after_account_navigation' );