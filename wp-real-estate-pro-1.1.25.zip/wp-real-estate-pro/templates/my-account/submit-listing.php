<?php
/**
 * My Account submit-listing
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/my-account/submit-listing.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$disallow_submission = wre_option( 'wre_disable_listing_submission' );
if( $disallow_submission == 'on' ) {
	if( is_user_logged_in()){
		$allowed_roles = array( 'wre_agent', 'administrator');
		$user = wp_get_current_user();
    $role = ( array ) $user->roles;
		if( !in_array( $role[0], $allowed_roles)  ) {
			echo wre_se_message( __( 'Only administrator and agents are allowed to post listings', 'wp-real-estate' ) );
			return;
		}
	} else {
		echo wre_se_message( __( 'Only administrator and agents are allowed to post listings', 'wp-real-estate' ) );
		return;
	}
}

global $current_user;
$current_user_id = $current_user->ID;

$membership_details = get_user_meta( $current_user_id, '_wre_subscription_id', true );
if( !$membership_details ) {
	$membership_details = get_user_meta( $current_user_id, '_wre_membership_details', true );
}

$prefix = '_wre_listing_';
$metabox_ids = array(
	$prefix.'description',
	$prefix.'details',
	$prefix.'features',
	$prefix.'images',
	$prefix.'status',
	$prefix.'address',
	$prefix.'settings',
	$prefix.'open',
);
$object_id = 'wre-listings-fields';
$listing_title = $listing_post_status = $is_premium = '';
if( isset( $_GET['edit'] ) && $_GET['edit'] != '' ) {
	$listings_post = get_post( $_GET['edit'] );
	if( $current_user_id && !empty( $listings_post ) && $listings_post->post_type == 'listing' && $listings_post->post_author == $current_user_id ) {
		$object_id = $_GET['edit'];
		$listing_title = get_the_title( $object_id );
		$listing_post_status = $listings_post->post_status;
		$is_premium = wre_meta('premium', $object_id);
	}
}
$args = array(
	'echo' => true,
	'remember' => true,
	'redirect' => ( is_ssl() ? 'https://' : 'http://' ) . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'],
	'form_id' => 'wre-loginform',
	'id_username' => 'user_login',
	'id_password' => 'user_pass',
	'id_remember' => 'rememberme',
	'id_submit' => 'wp-submit',
	'label_username' => __('Username', 'wp-real-estate'),
	'label_password' => __('Password', 'wp-real-estate'),
	'label_remember' => __('Remember Me', 'wp-real-estate'),
	'label_log_in' => __('Log In', 'wp-real-estate')
);

$show_membership_box = wre_invalid_membership();
?>
<div id="wre-listings-form-wrapper">

	<?php echo wre_se_message('', ''); ?>

	<div class="wre-login-notification">
		<?php if( ! $current_user_id ) { ?>
			<div class="cmb-row">
				<div class="cmb-th">
					<label><?php _e( 'Have an account?', 'wp-real-estate' ); ?></label>
				</div>
				<div class="wre-account-sign-in">
					<a class="button wre-sign-in" href="#"><?php _e( 'Sign in', 'wp-real-estate' ); ?></a>
					<?php _e( 'If you don\'t have an account you can create one below by entering your email address/username. Your account details will be confirmed via email.', 'wp-real-estate' ); ?>
				</div>
			</div>
			<?php do_action('wre_my_account_login_form'); ?>
		<?php } else { ?>
			<div class="cmb-row">
				<div class="cmb-th">
					<label><?php _e( 'Your account', 'wp-real-estate' ); ?></label>
				</div>
				<div class="wre-account-sign-in">
					<a class="button" href="<?php echo wp_logout_url( get_permalink() ); ?>"><?php _e( 'Sign out', 'wp-real-estate' ); ?></a>
					<?php echo __( 'You are currently signed in as ', 'wp-real-estate' ). '<strong>'. $current_user->data->user_login .'</strong>'; ?>
				</div>
			</div>
		<?php } ?>
	</div>

	<form class="wre-listings-form" method="post" id="wre-listings-form" enctype="multipart/form-data" encoding="multipart/form-data">
		<?php if( ! $current_user_id ) { ?>
			<div class="cmb-row">
				<div class="cmb-th">
					<label for="title"><?php _e( 'YOUR EMAIL *', 'wp-real-estate' ); ?></label>
				</div>
				<div class="cmb-td">
					<input type="text" name="email" value="" required="" />
				</div>
			</div>
		<?php } ?>
		<?php
		if( $show_membership_box ) {
			$packages = get_posts( array( 'post_type' => 'memberships', 'posts_per_page' => -1, 'field' => 'ids' ) );
			if( !empty( $packages ) ) {
				$package_id = wre_get_membership_details('', 'id');
				if( isset($_GET['package']) && $_GET['package'] != '' ) {
					$package_id = $_GET['package'];
				}
			?>
				<div class="cmb-row">
					<div class="cmb-th">
						<label for="wre-select-membership"><?php _e( 'Membership', 'wp-real-estate' ); ?></label>
					</div>
					<div class="cmb-td">
						<select name="membership" id="wre-select-membership">
							<option value="" data-package-amount=""><?php _e( 'Select Package', 'wp-real-estate' ); ?></option>
							<?php foreach( $packages as $package ) {
								$package_amount = wre_package_meta( 'price', $package->ID );
								$allowed_listings = wre_package_meta( 'allowed_listings', $package->ID );
								$package_rate = wre_package_rate($package->ID);
								if( $allowed_listings == -1 ) {
									$allowed_listings = __( 'Unlimited Listings', 'wp-real-estate' );
								} else {
									$allowed_listings = $allowed_listings.' '. __( 'Premium Listings', 'wp-real-estate' );
								}

							?>
								<option value="<?php echo esc_attr( $package->ID ); ?>" <?php selected( $package_id, $package->ID, true); ?> data-package-amount="<?php echo $package_amount; ?>">
									<?php echo esc_html( $package->post_title ); ?>
									-
									<?php echo esc_html($package_rate); ?>, <?php echo esc_html( $allowed_listings ); ?></span>
								</option>

							<?php } ?>
						</select>
					</div>
				</div>
		<?php }
		} ?>
		<div class="cmb-row">
			<div class="cmb-th">
				<label for="title"><?php _e( 'Title *', 'wp-real-estate' ); ?></label>
			</div>
			<div class="cmb-td">
				<input type="text" name="title" value="<?php echo esc_attr( $listing_title ); ?>" required="" />
			</div>
		</div>
		<?php if( wre_option( 'wre_auto_publish_listings' ) == 'on' || $listing_post_status == 'publish' ) { ?>
			<div class="cmb-row">
				<div class="cmb-th">
					<label for="wre-listing-status"><?php _e( 'Listing Status *', 'wp-real-estate' ); ?></label>
				</div>
				<div class="cmb-td">
					<select name="wre-listing-status" id="wre-listing-status">
						<option value="publish" <?php selected( $listing_post_status, 'publish' ); ?>><?php _e( 'Publish', 'wp-real-estate' ); ?></option>
						<option value="draft" <?php selected( $listing_post_status, 'draft' ); ?>><?php _e( 'Draft', 'wp-real-estate' ); ?></option>
					</select>
				</div>
			</div>
		<?php
		}
		$args = array( 'form_format' => '%3$s' );

		foreach( $metabox_ids as $metabox ) { // loop over config array

			if( $metabox == '_wre_listing_images' ) {
				?>
				<div class="cmb-row">
					<div class="cmb-th">
						<label for="title"><?php _e( 'Image Gallery', 'wp-real-estate' ); ?></label>
					</div>
					<div class="cmb-td">
					<?php if( $object_id != 'wre-listings-fields' ) {
							$gallery_images = wre_meta( 'image_gallery', $object_id );
							if( !empty($gallery_images) ) {

								echo '<ul id="wre-gallery-wrapper">';
									foreach( $gallery_images as $key => $gallery_image ) {
										echo '<li class="wre-image-wrapper">';
										echo '<img src="'.esc_url( $gallery_image ).'" />';
										echo '<a href="#" id="wre-remove-image" data-image-id="'.esc_attr( $key ).'"><i class="wre-icon-close"></i></a>';
										echo '<input type="hidden" name="wre_gallery_images[]" value="'. $key .'" />';
										echo '</li>';
									}
								echo '</ul>';

							}
						} ?>
						<input type="file" name="_wre_listing_images" value="" multiple="" accept="image/*" />
					</div>
				</div>
				<?php
			} else {
				cmb2_metabox_form( $metabox, $object_id, $args );
			}
		}

		if( $show_membership_box ) {
			if( isset($_GET['package']) && $_GET['package'] != '' ) {
				$package_amt = wre_package_meta('price', $_GET['package']);;
			} else {
				$package_amt = wre_get_membership_details('', 'price');
			}
			$class = '';
			if( $package_amt > 0 && ( $object_id == 'wre-listings-fields' || $listing_post_status == 'publish' ) ) {
				$class = 'in';
			}
		?>
			<div id="wre-payment-wrapper" class="<?php echo esc_attr( $class ); ?>">

				<div class="cmb-row">
					<div class="cmb-th">
						<label for="payment-method"><?php _e( 'Subscription Details', 'wp-real-estate' ); ?></label>
					</div>
				</div>
				<div id="wre-subscription-details"></div>

				<div id="wre-payment-options">
					<?php
					$payment_methods = array();
					if(wre_option('wre_enable_bacs'))
						$payment_methods[] = 'bacs';
					if(wre_option('wre_enable_paypal'))
						$payment_methods[] = 'paypal';
					if(wre_option('wre_enable_stripe'))
						$payment_methods[] = 'stripe';
					if( !empty($payment_methods) ) {
					?>
						<ul class="wre_payment_methods">
							<?php foreach( $payment_methods as $key => $payment_method ) {

								$checked = '';
								$title = !empty(wre_option('wre_'.$payment_method.'_title')) ? wre_option('wre_'.$payment_method.'_title') : '';

								if( !$title ) {
									if(  $payment_method == 'bacs') $title = 'Direct Bank Transfer';
									if(  $payment_method == 'paypal') $title = 'Paypal';
									if(  $payment_method == 'stripe') $title = 'Credit Card (Stripe)';
								}

								$description = wre_option('wre_'.$payment_method.'_description');
								$hide = 'wre-hidden';
								if( $key == 0 ) {
									$checked = 'checked="checked"';
									$hide = '';
								}
							?>
								<li class="wre_payment_method wre-<?php echo esc_attr($payment_method) ?>">
									<input id="wre_payment_method_<?php echo esc_attr($payment_method) ?>" type="radio" class="input-radio" name="wre_payment_method" value="<?php echo esc_attr($payment_method) ?>" <?php echo esc_attr($checked); ?> />
									<label for="wre_payment_method_<?php echo esc_attr($payment_method); ?>">
										<?php echo esc_html__($title, 'wp-real-estate'); ?>
									</label>
									<?php if( $payment_method == 'stripe' ) { ?>
										<div class="wre_payment_box wre_payment_method_stripe <?php echo $hide; ?>">
											<?php if($description) { ?>
												<p><?php echo esc_html__($description, 'wp-real-estate'); ?></p>
											<?php } ?>
											<p class="form-row form-row-wide">
												<label for="stripe-card-number"><?php _e( 'Card number', 'wp-real-estate' ); ?> <span class="required">*</span></label>
												<input id="stripe-card-number" class="input-text wc-credit-card-form-card-number" type="tel" placeholder="xxxx xxxx xxxx xxxx">
											</p>
											<p class="form-row form-row-first">
												<label for="stripe-card-expiry"><?php _e( 'Expiry (MM/YY)', 'wp-real-estate' ); ?> <span class="required">*</span></label>
												<input id="stripe-card-expiry" class="input-text wc-credit-card-form-card-expiry" type="tel" placeholder="MM / YY">
											</p>
											<p class="form-row form-row-last">
												<label for="stripe-card-cvc"><?php _e( 'Card code', 'wp-real-estate' ); ?> <span class="required">*</span></label>
												<input id="stripe-card-cvc" class="input-text wc-credit-card-form-card-cvc" type="tel" maxlength="4" placeholder="CVC" style="width:100px">
											</p>
										</div>
									<?php } else { ?>
									<?php if( $description ) { ?>
										<div class="wre_payment_box wre_payment_method_<?php echo esc_attr($payment_method); ?> <?php echo esc_attr($hide); ?>">
											<p><?php echo esc_html__($description, 'wp-real-estate'); ?></p>
										</div>
									<?php } } ?>

								</li>
							<?php } ?>
						</ul>
					<?php } ?>
				</div>
			</div>
		<?php }
		if( $object_id == 'wre-listings-fields' ) {
			$consent_label = apply_filters('submit_listing_consent_label', wre_option('submit_listing_consent_label'));
			$consent_desc = apply_filters('submit_listing_consent_desc', wre_option('submit_listing_consent_desc'));
			if($consent_desc) {
				echo '<div class="cmb-row wre-consent-desc">'.$consent_desc.'</div>';
			}
			if($consent_label) {
				echo '<div class="cmb-row wre-consent-label-wrapper">
								<input type="checkbox" id="wre-consent-label" name="consent_label" value="yes" required />
								<label for="wre-consent-label"><strong>'.$consent_label.'</strong></label>
							</div>';
			}
		}
		?>
		<input type="hidden" id="object_id" name="object_id" value="<?php echo esc_attr( $object_id ); ?>" />
		<input type="submit" class="wre-submit-listing" name="submit-listing" value="<?php _e( 'Submit Listing', 'wp-real-estate' ); ?>" />
		<img class="wre-submit-loader" src="<?php echo WRE_PLUGIN_URL ?>assets/images/loading.svg" />
		<?php wp_nonce_field( 'wre-submit_listing' ); ?>
	</form>

</div>
