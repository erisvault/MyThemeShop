<?php
/**
 * Register Form
 *
 * This template can be overridden by copying it to yourtheme/wre/my-account/form-register.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

do_action( 'wre_before_customer_register_form' );
?>

	<div class="wre-inner-container">

		<h2><?php _e( 'Register', 'wp-real-estate' ); ?></h2>

		<form method="post" id="wre-register-form" class="wre-form">

			<?php do_action( 'wre_register_form_start' ); ?>

			<p class="wre-form-row">
				<label for="reg_username"><?php _e( 'Username', 'wp-real-estate' ); ?> <span class="required">*</span></label>
				<input type="text" class="wre-text" name="username" id="reg_username" value="" />
			</p>

			<p class="wre-form-row">
				<label for="reg_email"><?php _e( 'Email address', 'wp-real-estate' ); ?> <span class="required">*</span></label>
				<input type="email" class="wre-text" name="email" id="reg_email" value="" />
			</p>

			<p class="wre-form-row">
				<label for="reg_password"><?php _e( 'Password', 'wp-real-estate' ); ?> <span class="required">*</span></label>
				<input type="password" class="wre-text" name="password" id="reg_password" />
			</p>

			<!-- Spam Trap -->
			<div style="<?php echo ( ( is_rtl() ) ? 'right' : 'left' ); ?>: -999em; position: absolute;">
				<label for="trap"><?php _e( 'Anti-spam', 'wp-real-estate' ); ?></label>
				<input type="text" name="email_2" id="trap" tabindex="-1" autocomplete="off" />
			</div>

			<?php do_action( 'wre_register_form' ); ?>

			<?php
			$consent_desc = apply_filters('wre_register_user_consent_desc', wre_option('submit_listing_consent_desc'));
			if($consent_desc) {
				echo '<p class="wre-form-row">'.$consent_desc.'</p>';
			}
			?>

			<p class="wre-form-row">
				<?php wp_nonce_field( 'wre-register', 'wre-register-nonce' ); ?>
				<input type="submit" class="wre-button button" name="register" value="<?php esc_attr_e( 'Register', 'wp-real-estate' ); ?>" />
			</p>

			<?php do_action( 'wre_register_form_end' ); ?>

		</form>

	</div>

<?php do_action( 'wre_after_customer_register_form' );