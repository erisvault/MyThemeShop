<?php
/**
 * Login Form
 *
 * This template can be overridden by copying it to yourtheme/wre/my-account/form-login.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

do_action( 'wre_before_customer_login_form' );
?>

	<div class="wre-inner-container wre-login-wrapper">

		<h2><?php _e( 'Login', 'wp-real-estate' ); ?></h2>

		<form class="wre-form" id="wre-login-form" method="post">

			<?php do_action( 'wre_login_form_start' ); ?>

			<p class="wre-form-row wre-form-input">
				<label for="username"><?php _e( 'Username or email address', 'wp-real-estate' ); ?> <span class="required">*</span></label>
				<input type="text" class="wre-text" name="username" id="username" value="" />
			</p>
			<p class="wre-form-row wre-form-input">
				<label for="password"><?php _e( 'Password', 'wp-real-estate' ); ?> <span class="required">*</span></label>
				<input class="wre-text" type="password" name="password" id="password" />
			</p>

			<?php do_action( 'wre_login_form' ); ?>

			<p class="wre-form-row">
				<?php wp_nonce_field( 'wre-login', 'wre-login-nonce' ); ?>
				<input type="submit" class="wre-button button" name="login" value="<?php esc_attr_e( 'Login', 'wp-real-estate' ); ?>" />
				<label class="wre-remember-me">
					<input name="rememberme" type="checkbox" id="rememberme" value="forever" />
					<span><?php _e( 'Remember me', 'wp-real-estate' ); ?></span>
				</label>
			</p>
			<p class="">
				<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php _e( 'Lost your password?', 'wp-real-estate' ); ?></a>
			</p>

			<?php do_action( 'wre_login_form_end' ); ?>

		</form>

	</div>

<?php do_action( 'wre_after_customer_login_form' );