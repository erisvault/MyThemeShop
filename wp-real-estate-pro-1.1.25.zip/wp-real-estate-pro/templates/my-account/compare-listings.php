<?php
/**
 * My Account compare-listings
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/my-account/compare-listings.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$listings = wre_get_comparison_data();
?>
<div class="wre-compare-wrapper">
<?php if (!empty($listings)) {
		$comparison_attributes = array('price'=> __( 'Price', 'wp-real-estate' ), 'type' => __( 'Type', 'wp-real-estate'), 'status' => __( 'Status' , 'wp-real-estate' ), 'purpose' => __( 'Purpose', 'wp-real-estate' ), 'bedrooms' => __( 'Bedrooms' ,'wp-real-estate' ), 'bathrooms' => __( 'Bathrooms' , 'wp-real-estate' ), 'car_spaces' => __( 'Car Spaces' , 'wp-real-estate' ), 'building_size' => __( 'Building Size', 'wp-real-estate' ), 'land_size' => __( 'Land Size', 'wp-real-estate' ));
		$internal_features = wre_option('internal_feature');
		$external_features = wre_option('external_feature');
?>

		<div class="listing-column listings-header">
			<div class="property-thumbnail wre-row"></div>
			<?php foreach ( $comparison_attributes as $comparison_attribute => $comparison_attr_label ) { ?>
				<div class="wre-row">
					<?php echo $comparison_attr_label; ?>
				</div>
			<?php }

			if ($internal_features) {
				foreach ($internal_features as $internal_feature) {
			?>
					<div class="wre-row">
						<?php echo $internal_feature; ?>
					</div>
			<?php
				}
			}

			if ($external_features) {
				foreach ($external_features as $external_feature) {
			?>
					<div class="wre-row">
						<?php echo $external_feature; ?>
					</div>
			<?php
				}
			}
			?>
		</div>

	<?php foreach ($listings as $listing) { ?>

			<div class="listing-column">
				<div class="property-thumbnail wre-row">
					<?php
					$image = wre_get_first_image($listing);
					$address = wre_meta('displayed_address', $listing);
					$listings_internal_features = wre_meta('internal_features', $listing);
					$listings_external_features = wre_meta('external_features', $listing);
					?>
					<p>
						<a href="<?php echo get_the_permalink( $listing ); ?>">
							<img src="<?php echo esc_url($image['sml']); ?>" />
						</a>
					</p>
					<p><?php esc_html_e($address); ?></p>
				</div>
				<?php foreach ($comparison_attributes as $comparison_attribute => $comparison_attr_label ) { ?>
					<div class="wre-row">
						<?php
						$value = wre_meta($comparison_attribute, $listing);
						if ($value) {
							if ($comparison_attribute == 'price') {
								$suffix = wre_meta('price_suffix', $listing);
								$value = wre_format_price($value) . ' ' . $suffix;
							} else if ($comparison_attribute == 'building_size') {
								$value = esc_html($value) . ' ' . esc_html(wre_meta('building_unit', $listing));
							} else if ($comparison_attribute == 'land_size') {
								$value = esc_html($value) . ' ' . esc_html(wre_meta('land_unit', $listing));
							} else if( $comparison_attribute == 'purpose' ){
								if( $value == 'Sell' ){
									$value = __( 'Sell' , 'wp-real-estate' );
								} else {
									$value = __( 'Rent' , 'wp-real-estate' );
								}
							} else if( $comparison_attribute == 'type' ){
								$listing_term = get_term_by('slug', $value, 'listing-type');
								if( $listing_term ){
									$value = $listing_term->name;
								}
							}
							echo $value;
						} else {
							echo '-';
						}
						?>
					</div>
				<?php }

				if ($internal_features) {
					foreach ($internal_features as $internal_feature) {
						$value = '-';
						if (!empty($listings_internal_features) && in_array($internal_feature, $listings_internal_features)) {
							$value = '<i class="wre-icon-tick-2"></i>';
						}
						?>
						<div class="wre-row features-list">
							<?php echo $value; ?>
						</div>
						<?php
					}
				}

				if ($external_features) {
					foreach ($external_features as $external_feature) {
						$value = '-';
						if (!empty($listings_external_features) && in_array($external_feature, $listings_external_features)) {
							$value = '<i class="wre-icon-tick-2"></i>';
						}
						?>
						<div class="wre-row features-list">
							<?php echo $value; ?>
						</div>
				<?php
					}
				}
				?>
			</div>

<?php	}
	} else {
		echo wre_se_message( sprintf( __( 'Please select Listings from %s to compare.', 'wp-real-estate' ), '<a href="'.get_permalink( wre_option( 'archives_page' ) ).'">here</a>' ) );
	} ?>
</div>
