<?php
/**
 * My Account my-listings
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/my-account/my-listings.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$submit_listing_link = get_the_permalink( wre_option( 'submit_listings' ) );

if (!is_user_logged_in()) {
	$message = sprintf( __( 'Please %s to view this page', 'wp-real-estate' ), '<a href="'.esc_url( wre_get_account_page_link() ).'">'.__('login', 'wp-real-estate').'</a>' );
	echo wre_se_message($message);
} else {

	echo '<a class="wre-add-new" href="'.esc_url( $submit_listing_link ).'">'. __( 'Add New', 'wp-real-estate' ) .'</a>';

	$my_listings = wre_get_contextual_query( 'my-listings' );
	// The Loop
	if ( $my_listings->have_posts() ) {

		$ml_view = wre_option('my_listings_mode') ? wre_option('my_listings_mode') : 'grid-view';
		$ml_columns = wre_option('my_listings_columns') ? wre_option('my_listings_columns') : '3';
		echo '<div class="wre-my-listings-wrapper">';

			echo '<ul class="wre-items '. esc_attr( $ml_view ) .'">';
				while ( $my_listings->have_posts() ) {
					$my_listings->the_post();

					$listing_id = absint( wre_get_ID() );
					?>
					<li <?php post_class('col-'.$ml_columns); ?> itemscope itemtype="http://schema.org/House">
						<?php
						do_action('wre_before_listings_loop_item_wrapper');
							remove_action('wre_before_listings_loop_image', 'wre_template_loop_shortlisted', 10);
							do_action('wre_before_listings_loop_item_summary');
						?>
							<div class="summary">
								<?php
								do_action('wre_before_listings_loop_item');
								do_action('wre_listings_loop_item');
								do_action('wre_my_listings_actions');
								do_action('wre_after_listings_loop_item');
								?>
							</div>
							<?php
							do_action('wre_after_listings_loop_item_summary');
							do_action('wre_after_listings_loop_item_wrapper');
							?>
					</li>
					<?php
				}
			echo '</ul>';
			do_action( 'wre_after_listings_loop' );
		echo '</div>';
		wp_reset_postdata();
	} else {
		echo wre_se_message( __( 'No Listings found.', 'wp-real-estate' ) );
	}
}