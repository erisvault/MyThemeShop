<?php
/**
 * My Account bank-details
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/my-account/bank-details.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if(!empty($bacs_accounts)) {
?>
<section class="wre-bacs-bank-details">
	<h2 class="wre-bacs-bank-details-heading"><?php _e( 'Our bank details', 'wp-real-estate' ); ?></h2>
	<?php
	foreach( $bacs_accounts as $bacs_account ) {
		$bacs_account = (object) $bacs_account;
		$bsb_code = '';
		if(!empty($bacs_account->wre_bsb)) {
			$bsb_code = $bacs_account->wre_bsb;
		}
		$iban = '';
		if(!empty($bacs_account->wre_iban)) {
			$iban = $bacs_account->wre_iban;
		}
		if( $bacs_account->wre_account_name ) {
			echo '<h3 class="wre-bacs-bank-details-account-name">' . wp_kses_post( wp_unslash( $bacs_account->wre_account_name ) ) . ':</h3>';
		}
		echo '<ul class="wre-bacs-bank-details">';
		
			// BACS account fields shown on the thanks page and in emails
			$account_fields = apply_filters( 'wre_bacs_account_fields', array(
				'bank_name' => array(
					'label' => __( 'Bank', 'wp-real-estate' ),
					'value' => $bacs_account->wre_bank_name,
				),
				'account_number' => array(
					'label' => __( 'Account number', 'wp-real-estate' ),
					'value' => $bacs_account->wre_account_number,
				),
				'sort_code'	=> array(
					'label' =>  apply_filters( 'wre_bacs_sort_code', __( 'BSB', 'wp-real-estate' ) ),
					'value' => $bsb_code,
				),
				'iban'		=> array(
					'label' => __( 'IBAN', 'wp-real-estate' ),
					'value' => $iban,
				),
				'bic'		=> array(
					'label' => __( 'BIC', 'wp-real-estate' ),
					'value' => $bacs_account->wre_swift,
				),
			) );
			foreach ( $account_fields as $field_key => $field ) {
				if ( ! empty( $field['value'] ) ) {
					echo '<li class="' . esc_attr( $field_key ) . '">' . wp_kses_post( $field['label'] ) . ': <strong>' . wp_kses_post( wptexturize( $field['value'] ) ) . '</strong></li>';
				}
			}
		echo '</ul>';
	}
	echo '</section>';
}