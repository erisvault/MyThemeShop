<?php
/**
 * My-Listings Loop listing-actions
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/my-account/my-listings-loop/listing-actions.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$listing_id = absint( wre_get_ID() );
$submit_listing_link = get_the_permalink( wre_option( 'submit_listings' ) );
$edit_listing_link = $submit_listing_link.'?edit='.$listing_id;
?>
<ul class="wre-my-listings-icons">
	<li class="wre-delete">
		<a href="#" data-listing-id="<?php echo esc_attr( $listing_id ); ?>">
			<i class="wre-icon-trash-empty"></i>
			<span class="wre-hover-text"><?php _e( 'Delete', 'wp-real-estate' ); ?></span>
		</a>
	</li>
	<?php if( $submit_listing_link ) { ?>
		<li class="wre-edit">
			<a href="<?php echo esc_url( $edit_listing_link ); ?>">
				<i class="wre-icon-edit"></i>
				<span class="wre-hover-text"><?php _e( 'Edit', 'wp-real-estate' ); ?></span>
			</a>
		</li>
		<?php
		if( wre_is_subscriber() ) {

			$listing_status = get_post_status( $listing_id );
			$is_premium = wre_meta('premium', $listing_id);
			$user_package_id = wre_get_membership_details( '', 'id' );
			//If user is not subscribed to any package
			if( ! $user_package_id ) {
				$listing_text = '<i class="wre-icon-subscribe"></i>';
				$tooltip_text = __( 'Subscribe', 'wp-real-estate' );
				$edit_listing_link = get_the_permalink( wre_option( 'wre_user_packages' ) );
			} else {
				if( $listing_status == 'publish' && $is_premium == 'on' ) {
					$listing_text = '<i class="wre-icon-tick-1"></i>';
					$tooltip_text = __( 'Published', 'wp-real-estate' );
					$edit_listing_link = get_the_permalink( $listing_id );
				} else {

					if( $is_premium == 'on' ) {
						$listing_text = '<i class="wre-icon-clock"></i>';
						$tooltip_text = __( 'Waiting for Approval', 'wp-real-estate' );
					} else {
						$listing_text = '<i class="wre-icon-clock"></i>';
						$tooltip_text = __( 'Make Premium', 'wp-real-estate' );
					}
				}
			}
			if( $listing_text ) {
		?>
				<li class="wre-payment-link <?php echo esc_attr( $listing_status ); ?>">
					<a href="<?php echo esc_url( $edit_listing_link ); ?>" class="pay-listing">
						<?php echo $listing_text; ?>
						<span><?php echo esc_html( $tooltip_text ); ?></span>
					</a>
				</li>
			<?php
			}
		}
	}
	?>
</ul>