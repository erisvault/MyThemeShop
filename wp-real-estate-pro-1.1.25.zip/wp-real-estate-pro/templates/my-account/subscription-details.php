<?php
/**
 * My-Listings Loop subscription details
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/my-account/subscription-details.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<div id="wre-membership-info">
	<?php
	$package_page_link = esc_url( get_the_permalink( wre_option( 'wre_user_packages' ) ) );
	if( empty($subscription) ) {
		$message = sprintf( __( 'Please %s to make listings premium', 'wp-real-estate' ), '<a href="'. $package_page_link .'">'.__( 'subscribe', 'wp-real-estate' ).'</a>' );
		echo wre_se_message( $message );
		return;
	}
	$subscription_status =  $subscription['payment_status'];

	if( $subscription_status == 'cancelled' || $subscription_status == 'expired' ) {
		$message = sprintf( __( 'Your Subscription is %s. Please %s to make listings premium', 'wp-real-estate' ), $subscription_status, '<a href="'. $package_page_link .'">'.__( 'subscribe', 'wp-real-estate' ).'</a>' );
		echo wre_se_message( $message );
	} else {
		$user_subscription =  $subscription['id'];

		$expiration_date =  $subscription['expiry_date'];
		if( $expiration_date == '' )
			$expiration_date = '-';
		else
			$expiration_date  = date( 'd-M-Y', $expiration_date );

		$remaining_listings = wre_get_remaining_listings();
		?>
		<table>
			<thead>
				<tr>
					<th><?php _e( 'Level', 'wp-real-estate' ); ?></th>
					<th><?php _e( 'Billing', 'wp-real-estate' ); ?></th>
					<th><?php _e( 'Remaining Listings', 'wp-real-estate' ); ?></th>
					<th><?php _e( 'Expiration', 'wp-real-estate' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>
						<?php echo esc_html( get_the_title($user_subscription) ); ?>
						<a href="<?php echo esc_url($package_page_link); ?>" class="wre-change-membership"><?php _e( 'Change', 'wp-real-estate' ); ?></a>
					</td>
					<td>
						<p><strong><?php echo wre_currency_symbol(); ?><?php echo esc_html(  $subscription['price'] ); ?></strong> </p>
					</td>
					<td><?php echo esc_html( $remaining_listings ); ?></td>
					<td><?php echo esc_html( $expiration_date ); ?></td>
				</tr>
			</tbody>
		</table>
	<?php do_action('wre_after_subscription_details'); ?>
	<?php } ?>
</div>
