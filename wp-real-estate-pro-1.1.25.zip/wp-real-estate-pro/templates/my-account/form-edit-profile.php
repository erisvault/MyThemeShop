<?php
/**
 * Edit account form
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/my-account/form-edit-profile.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
do_action( 'wre_before_edit_profile_form' );

$agent = new WRE_Agent();
$agent_fields = $agent->get_customer_meta_fields();
?>
<form class="wre-form" id="wre-edit-profile" action="" method="post">

	<?php do_action( 'wre_edit_profile_form_start' ); ?>
	
	<?php
	if( !empty($agent_fields) && isset($agent_fields['agent_profile']['fields']) ) { 
		$agent_feilds = $agent_fields['agent_profile']['fields'];
	
		foreach( $agent_feilds as $key => $field ) { ?>
			<p class="wre-form-row">
				<label for="<?php echo esc_attr($key); ?>"><?php echo esc_html($field['label']); ?></label>
				<?php if( $field['type'] == 'textarea' ) { ?>
				<textarea name="<?php echo esc_attr($key); ?>" class="wre-text" id="<?php echo esc_attr($key); ?>" rows="8"><?php echo esc_html(get_the_author_meta( $key, $user_id )); ?></textarea>
				<?php } else { ?>
					<input type="<?php echo esc_attr($field['type']); ?>" class="wre-text" name="<?php echo esc_attr($key); ?>" id="<?php echo esc_attr($key); ?>" value="<?php echo esc_attr(get_the_author_meta( $key, $user_id )); ?>" />
				<?php } ?>
			</p>
		<?php } ?>
		<div class="wre-form-row">
			<?php
			$upload_url = get_the_author_meta( 'wre_upload_meta', $user_id );
			$upload_edit_url = get_the_author_meta( 'wre_upload_edit_meta', $user_id );
			?>
			<div>
				<?php echo get_avatar( $user_id, 200 ); ?>
			</div>
			<p>
				<label for="agent-image"><?php _e('Profile Photo', 'wp-real-estate'); ?></label>
				<input type="file" name="agent-image" id="agent-image" value="" accept="image/*" />
				<input class="hidden" type="hidden" name="wre_upload_meta" id="wre_upload_meta" value="<?php echo esc_url_raw( $upload_url ); ?>" />
				<input class="hidden" type="hidden" name="wre_upload_edit_meta" id="wre_upload_edit_meta" value="<?php echo esc_url_raw( $upload_edit_url ); ?>" />
			</p>
		</div>
	<?php } ?>

	<div class="clear"></div>

	<?php do_action( 'wre_edit_profile_form' ); ?>

	<p>
		<?php wp_nonce_field( 'save_profile_details' ); ?>
		<input type="submit" class="wre-button button" name="save_account_details" value="<?php esc_attr_e( 'Save changes', 'wp-real-estate' ); ?>" />
	</p>

	<?php do_action( 'wre_edit_profile_form_end' ); ?>
</form>

<?php do_action( 'wre_after_edit_profile_form' );