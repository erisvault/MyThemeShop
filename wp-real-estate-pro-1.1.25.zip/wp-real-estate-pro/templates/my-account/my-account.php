<?php
/**
 * My Account Dashboard
 *
 * Shows the first intro screen on the account dashboard.
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/my-account/my-account.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>

<p><?php
	/* translators: 1: user display name 2: logout url */
	printf(
		__( 'Hello %1$s (not %1$s? <a href="%2$s">Log out</a>)', 'wp-real-estate' ),
		'<strong>' . esc_html( $current_user->display_name ) . '</strong>',
		esc_url( wp_logout_url( wre_get_account_page_link() ) )
	);
?></p>

<p><?php
	printf(
		__( 'From your account dashboard you can view your <a href="%1$s">subscriptions</a>, and <a href="%2$s">edit your password and account details</a>.', 'wp-real-estate' ),
		esc_url( wre_get_account_endpoint_page_link('subscription') ),
		esc_url( wre_get_account_endpoint_page_link('edit_account') )
	);
?></p>

<?php
do_action( 'wre_account_dashboard' );
do_action( 'wre_before_my_account' );
do_action( 'wre_after_my_account' );
