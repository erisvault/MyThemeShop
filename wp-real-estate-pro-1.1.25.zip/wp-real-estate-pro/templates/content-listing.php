<?php
/**
 * The Template for displaying listing content in the content-listing.php template
 *
 * This template can be overridden by copying it to yourtheme/wp-real-estate/content-listing.php.
 *
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

$columns = wre_default_grid_columns();

wre_get_content_listings_data( $columns );