<?php
/**
 * Make theme compatible with WP Real Estate Plugin
 *
 * @param $wre_theme_compatible
 *
 * @return bool
 */
add_filter('wre_theme_compatibility', 'your_custom_filter_function');
function your_custom_filter_function( $return ) {
	return false;
}

/**
 * To change default display mode on listings page
 *
 * @param $wre_default_display_mode
 *
 * @return string
 */
add_filter( 'wre_default_display_mode', function(){
	return 'list-view'; //list-view or grid-view
});

/**
 * To change grid columns
 *
 * @param $wre_grid_columns
 *
 * @return number
 */
add_filter( 'wre_grid_columns', function(){
	return 4; //2,3 or 4
});

/**
 * To change number of listings/agencies
 *
 * @param $wre_default_archive_number
 *
 * @return number
 */
add_filter( 'wre_default_archive_number', function(){
	return 6;
});

/**
 * To hide in-content sidebar
 *
 * @param $wre_hide_in_content_sidebar
 *
 * @return string yes/no
 */
add_filter( 'wre_hide_in_content_sidebar', function(){
	return 'yes'; // yes or no
});

/**
 * Set Default colors on theme activation
 *
 * @param $wre_default_colors
 *
 * @return $colors
 */
add_filter( 'wre_default_colors', 'your_custom_filter_function' );
function your_custom_filter_function( $colors ) {
	$colors = array(
		'wre_icons_color' => '#aeaeae',
		'wre_search_bg' => '#aeaeae',
		'wre_sidebar_headings_color' => '#151515',
		'wre_button_bg' => '#151515',
		'wre_button_bg_hover' => '#151515',
		'wre_price_color' => '#FFCA00',
		'wre_button_text_color' => '#FFCA00',
		'wre_button_text_hover' => '#fff',
		'wre_sidebar_headings_color' => '#151515',
		'wre_tagline_color' => '#151515',
		'wre_address_color' => '#151515',
		'wre_title_color' => '#151515',
		'wre_status_active_text_color' => '#000000',
		'wre_status_active_bg_color' => '#aeaeae',
		'wre_status_sold_text_color' => '#dedede',
		'wre_status_sold_bg_color' => '#444',
		'wre_status_under-offer_text_color' => '#000',
		'wre_status_under-offer_bg_color' => '#dedede'
	);
	return $colors;
}

/**
 * Related Listings Filters
 */
//Filter to show Related Listings
add_filter( 'wre_show_rl', function(){
	return 'no'; // yes/no
});

//Filter to set Related Listings Mode
add_filter( 'wre_rl_mode', function(){
	return 'list-view'; // grid-view/list-view
});

//Filter to set Related Listings Columns
add_filter( 'wre_rl_columns', function(){
	return 2; // 2,3 or 4
});

//Filter to set single agent max-listings
add_filter( 'wre_max_rl', function(){
	return 9; // any integer value
});

/**
 * Agents Archive Filters
 */
//Filter to set agents archive mode
add_filter( 'wre_agents_mode', function(){
	return 'list-view'; //grid-view / list-view
});

add_filter( 'wre_archive_agents_columns', function(){
	return 4; // 2, 3 or 4
});

add_filter( 'wre_max_archive_agents', function(){
	return 4; // any integer
});

add_filter( 'wre_agents_archive_allow_pagination', function(){
	return 'no'; // yes/no
});

/**
 * Single Agent Filters
 */
//Filter to show agents listings in single-agent page
add_filter( 'wre_show_agents_listings', function(){
	return 'no'; // yes/no
});

//Filter to set single agent listings mode
add_filter( 'wre_agent_mode', function(){
	return 'list-view'; // grid-view/list-view
});

//Filter to single agent listings columns
add_filter( 'wre_agent_columns', function(){
	return 2; // 2,3 or 4
});

//Filter to set single agent max-listings
add_filter( 'wre_agent_max_listings', function(){
	return 3; // any integer value
});

/**
 * Control agent list on Single Agency page
 *
 * @param $wre_admin_agency_get_agents
 *
 * @return $args
 */
add_filter( 'wre_admin_agency_get_agents', 'your_custom_filter_function' );
function your_custom_filter_function( $args ) {
	$args = array(
		'role' => '',
		'role__in' => array('wre_agent', 'administrator'),
		'role__not_in' => array(),
		'meta_key' => '',
		'meta_value' => '',
		'meta_compare' => '',
		'meta_query' => array(),
		'date_query' => array(),
		'include' => array(),
		'exclude' => array(),
		'orderby' => 'display_name',
		'order' => 'ASC',
		'offset' => '',
		'search' => '',
		'number' => '',
		'count_total' => false,
		'fields' => array('display_name', 'ID'),
		'who' => '',
	)
	return $args;
}

/**
 * Modify search custom fields
 *
 * @return array
 */
apply_filters( 'wre_keyword_search_fields', 'your_custom_filter_function', 10, 1 );

/**
 * Add extra options in WRE Settings
 *
 * We use the awesome CMB2 framework for all option fields and metaboxes.
 */
apply_filters( 'wre_admin_options', 'your_custom_filter_function', 10, 2 );

/**
 * Add a custom fields to the listings
 */
apply_filters( 'wre_metabox_description', 'add_custom_field', 10, 2 );
apply_filters( 'wre_metabox_images', 'add_custom_field', 10, 2 );
apply_filters( 'wre_metabox_address', 'add_custom_field', 10, 2 );
apply_filters( 'wre_metabox_settings', 'add_custom_field', 10, 2 );
apply_filters( 'wre_metabox_features', 'add_custom_field', 10, 2 );
apply_filters( 'wre_metabox_inspection', 'add_custom_field', 10, 2 );

/**
 * To get the value of custom field
 */
 get_post_meta( get_the_ID(), ‘_wre_custom_field’, true);

/**
 * Modify localized script data
 *
 * @return array
 *
 * This filter allows you to modify the localized script data that is used for various Javascript functions such as maps and slideshow on single listings. You could use this filter to set different options on individual listings such as a different map height slide duration.
 */
apply_filters( 'wre_localized_script', 'your_custom_filter_function', 10, 1 );

/**
 * Change the default theme template path (default is 'wp-real-estate')
 *
 * @return string
 *
 * With this filter, you can set the Template path to be used in your theme folder. Any correctly named templates in this folder will override the default plugin templates.
 */
apply_filters( 'wre_template_path', 'your_custom_filter_function', 10, 1 );

/**
 * Change default blank image
 *
 * @return string
 *
 * Use this filter to change the default blank image on listings.
 */
apply_filters( 'wre_default_no_image', 'your_custom_filter_function', 10, 1 );

/**
 * Hide page title on listings archive
 */
apply_filters( 'wre_archive_page_title', 'your_custom_filter_function' );
function your_custom_filter_function( $return ) {
	return false;
}
