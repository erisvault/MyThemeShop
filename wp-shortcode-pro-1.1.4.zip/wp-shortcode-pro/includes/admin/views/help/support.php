<h3><?php _e('Support', 'wp-shortcode-pro'); ?></h3>
<?php
$support = new WP_Shortcode_Admin_System_Info;
$support->display_content();