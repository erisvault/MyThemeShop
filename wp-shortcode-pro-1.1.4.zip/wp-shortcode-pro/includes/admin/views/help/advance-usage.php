<h3>Advanced Usage</h3>
<p>This section deals with the advance features offered by WP Shortcode Pro</p>
<p>
	<strong>Mapping Existing Shortcodes to WP Shortcode Pro</strong><br />
	<a href="https://mythemeshop.com/kb/wp-shortcode-pro/mapping-existing-shortcodes-to-wp-shortcode-pro/" target="_blank">https://mythemeshop.com/kb/wp-shortcode-pro/mapping-existing-shortcodes-to-wp-shortcode-pro/</a>
</p>
<p>
	<strong>Create a Custom Shortcode with WP Shortcode Pro</strong><br />
	<a href="https://mythemeshop.com/kb/wp-shortcode-pro/create-a-custom-shortcode-with-wp-shortcode-pro/">https://mythemeshop.com/kb/wp-shortcode-pro/create-a-custom-shortcode-with-wp-shortcode-pro/</a>
</p>