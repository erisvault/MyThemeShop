<?php $options = get_option('swift'); ?>
<?php get_header(); ?>
<div id="page">
	<div class="content">
		<article class="article">
			<div id="content_box">
				<div id="firstNewsBox">
					<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                    <div class="firstPost excerpt">
			<a id="featured-thumbnail" href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark">
				<?php if ( has_post_thumbnail() ) { ?>
					<?php the_post_thumbnail('featured',array('title' => '')); ?>
				<?php } else { ?>
					<div class="featured-thumbnail">
						<img width="300" height="180" src="<?php echo get_template_directory_uri(); ?>/images/300x180.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
					</div>
				<?php } ?>
			</a>
						<h2 class="title front-view-title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
               <?php if($options['mts_headline_meta'] == '1') { ?>
						<div class="post-info">
							<span class="postAuthor"><?php the_author_posts_link(); ?></span>
							<time><?php the_time('j/m/Y'); ?></time>
							<span class="postComments"><?php comments_popup_link(__('No Comments'), __('1 Comment'), __('% Comments'), 'commentslink', __('Comments off')); ?></span>
						</div>
               <?php } ?>
						<div class="post-content front-view-text">
							<?php echo excerpt(21);?>
						</div>
						<div class="readMore">
							<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Read Article','mythemeshop'); ?></a>
						</div>
					</div>                   
                    <?php endwhile; endif;?>               
				</div>	
			</div>
		</article>
<?php get_sidebar(); ?>
<?php get_footer(); ?>