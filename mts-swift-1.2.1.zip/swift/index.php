<?php $options = get_option('swift'); ?>
<?php get_header(); ?>
<div id="page">
	<div class="content">
		<article class="article">
			<div id="content_box">
			<?php if (is_home() && !is_paged()) { ?>
				<?php if($options['mts_featured_slider'] == '1') { ?>
					<div class="slider-container">
						<div class="flex-container">
							<div class="flexslider">
								<ul class="slides">
								<?php $my_query = new WP_Query('cat='.$options['mts_featured_slider_cat'].'&posts_per_page=3'); while ($my_query->have_posts()) : $my_query->the_post(); $image_id = get_post_thumbnail_id(); $image_url = wp_get_attachment_image_src($image_id,'slider'); $image_url = $image_url[0]; ?>
									<li data-thumb="<?php echo $image_url; ?>">
										<div class="slider-thumbnail">
											<a href="<?php the_permalink() ?>">
												<?php the_post_thumbnail('slider',array('title' => '')); ?>	
											</a>									
										</div>
										<div class="flex-caption">
											<h2 class="title slidertitle"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
											<div class="post-info">
												<span class="postAuthor"><?php the_author_posts_link(); ?></span>
												<time><?php the_time('j/m/Y'); ?></time>
												<span class="postComments"><?php comments_popup_link(__('No Comments'), __('1 Comment'), __('% Comments'), 'commentslink', __('Comments off')); ?></span>
											</div>
											<span class="slidertext"><?php echo excerpt(20); ?></span>
											<div class="sliderReadMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Read Article','mythemeshop'); ?></a></div>
										</div>
									</li>
							   <?php endwhile; ?>
							   </ul>
							</div>
						</div>
					</div>
				<?php } ?> 
			<?php } ?>

				<div id="firstNewsBox">
                    <?php $i = 1; $my_query = new wp_query( 'posts_per_page=2' ); ?>
					<h4 class="firstNewsTitle"><?php _e('Latest','mythemeshop'); ?></h4>
					<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
                    <div class="firstPost excerpt <?php if($i == 2){echo 'last';} ?>">
			<a id="featured-thumbnail" href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark">
				<?php if ( has_post_thumbnail() ) { ?>
					<?php the_post_thumbnail('featured',array('title' => '')); ?>
				<?php } else { ?>
					<div class="featured-thumbnail">
						<img width="300" height="180" src="<?php echo get_template_directory_uri(); ?>/images/300x180.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
					</div>
				<?php } ?>
			</a>
						<h2 class="title front-view-title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
               <?php if($options['mts_headline_meta'] == '1') { ?>
						<div class="post-info">
							<span class="postAuthor"><?php the_author_posts_link(); ?></span>
							<time><?php the_time('j/m/Y'); ?></time>
							<span class="postComments"><?php comments_popup_link(__('No Comments'), __('1 Comment'), __('% Comments'), 'commentslink', __('Comments off')); ?></span>
						</div>
               <?php } ?>
						<div class="post-content front-view-text">
							<?php echo excerpt(21);?>
						</div>
						<div class="readMore">
							<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Read Article','mythemeshop'); ?></a>
						</div>
					</div>                   
                    <?php $i++; endwhile; endif;?>               
				</div>
				
				<div id="secondNewsBox" class="secondboxmargin">
                    <?php
					  $i = 1;
					  $my_query = new wp_query( 'cat='.$options['mts_featured_first_cat'].'&posts_per_page=4' );
					?>
					<?php $f4cat=$options['mts_featured_first_cat']; echo '<h4 class="firstNewsTitle">'.get_the_category_by_id($f4cat).'</h4>'; ?>
					<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
                    <div class="firstPost excerpt <?php if($i % 2 == 0){echo 'last';} ?>">
						<h2 class="title front-view-title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
               <?php if($options['mts_headline_meta'] == '1') { ?>
						<div class="post-info">
							<span class="postAuthor"><?php the_author_posts_link(); ?></span>
							<time><?php the_time('j/m/Y'); ?></time>
							<span class="postComments"><?php comments_popup_link(__('No Comments'), __('1 Comment'), __('% Comments'), 'commentslink', __('Comments off')); ?></span>
						</div>
               <?php } ?>
						<div class="frontViewContent">
							<div class="frontSmallThumb">
								<a id="featured-thumbnail" href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark">
				<?php if ( has_post_thumbnail() ) { ?>
					<?php the_post_thumbnail('small',array('title' => '')); ?>
				<?php } else { ?>
					<div class="featured-thumbnail">
						<img width="140" height="95" src="<?php echo get_template_directory_uri(); ?>/images/140x95.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
					</div>
				<?php } ?>
</a>
							</div>
							<div class="post-content front-view-text-small">
								<?php echo excerpt(10);?>...
							</div>
							<a class="continueReading" href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Continue Reading','mythemeshop'); ?></a>
						</div>
					</div>                   
                    <?php $i++; endwhile; endif;?>               
				</div><!--#secondNewsBox-->
					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Homepage Ad') ) : ?>
					<?php endif; ?>
				<div id="thirdNewsBox">
                    <?php $i = 1; $my_query = new wp_query( 'cat='.$options['mts_featured_second_cat'].'&posts_per_page=5' );
					?>
					<?php $f4cat=$options['mts_featured_second_cat']; echo '<h4 class="firstNewsTitle">'.get_the_category_by_id($f4cat).'</h4>'; ?>
					<div class="leftcol">
					
					</div>
					<div class="rightcol">
					<ul>
					<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
                    <li class="thirdPost excerpt <?php if($i % 2 == 0){echo 'last';} ?>">
						<a id="featuredthumb" href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark">
				<?php if ( has_post_thumbnail() ) { ?>
					<?php the_post_thumbnail('hover',array('title' => '')); ?>
				<?php } else { ?>
					<div class="featured-thumbnail">
						<img width="220" height="250" src="<?php echo get_template_directory_uri(); ?>/images/220x250.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
					</div>
				<?php } ?>
</a>
						<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" class="relnewslink" rel="bookmark"><?php the_title(); ?></a>
					</li>
                    <?php $i++; endwhile; endif;?>  
					</ul>        
					</div>
				</div><!--#thirdNewsBox-->
				
				<div class="carousel-container">
					<?php if (is_home() && !is_paged()) { ?>
						<?php if($options['mts_carousel'] == '1') { ?>
						<div class="flex-container">
							<div class="carousel">
							<?php $f4cat=$options['mts_featured_carousel_cat']; echo '<h4 class="firstNewsTitle">'.get_the_category_by_id($f4cat).'</h4>'; ?>
								<ul class="slides">
								<?php $my_query = new WP_Query('cat='.$options['mts_featured_carousel_cat'].'&posts_per_page=6'); while ($my_query->have_posts()) : $my_query->the_post(); $image_id = get_post_thumbnail_id(); $image_url = wp_get_attachment_image_src($image_id,'slider'); $image_url = $image_url[0]; ?>
									<li data-thumb="<?php echo $image_url; ?>">
										<div class="carousel-thumbnail">
											<a href="<?php the_permalink() ?>">
																<?php if ( has_post_thumbnail() ) { ?>
					<?php the_post_thumbnail('carousel',array('title' => '')); ?>
				<?php } else { ?>
					<div class="featured-thumbnail">
						<img width="140" height="115" src="<?php echo get_template_directory_uri(); ?>/images/140x115.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
					</div>
				<?php } ?>
											</a>									
										</div>
										<a class="carouseltitle" href="<?php the_permalink() ?>"><?php the_title(); ?></a>
									</li>
							   <?php endwhile; ?>
							   </ul>
							</div>
						</div>
						<?php } ?> 
					<?php } ?>
				</div><!--carousel-container-->
			</div>
		</article>
<?php get_sidebar(); ?>
<?php get_footer(); ?>