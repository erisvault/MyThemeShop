/**
 * seekers Metaboxes
 */
;(function( $ ) {

	'use strict';

	// Dom Ready
	$(function() {

		// Metabox tabs
		$( 'a', '.seekers_metabox_tabs' ).on( 'click', function() {

			var $this = $( this ),
				target = $( '#seekers_tab_' + $this.attr( 'href' ) );

			$( '.seekers_metabox_tab.active' ).removeClass( 'active' );

			$this.parent().siblings().removeClass( 'active' );
			$this.parent().addClass( 'active' );
			target.addClass( 'active' );
			target.fadeIn( 800 );

			return false;
		});

		// Select
		$( '.seekers_field select' ).select2({
			minimumResultsForSearch: 10,
			dropdownCssClass: 'seekers-select2'
		});

		// Upload file
		var uploads = $( '.seekers_upload_button' ),
			frame;
		if ( uploads.length ) {
			uploads.on( 'click', function( event ) {
				event.preventDefault();

				var $this = $( this );

				// If the media frame already exists, reopen it.
				if ( frame ) {
					frame.open();
					return;
				}

				// Create the media frame.
				frame = wp.media({
					multiple: false
				});

				// When an image is selected, run a callback.
				frame.on( 'select', function() {

					// Grab the selected attachment.
					var attachment = frame.state().get( 'selection' ).first();
					frame.close();

					$this.prev().val( attachment.attributes.url );
				});

				// Finally, open the modal.
				frame.open();
			});
		}

		// Buttonset
		$( '.seekers_field.seekers-buttonset a' ).on( 'click', function( event ) {
			event.preventDefault();

			var $radiosetcontainer = $( this ).closest( '.seekers-buttonset' );
			$radiosetcontainer.find( '.buttonset-state-active' ).removeClass( 'buttonset-state-active' );

			$( this ).addClass( 'buttonset-state-active' );
			$radiosetcontainer.find( '.button-set-value' ).val( $radiosetcontainer.find( '.buttonset-state-active' ).data( 'value' ) ).trigger( 'change' );
		});

		// Dependency
		function seekersCheckDependency( $currentValue, $desiredValue, $comparison ) {
			var $passed = false;
			if ( '==' === $comparison ) {
				if ( $currentValue == $desiredValue ) {
					$passed = true;
				}
			}
			if ( '=' === $comparison ) {
				if ( $currentValue = $desiredValue ) {
					$passed = true;
				}
			}
			if ( '>=' === $comparison ) {
				if ( $currentValue >= $desiredValue ) {
					$passed = true;
				}
			}
			if ( '<=' === $comparison ) {
				if ( $currentValue <= $desiredValue ) {
					$passed = true;
				}
			}
			if ( '>' === $comparison ) {
				if ( $currentValue > $desiredValue ) {
					$passed = true;
				}
			}
			if ( '<' === $comparison ) {
				if ( $currentValue < $desiredValue ) {
					$passed = true;
				}
			}
			if ( '!=' === $comparison ) {
				if ( $currentValue != $desiredValue ) {
					$passed = true;
				}
			}

			return $passed;
		}

		function seekersLoopDependencies( $container ) {
			var $passed = false;
			$container.find( 'span' ).each( function() {

				var $value = $( this ).data( 'value' ),
					$comparison = $( this ).data( 'comparison' ),
					$field = $( this ).data( 'field' );

				$passed = seekersCheckDependency( $( '#seekers_' + $field ).val(), $value, $comparison );
				return $passed;
			});

			if ( $passed ) {
				 $container.parents( '.seekers_metabox_field' ).fadeIn( 300 );
			} else {
				 $container.parents( '.seekers_metabox_field' ).hide();
			}
		}

		$( '.seekers-dependency' ).each( function() {
			seekersLoopDependencies( $( this ) );
		});

		$( '[id*="seekers"]' ).on( 'change', function() {
			var $id = $( this ).attr( 'id' ),
				$field = $id.replace( 'seekers_', '' );
			$( 'span[data-field="' + $field + '"]' ).each( function() {
				seekersLoopDependencies( $( this ).parents( '.seekers-dependency' ) );
			});
		});
	});

})( jQuery );
