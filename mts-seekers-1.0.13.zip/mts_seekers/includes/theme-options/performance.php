<?php
/**
 * Performance Tab
 *
 * @package Seekers
 */

$menus['performance'] = array(
	'icon'  => 'fa-bolt',
	'title' => esc_html__( 'Performance', 'seekers' ),
	'desc'  => esc_html__( 'This tab contains optimization options which can help make your site run faster.', 'seekers' ),
);

$sections['performance'] = array(

	array(
		'id'       => 'async_js',
		'type'     => 'switch',
		'title'    => esc_html__( 'Async JavaScript', 'seekers' ),
		// translators: Using code tag in description.
		'sub_desc' => sprintf( esc_html__( 'Add %s attribute to script tags to improve page download speed.', 'seekers' ), '<code>async</code>' ),
		'std'      => '1',
	),

	array(
		'id'       => 'remove_ver_params',
		'type'     => 'switch',
		'title'    => esc_html__( 'Remove ver parameters', 'seekers' ),
		// translators: Using code tag in description.
		'sub_desc' => sprintf( esc_html__( 'Remove %s parameter from CSS and JS file calls. It may improve speed in some browsers which do not cache files having the parameter.', 'seekers' ), '<code>ver</code>' ),
		'std'      => '1',
	),

	array(
		'id'       => 'disable_emojis',
		'type'     => 'switch',
		'title'    => esc_html__( 'Disable Emojis', 'seekers' ),
		'sub_desc' => esc_html__( 'Disables the new WordPress emoji functionality.', 'seekers' ),
		'std'      => '0',
	),

	array(
		'id'       => 'prefetching',
		'type'     => 'switch',
		'title'    => esc_html__( 'Prefetching', 'seekers' ),
		'sub_desc' => esc_html__( 'Enable or disable prefetching. If user is on homepage, then single page will load faster and if user is on single page, homepage will load faster in modern browsers.', 'seekers' ),
		'std'      => '0',
	),
);

if ( seekers_is_woocommerce_active() ) {
	$sections['performance'][] = array(
		'id'       => 'optimize_wc',
		'type'     => 'switch',
		'title'    => esc_html__( 'Optimize WooCommerce scripts', 'seekers' ),
		'sub_desc' => esc_html__( 'Load WooCommerce scripts and styles only on WooCommerce pages.', 'seekers' ),
		'std'      => '1',
	);
}
