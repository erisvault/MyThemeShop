<?php
/**
 * Single Subscribe
 *
 * @package Seekers
 */

$menus['single-authorbox'] = array(
	'title' => esc_html__( 'Author Box', 'seekers' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of Author box in single posts page.', 'seekers' ),
);

$mts_patterns = array(
	'nobg' => array( 'img' => $uri . 'bg-patterns/nobg.png' ),
);
for ( $i = 0; $i <= 52; $i++ ) {
	$mts_patterns[ 'pattern' . $i ] = array( 'img' => $uri . 'bg-patterns/pattern' . $i . '.png' );
}

for ( $i = 1; $i <= 29; $i++ ) {
	$mts_patterns[ 'hbg' . $i ] = array( 'img' => $uri . 'bg-patterns/hbg' . $i . '.png' );
}

$sections['single-authorbox'] = array(

	array(
		'id'    => 'single_authorbox_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Author box Settings', 'seekers' ),
	),
	array(
		'id'       => 'single_authorbox_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Author box Background', 'seekers' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image for subscribe box from here.', 'seekers' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'single_authorbox_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Margin', 'seekers' ),
		'sub_desc' => esc_html__( 'Set Author box margin from here.', 'seekers' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_authorbox_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'seekers' ),
		'sub_desc' => esc_html__( 'Set Author box padding from here.', 'seekers' ),
		'std'      => array(
			'left'   => '0',
			'top'    => '40px',
			'right'  => '0',
			'bottom' => '35px',
		),
	),
	array(
		'id'       => 'single_authorbox_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'seekers' ),
		'sub_desc' => esc_html__( 'Author box border radius.', 'seekers' ),
		'std'      => '0',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'single_authorbox_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'seekers' ),
		'sub_desc' => esc_html__( 'Select border', 'seekers' ),
		'std'      => array(
			'direction' => 'top',
			'size'      => '1',
			'style'     => 'solid',
			'color'     => '#d0d2dc',
		),
	),

	array(
		'id'    => 'single_authorbox_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Author Box Title Font', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'Author Box Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '700',
			'font-size'     => '28px',
			'line-height'   => '38px',
			'color'         => '#3f4770',
			'css-selectors' => '.postauthor h4',
		),
	),
	array(
		'id'    => 'single_authorbox_author_name_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Author Box Name Font', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'Author Box Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '700',
			'font-size'     => '32px',
			'line-height'   => '41px',
			'color'         => '#01cedf',
			'css-selectors' => '.postauthor h5, .postauthor h5 a',
		),
	),
	array(
		'id'    => 'single_authorbox_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Author Box Text Font', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'Author Box Text Font',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '400',
			'font-size'     => '21px',
			'line-height'   => '41px',
			'color'         => '#3f4770',
			'css-selectors' => '.postauthor p',
		),
	),

	array(
		'id'    => 'single_author_img_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Author Image Settings', 'seekers' ),
	),
	array(
		'id'       => 'single_author_image_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Margin', 'seekers' ),
		'sub_desc' => esc_html__( 'Set Author image margin from here.', 'seekers' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '40px',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_author_image_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'seekers' ),
		'sub_desc' => esc_html__( 'Author image border radius.', 'seekers' ),
		'std'      => '150',
		'args'     => array( 'type' => 'number' ),
	),

);
