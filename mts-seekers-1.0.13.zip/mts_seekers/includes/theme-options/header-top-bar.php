<?php
/**
 * Top Bar
 *
 * @package Seekers
 */

$menus['header']['child']['header-top-bar'] = array(
	'title' => esc_html__( 'Topbar', 'seekers' ),
	'desc'  => esc_html__( 'From here, you can control the topbar of header section.', 'seekers' ),
);

$sections['header-top-bar'] = array(

	array(
		'id'       => 'mts_show_primary_nav',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Primary Menu', 'seekers' ),
		// translators: Primary Navigation Menu with strong tag.
		'sub_desc' => sprintf( esc_html__( 'Use this button to enable %s.', 'seekers' ), '<strong>' . esc_html__( 'Primary Navigation Menu', 'seekers' ) . '</strong>' ),
		'std'      => '0',
	),

	array(
		'id'         => 'mts_top_bar_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Top Bar Background', 'seekers' ),
		'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'seekers' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'primary_navigation_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Primary Navigation', 'seekers' ),
		'std'        => array(
			'preview-text'  => 'Primary Navigation Font',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => 'normal',
			'font-size'     => '13px',
			'color'         => '#777',
			'css-selectors' => '#primary-navigation a',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'mts_header_social_icons',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show header social icons', 'seekers' ),
		'sub_desc'   => esc_html__( 'Use this button to show or hide Header Social Icons.', 'seekers' ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'mts_header_social',
		'title'      => esc_html__( 'Header Social Icons', 'seekers' ),
		'sub_desc'   => esc_html__( 'Add Social Media icons in header.', 'seekers' ),
		'type'       => 'group',
		'groupname'  => esc_html__( 'Header Icons', 'seekers' ), // Group name.
		'subfields'  => array(
			array(
				'id'    => 'mts_header_icon_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'seekers' ),
			),
			array(
				'id'    => 'mts_header_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Icon', 'seekers' ),
			),
			array(
				'id'    => 'mts_header_icon_link',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'seekers' ),
			),
			array(
				'id'    => 'mts_header_icon_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background color', 'seekers' ),
			),
			array(
				'id'    => 'mts_header_icon_hover_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background hover color', 'seekers' ),
			),
			array(
				'id'    => 'mts_header_icon_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon color', 'seekers' ),
			),
			array(
				'id'    => 'mts_header_icon_hover_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon hover color', 'seekers' ),
			),
			array(
				'id'    => 'mts_header_icon_margin',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Margin', 'seekers' ),
			),
			array(
				'id'    => 'mts_header_icon_padding',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Padding', 'seekers' ),
			),
			array(
				'id'       => 'mts_header_icon_border',
				'type'     => 'border',
				'title'    => esc_html__( 'Border', 'seekers' ),
				'sub_desc' => esc_html__( 'Select border.', 'seekers' ),
			),
			array(
				'id'    => 'mts_header_icon_border_radius',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Header icon border radius', 'seekers' ),
				'args'  => array( 'type' => 'number' ),
			),
		),
		'std'        => array(
			'facebook' => array(
				'group_title'                   => 'Facebook',
				'group_sort'                    => '1',
				'mts_header_icon_title'         => 'Facebook',
				'mts_header_icon'               => 'facebook',
				'mts_header_icon_link'          => '#',
				'mts_header_icon_bgcolor'       => '',
				'mts_header_icon_hover_bgcolor' => '',
				'mts_header_icon_color'         => '#2e4152',
				'mts_header_icon_hover_color'   => seekers_get_settings( 'link_color_scheme' ),
				'mts_header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '8px',
					'bottom' => '0',
					'left'   => '0',
				),
				'mts_header_icon_padding'       => array(
					'top'    => '12px',
					'right'  => '8px',
					'bottom' => '12px',
					'left'   => '8px',
				),
				'mts_header_icon_border_radius' => '0',
				'mts_header_icon_border_radius' => '0',
				'mts_header_icon_border'        => array(
					'direction' => 'all',
					'size'      => '0',
					'style'     => 'solid',
					'color'     => '#777',
				),
			),
			'twitter'  => array(
				'group_title'                   => 'Twitter',
				'group_sort'                    => '2',
				'mts_header_icon_title'         => 'Twitter',
				'mts_header_icon'               => 'twitter',
				'mts_header_icon_link'          => '#',
				'mts_header_icon_bgcolor'       => '',
				'mts_header_icon_hover_bgcolor' => '',
				'mts_header_icon_color'         => '#2e4152',
				'mts_header_icon_hover_color'   => seekers_get_settings( 'link_color_scheme' ),
				'mts_header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '8px',
					'bottom' => '0',
					'left'   => '0',
				),
				'mts_header_icon_padding'       => array(
					'top'    => '12px',
					'right'  => '8px',
					'bottom' => '12px',
					'left'   => '8px',
				),
				'mts_header_icon_border_radius' => '0',
				'mts_header_icon_border'        => array(
					'direction' => 'all',
					'size'      => '0',
					'style'     => 'solid',
					'color'     => '#777',
				),
			),
			'gplus'    => array(
				'group_title'                   => 'Google Plus',
				'group_sort'                    => '3',
				'mts_header_icon_title'         => 'Google Plus',
				'mts_header_icon'               => 'google-plus',
				'mts_header_icon_link'          => '#',
				'mts_header_icon_bgcolor'       => '',
				'mts_header_icon_hover_bgcolor' => '',
				'mts_header_icon_color'         => '#2e4152',
				'mts_header_icon_hover_color'   => seekers_get_settings( 'link_color_scheme' ),
				'mts_header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '8px',
					'bottom' => '0',
					'left'   => '0',
				),
				'mts_header_icon_padding'       => array(
					'top'    => '12px',
					'right'  => '8px',
					'bottom' => '12px',
					'left'   => '8px',
				),
				'mts_header_icon_border_radius' => '0',
				'mts_header_icon_border'        => array(
					'direction' => 'all',
					'size'      => '0',
					'style'     => 'solid',
					'color'     => '#777',
				),
			),
			'youtube'  => array(
				'group_title'                   => 'YouTube',
				'group_sort'                    => '4',
				'mts_header_icon_title'         => 'YouTube',
				'mts_header_icon'               => 'youtube-play',
				'mts_header_icon_link'          => '#',
				'mts_header_icon_bgcolor'       => '',
				'mts_header_icon_hover_bgcolor' => '',
				'mts_header_icon_color'         => '#2e4152',
				'mts_header_icon_hover_color'   => seekers_get_settings( 'link_color_scheme' ),
				'mts_header_icon_margin'        => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'mts_header_icon_padding'       => array(
					'top'    => '12px',
					'right'  => '8px',
					'bottom' => '12px',
					'left'   => '8px',
				),
				'mts_header_icon_border_radius' => '0',
				'mts_header_icon_border'        => array(
					'direction' => 'all',
					'size'      => '0',
					'style'     => 'solid',
					'color'     => '#777',
				),
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_header_social_icons',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

);
