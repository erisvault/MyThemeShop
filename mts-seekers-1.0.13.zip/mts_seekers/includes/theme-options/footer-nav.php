<?php
/**
 * Navigation
 *
 * @package Seekers
 */

$menus['footer']['child']['footer-nav'] = array(
	'title' => esc_html__( 'Navigation Section', 'seekers' ),
	'desc'  => esc_html__( 'From here, you can control the Navigation Section.', 'seekers' ),
);

$sections['footer-nav'] = array(

	array(
		'id'       => 'footer_nav_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Navigation Section', 'seekers' ),
		'sub_desc' => esc_html__( 'Enable or disable Navigation Section with this option.', 'seekers' ),
		'std'      => '0',
	),

	array(
		'id'         => 'footer_nav_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Navigation Section Alignment', 'seekers' ),
		'sub_desc'   => esc_html__( 'Choose alignment of Navigation Section.', 'seekers' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'seekers' ),
			'center' => esc_html__( 'Center', 'seekers' ),
			'right'  => esc_html__( 'Right', 'seekers' ),
		),
		'std'        => 'left',
		'class'      => 'green',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_nav_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'seekers' ),
		'sub_desc'   => esc_html__( 'Navigation Section margin.', 'seekers' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '30px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'seekers' ),
		'sub_desc'   => esc_html__( 'Navigation Section padding.', 'seekers' ),
		'std'        => array(
			'top'    => '30px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'seekers' ),
		'sub_desc'   => esc_html__( 'Select border', 'seekers' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_nav_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Footer Navigation', 'seekers' ),
		'std'        => array(
			'preview-text'   => 'Footer Navigation Font',
			'preview-color'  => 'dark',
			'font-family'    => 'Karla',
			'font-weight'    => '700',
			'font-size'      => '16px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.footer-nav li a',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_menu_item_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Nav Menu items', 'seekers' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_menu_item_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Menu Items Margin', 'seekers' ),
		'sub_desc'   => esc_html__( 'Navigation Section menu item margin.', 'seekers' ),
		'top'        => false,
		'bottom'     => false,
		'std'        => array(
			'right' => '0',
			'left'  => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_separator',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Nav Separator', 'seekers' ),
		'sub_desc'   => esc_html__( 'Enable or disable nav separator with this option.', 'seekers' ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_separator_content',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Separator', 'seekers' ),
		'sub_desc'   => esc_html__( 'Use any separator, ex: "-" "/" "|" "." ">"', 'seekers' ),
		'std'        => '|',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_separator',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_separator_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Separator Color', 'seekers' ),
		'sub_desc'   => esc_html__( 'Set nav separator color from here.', 'seekers' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_separator',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_nav_separator_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Separator Margin', 'seekers' ),
		'sub_desc'   => esc_html__( 'Nav Separator margin.', 'seekers' ),
		'top'        => false,
		'bottom'     => false,
		'std'        => array(
			'right' => '25px',
			'left'  => '25px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_separator',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_social_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Social Icons', 'seekers' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_nav_social_icons',
		'type'       => 'switch',
		'title'      => esc_html__( 'Social Icons', 'seekers' ),
		'sub_desc'   => esc_html__( 'Enable or disable social icons with this option.', 'seekers' ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_nav_social',
		'title'      => esc_html__( 'Footer Social Icons', 'seekers' ),
		'sub_desc'   => esc_html__( 'Add Social Media icons in footer nav section.', 'seekers' ),
		'type'       => 'group',
		'groupname'  => esc_html__( 'Social Icons', 'seekers' ), // Group name.
		'subfields'  => array(
			array(
				'id'    => 'footer_nav_social_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'seekers' ),
			),
			array(
				'id'    => 'footer_nav_social_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Icon', 'seekers' ),
			),
			array(
				'id'    => 'footer_nav_social_link',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'seekers' ),
			),
			array(
				'id'    => 'footer_nav_social_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Background color', 'seekers' ),
			),
			array(
				'id'    => 'footer_nav_social_hover_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Background hover color', 'seekers' ),
			),
			array(
				'id'    => 'footer_nav_social_color',
				'type'  => 'color',
				'title' => esc_html__( 'Icon color', 'seekers' ),
			),
			array(
				'id'    => 'footer_nav_social_hover_color',
				'type'  => 'color',
				'title' => esc_html__( 'Icon hover color', 'seekers' ),
			),
			array(
				'id'    => 'footer_nav_social_margin',
				'type'  => 'margin',
				'title' => esc_html__( 'Margin', 'seekers' ),
			),
			array(
				'id'    => 'footer_nav_social_padding',
				'type'  => 'margin',
				'title' => esc_html__( 'Padding', 'seekers' ),
			),
			array(
				'id'    => 'footer_nav_social_border_radius',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Border radius', 'seekers' ),
				'args'  => array( 'type' => 'number' ),
			),
			array(
				'id'    => 'footer_nav_social_border_size',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Border Size', 'seekers' ),
				'args'  => array( 'type' => 'number' ),
			),
			array(
				'id'      => 'footer_nav_social_border_style',
				'type'    => 'select',
				'title'   => esc_html__( 'Border Style', 'seekers' ),
				'options' => array(
					'none'   => esc_html__( 'None', 'seekers' ),
					'solid'  => esc_html__( 'Solid', 'seekers' ),
					'dotted' => esc_html__( 'Dotted', 'seekers' ),
					'dashed' => esc_html__( 'Dashed', 'seekers' ),
					'double' => esc_html__( 'Double', 'seekers' ),
					'groove' => esc_html__( 'Groove', 'seekers' ),
					'ridge'  => esc_html__( 'Ridge', 'seekers' ),
					'inset'  => esc_html__( 'Inset', 'seekers' ),
					'outset' => esc_html__( 'Outset', 'seekers' ),
				),
			),
			array(
				'id'    => 'footer_nav_social_border_color',
				'type'  => 'color',
				'title' => esc_html__( 'Border Color', 'seekers' ),
			),
		),
		'std'        => array(
			'facebook'  => array(
				'group_title'                     => 'Facebook',
				'group_sort'                      => '1',
				'footer_nav_social_title'         => 'Facebook',
				'footer_nav_social_icon'          => 'facebook-square',
				'footer_nav_social_link'          => '#',
				'footer_nav_social_bgcolor'       => '',
				'footer_nav_social_hover_bgcolor' => '',
				'footer_nav_social_color'         => '#ffffff',
				'footer_nav_social_hover_color'   => seekers_get_settings( 'mts_color_scheme' ),
				'footer_nav_social_margin'        => array(
					'top'    => '0',
					'right'  => '24px',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_nav_social_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_nav_social_border_radius' => '0',
				'footer_nav_social_border_size'   => '1',
				'footer_nav_social_border_style'  => 'none',
				'footer_nav_social_border_color'  => '#dddddd',
			),
			'youtube'   => array(
				'group_title'                     => 'Youtube',
				'group_sort'                      => '1',
				'footer_nav_social_title'         => 'Youtube',
				'footer_nav_social_icon'          => 'youtube',
				'footer_nav_social_link'          => '#',
				'footer_nav_social_bgcolor'       => '',
				'footer_nav_social_hover_bgcolor' => '',
				'footer_nav_social_color'         => '#ffffff',
				'footer_nav_social_hover_color'   => seekers_get_settings( 'mts_color_scheme' ),
				'footer_nav_social_margin'        => array(
					'top'    => '0',
					'right'  => '24px',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_nav_social_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_nav_social_border_radius' => '0',
				'footer_nav_social_border_size'   => '1',
				'footer_nav_social_border_style'  => 'none',
				'footer_nav_social_border_color'  => '#dddddd',
			),
			'twitter'   => array(
				'group_title'                     => 'Twitter',
				'group_sort'                      => '3',
				'footer_nav_social_title'         => 'Twitter',
				'footer_nav_social_icon'          => 'twitter',
				'footer_nav_social_link'          => '#',
				'footer_nav_social_bgcolor'       => '',
				'footer_nav_social_hover_bgcolor' => '',
				'footer_nav_social_color'         => '#ffffff',
				'footer_nav_social_hover_color'   => seekers_get_settings( 'mts_color_scheme' ),
				'footer_nav_social_margin'        => array(
					'top'    => '0',
					'right'  => '24px',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_nav_social_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_nav_social_border_radius' => '0',
				'footer_nav_social_border_size'   => '1',
				'footer_nav_social_border_style'  => 'none',
				'footer_nav_social_border_color'  => '#dddddd',
			),
			'pinterest' => array(
				'group_title'                     => 'Pinterest',
				'group_sort'                      => '4',
				'footer_nav_social_title'         => 'Pinterest',
				'footer_nav_social_icon'          => 'pinterest',
				'footer_nav_social_link'          => '#',
				'footer_nav_social_bgcolor'       => '',
				'footer_nav_social_hover_bgcolor' => '',
				'footer_nav_social_color'         => '#ffffff',
				'footer_nav_social_hover_color'   => seekers_get_settings( 'mts_color_scheme' ),
				'footer_nav_social_margin'        => array(
					'top'    => '0',
					'right'  => '24px',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_nav_social_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_nav_social_border_radius' => '0',
				'footer_nav_social_border_size'   => '1',
				'footer_nav_social_border_style'  => 'none',
				'footer_nav_social_border_color'  => '#dddddd',
			),
			'instagram' => array(
				'group_title'                     => 'Instagram',
				'group_sort'                      => '5',
				'footer_nav_social_title'         => 'Instagram',
				'footer_nav_social_icon'          => 'instagram',
				'footer_nav_social_link'          => '#',
				'footer_nav_social_bgcolor'       => '',
				'footer_nav_social_hover_bgcolor' => '',
				'footer_nav_social_color'         => '#ffffff',
				'footer_nav_social_hover_color'   => seekers_get_settings( 'mts_color_scheme' ),
				'footer_nav_social_margin'        => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_nav_social_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'footer_nav_social_border_radius' => '0',
				'footer_nav_social_border_size'   => '1',
				'footer_nav_social_border_style'  => 'none',
				'footer_nav_social_border_color'  => '#dddddd',
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_social_icons',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_nav_social_font_size',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Font Size', 'seekers' ),
		'sub_desc'   => esc_html__( 'Set font size of footer nav social icons in px.', 'seekers' ),
		'std'        => '24',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_nav_social_icons',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

);
