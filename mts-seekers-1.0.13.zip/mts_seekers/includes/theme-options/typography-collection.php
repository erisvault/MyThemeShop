<?php
/**
 * Typography tab
 *
 * @package Seekers
 */

$menus['typography-collection'] = array(
	'icon'       => 'fa-text-width',
	'title'      => esc_html__( 'Typography', 'seekers' ),
	'hide_title' => true,
);

$sections['typography-collection'] = array(

	array(
		'id'    => 'typography-collections',
		'type'  => 'typography_collections',
		'title' => esc_html__( 'Theme Typography', 'seekers' ),
		'desc'  => esc_html__( 'From here, you can control the fonts used on your site. You can choose from 17 standard font sets, or from the Google Fonts Library containing 800+ fonts.', 'seekers' ),
	),

	array(
		'id'    => 'seekers_logo',
		'type'  => 'typography',
		'title' => esc_html__( 'Logo Font', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'Logo',
			'preview-color' => 'light',
			'font-family'   => 'Quicksand',
			'font-weight'   => '500',
			'font-size'     => '38px',
			'color'         => seekers_get_settings( 'link_color_scheme' ),
			'css-selectors' => '#logo a',
		),
	),

	array(
		'id'    => 'secondary_navigation_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Secondary Navigation', 'seekers' ),
		'std'   => array(
			'preview-text'   => 'Secondary Navigation Font',
			'preview-color'  => 'light',
			'font-family'    => 'Karla',
			'font-weight'    => '700',
			'font-size'      => '18px',
			'color'          => '#3f4770',
			'css-selectors'  => '#secondary-navigation a, .header-5 .navigation .toggle-caret, .header-search-icon',
			'additional-css' => 'text-transform: uppercase;',
		),
	),

	array(
		'id'    => 'home_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Archive Post Titles', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'Archive Article Title',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-size'     => '32px',
			'font-weight'   => '700',
			'color'         => '#3f4770',
			'css-selectors' => '.latestPost .title a',
		),
	),

	array(
		'id'    => 'single_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Single Post Title', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'Single Article Title',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-size'     => '56px',
			'font-weight'   => '700',
			'line-height'   => '60px',
			'color'         => '#2e4257',
			'css-selectors' => '.single-title',
		),
	),

	array(
		'id'    => 'content_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Content Font', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'Content Font',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '400',
			'font-size'     => '21px',
			'line-height'   => '41px',
			'color'         => '#3f4770',
			'css-selectors' => 'body',
		),
	),

	array(
		'id'    => 'sidebar_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Widget Title', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '400',
			'font-size'     => '28px',
			'color'         => '#3f4770',
			'css-selectors' => '#sidebar .widget h3.widget-title',
		),
	),

	array(
		'id'    => 'sidebar_url',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Links', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Links',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '700',
			'font-size'     => '18px',
			'line-height'   => '24px',
			'color'         => '#3f4770',
			'css-selectors' => '#sidebar .widget a, #sidebar .widget li',
		),
	),
	array(
		'id'    => 'sidebar_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Font', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Font',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '24px',
			'color'         => '#b0b3c0',
			'css-selectors' => '#sidebar .widget',
		),
	),

	array(
		'id'    => 'top_footer_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Widget Title', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'Footer Title Font',
			'preview-color' => 'dark',
			'font-family'   => 'Karla',
			'font-weight'   => '700',
			'font-size'     => '24px',
			'color'         => '#ffffff',
			'css-selectors' => '.footer-widgets h3, #site-footer .widget #wp-subscribe .title, .brands-title',
		),
	),

	array(
		'id'    => 'top_footer_link_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Link', 'seekers' ),
		'std'   => array(
			'preview-text'   => 'Footer Links',
			'preview-color'  => 'dark',
			'font-family'    => 'Karla',
			'font-weight'    => '700',
			'font-size'      => '18px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.f-widget a, footer .wpt_widget_content a, footer .wp_review_tab_widget_content a, footer .wpt_tab_widget_content a, footer .widget .wp_review_tab_widget_content a',
		),
	),

	array(
		'id'    => 'top_footer_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer font', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'Footer Font',
			'preview-color' => 'dark',
			'font-family'   => 'Karla',
			'font-weight'   => '700',
			'font-size'     => '16px',
			'color'         => '#bcc0c5',
			'css-selectors' => '.footer-widgets, .f-widget .top-posts .comment_num, footer .meta, footer .twitter_time, footer .widget .wpt_widget_content .wpt-postmeta, footer .widget .wpt_comment_content, footer .widget .wpt_excerpt, footer .wp_review_tab_widget_content .wp-review-tab-postmeta, footer .advanced-recent-posts p, footer .popular-posts p, footer .category-posts p, footer .widget .post-info',
		),
	),

	array(
		'id'    => 'copyrights_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Copyrights Section', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'Copyrights Font',
			'preview-color' => 'dark',
			'font-family'   => 'Karla',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'color'         => '#ffffff',
			'css-selectors' => '#copyright-note',
		),
	),

	array(
		'id'    => 'h1_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H1 Heading in Content', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'H1 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '700',
			'font-size'     => '28px',
			'color'         => '#3f4770',
			'css-selectors' => 'h1',
		),
	),

	array(
		'id'    => 'h2_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H2 Heading in Content', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'H2 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '700',
			'font-size'     => '24px',
			'color'         => '#3f4770',
			'css-selectors' => 'h2',
		),
	),

	array(
		'id'    => 'h3_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H3 Heading in Content', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'H3 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '700',
			'font-size'     => '22px',
			'color'         => '#3f4770',
			'css-selectors' => 'h3',
		),
	),

	array(
		'id'    => 'h4_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H4 Heading in Content', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'H4 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '700',
			'font-size'     => '20px',
			'color'         => '#3f4770',
			'css-selectors' => 'h4',
		),
	),

	array(
		'id'    => 'h5_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H5 Heading in Content', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'H5 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '700',
			'font-size'     => '18px',
			'color'         => '#3f4770',
			'css-selectors' => 'h5',
		),
	),

	array(
		'id'    => 'h6_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H6 Heading in Content', 'seekers' ),
		'std'   => array(
			'preview-text'  => 'H6 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '700',
			'font-size'     => '16px',
			'color'         => '#3f4770',
			'css-selectors' => 'h6',
		),
	),

	array(
		'id'       => 'typography-subsets',
		'type'     => 'multi_checkbox',
		'title'    => esc_html__( 'Character sets', 'seekers' ),
		'sub_desc' => esc_html__( 'Choose the character sets you wish to include. Please note that not all sets are available for all fonts.', 'seekers' ),
		'options'  => array(
			'latin'        => esc_html__( 'Latin', 'seekers' ),
			'latin-ext'    => esc_html__( 'Latin Extended', 'seekers' ),
			'cyrillic'     => esc_html__( 'Cyrillic', 'seekers' ),
			'cyrillic-ext' => esc_html__( 'Cyrillic Extended', 'seekers' ),
			'greek'        => esc_html__( 'Greek', 'seekers' ),
			'greek-ext'    => esc_html__( 'Greek Extended', 'seekers' ),
			'vietnamese'   => esc_html__( 'Vietnamese', 'seekers' ),
			'khmer'        => esc_html__( 'Khmer', 'seekers' ),
			'devanagari'   => esc_html__( 'Devanagari', 'seekers' ),
		),
		'std'      => array( 'latin' ),
	),
);
