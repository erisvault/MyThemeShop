<?php
/**
 * HomePage Pagination
 *
 * @package Seekers
 */

$menus['home-pagination'] = array(
	'title' => esc_html__( 'Pagination', 'seekers' ),
	'desc'  => esc_html__( 'From here, you can control the elements of homepage pagination.', 'seekers' ),
);

$sections['home-pagination'] = array(

	array(
		'id'       => 'mts_pagenavigation_type',
		'type'     => 'radio',
		'title'    => esc_html__( 'Pagination Type', 'seekers' ),
		'sub_desc' => esc_html__( 'Select pagination type.', 'seekers' ),
		'options'  => array(
			'0' => esc_html__( 'Default (Next / Previous)', 'seekers' ),
			'1' => esc_html__( 'Numbered (1 2 3 4...)', 'seekers' ),
			'2' => esc_html__( 'AJAX (Load More Button)', 'seekers' ),
			'3' => esc_html__( 'AJAX (Auto Infinite Scroll)', 'seekers' ),
		),
		'std'      => '0',
	),

	array(
		'id'         => 'load_more_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Load More Alignment', 'seekers' ),
		'sub_desc'   => esc_html__( 'Choose the load more alignment from here.', 'seekers' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'seekers' ),
			'center' => esc_html__( 'Center', 'seekers' ),
			'right'  => esc_html__( 'Right', 'seekers' ),
			'full'   => esc_html__( 'Full Width', 'seekers' ),
		),
		'std'        => 'center',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_pagenavigation_bgcolor',
		'type'     => 'color',
		'title'    => esc_html__( 'Pagination background color', 'seekers' ),
		'sub_desc' => esc_html__( 'Select pagination background color.', 'seekers' ),
		'std'      => '#3f4770',
	),
	array(
		'id'       => 'mts_pagenavigation_hover_bgcolor',
		'type'     => 'color',
		'title'    => esc_html__( 'Pagination background hover color', 'seekers' ),
		'sub_desc' => esc_html__( 'Select pagination background hover color.', 'seekers' ),
		'std'      => seekers_get_settings( 'mts_color_scheme' ),
	),
	array(
		'id'       => 'mts_pagenavigation_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Pagination color', 'seekers' ),
		'sub_desc' => esc_html__( 'Select pagination color.', 'seekers' ),
		'std'      => '#ffffff',
	),
	array(
		'id'       => 'mts_pagenavigation_hover_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Pagination hover color', 'seekers' ),
		'sub_desc' => esc_html__( 'Select pagination hover color.', 'seekers' ),
		'std'      => '#3f4770',
	),
	array(
		'id'       => 'mts_pagenavigation_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Pagination Margin', 'seekers' ),
		'sub_desc' => esc_html__( 'Update pagination margin from here.', 'seekers' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '5px',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'mts_pagenavigation_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Pagination Padding', 'seekers' ),
		'sub_desc' => esc_html__( 'Update pagination padding from here.', 'seekers' ),
		'std'      => array(
			'top'    => '10px',
			'right'  => '13px',
			'bottom' => '10px',
			'left'   => '13px',
		),
	),
	array(
		'id'       => 'mts_pagenavigation_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Pagination border radius', 'seekers' ),
		'sub_desc' => esc_html__( 'Update pagination border radius in px.', 'seekers' ),
		'std'      => '0',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'pagenavigation_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'seekers' ),
		'sub_desc' => esc_html__( 'Select border', 'seekers' ),
	),

);
