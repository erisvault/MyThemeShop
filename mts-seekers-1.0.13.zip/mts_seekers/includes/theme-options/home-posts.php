<?php
/**
 * HomePage Posts
 *
 * @package Seekers
 */

$features = seekers_get_settings( 'mts_featured_categories' );
if ( empty( $features ) ) {
	return;
}
foreach ( $features as $feature ) :
	$title        = isset( $feature['mts_featured_title'] ) ? $feature['mts_featured_title'] : 'No Title';
	$posts_layout = isset( $feature['mts_thumb_layout'] ) ? $feature['mts_thumb_layout'] : '';
	if ( 'layout-default' === $posts_layout ) {
		$posts_layout = 'default';
	}
	$unique_id = isset( $feature['unique_id'] ) ? $feature['unique_id'] : '';

	$menus[ 'homepage-' . $unique_id ] = array(
		'title' => $title,
		// translators: description.
		'desc'  => sprintf( wp_kses_post( __( 'From here, you can control the elements of %s', 'seekers' ) ), $title ),
	);

	$sections[ 'homepage-' . $unique_id ] = array(

		/**
		 * Layout Default Settings
		 *
		 * @package Seekers
		 */

		// Section Title.
		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'seekers' ),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'seekers' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'seekers' ),
			'std'      => '0',
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'seekers' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'seekers' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'seekers' ),
				'center' => esc_html__( 'Center', 'seekers' ),
				'right'  => esc_html__( 'Right', 'seekers' ),
				'full'   => esc_html__( 'Full Width', 'seekers' ),
			),
			'std'        => 'left',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'seekers' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'seekers' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '#ffffff',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'post_title_shadow' . $unique_id,
			'type'       => 'switch',
			'title'      => esc_html__( 'Box Shadow', 'seekers' ),
			'sub_desc'   => esc_html__( 'Use this button to show or hide box shadow in post container.', 'seekers' ),
			'std'        => '1',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'seekers' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'seekers' ),
			'std'        => array(
				'top'    => '125px',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'seekers' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'seekers' ),
			'std'        => array(
				'top'    => '18px',
				'right'  => '40px',
				'bottom' => '18px',
				'left'   => '40px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'seekers' ),
			'sub_desc'   => esc_html__( 'Select border', 'seekers' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'seekers' ),
			'std'        => array(
				'preview-text'  => 'Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Karla',
				'font-weight'   => '400',
				'font-size'     => '32px',
				'color'         => '#3f4770',
				'css-selectors' => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Meta info.
		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_post_meta_info_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Meta Info', 'seekers' ),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_home_headline_meta_info' . $unique_id,
			'type'     => 'layout2',
			// translators: title.
			'title'    => sprintf( wp_kses_post( __( '%s Meta Info', 'seekers' ) ), $title ),
			// translators: description.
			'sub_desc' => sprintf( wp_kses_post( __( 'Organize how you want the post meta info to appear on %s', 'seekers' ) ), $title ),
			'options'  => array(
				'enabled'  => array(
					'author' => array(
						'label'     => __( 'Author Name', 'seekers' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_author_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'seekers' ),
							),
							array(
								'id'       => 'mts_meta_info_author_divider_' . $unique_id,
								'type'     => 'text',
								'class'    => 'small-text',
								'title'    => esc_html__( 'Divider', 'seekers' ),
								'sub_desc' => esc_html__( 'Use any divider, ex: "-" "/" "|" "." ">"', 'seekers' ),
								'std'      => '|',
							),
							array(
								'id'     => 'mts_meta_info_author_margin_' . $unique_id,
								'type'   => 'margin',
								'title'  => esc_html__( 'Margin', 'seekers' ),
								'top'    => false,
								'bottom' => false,
								'std'    => array(
									'left'  => '-12px',
									'right' => '4px',
								),
							),
						),
					),
					'date'   => array(
						'label'     => esc_html__( 'Date', 'seekers' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_date_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'seekers' ),
							),
							array(
								'id'       => 'mts_meta_info_date_divider_' . $unique_id,
								'type'     => 'text',
								'class'    => 'small-text',
								'title'    => esc_html__( 'Divider', 'seekers' ),
								'sub_desc' => esc_html__( 'Use any divider, ex: "-" "/" "|" "." ">"', 'seekers' ),
							),
							array(
								'id'     => 'mts_meta_info_date_margin_' . $unique_id,
								'type'   => 'margin',
								'title'  => esc_html__( 'Margin', 'seekers' ),
								'top'    => false,
								'bottom' => false,
								'std'    => array(
									'left'  => '0',
									'right' => '0',
								),
							),
						),
					),
				),
				'disabled' => array(
					'category' => array(
						'label'     => esc_html__( 'Categories', 'seekers' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_category_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'seekers' ),
							),
							array(
								'id'       => 'mts_meta_info_category_divider_' . $unique_id,
								'type'     => 'text',
								'class'    => 'small-text',
								'title'    => esc_html__( 'Divider', 'seekers' ),
								'sub_desc' => esc_html__( 'Use any divider, ex: "-" "/" "|" "." ">"', 'seekers' ),
							),
							array(
								'id'     => 'mts_meta_info_category_margin_' . $unique_id,
								'type'   => 'margin',
								'title'  => esc_html__( 'Margin', 'seekers' ),
								'top'    => false,
								'bottom' => false,
								'std'    => array(
									'left'  => '0',
									'right' => '0',
								),
							),
						),
					),
					'comment'  => array(
						'label'     => esc_html__( 'Comment Count', 'seekers' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_comment_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'seekers' ),
							),
							array(
								'id'       => 'mts_meta_info_comment_divider_' . $unique_id,
								'type'     => 'text',
								'class'    => 'small-text',
								'title'    => esc_html__( 'Divider', 'seekers' ),
								'sub_desc' => esc_html__( 'Use any divider, ex: "-" "/" "|" "." ">"', 'seekers' ),
							),
							array(
								'id'     => 'mts_meta_info_comment_margin_' . $unique_id,
								'type'   => 'margin',
								'title'  => esc_html__( 'Margin', 'seekers' ),
								'top'    => false,
								'bottom' => false,
								'std'    => array(
									'left'  => '0',
									'right' => '0',
								),
							),
						),
					),
				),
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'seekers' ),
			'sub_desc' => esc_html__( 'Post Meta Info margin.', 'seekers' ),
			'std'      => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '20px',
				'left'   => '0',
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'seekers' ),
			'sub_desc' => esc_html__( 'Post Meta Info padding.', 'seekers' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_meta_info_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Meta Info Typography', 'seekers' ),
			'std'   => array(
				'preview-text'   => 'Post Meta Info Font',
				'preview-color'  => 'light',
				'font-family'    => 'Karla',
				'font-weight'    => '700',
				'font-size'      => '14px',
				'color'          => '#222222',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .post-info, .layout-' . $unique_id . ' .latestPost .post-info a',
			),
		) : null,
		// Post Container.
		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'seekers' ),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'readmore_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Enable/Disable Read More', 'seekers' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide readmore.', 'seekers' ),
			'std'      => '0',
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'seekers' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'seekers' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'seekers' ),
			'sub_desc' => esc_html__( 'Select border', 'seekers' ),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'seekers' ),
			'sub_desc' => esc_html__( 'Post margin.', 'seekers' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '0',
				'bottom' => '35px',
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'seekers' ),
			'sub_desc' => esc_html__( 'Post padding.', 'seekers' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_featured_category_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'seekers' ),
			'std'   => array(
				'preview-text'  => 'Post Font',
				'preview-color' => 'light',
				'font-family'   => 'Karla',
				'font-weight'   => '700',
				'font-size'     => '32px',
				'color'         => '#2e4257',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_featured_category_excerpt_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Excerpt Font', 'seekers' ),
			'std'   => array(
				'preview-text'  => 'Post Font',
				'preview-color' => 'light',
				'font-family'   => 'Karla',
				'font-weight'   => '400',
				'font-size'     => '21px',
				'line-height'   => '41px',
				'color'         => '#3f4770',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .front-view-content, .layout-' . $unique_id . ' .readMore a',
			),
		) : null,

		/**
		 * Layout 1.
		 *
		 * @package Seekers
		 */

		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'bigpost_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Big Post Title Padding', 'seekers' ),
			'sub_desc' => esc_html__( 'Set big post title padding from here.', 'seekers' ),
			'std'      => array(
				'top'    => '34px',
				'right'  => '35px',
				'bottom' => '30px',
				'left'   => '35px',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'search_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Search Section Settings', 'seekers' ),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'search_form_background_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Search Form Background Color', 'seekers' ),
			'sub_desc' => esc_html__( 'Select background color for your search form.', 'seekers' ),
			'std'      => '#eff5f6',
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'search_cats_' . $unique_id,
			'type'     => 'select',
			'data'     => 'category',
			'multiple' => true,
			'title'    => esc_html__( 'Category(s) to show', 'seekers' ),
			'sub_desc' => esc_html__( 'Select categories to show below search form', 'seekers' ),
			'args'     => array(
				'hide_empty' => 0,
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'search_cat_background_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Category(s) Background Color', 'seekers' ),
			'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'seekers' ),
			'std'      => '#3f4770',
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'search_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'seekers' ),
			'sub_desc' => esc_html__( 'Set search form padding from here.', 'seekers' ),
			'std'      => array(
				'top'    => '48px',
				'right'  => '52px',
				'bottom' => '230px',
				'left'   => '73px',
			),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'search_grid_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Grid Section Settings', 'seekers' ),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'search_grid_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Posts Section Background Color', 'seekers' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'seekers' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'search_grid_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'seekers' ),
			'sub_desc' => esc_html__( 'Set grid title margin from here.', 'seekers' ),
			'std'      => array(
				'top'    => '-197px',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'search_grid_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'seekers' ),
			'sub_desc' => esc_html__( 'Set grid title padding from here.', 'seekers' ),
			'std'      => array(
				'top'    => '48px',
				'right'  => '52px',
				'bottom' => '40px',
				'left'   => '73px',
			),
		) : null,

		// Section Title.
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'seekers' ),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'seekers' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'seekers' ),
			'std'      => '0',
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'seekers' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'seekers' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'seekers' ),
				'center' => esc_html__( 'Center', 'seekers' ),
				'right'  => esc_html__( 'Right', 'seekers' ),
				'full'   => esc_html__( 'Full Width', 'seekers' ),
			),
			'std'        => 'left',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'seekers' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'seekers' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '#ffffff',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'post_title_shadow' . $unique_id,
			'type'       => 'switch',
			'title'      => esc_html__( 'Box Shadow', 'seekers' ),
			'sub_desc'   => esc_html__( 'Use this button to show or hide box shadow in post container.', 'seekers' ),
			'std'        => '1',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'seekers' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'seekers' ),
			'std'        => array(
				'top'    => '-210px',
				'right'  => '0',
				'bottom' => '180px',
				'left'   => '52px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'seekers' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'seekers' ),
			'std'        => array(
				'top'    => '18px',
				'right'  => '40px',
				'bottom' => '18px',
				'left'   => '40px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'seekers' ),
			'sub_desc'   => esc_html__( 'Select border', 'seekers' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'seekers' ),
			'std'        => array(
				'preview-text'   => 'Title Font',
				'preview-color'  => 'light',
				'font-family'    => 'Karla',
				'font-weight'    => '400',
				'font-size'      => '32px',
				'color'          => '#3f4770',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Meta info.
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'mts_post_meta_info_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Meta Info', 'seekers' ),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_home_meta_info' . $unique_id,
			'type'     => 'multi_checkbox',
			'title'    => esc_html__( 'Post Meta Info', 'seekers' ),
			'sub_desc' => esc_html__( 'Show or hide post meta info.', 'seekers' ),
			'options'  => array(
				'author'   => esc_html__( 'Author Name', 'seekers' ),
				'comment'  => esc_html__( 'Comments', 'seekers' ),
				'time'     => esc_html__( 'Time/Date', 'seekers' ),
				'category' => esc_html__( 'Category', 'seekers' ),
			),
			'std'      => array(
				'category',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'l14_cat_background_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Category Background Color', 'seekers' ),
			'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'seekers' ),
			'std'      => seekers_get_settings( 'mts_color_scheme' ),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'bigpost_background_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Big Post Title Background Color', 'seekers' ),
			'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'seekers' ),
			'std'      => seekers_get_settings( 'mts_color_scheme' ),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'big_l14_cat_background_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Big Post Category Background Color', 'seekers' ),
			'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'seekers' ),
			'std'      => '#3f4770',
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'seekers' ),
			'sub_desc' => esc_html__( 'Post Meta Info margin.', 'seekers' ),
			'std'      => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '20px',
				'left'   => '0',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'seekers' ),
			'sub_desc' => esc_html__( 'Post Meta Info padding.', 'seekers' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'l14_bigpost_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Big Post Meta Info Typography', 'seekers' ),
			'std'   => array(
				'preview-text'  => 'Big Post Meta Info Font',
				'preview-color' => 'dark',
				'font-family'   => 'Karla',
				'font-weight'   => '400',
				'font-size'     => '18px',
				'color'         => '#ffffff',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost.big .post-info, .layout-' . $unique_id . ' .latestPost.big .post-info a',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'mts_meta_info_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Meta Info Typography', 'seekers' ),
			'std'   => array(
				'preview-text'   => 'Post Meta Info Font',
				'preview-color'  => 'light',
				'font-family'    => 'Karla',
				'font-weight'    => '700',
				'font-size'      => '15px',
				'color'          => '#2e4257',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .post-info, .layout-' . $unique_id . ' .latestPost .post-info a',
			),
		) : null,

		// Post Container.
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'seekers' ),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'seekers' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'seekers' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'seekers' ),
			'sub_desc' => esc_html__( 'Select border', 'seekers' ),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'seekers' ),
			'sub_desc' => esc_html__( 'Post margin.', 'seekers' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '0',
				'bottom' => '0',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'seekers' ),
			'sub_desc' => esc_html__( 'Post padding.', 'seekers' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'mts_featured_category_bigpost_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Big Post Title Font', 'seekers' ),
			'std'   => array(
				'preview-text'  => 'Big Post Font',
				'preview-color' => 'light',
				'font-family'   => 'Karla',
				'font-weight'   => '700',
				'font-size'     => '40px',
				'line-height'   => '44px',
				'color'         => '#2e4257',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost.big .title a',
			),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'mts_featured_category_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'seekers' ),
			'std'   => array(
				'preview-text'  => 'Post Font',
				'preview-color' => 'light',
				'font-family'   => 'Karla',
				'font-weight'   => '700',
				'font-size'     => '24px',
				'line-height'   => '28px',
				'color'         => '#2e4257',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		) : null,

		/**
		 * Layout 2.
		 *
		 * @package Seekers
		 */

		// Section Title.
		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'seekers' ),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'seekers' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'seekers' ),
			'std'      => '1',
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'seekers' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'seekers' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'seekers' ),
				'center' => esc_html__( 'Center', 'seekers' ),
				'right'  => esc_html__( 'Right', 'seekers' ),
				'full'   => esc_html__( 'Full Width', 'seekers' ),
			),
			'std'        => 'left',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'seekers' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'seekers' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '#ffffff',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'post_title_shadow' . $unique_id,
			'type'       => 'switch',
			'title'      => esc_html__( 'Box Shadow', 'seekers' ),
			'sub_desc'   => esc_html__( 'Use this button to show or hide box shadow in post container.', 'seekers' ),
			'std'        => '1',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'seekers' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'seekers' ),
			'std'        => array(
				'top'    => '-42px',
				'right'  => '0',
				'bottom' => '35px',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'seekers' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'seekers' ),
			'std'        => array(
				'top'    => '23px',
				'right'  => '41px',
				'bottom' => '15px',
				'left'   => '41px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'seekers' ),
			'sub_desc'   => esc_html__( 'Select border', 'seekers' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'seekers' ),
			'std'        => array(
				'preview-text'   => 'Title Font',
				'preview-color'  => 'light',
				'font-family'    => 'Karla',
				'font-weight'    => '400',
				'font-size'      => '32px',
				'color'          => '#3f4770',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Meta info.
		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'mts_post_meta_info_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Meta Info', 'seekers' ),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'mts_home_meta_info' . $unique_id,
			'type'     => 'multi_checkbox',
			'title'    => esc_html__( 'Post Meta Info', 'seekers' ),
			'sub_desc' => esc_html__( 'Show or hide post meta info.', 'seekers' ),
			'options'  => array(
				'author'   => esc_html__( 'Author Name', 'seekers' ),
				'comment'  => esc_html__( 'Comments', 'seekers' ),
				'time'     => esc_html__( 'Time/Date', 'seekers' ),
				'category' => esc_html__( 'Category', 'seekers' ),
			),
			'std'      => array(
				'category',
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'l14_cat_background_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Category Background Color', 'seekers' ),
			'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'seekers' ),
			'std'      => seekers_get_settings( 'mts_color_scheme' ),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'l15_cat_text_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Category Text Color', 'seekers' ),
			'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'seekers' ),
			'std'      => '#3f4770',
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'seekers' ),
			'sub_desc' => esc_html__( 'Post Meta Info margin.', 'seekers' ),
			'std'      => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '20px',
				'left'   => '0',
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'seekers' ),
			'sub_desc' => esc_html__( 'Post Meta Info padding.', 'seekers' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'mts_meta_info_bigpost_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Big Post Meta Info Typography', 'seekers' ),
			'std'   => array(
				'preview-text'   => 'Big Post Meta Info Font',
				'preview-color'  => 'dark',
				'font-family'    => 'Karla',
				'font-weight'    => '700',
				'font-size'      => '15px',
				'color'          => '#2e4257',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost.big .post-info, .layout-' . $unique_id . ' .latestPost.big .post-info a',
			),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'mts_meta_info_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Meta Info Typography', 'seekers' ),
			'std'   => array(
				'preview-text'   => 'Post Meta Info Font',
				'preview-color'  => 'light',
				'font-family'    => 'Karla',
				'font-weight'    => '700',
				'font-size'      => '15px',
				'color'          => '#2e4257',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .post-info, .layout-' . $unique_id . ' .latestPost .post-info a',
			),
		) : null,

		// Post Container.
		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'seekers' ),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'seekers' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'seekers' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '#eff5f6',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'layout_backround_position_' . $unique_id,
			'type'     => 'text',
			'class'    => 'small-text',
			'title'    => esc_html__( 'Background Position from Top', 'seekers' ),
			'sub_desc' => esc_html__( 'Enter background position from top in px.', 'seekers' ),
			'std'      => '0',
			'args'     => array( 'type' => 'number' ),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'seekers' ),
			'sub_desc' => esc_html__( 'Select border', 'seekers' ),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'seekers' ),
			'sub_desc' => esc_html__( 'Post margin.', 'seekers' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '125px',
				'bottom' => '35px',
			),
		) : null,
		( 'layout-2' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'seekers' ),
			'sub_desc' => esc_html__( 'Post padding.', 'seekers' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'mts_featured_category_bigpost_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Big Post Title Font', 'seekers' ),
			'std'   => array(
				'preview-text'  => 'Big Post Font',
				'preview-color' => 'light',
				'font-family'   => 'Karla',
				'font-weight'   => '700',
				'font-size'     => '32px',
				'color'         => '#2e4257',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost.big .title a',
			),
		) : null,

		( 'layout-2' === $posts_layout ) ? array(
			'id'    => 'mts_featured_category_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'seekers' ),
			'std'   => array(
				'preview-text'  => 'Post Font',
				'preview-color' => 'light',
				'font-family'   => 'Karla',
				'font-weight'   => '700',
				'font-size'     => '24px',
				'line-height'   => '1.2',
				'color'         => '#2e4257',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost.small .title a',
			),
		) : null,

		/**
		 * Layout 3.
		 *
		 * @package Seekers
		 */

		// Section Title.
		( 'layout-3' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'seekers' ),
		) : null,

		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'seekers' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'seekers' ),
			'std'      => '0',
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'seekers' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'seekers' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'seekers' ),
				'center' => esc_html__( 'Center', 'seekers' ),
				'right'  => esc_html__( 'Right', 'seekers' ),
				'full'   => esc_html__( 'Full Width', 'seekers' ),
			),
			'std'        => 'left',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'seekers' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'seekers' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '#ffffff',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'         => 'post_title_shadow' . $unique_id,
			'type'       => 'switch',
			'title'      => esc_html__( 'Box Shadow', 'seekers' ),
			'sub_desc'   => esc_html__( 'Use this button to show or hide box shadow in post container.', 'seekers' ),
			'std'        => '1',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'seekers' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'seekers' ),
			'std'        => array(
				'top'    => '-42px',
				'right'  => '0',
				'bottom' => '35px',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'seekers' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'seekers' ),
			'std'        => array(
				'top'    => '18px',
				'right'  => '40px',
				'bottom' => '18px',
				'left'   => '40px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'seekers' ),
			'sub_desc'   => esc_html__( 'Select border', 'seekers' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-3' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'seekers' ),
			'std'        => array(
				'preview-text'   => 'Title Font',
				'preview-color'  => 'light',
				'font-family'    => 'Karla',
				'font-weight'    => '400',
				'font-size'      => '32px',
				'color'          => '#3f4770',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Meta info.
		( 'layout-3' === $posts_layout ) ? array(
			'id'    => 'mts_post_meta_info_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Meta Info', 'seekers' ),
		) : null,

		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'mts_home_meta_info' . $unique_id,
			'type'     => 'multi_checkbox',
			'title'    => esc_html__( 'Post Meta Info', 'seekers' ),
			'sub_desc' => esc_html__( 'Show or hide post meta info.', 'seekers' ),
			'options'  => array(
				'author'   => esc_html__( 'Author Name', 'seekers' ),
				'comment'  => esc_html__( 'Comments', 'seekers' ),
				'time'     => esc_html__( 'Time/Date', 'seekers' ),
				'category' => esc_html__( 'Category', 'seekers' ),
			),
			'std'      => array(
				'category',
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'l14_cat_background_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Category Background Color', 'seekers' ),
			'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'seekers' ),
			'std'      => seekers_get_settings( 'mts_color_scheme' ),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'l15_cat_text_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Category Text Color', 'seekers' ),
			'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'seekers' ),
			'std'      => '#3f4770',
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'seekers' ),
			'sub_desc' => esc_html__( 'Post Meta Info margin.', 'seekers' ),
			'std'      => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '20px',
				'left'   => '0',
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'seekers' ),
			'sub_desc' => esc_html__( 'Post Meta Info padding.', 'seekers' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'layout-3' === $posts_layout ) ? array(
			'id'    => 'mts_meta_info_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Meta Info Typography', 'seekers' ),
			'std'   => array(
				'preview-text'   => 'Post Meta Info Font',
				'preview-color'  => 'light',
				'font-family'    => 'Karla',
				'font-weight'    => '700',
				'font-size'      => '15px',
				'color'          => '#2e4257',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .post-info, .layout-' . $unique_id . ' .latestPost .post-info a',
			),
		) : null,

		// Post Container.
		( 'layout-3' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'seekers' ),
		) : null,

		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'seekers' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'seekers' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '#eff5f6',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'layout_backround_position_' . $unique_id,
			'type'     => 'text',
			'class'    => 'small-text',
			'title'    => esc_html__( 'Background Position from Top', 'seekers' ),
			'sub_desc' => esc_html__( 'Enter background position from top in px.', 'seekers' ),
			'std'      => '-64',
			'args'     => array( 'type' => 'number' ),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'seekers' ),
			'sub_desc' => esc_html__( 'Select border', 'seekers' ),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'seekers' ),
			'sub_desc' => esc_html__( 'Post margin.', 'seekers' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '96px',
				'bottom' => '35px',
			),
		) : null,
		( 'layout-3' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'seekers' ),
			'sub_desc' => esc_html__( 'Post padding.', 'seekers' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'layout-3' === $posts_layout ) ? array(
			'id'    => 'mts_featured_category_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'seekers' ),
			'std'   => array(
				'preview-text'  => 'Post Font',
				'preview-color' => 'light',
				'font-family'   => 'Karla',
				'font-weight'   => '700',
				'font-size'     => '24px',
				'line-height'   => '1.2',
				'color'         => '#2e4257',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		) : null,

		/**
		 * Layout Partners.
		 *
		 * @package Seekers
		 */

		( 'layout-partners' === $posts_layout ) ? array(
			'id'        => 'partners_section_' . $unique_id,
			'type'      => 'group',
			'title'     => esc_html__( 'Partners Items', 'seekers' ),
			'groupname' => esc_html__( 'Partner Item', 'seekers' ),
			'subfields' => array(
				array(
					'id'    => 'partner_title',
					'type'  => 'text',
					'title' => esc_html__( 'Title', 'seekers' ),
				),
				array(
					'id'       => 'partner_image',
					'type'     => 'upload',
					'title'    => esc_html__( 'Image', 'seekers' ),
					'sub_desc' => esc_html__( 'Upload or select an image for partner. Recommended Size(190X70px)', 'seekers' ),
				),
				array(
					'id'       => 'partner_url',
					'type'     => 'text',
					'title'    => esc_html__( 'Link', 'seekers' ),
					'sub_desc' => esc_html__( 'Insert a link URL of partner', 'seekers' ),
					'std'      => '#',
				),
			),
		) : null,

		// Section Title.
		( 'layout-partners' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'seekers' ),
		) : null,

		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'seekers' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'seekers' ),
			'std'      => '1',
		) : null,

		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'partner_section_title_' . $unique_id,
			'type'       => 'text',
			'title'      => esc_html__( 'Section Title', 'seekers' ),
			'sub_desc'   => esc_html__( 'Partners section title.', 'seekers' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'partners_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Partners Title Font', 'seekers' ),
			'std'        => array(
				'preview-text'   => 'Partners Title Font',
				'preview-color'  => 'dark',
				'font-family'    => 'Karla',
				'font-weight'    => '400',
				'font-size'      => '16px',
				'line-height'    => '19px',
				'color'          => '#03c96a',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.article.layout-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'seekers' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'seekers' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'seekers' ),
				'center' => esc_html__( 'Center', 'seekers' ),
				'right'  => esc_html__( 'Right', 'seekers' ),
				'full'   => esc_html__( 'Full Width', 'seekers' ),
			),
			'std'        => 'full',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'seekers' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'seekers' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '#ffffff',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'post_title_shadow' . $unique_id,
			'type'       => 'switch',
			'title'      => esc_html__( 'Box Shadow', 'seekers' ),
			'sub_desc'   => esc_html__( 'Use this button to show or hide box shadow in post container.', 'seekers' ),
			'std'        => '1',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'seekers' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'seekers' ),
			'left'       => false,
			'right'      => false,
			'std'        => array(
				'top'    => '0',
				'bottom' => '-80px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'seekers' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'seekers' ),
			'std'        => array(
				'left'   => '40px',
				'top'    => '40px',
				'right'  => '40px',
				'bottom' => '40px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'seekers' ),
			'sub_desc'   => esc_html__( 'Select border', 'seekers' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Post Container.
		( 'layout-partners' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'seekers' ),
		) : null,

		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'seekers' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'seekers' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'seekers' ),
			'sub_desc' => esc_html__( 'Select border', 'seekers' ),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'seekers' ),
			'sub_desc' => esc_html__( 'Post margin.', 'seekers' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '0',
				'bottom' => '35px',
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'seekers' ),
			'sub_desc' => esc_html__( 'Post padding.', 'seekers' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		/**
		 * Layout Category.
		 *
		 * @package Seekers
		 */

		( 'layout-category' === $posts_layout ) ? array(
			'id'        => 'cat_section_' . $unique_id,
			'type'      => 'group',
			'title'     => esc_html__( 'Category items', 'seekers' ),
			'sub_desc'  => esc_html__( 'Add category Item from here', 'seekers' ),
			'groupname' => esc_html__( 'Category item', 'seekers' ),
			'subfields' => array(
				array(
					'id'    => 'cat_section_title',
					'type'  => 'text',
					'title' => esc_html__( 'Title', 'seekers' ),
				),
				array(
					'id'       => 'cat_section_category',
					'type'     => 'select',
					'title'    => esc_html__( 'Category', 'seekers' ),
					'sub_desc' => esc_html__( 'Select a category for this section', 'seekers' ),
					'data'     => 'category',
				),
				array(
					'id'       => 'cat_section_image',
					'type'     => 'upload',
					'title'    => esc_html__( 'Image', 'seekers' ),
					'sub_desc' => esc_html__( 'Upload or select an image for category. Recommended Size(365X287px)', 'seekers' ),
				),
				array(
					'id'    => 'cat_section_background',
					'type'  => 'color',
					'title' => esc_html__( 'Select overlay color for your category', 'seekers' ),
					'args'  => array( 'opacity' => true ),
					'std'   => 'rgba(0, 0, 0, 0.3)',
				),
				array(
					'id'    => 'cat_section_hover_background',
					'type'  => 'color',
					'title' => esc_html__( 'Select overlay hover color for your category', 'seekers' ),
					'args'  => array( 'opacity' => true ),
					'std'   => 'rgba(0, 0, 0, 0.6)',
				),
			),
		) : null,

		// Post Container.
		( 'layout-category' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'seekers' ),
		) : null,

		( 'layout-category' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'seekers' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'seekers' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-category' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'seekers' ),
			'sub_desc' => esc_html__( 'Select border', 'seekers' ),
		) : null,
		( 'layout-category' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'seekers' ),
			'sub_desc' => esc_html__( 'Post margin.', 'seekers' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '0',
				'bottom' => '35px',
			),
		) : null,
		( 'layout-category' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'seekers' ),
			'sub_desc' => esc_html__( 'Post padding.', 'seekers' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		/**
		 * Layout Subscribe.
		 *
		 * @package Seekers
		 */

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_size_' . $unique_id,
			'type'     => 'button_set',
			'title'    => esc_html__( 'Section Size', 'seekers' ),
			'sub_desc' => esc_html__( 'Select the size of subscribe widget.', 'seekers' ),
			'options'  => array(
				'full'      => esc_html__( 'Full', 'seekers' ),
				'container' => esc_html__( 'Container', 'seekers' ),
			),
			'std'      => 'full',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_alignment_' . $unique_id,
			'type'     => 'button_set',
			'title'    => esc_html__( 'Alignment', 'seekers' ),
			'sub_desc' => esc_html__( 'Alignment of subscribe widget content', 'seekers' ),
			'options'  => array(
				'left'   => esc_html__( 'Left', 'seekers' ),
				'center' => esc_html__( 'Center', 'seekers' ),
				'right'  => esc_html__( 'Right', 'seekers' ),
			),
			'std'      => 'center',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Title Typography', 'seekers' ),
			'std'   => array(
				'preview-text'  => 'Title Font',
				'preview-color' => 'dark',
				'font-family'   => 'Karla',
				'font-weight'   => '700',
				'font-size'     => '40px',
				'color'         => '#ffffff',
				'css-selectors' => '.layout-' . $unique_id . ' .widget #wp-subscribe .title, .layout-' . $unique_id . ' .layout-subscribe .left-content h4',
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_input_background_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Input Fields Background Color', 'seekers' ),
			'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'seekers' ),
			'std'      => '#ffffff',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_input_size_' . $unique_id,
			'type'     => 'button_set',
			'title'    => esc_html__( 'Input Field Size', 'seekers' ),
			'sub_desc' => esc_html__( 'Select the size of input fields.', 'seekers' ),
			'options'  => array(
				'large' => esc_html__( 'Large', 'seekers' ),
				'small' => esc_html__( 'Small', 'seekers' ),
			),
			'std'      => 'large',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_input_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Input Fields Typography', 'seekers' ),
			'std'   => array(
				'preview-text'  => 'Input Fields Font',
				'preview-color' => 'dark',
				'font-family'   => 'Karla',
				'font-weight'   => '700',
				'font-size'     => '18px',
				'color'         => '#2e4257',
				'css-selectors' => '.layout-' . $unique_id . ' .layout-subscribe #wp-subscribe input.email-field, .layout-' . $unique_id . ' .layout-subscribe #wp-subscribe input.name-field',
			),
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_text_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Text Typography', 'seekers' ),
			'std'   => array(
				'preview-text'  => 'Text Font',
				'preview-color' => 'dark',
				'font-family'   => 'Karla',
				'font-weight'   => '700',
				'font-size'     => '20px',
				'color'         => '#ffffff',
				'css-selectors' => '.layout-' . $unique_id . ' .layout-subscribe #wp-subscribe p.text, .layout-' . $unique_id . ' .subscribe-icons-container p, .layout-' . $unique_id . ' .layout-subscribe .left-content p',
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_small_text_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Small Text Typography', 'seekers' ),
			'std'   => array(
				'preview-text'  => 'Text Font',
				'preview-color' => 'dark',
				'font-family'   => 'Karla',
				'font-weight'   => '400',
				'font-size'     => '13px',
				'color'         => '#ffffff',
				'css-selectors' => '.layout-' . $unique_id . ' .layout-subscribe .wp-subscribe-wrap p.footer-text, .layout-' . $unique_id . ' .layout-subscribe .widget .wp-subscribe .wps-consent-wrapper',
			),
		) : null,

		// Left Content.
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_left_content_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Subscribe Left Content', 'seekers' ),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_left_content_logo_' . $unique_id,
			'type'     => 'upload',
			'title'    => esc_html__( 'Left Content Logo', 'seekers' ),
			'sub_desc' => esc_html__( 'Select an image file for left content logo.', 'seekers' ),
			'return'   => 'url',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_left_content_title_' . $unique_id,
			'type'  => 'text',
			'title' => esc_html__( 'Left Content Title', 'seekers' ),
			'std'   => 'Know where to go!',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_left_content_text_' . $unique_id,
			'type'  => 'textarea',
			'title' => esc_html__( 'Left Content Text', 'seekers' ),
			'std'   => 'Sign up for our daily tips to make your best vacation.',
		) : null,

		// Social Icons.
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_icon_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Subscribe Social Icons', 'seekers' ),
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_social_icons_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Subscribe Social Icons', 'seekers' ),
			'sub_desc' => esc_html__( 'Enable or disable subscribe social icons with this option.', 'seekers' ),
			'std'      => '1',
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'         => 'subscribe_icon_title_' . $unique_id,
			'type'       => 'text',
			'title'      => esc_html__( 'Title', 'seekers' ),
			'sub_desc'   => esc_html__( 'Subscribe icon title.', 'seekers' ),
			'std'        => 'Follow Us',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'subscribe_social_icons_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'         => 'subscribe_social_' . $unique_id,
			'title'      => esc_html__( 'Footer Social Icons', 'seekers' ),
			'sub_desc'   => esc_html__( 'Add Social Media icons in footer nav section.', 'seekers' ),
			'type'       => 'group',
			'groupname'  => esc_html__( 'Social Icons', 'seekers' ), // Group name.
			'subfields'  => array(
				array(
					'id'    => 'subscribe_social_title',
					'type'  => 'text',
					'title' => esc_html__( 'Title', 'seekers' ),
				),
				array(
					'id'    => 'subscribe_social_icon',
					'type'  => 'icon_select',
					'title' => esc_html__( 'Icon', 'seekers' ),
				),
				array(
					'id'    => 'subscribe_social_link',
					'type'  => 'text',
					'title' => esc_html__( 'URL', 'seekers' ),
				),
				array(
					'id'    => 'subscribe_social_color',
					'type'  => 'color',
					'title' => esc_html__( 'Icon color', 'seekers' ),
				),
				array(
					'id'    => 'subscribe_social_hover_color',
					'type'  => 'color',
					'title' => esc_html__( 'Icon hover color', 'seekers' ),
				),
				array(
					'id'    => 'subscribe_social_margin',
					'type'  => 'margin',
					'title' => esc_html__( 'Margin', 'seekers' ),
				),
				array(
					'id'    => 'subscribe_social_padding',
					'type'  => 'margin',
					'title' => esc_html__( 'Padding', 'seekers' ),
				),
			),
			'std'        => array(
				'facebook'  => array(
					'group_title'                  => 'Facebook',
					'group_sort'                   => '1',
					'subscribe_social_title'       => 'Facebook',
					'subscribe_social_icon'        => 'facebook-square',
					'subscribe_social_link'        => '#',
					'subscribe_social_color'       => '#ffffff',
					'subscribe_social_hover_color' => seekers_get_settings( 'mts_color_scheme' ),
					'subscribe_social_margin'      => array(
						'top'    => '0',
						'right'  => '22px',
						'bottom' => '0',
						'left'   => '0',
					),
					'subscribe_social_padding'     => array(
						'top'    => '0',
						'right'  => '0',
						'bottom' => '0',
						'left'   => '0',
					),
				),
				'youtube'   => array(
					'group_title'                  => 'Youtube',
					'group_sort'                   => '1',
					'subscribe_social_title'       => 'Youtube',
					'subscribe_social_icon'        => 'youtube',
					'subscribe_social_link'        => '#',
					'subscribe_social_color'       => '#ffffff',
					'subscribe_social_hover_color' => seekers_get_settings( 'mts_color_scheme' ),
					'subscribe_social_margin'      => array(
						'top'    => '0',
						'right'  => '22px',
						'bottom' => '0',
						'left'   => '0',
					),
					'subscribe_social_padding'     => array(
						'top'    => '0',
						'right'  => '0',
						'bottom' => '0',
						'left'   => '0',
					),
				),
				'twitter'   => array(
					'group_title'                  => 'Twitter',
					'group_sort'                   => '3',
					'subscribe_social_title'       => 'Twitter',
					'subscribe_social_icon'        => 'twitter',
					'subscribe_social_link'        => '#',
					'subscribe_social_color'       => '#ffffff',
					'subscribe_social_hover_color' => seekers_get_settings( 'mts_color_scheme' ),
					'subscribe_social_margin'      => array(
						'top'    => '0',
						'right'  => '22px',
						'bottom' => '0',
						'left'   => '0',
					),
					'subscribe_social_padding'     => array(
						'top'    => '0',
						'right'  => '0',
						'bottom' => '0',
						'left'   => '0',
					),
				),
				'pinterest' => array(
					'group_title'                  => 'Pinterest',
					'group_sort'                   => '4',
					'subscribe_social_title'       => 'Pinterest',
					'subscribe_social_icon'        => 'pinterest',
					'subscribe_social_link'        => '#',
					'subscribe_social_color'       => '#ffffff',
					'subscribe_social_hover_color' => seekers_get_settings( 'mts_color_scheme' ),
					'subscribe_social_margin'      => array(
						'top'    => '0',
						'right'  => '22px',
						'bottom' => '0',
						'left'   => '0',
					),
					'subscribe_social_padding'     => array(
						'top'    => '0',
						'right'  => '0',
						'bottom' => '0',
						'left'   => '0',
					),
				),
				'instagram' => array(
					'group_title'                  => 'Instagram',
					'group_sort'                   => '5',
					'subscribe_social_title'       => 'Instagram',
					'subscribe_social_icon'        => 'instagram',
					'subscribe_social_link'        => '#',
					'subscribe_social_color'       => '#ffffff',
					'subscribe_social_hover_color' => seekers_get_settings( 'mts_color_scheme' ),
					'subscribe_social_margin'      => array(
						'top'    => '0',
						'right'  => '0',
						'bottom' => '0',
						'left'   => '0',
					),
					'subscribe_social_padding'     => array(
						'top'    => '0',
						'right'  => '0',
						'bottom' => '0',
						'left'   => '0',
					),
				),
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'subscribe_social_icons_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Post Container.
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'seekers' ),
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'seekers' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'seekers' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '#2e4257',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'seekers' ),
			'sub_desc' => esc_html__( 'Select border', 'seekers' ),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'seekers' ),
			'sub_desc' => esc_html__( 'Post margin.', 'seekers' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '0',
				'bottom' => '0',
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'seekers' ),
			'sub_desc' => esc_html__( 'Post padding.', 'seekers' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '35px',
				'right'  => '0',
				'bottom' => '15px',
			),
		) : null,

		/**
		 * Layout Ad.
		 *
		 * @package Seekers
		 */

		( 'layout-ad' === $posts_layout ) ? array(
			'id'       => 'adcode_' . $unique_id,
			'type'     => 'ace_editor',
			'mode'     => 'html',
			'title'    => esc_html__( 'Ad Code', 'seekers' ),
			'sub_desc' => esc_html__( 'Paste your Adsense, BSA or other ad code here to show ads.', 'seekers' ),
		) : null,

		// Post Container.
		( 'layout-ad' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'seekers' ),
		) : null,

		( 'layout-ad' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'seekers' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'seekers' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-ad' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'seekers' ),
			'sub_desc' => esc_html__( 'Select border', 'seekers' ),
		) : null,
		( 'layout-ad' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'seekers' ),
			'sub_desc' => esc_html__( 'Post margin.', 'seekers' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '0',
				'bottom' => '35px',
			),
		) : null,
		( 'layout-ad' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'seekers' ),
			'sub_desc' => esc_html__( 'Post padding.', 'seekers' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

	);
endforeach;
