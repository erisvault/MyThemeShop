<?php
/**
 * Header Tab
 *
 * @package Seekers
 */

$menus['header'] = array(
	'icon'  => 'fa-header',
	'title' => esc_html__( 'Header', 'seekers' ),
);

$menus['header']['child']['header-general'] = array(
	'title' => esc_html__( 'General', 'seekers' ),
	'desc'  => esc_html__( 'From here, you can control the elements of header section.', 'seekers' ),
);

$sections['header-general'] = array(

	array(
		'id'       => 'mts_header_style',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Header Styling', 'seekers' ),
		'sub_desc' => wp_kses( __( 'Choose the <strong>Header design</strong> for your site.', 'seekers' ), array( 'strong' => '' ) ),
		'options'  => array(
			'regular_header'     => array( 'img' => $uri . 'headers/h1.jpg' ),
			'logo_in_nav_header' => array( 'img' => $uri . 'headers/h2.jpg' ),
			'5'                  => array( 'img' => $uri . 'headers/h5.jpg' ),
		),
		'std'      => '5',
	),

	array(
		'id'       => 'mts_sticky_nav',
		'type'     => 'switch',
		'title'    => esc_html__( 'Floating Navigation Menu', 'seekers' ),
		// translators: Floating Navigation Menu with strong tag.
		'sub_desc' => sprintf( esc_html__( 'Use this button to enable %s.', 'seekers' ), '<strong>' . esc_html__( 'Floating Navigation Menu', 'seekers' ) . '</strong>' ),
		'std'      => '0',
	),

	array(
		'id'       => 'mts_header_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Header Margin', 'seekers' ),
		'sub_desc' => esc_html__( 'Set header margin from here.', 'seekers' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '0',
		),
	),
	array(
		'id'       => 'mts_header_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Header Padding', 'seekers' ),
		'sub_desc' => esc_html__( 'Set header padding from here.', 'seekers' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '27px',
			'bottom' => '21px',
		),
	),

	array(
		'id'       => 'mts_header_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'seekers' ),
		'sub_desc' => esc_html__( 'Select border.', 'seekers' ),
	),

	array(
		'id'         => 'menu_search_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Search box Margin', 'seekers' ),
		'sub_desc'   => esc_html__( 'Set margin of search box from here.', 'seekers' ),
		'left'       => false,
		'right'      => false,
		'std'        => array(
			'top'    => '-2px',
			'bottom' => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_header_style',
				'value'      => '5',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'mts_header_search',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Header Search Form', 'seekers' ),
		'sub_desc'   => wp_kses( __( 'Use this button to Show or Hide the <strong>Header Search Form</strong> completely.', 'seekers' ), array( 'strong' => '' ) ),
		'std'        => '1',
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'mts_header_style',
				'value'      => '5',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'menu_icon_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Menu Icon Color', 'seekers' ),
		'sub_desc'   => esc_html__( 'Select header menu icon color.', 'seekers' ),
		'std'        => '#a0c2cc',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_header_style',
				'value'      => '5',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'nav_position',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Menu position from Top', 'seekers' ),
		'sub_desc'   => esc_html__( 'Set menu position from top in px.', 'seekers' ),
		'std'        => '190',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_header_style',
				'value'      => '5',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_header_section2',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Logo', 'seekers' ),
		'sub_desc' => wp_kses( __( 'Use this button to Show or Hide the <strong>Logo</strong> completely.', 'seekers' ), array( 'strong' => '' ) ),
		'std'      => '1',
	),

	array(
		'id'         => 'mts_header_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Header Background', 'seekers' ),
		'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'seekers' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'mts_header_style',
				'value'      => 'regular_header',
				'comparison' => '==',
			),
			array(
				'field'      => 'mts_header_style',
				'value'      => '5',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_main_navigation_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Main Navigation Background', 'seekers' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'seekers' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'main_navigation_dropdown_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Color', 'seekers' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'seekers' ),
		'std'      => '#3f4770',
	),
	array(
		'id'       => 'main_navigation_dropdown_hover_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Hover Color', 'seekers' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'seekers' ),
		'std'      => seekers_get_settings( 'link_color_scheme' ),
	),

);
