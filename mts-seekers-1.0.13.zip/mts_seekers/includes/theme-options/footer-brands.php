<?php
/**
 * Brands
 *
 * @package Seekers
 */

$menus['footer']['child']['footer-brands'] = array(
	'title' => esc_html__( 'Brands Section', 'seekers' ),
	'desc'  => esc_html__( 'From here, you can control the Brands Section.', 'seekers' ),
);

$sections['footer-brands'] = array(

	array(
		'id'       => 'footer_brands_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Brands Section', 'seekers' ),
		'sub_desc' => esc_html__( 'Enable or disable Brands Section with this option.', 'seekers' ),
		'std'      => '0',
	),

	array(
		'id'         => 'footer_brands_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Brands Section Alignment', 'seekers' ),
		'sub_desc'   => esc_html__( 'Choose alignment of Brands Section.', 'seekers' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'seekers' ),
			'center' => esc_html__( 'Center', 'seekers' ),
			'right'  => esc_html__( 'Right', 'seekers' ),
		),
		'std'        => 'center',
		'class'      => 'green',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'brands_section_title',
		'type'       => 'text',
		'title'      => esc_html__( 'Brands Title', 'seekers' ),
		'sub_desc'   => esc_html__( 'Enter brands title here.', 'seekers' ),
		'std'        => esc_html__( 'Our Brands:', 'seekers' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),

	),

	array(
		'id'         => 'footer_brands_items',
		'type'       => 'group',
		'title'      => esc_html__( 'Brands', 'seekers' ),
		'groupname'  => esc_html__( 'Brand', 'seekers' ), // Group name.
		'subfields'  => array(
			array(
				'id'       => 'brand_title',
				'type'     => 'text',
				'title'    => esc_html__( 'Title', 'seekers' ),
				'sub_desc' => esc_html__( 'The title will not be shown.', 'seekers' ),
			),
			array(
				'id'       => 'brand_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Image', 'seekers' ),
				'sub_desc' => esc_html__( 'Upload or select an image for brand', 'seekers' ),
			),
			array(
				'id'       => 'brand_url',
				'type'     => 'text',
				'title'    => esc_html__( 'Link', 'seekers' ),
				'sub_desc' => esc_html__( 'Insert a link URL of brand', 'seekers' ),
				'std'      => '#',
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'brands_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'seekers' ),
		'sub_desc'   => esc_html__( 'Brands Section margin.', 'seekers' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'brands_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'seekers' ),
		'sub_desc'   => esc_html__( 'Brands Section padding.', 'seekers' ),
		'std'        => array(
			'top'    => '40px',
			'right'  => '0',
			'bottom' => '27px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'brands_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'seekers' ),
		'sub_desc'   => esc_html__( 'Select border', 'seekers' ),
		'std'        => array(
			'direction' => 'top',
			'size'      => '1',
			'style'     => 'solid',
			'color'     => '#008b3e',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
);
