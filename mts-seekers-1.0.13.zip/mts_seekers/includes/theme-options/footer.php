<?php
/**
 * Footer Tab
 *
 * @package Seekers
 */

$menus['footer'] = array(
	'icon'  => 'fa-table',
	'title' => esc_html__( 'Footer', 'seekers' ),
	'desc'  => esc_html__( 'From here, you can control the elements of footer section.', 'seekers' ),
);

$menus['footer']['child']['footer-general'] = array(
	'title' => esc_html__( 'General', 'seekers' ),
	'desc'  => esc_html__( 'From here, you can control the elements of footer section.', 'seekers' ),
);

$mts_patterns = array(
	'nobg' => array( 'img' => $uri . 'bg-patterns/nobg.png' ),
);
for ( $i = 1; $i <= 29; $i++ ) {
	$mts_patterns[ 'hbg' . $i ] = array( 'img' => $uri . 'bg-patterns/hbg' . $i . '.png' );
}

$sections['footer-general'] = array(

	array(
		'id'       => 'mts_top_footer',
		'type'     => 'switch',
		'title'    => esc_html__( 'Footer', 'seekers' ),
		'sub_desc' => esc_html__( 'Enable or disable footer with this option.', 'seekers' ),
		'std'      => '0',
	),

	array(
		'id'         => 'mts_top_footer_num',
		'type'       => 'button_set',
		'class'      => 'green',
		'title'      => esc_html__( 'Footer Layout', 'seekers' ),
		'sub_desc'   => wp_kses( __( 'Choose the number of widget areas in the <strong>footer</strong>', 'seekers' ), array( 'strong' => '' ) ),
		'options'    => array(
			'1' => esc_html__( '1 Widget', 'seekers' ),
			'2' => esc_html__( '2 Widgets', 'seekers' ),
			'3' => esc_html__( '3 Widgets', 'seekers' ),
			'4' => esc_html__( '4 Widgets', 'seekers' ),
		),
		'std'        => '3',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_top_footer',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_sections_position',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Footer Sections Position', 'seekers' ),
		'sub_desc'   => esc_html__( 'Choose position of Footer Sections.', 'seekers' ),
		'options'    => array(
			'top'    => esc_html__( 'Above', 'seekers' ),
			'left'   => esc_html__( 'Left', 'seekers' ),
			'bottom' => esc_html__( 'Below', 'seekers' ),
			'right'  => esc_html__( 'Right', 'seekers' ),
		),
		'std'        => 'bottom',
		'class'      => 'green',
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_copyrights',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Copyrights Text', 'seekers' ),
		'sub_desc' => esc_html__( 'You can change or remove our link from footer and use your own custom text.', 'seekers' ) . ( MTS_THEME_WHITE_LABEL ? '' : wp_kses( __( '(You can also use your affiliate link to <strong>earn 55% of sales</strong>. Ex: <a href="https://mythemeshop.com/go/aff/aff" target="_blank">https://mythemeshop.com/?ref=username</a>)', 'seekers' ), array( 'strong' => '', 'a' => array( 'href' => array(), 'target' => array() ) ) ) ),
		// translators: Default value.
		'std'      => MTS_THEME_WHITE_LABEL ? null : sprintf( __( 'Theme by %s', 'seekers' ), '<a href="http://mythemeshop.com/" rel="nofollow">MyThemeShop</a>' ),
	),

);
