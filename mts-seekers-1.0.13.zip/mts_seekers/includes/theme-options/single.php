<?php
/**
 * Single Tab
 *
 * @package Seekers
 */

$menus['single-general'] = array(
	'title' => esc_html__( 'General', 'seekers' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of your single posts page.', 'seekers' ),
);

$sections['single-general'] = array(

	array(
		'id'       => 'mts_show_featured',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Featured image', 'seekers' ),
		'sub_desc' => esc_html__( 'Enable/Disable the Featured images in the single post.', 'seekers' ),
		'std'      => '1',
	),
	array(
		'id'       => 'featured_image_size',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Header Size', 'seekers' ),
		'sub_desc' => esc_html__( 'Choose the featured image size', 'seekers' ),
		'options'  => array(
			'default' => esc_html__( 'Content Size', 'seekers' ),
			'full'    => esc_html__( 'Full Width', 'seekers' ),
		),
		'std'      => 'full',
	),
	array(
		'id'         => 'featured_image_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Header Image Margin', 'seekers' ),
		'sub_desc'   => esc_html__( 'Set header image margin from here.', 'seekers' ),
		'std'        => array(
			'top'    => '-35px',
			'right'  => '0',
			'bottom' => '133px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'featured_text_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Alignment', 'seekers' ),
		'sub_desc'   => esc_html__( 'Choose the featured image text alignment', 'seekers' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'seekers' ),
			'center' => esc_html__( 'Center', 'seekers' ),
			'right'  => esc_html__( 'Right', 'seekers' ),
		),
		'std'        => 'left',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'author_image_on_full',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Author Image', 'seekers' ),
		'sub_desc'   => esc_html__( 'Enable or disable author image with this option', 'seekers' ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'show_prev_next',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show preview and next article buttons', 'seekers' ),
		'sub_desc'   => esc_html__( 'Use this button to show or hide preview and next article buttons.', 'seekers' ),
		'std'        => '1',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_single_post_layout',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Post Layout', 'seekers' ),
		'sub_desc' => esc_html__( 'Customize the look of single posts', 'seekers' ),
		'options'  => array(
			'enabled'  => array(
				'content'   => array(
					'label'     => esc_html__( 'Post Content', 'seekers' ),
					'subfields' => array(),
				),
				'related'   => array(
					'label'     => esc_html__( 'Related Posts', 'seekers' ),
					'subfields' => array(
						array(
							'id'       => 'related_post_title',
							'type'     => 'text',
							'title'    => esc_html__( 'Related Posts Title', 'seekers' ),
							'sub_desc' => esc_html__( 'Enter the title text to show in the related posts section.', 'seekers' ),
							'std'      => esc_html__( 'You May Also Like...', 'seekers' ),

						),
						array(
							'id'       => 'mts_related_posts_taxonomy',
							'type'     => 'switch',
							'title'    => esc_html__( 'Related Posts Taxonomy', 'seekers' ),
							'options'  => array(
								'tags'       => esc_html__( 'Tags', 'seekers' ),
								'categories' => esc_html__( 'Categories', 'seekers' ),
							),
							'class'    => 'green',
							'sub_desc' => esc_html__( 'Related Posts based on tags or categories.', 'seekers' ),
							'std'      => 'categories',
						),
					),
				),
				'author'    => array(
					'label'     => esc_html__( 'Author Box', 'seekers' ),
					'subfields' => array(),
				),
				'subscribe' => array(
					'label'     => esc_html__( 'Subscribe Box', 'seekers' ),
					'subfields' => array(),
				),
			),
			'disabled' => array(
				'tags' => array(
					'label'     => esc_html__( 'Tags', 'seekers' ),
					'subfields' => array(),
				),
			),
		),
	),

	array(
		'id'       => 'single_meta_info_background',
		'type'     => 'color',
		'title'    => esc_html__( 'Single Meta Info Background Color', 'seekers' ),
		'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'seekers' ),
		'std'      => '#3f4770',
	),

	array(
		'id'       => 'mts_single_headline_meta_info',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Meta Info', 'seekers' ),
		'sub_desc' => esc_html__( 'Organize how you want the post meta info to appear on single page', 'seekers' ),
		'options'  => array(
			'enabled'  => array(
				'author' => array(
					'label'     => esc_html__( 'Author Name', 'seekers' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_author_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'seekers' ),
						),
						array(
							'id'       => 'mts_single_meta_info_author_divider',
							'type'     => 'text',
							'class'    => 'small-text',
							'title'    => esc_html__( 'Divider', 'seekers' ),
							'sub_desc' => esc_html__( 'Use any divider, ex: "-" "/" "|" "." ">"', 'seekers' ),
							'std'      => '|',
						),
						array(
							'id'     => 'mts_single_meta_info_author_margin',
							'type'   => 'margin',
							'title'  => esc_html__( 'Margin', 'seekers' ),
							'top'    => false,
							'bottom' => false,
							'std'    => array(
								'left'  => '-12px',
								'right' => '4px',
							),
						),
					),
				),
				'date'   => array(
					'label'     => esc_html__( 'Date', 'seekers' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_date_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'seekers' ),
						),
						array(
							'id'       => 'mts_single_meta_info_date_divider',
							'type'     => 'text',
							'class'    => 'small-text',
							'title'    => esc_html__( 'Divider', 'seekers' ),
							'sub_desc' => esc_html__( 'Use any divider, ex: "-" "/" "|" "." ">"', 'seekers' ),
						),
						array(
							'id'     => 'mts_single_meta_info_date_margin',
							'type'   => 'margin',
							'title'  => esc_html__( 'Margin', 'seekers' ),
							'top'    => false,
							'bottom' => false,
							'std'    => array(
								'left'  => '0',
								'right' => '0',
							),
						),
					),
				),
			),
			'disabled' => array(
				'category' => array(
					'label'     => esc_html__( 'Categories', 'seekers' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_category_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'seekers' ),
						),
						array(
							'id'       => 'mts_single_meta_info_category_divider',
							'type'     => 'text',
							'class'    => 'small-text',
							'title'    => esc_html__( 'Divider', 'seekers' ),
							'sub_desc' => esc_html__( 'Use any divider, ex: "-" "/" "|" "." ">"', 'seekers' ),
						),
						array(
							'id'     => 'mts_single_meta_info_category_margin',
							'type'   => 'margin',
							'title'  => esc_html__( 'Margin', 'seekers' ),
							'top'    => false,
							'bottom' => false,
							'std'    => array(
								'left'  => '0',
								'right' => '0',
							),
						),
					),
				),
				'comment'  => array(
					'label'     => esc_html__( 'Comment Count', 'seekers' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_comment_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'seekers' ),
						),
						array(
							'id'       => 'mts_single_meta_info_comment_divider',
							'type'     => 'text',
							'class'    => 'small-text',
							'title'    => esc_html__( 'Divider', 'seekers' ),
							'sub_desc' => esc_html__( 'Use any divider, ex: "-" "/" "|" "." ">"', 'seekers' ),
						),
						array(
							'id'     => 'mts_single_meta_info_comment_margin',
							'type'   => 'margin',
							'title'  => esc_html__( 'Margin', 'seekers' ),
							'top'    => false,
							'bottom' => false,
							'std'    => array(
								'left'  => '0',
								'right' => '0',
							),
						),
					),
				),
			),
		),
	),

	array(
		'id'       => 'mts_breadcrumb',
		'type'     => 'switch',
		'title'    => esc_html__( 'Breadcrumbs', 'seekers' ),
		'sub_desc' => esc_html__( 'Breadcrumbs are a great way to make your site more user-friendly. You can enable them by checking this box.', 'seekers' ),
		'std'      => '1',
	),

	array(
		'id'         => 'breadcrumb_icon',
		'type'       => 'icon_select',
		'title'      => esc_html__( 'Icon', 'seekers' ),
		'sub_desc'   => esc_html__( 'Select divider icons from here.', 'seekers' ),
		'std'        => 'angle-right',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'breadcrumb_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Breadcrumbs Font', 'seekers' ),
		'std'        => array(
			'preview-text'   => 'Breadcrumbs',
			'preview-color'  => 'light',
			'font-family'    => 'Karla',
			'font-weight'    => '700',
			'font-size'      => '18px',
			'color'          => '#3f4770',
			'css-selectors'  => '.breadcrumb, .rank-math-breadcrumb',
			'additional-css' => 'text-transform: uppercase;',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_author_comment',
		'type'     => 'switch',
		'title'    => esc_html__( 'Highlight Author Comment', 'seekers' ),
		'sub_desc' => esc_html__( 'Use this button to highlight author comments.', 'seekers' ),
		'std'      => '1',
	),

	array(
		'id'       => 'mts_comment_date',
		'type'     => 'switch',
		'title'    => esc_html__( 'Date in Comments', 'seekers' ),
		'sub_desc' => esc_html__( 'Use this button to show the date for comments.', 'seekers' ),
		'std'      => '1',
	),
);
