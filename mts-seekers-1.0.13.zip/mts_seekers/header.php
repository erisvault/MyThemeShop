<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="page">
 *
 * @package Seekers
 */

?><!doctype html>
<html<?php seekers_attr( 'html' ); ?>>
<head<?php seekers_attr( 'head' ); ?>>
	<?php wp_head(); ?>
</head>

<body<?php seekers_attr( 'body' ); ?>>

	<?php get_template_part( 'template-parts/header/clickable', 'background' ); ?>

	<div<?php seekers_attr( 'main' ); ?>>

		<?php seekers_action( 'before_wrapper' ); ?>
