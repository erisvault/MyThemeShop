<?php
/**
 * The template for displaying all single posts.
 *
 * @package Seekers
 */

get_header(); ?>

	<div id="wrapper" class="<?php seekers_single_page_class(); ?>">

		<?php seekers_action( 'single_top' ); ?>

		<div class="container clearfix">

			<?php
			seekers_single_featured_image_effect();

			seekers_action( 'before_content' );

			seekers_single_sections();

			seekers_action( 'after_content' );

			get_sidebar();
			?>

		</div>

		<?php
		if ( 'full' === seekers_get_settings( 'related_posts_position' ) ) {
			seekers_related_posts();
		}
		?>

<?php
get_footer();
