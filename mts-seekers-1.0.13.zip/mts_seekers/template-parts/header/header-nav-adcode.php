<?php if ( seekers_get_settings( 'navigation_ad' ) && seekers_get_settings( 'navigation_adcode' ) ) { ?>
	<div class="navigation-banner">
		<div class="container">
			<div style="<?php ad_size_value( seekers_get_settings( 'navigation_ad_size' ) ); ?>">
				<?php echo seekers_get_settings( 'navigation_adcode' ); ?>
			</div>
		</div>
	</div>
<?php } ?>
