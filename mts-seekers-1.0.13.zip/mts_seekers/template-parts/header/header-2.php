<?php
/**
 * Header Layout - 2
 *
 * @package Seekers
 */
?>
<header id="site-header" class="main-header <?php echo esc_attr( seekers_get_settings( 'mts_header_style' ) ); ?> clearfix" role="banner" itemscope itemtype="http://schema.org/WPHeader">
	<?php if ( seekers_get_settings( 'mts_show_primary_nav' ) === 1 ) { ?>
		<div id="primary-nav">
			<div class="container clearfix">
				<div id="primary-navigation" class="primary-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
					<nav class="navigation clearfix">
						<?php
						// Primary Navigation.
						if ( has_nav_menu( 'primary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'primary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new seekers_menu_walker(),
							));
						}

						// Header Social Icons.
						if ( 1 === seekers_get_settings( 'mts_header_social_icons' ) && ! empty( seekers_get_settings( 'mts_header_social' ) ) && is_array( seekers_get_settings( 'mts_header_social' ) ) ) {
							$header_icons = seekers_get_settings( 'mts_header_social' );
							seekers_social_icons( $header_icons, true );
						}
						?>
					</nav>
				</div>
			</div>
		</div>
	<?php } ?>

	<?php if ( seekers_get_settings( 'mts_sticky_nav' ) === 1 ) { ?>
	<div class="clear" id="catcher"></div>
	<div id="header" class="sticky-navigation">
	<?php } else { ?>
	<div id="header">
	<?php } ?>
		<div class="container">

			<div class="logo-wrap">
				<?php seekers_logo(); ?>
			</div>

			<div id="secondary-navigation" class="secondary-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
				<a href="#" id="pull" class="toggle-mobile-menu"><?php _e( 'Menu', 'seekers' ); ?></a>
				<?php if ( has_nav_menu( 'mobile' ) ) { ?>

					<nav class="navigation clearfix">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'secondary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new seekers_menu_walker(),
							));
						}
						?>
					</nav>
					<nav class="navigation mobile-only clearfix mobile-menu-wrapper">
						<?php
						// Mobile Navigation.
						if ( has_nav_menu( 'mobile' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'mobile',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new seekers_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } else { ?>

					<nav class="navigation clearfix mobile-menu-wrapper">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'secondary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new seekers_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } ?>
			</div>
		</div><!--.container-->
	</div>
</header>
<?php get_template_part( 'template-parts/header/header', 'nav-adcode' ); ?>
<?php get_template_part( 'template-parts/header/header', 'adcode' ); ?>
