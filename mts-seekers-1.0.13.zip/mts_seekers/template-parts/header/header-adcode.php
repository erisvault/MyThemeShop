<?php
/**
 * Header adcode
 *
 */

$ad_show_on = seekers_get_settings( 'header_adcode_show' );
$layouts    = seekers_get_settings( 'mts_header_style' );

if ( ! empty( seekers_get_settings( 'mts_header_adcode' ) ) ) {
	echo ( 'regular_header' !== $layouts ) ? '<div class="container small-header">' : '';

	if ( 'all' === $ad_show_on ) {
		if ( ! empty( seekers_get_settings( 'mts_header_adcode' ) ) ) {
			if ( 0 !== seekers_get_settings( 'mts_header_ad_size' ) ) {
				$style = 'max-width: 100%;';
			}
			?>
			<div class="widget-header">
				<div style="<?php ad_size_value( seekers_get_settings( 'mts_header_ad_size' ) ); ?> <?php echo $style; ?>">
					<?php echo seekers_get_settings( 'mts_header_adcode' ); ?>
				</div>
			</div>
		<?php
		}
	}
	if ( 'home' === $ad_show_on ) {
		if ( is_home() || is_front_page() ) {
			if ( ! empty( seekers_get_settings( 'mts_header_adcode' ) ) ) {
				if ( 0 !== seekers_get_settings( 'mts_header_ad_size' ) ) {
					$style = 'max-width: 100%;';
				}
				?>
				<div class="widget-header">
					<div style="<?php ad_size_value( seekers_get_settings( 'mts_header_ad_size' ) ); ?> <?php echo $style; ?>">
						<?php echo seekers_get_settings( 'mts_header_adcode' ); ?>
					</div>
				</div>
			<?php
			}
		}
	}
	if ( 'single' === $ad_show_on ) {
		if ( is_single() ) {
			if ( ! empty( seekers_get_settings( 'mts_header_adcode' ) ) ) {
				if ( 0 !== seekers_get_settings( 'mts_header_ad_size' ) ) {
					$style = 'max-width: 100%;';
				}
				?>
				<div class="widget-header">
					<div style="<?php ad_size_value( seekers_get_settings( 'mts_header_ad_size' ) ); ?> <?php echo $style; ?>">
						<?php echo seekers_get_settings( 'mts_header_adcode' ); ?>
					</div>
				</div>
			<?php
			}
		}
	}
	if ( 'page' === $ad_show_on ) {
		if ( is_page() ) {
			if ( ! empty( seekers_get_settings( 'mts_header_adcode' ) ) ) {
				if ( 0 !== seekers_get_settings( 'mts_header_ad_size' ) ) {
					$style = 'max-width: 100%;';
				}
				?>
				<div class="widget-header">
					<div style="<?php ad_size_value( seekers_get_settings( 'mts_header_ad_size' ) ); ?> <?php echo $style; ?>">
						<?php echo seekers_get_settings( 'mts_header_adcode' ); ?>
					</div>
				</div>
			<?php
			}
		}
	}

	echo ( 'regular_header' !== $layouts ) ? '</div>' : '';
}
