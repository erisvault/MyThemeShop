<?php
/**
 * Posts Layout - layout 1
 *
 * @package Seekers
 */

$featured = seekers()->featured_layouts;
?>
<div class="<?php $featured->get_article_class(); ?>">

	<div id="content_box">

		<section id="latest-posts" class="<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">

			<?php
			$j = 0;
			while ( have_posts() ) :
				the_post();
					$post_meta_info = seekers_get_settings( 'mts_home_meta_info' . $featured->current['unique_id'] );
					?>
				<?php if ( 1 === ++$j ) : ?>
					<div class="right-post-wrapper">
				<?php endif; ?>
				<?php if ( 2 === $j ) : ?>
					<div class="left-post-wrapper">

						<div id="search-14" class="widget layout-search clearfix">

							<form method="get" id="searchform" class="search-form" action="<?php echo esc_attr( home_url() ); ?>" _lpchecked="1">
								<fieldset>
									<input type="text" name="s" id="s" value="<?php the_search_query(); ?>" placeholder="<?php esc_html_e( 'Search the site...', 'seekers' ); ?>" <?php if ( ! empty( seekers_get_settings( 'mts_ajax_search' ) ) ) echo ' autocomplete="off"'; ?> />
									<button id="search-image" class="sbutton" type="submit" value="<?php esc_html_e( 'Search', 'seekers' ); ?>"><div class="layout-search-icon"><i class="fa fa-search fa-flip-horizontal"></i></div></button>
								</fieldset>
							</form>

							<div class="grid-categories">
								<?php
								if ( ! empty( seekers_get_settings( 'search_cats_' . $featured->current['unique_id'] ) ) && is_array( seekers_get_settings( 'search_cats_' . $featured->current['unique_id'] ) ) ) :
									$grid_cats = seekers_get_settings( 'search_cats_' . $featured->current['unique_id'] );
									foreach ( $grid_cats as $grid_cat ) :
										printf( '<a href="%1$s" title="%2$s">%3$s</a>', get_category_link( $grid_cat ), get_cat_name( $grid_cat ), get_cat_name( $grid_cat ) );
									endforeach;
								endif;
								?>
							</div>

						</div><!-- END #search-14 -->

						<?php $featured->get_section_title(); ?>

						<div class="post-wrapper clearfix">
				<?php endif; ?>
				<article class="latestPost excerpt <?php echo ( 1 === $j ) ? 'big' : 'small'; ?>">

					<?php $featured->get_post_thumbnail( $j ); ?>

					<div class="wrapper clearfix">

						<div class="post-info top">
							<?php
							if ( isset( $post_meta_info['category'] ) ) :
								printf( '<span class="thecategory">%s</span>', seekers_get_the_category( ' ' ) );
							endif;
							?>
						</div>

						<?php
						if ( 1 !== $j ) {
						?>
							<div class="post-info bottom">
								<?php
								if ( isset( $post_meta_info['author'] ) ) :
									printf( '<span class="theauthor"><span>%s</span></span>', get_the_author_posts_link() );
								endif;
								if ( isset( $post_meta_info['time'] ) ) :
									printf( '<span class="thetime date updated"><span>%s</span></span>', get_the_time( get_option( 'date_format' ) ) );
								endif;
								if ( isset( $post_meta_info['comment'] ) ) :
									printf( '<span class="thecomment">%s</span>', get_comments_number_text() );
								endif;
								?>
							</div>
						<?php
						}
						?>

						<?php $featured->get_post_title( false ); ?>

					</div>
				</article>
				<?php if ( 1 === $j ) : ?>
					</div>
				<?php endif; ?>
				<?php if ( ( $wp_query->current_post + 1 ) == ( $wp_query->post_count ) ) : ?>
					</div></div>
				<?php endif; ?>
			<?php
			endwhile;
			?>
			<div class="container">
				<?php
				if ( ! $featured->current['is_latest'] ) {
					seekers_pagination( seekers_get_settings( 'mts_pagenavigation_type' ) );
				}
				?>
			</div>
			<?php
			wp_reset_query();
			?>
		</section><!--#latest-posts-->
	</div>
</div>
