<?php
/**
 * Before footer detect ad blocker notice.
 *
 */

if ( seekers_get_settings( 'detect_adblocker' ) && ( 'popup' === seekers_get_settings( 'detect_adblocker_type' ) || 'floating' === seekers_get_settings( 'detect_adblocker_type' ) ) ) { ?>
	<?php if ( 'popup' === seekers_get_settings( 'detect_adblocker_type' ) ) { ?>
		<div class="blocker-overlay"></div>
	<?php } ?>
	<?php echo detect_adblocker_notice(); ?>
<?php } ?>
