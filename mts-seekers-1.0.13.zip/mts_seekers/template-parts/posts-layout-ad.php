<?php
/**
 * Posts Layout - layout ad
 *
 * @package Seekers
 */
$featured = seekers()->featured_layouts;
?>
<div class="<?php $featured->get_article_class(); ?>">
	<section class="<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">
		<?php if ( ! empty( seekers_get_settings( 'adcode_' . $featured->current['unique_id'] ) ) ) { ?>
			<div class="container">
				<div class="widget-ad"><?php echo seekers_get_settings( 'adcode_' . $featured->current['unique_id'] ); ?></div>
			</div>
		<?php } ?>
	</section><!--#latest-posts-->
</div>
