<?php
/**
 * Posts Layout - layout 3
 *
 * @package Seekers
 */

$featured = seekers()->featured_layouts;
?>
<div class="<?php $featured->get_article_class(); ?>">

	<div id="content_box">

		<?php seekers_action( 'start_content_box' ); ?>

		<div class="container">

			<?php $featured->get_section_title(); ?>

			<section id="latest-posts" class="<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">
				<?php
				$j = 0;
				while ( have_posts() ) :
					the_post();
					$post_meta_info = seekers_get_settings( 'mts_home_meta_info' . $featured->current['unique_id'] );
					?>
					<article class="latestPost excerpt small">

						<?php $featured->get_post_thumbnail(); ?>

						<div class="wrapper clearfix">
							<div class="post-info top">
								<?php
								if ( isset( $post_meta_info['category'] ) ) :
									printf( '<span class="thecategory">%s</span>', seekers_get_the_category( ' ' ) );
								endif;
								?>
							</div>
							<div class="post-info bottom">
								<?php
								if ( isset( $post_meta_info['author'] ) ) :
									printf( '<span class="theauthor"><span>%s</span></span>', get_the_author_posts_link() );
								endif;
								if ( isset( $post_meta_info['time'] ) ) :
									printf( '<span class="thetime date updated"><span>%s</span></span>', get_the_time( get_option( 'date_format' ) ) );
								endif;
								if ( isset( $post_meta_info['comment'] ) ) :
									printf( '<span class="thecomment">%s</span>', get_comments_number_text() );
								endif;
								?>
							</div>

							<?php $featured->get_post_title(); ?>

						</div>
					</article>
					<?php
					endwhile;

					$featured->get_post_pagination();
					?>
			</section><!--#latest-posts-->
		</div>
	</div>
</div>
