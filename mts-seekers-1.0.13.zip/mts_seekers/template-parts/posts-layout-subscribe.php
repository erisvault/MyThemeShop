<?php
/**
 * Posts Layout - layout subscribe
 *
 * @package Seekers
 */
$featured = seekers()->featured_layouts;
?>
<?php
if ( 'container' === seekers_get_settings( 'subscribe_size_' . $featured->current['unique_id'] ) ) :
?>
<div class="container clear clearfix">
<?php
endif;
?>
	<div class="<?php $featured->get_article_class(); ?>">

		<section class="<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">

			<div class="container">

				<div class="wrapper">

					<div class="left-content clearfix">
						<?php
						$logo = ( null !== seekers_get_settings( 'subscribe_left_content_logo_' . $featured->current['unique_id'] ) ) ? seekers_get_settings( 'subscribe_left_content_logo_' . $featured->current['unique_id'] ) : '';

						$title = ( null !== seekers_get_settings( 'subscribe_left_content_title_' . $featured->current['unique_id'] ) ) ? seekers_get_settings( 'subscribe_left_content_title_' . $featured->current['unique_id'] ) : '';

						$text = ( null !== seekers_get_settings( 'subscribe_left_content_text_' . $featured->current['unique_id'] ) ) ? seekers_get_settings( 'subscribe_left_content_text_' . $featured->current['unique_id'] ) : '';

						if ( ! empty( $logo ) ) {
							printf( '<div class="left-logo"><img src="%s"></div>', $logo );
						}
						if ( ! empty( $title ) || ! empty( $text ) ) {
							printf( '<div class="text-wrapper"><h4>%1$s</h4><p>%2$s</p></div>', $title, $text );
						}
						?>
					</div>

					<div class="right-content">

						<?php $featured->get_sidebar(); ?>

						<div class="subscribe-icons-container">

							<?php
							if ( ! empty( seekers_get_settings( 'subscribe_icon_title_' . $featured->current['unique_id'] ) ) ) {
								printf( '<p class="subscribe-icons-title">%s</p>', seekers_get_settings( 'subscribe_icon_title_' . $featured->current['unique_id'] ) );
							}

							// Subscribe Icons
							if ( 1 === seekers_get_settings( 'subscribe_social_icons_' . $featured->current['unique_id'] ) && ! empty( seekers_get_settings( 'subscribe_social_' . $featured->current['unique_id'] ) ) && is_array( seekers_get_settings( 'subscribe_social_' . $featured->current['unique_id'] ) ) ) {
								$subscribe_icons = seekers_get_settings( 'subscribe_social_' . $featured->current['unique_id'] );
								echo '<div class="subscribe-social-icons">';

								foreach ( $subscribe_icons as $item ) {
									printf(
										'<a href="%1$s" title="%2$s" class="subscribe-%3$s" target="_blank"><span class="fa fa-%3$s"></span></a>',
										$item['subscribe_social_link'],
										$item['subscribe_social_title'],
										$item['subscribe_social_icon']
									);
								}

								echo '</div>';
							}
							?>

						</div>

					</div>

				</div>

			</div>

		</section><!--#latest-posts-->

	</div>
<?php
if ( 'container' === seekers_get_settings( 'subscribe_size_' . $featured->current['unique_id'] ) ) :
?>
</div>
<?php
endif;
?>
