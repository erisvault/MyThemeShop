<?php
/**
 * The template for displaying search results pages.
 *
 * @package Seekers
 */

get_header(); ?>

	<div id="wrapper">

		<div class="container">

			<div class="article">

				<?php seekers_action( 'before_content' ); ?>

				<div id="content_box">

					<?php if ( have_posts() ) : ?>

						<h1 class="page-title">
							<?php
							// translators: search query.
							printf( esc_html__( 'Search Results for: %s', 'seekers' ), '<span>' . get_search_query() . '</span>' );
							?>
						</h1>
					<?php else : ?>
						<h1 class="page-title"><?php esc_html_e( 'Nothing Found', 'seekers' ); ?></h1>
					<?php endif; ?>

					<?php
					if ( 'above' === seekers_get_settings( 'search_position' ) ) {
						get_search_form();
					}

					$j = 0;
					if ( have_posts() ) {
						while ( have_posts() ) {
							the_post();
							seekers_blog_articles( 'default' );
						}
					} else {
						get_template_part( 'template-parts/no', 'results' );
					}

					if ( 0 !== $j ) {
						seekers_pagination( seekers_get_settings( 'mts_pagenavigation_type' ) );
					}

					if ( 'below' === seekers_get_settings( 'search_position' ) ) {
						get_search_form();
					}
					?>
				</div>

				<?php seekers_action( 'after_content' ); ?>

			</div>

			<?php get_sidebar(); ?>

		</div>

<?php
get_footer();
