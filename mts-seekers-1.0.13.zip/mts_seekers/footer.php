<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Seekers
 */

get_template_part( 'template-parts/footer/footer', 'ad' );
?>
	</div><!--#wrapper-->

	<footer<?php seekers_attr( 'footer' ); ?>>

		<div class="container">
			<?php
			if ( 'bottom' !== seekers_get_settings( 'footer_sections_position' ) ) {
				get_template_part( 'template-parts/footer/footer', 'sections' );
			}

			if ( seekers_get_settings( 'mts_top_footer' ) ) {
				seekers_footer_widget_columns();
			}

			if ( 'bottom' === seekers_get_settings( 'footer_sections_position' ) ) {
				get_template_part( 'template-parts/footer/footer', 'sections' );
			}
			?>
		</div>

		<?php seekers_footer_copyrights(); ?>

	</footer><!--#site-footer-->

</div><!--.main-container-->

<?php get_template_part( 'template-parts/footer/footer', 'detect-adblocker' ); ?>

<?php wp_footer(); ?>

</body>
</html>
