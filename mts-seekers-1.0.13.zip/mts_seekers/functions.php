<?php
/**
 *  Do not remove these lines, sky will fall on your head.
 *
 *  @package Seekers
 */

if ( ! defined( 'MTS_THEME_WHITE_LABEL' ) ) {
	define( 'MTS_THEME_WHITE_LABEL', false );
}

/**
 * Starting Theme Engine :)
 */
include_once get_parent_theme_file_path( 'includes/class-seekers.php' );
