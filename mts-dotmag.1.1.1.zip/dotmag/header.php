<!DOCTYPE html>
<?php $options = get_option('dotmag'); ?>
<html class="no-js" <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<title><?php wp_title(''); ?></title>
	<?php mts_meta(); ?>
	<?php mts_head(); ?>
	<?php wp_head(); ?>
</head>

<?php flush(); ?>

<body id ="blog" <?php body_class('main'); ?>>
	<header class="main-header">
		<div class="container">
			<div class="main-navigation">
				<nav id="navigation">
					<?php if ( has_nav_menu( 'primary-menu' ) ) { ?>
						<?php wp_nav_menu( array( 'theme_location' => 'primary-menu', 'menu_class' => 'menu', 'container' => '' ) ); ?>
                        <?php echo $options['mts_header_text']; ?>
					<?php } else { ?>
						<ul class="menu">
							<?php echo $options['mts_header_text']; ?>
							<li class="home-tab home-padding"><a href="<?php echo home_url(); ?>">Home</a></li>
							<?php wp_list_pages('title_li='); ?>
						</ul>
					<?php } ?><!--#nav-primary-->
				</nav>
			</div>
			<div id="header">
				<div class="content">
					<?php if( is_front_page() || is_home() || is_404() ) { ?>
						<h1 id="logo"><a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a></h1>
					<?php } else { ?>
						<h2 id="logo"><a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a></h2>
					<?php } ?>  
					<?php if ( ! dynamic_sidebar( 'Header' ) ) : ?><?php endif ?>             
				</div>
				<div class="secondary-navigation">
					<nav id="navigation" >
						<?php if ( has_nav_menu( 'secondary-menu' ) ) { ?>
							<?php wp_nav_menu( array( 'theme_location' => 'secondary-menu', 'menu_class' => 'menu', 'container' => '' ) ); ?>
						<?php } else { ?>
							<ul class="menu">
								<?php wp_list_categories('title_li='); ?>
							</ul>
						<?php } ?>
					</nav>
				</div>              
			</div><!--#header-->
		</div><!--.container-->        
	</header>
<div class="main-container">
<?php if(is_single()){
	if ($options['mts_breadcrumb'] == '1') { ?>		
		<div id="breadCrumpBox">
			<section class="slider">
				<div class="breadcrumb">
					<?php if( function_exists( 'rank_math' ) && rank_math()->breadcrumbs ) {
					    rank_math_the_breadcrumbs();
					  } else {
					    the_breadcrumb();
				    } ?>
		        </div>
		    </section>
		</div>
	<?php }
} else { ?>
<?php if(is_home()){ ?>
<?php if($options['mts_featured_slider'] == '1') { ?>
	<div id="sliderBox">
		<section class="slider">
			<div class="flexslider">
				<ul class="slides">
					<?php $my_query = new WP_Query('cat='.$options['mts_featured_cat'].'&posts_per_page=3'); while ($my_query->have_posts()) : $my_query->the_post(); $image_id = get_post_thumbnail_id(); $image_url = wp_get_attachment_image_src($image_id,'slider'); $image_url = $image_url[0]; ?>
					<li data-thumb="<?php echo $image_url; ?>">
						<a href="<?php the_permalink() ?>" class="slidelink"><?php the_post_thumbnail('slider',array('title' => '')); ?></a>
						<p class="flex-caption">
							<span class="sliderTitle"><a href="<?php the_permalink() ?>"><?php the_title();?></a></span>
							<span class="sliderInfo"><?php _e('by ','mythemeshop'); the_author_posts_link(); ?><?php _e(' On ','mythemeshop'); the_time('F j, Y'); ?><?php _e(' In ','mythemeshop'); $category = get_the_category(); echo '<a href="'.get_category_link($category[0]->cat_ID).'">'.$category[0]->cat_name.'</a>';?></span>
							<span class="sliderContent"><?php echo excerpt(30)?></span>
							<span class="sliderReadMore"><a href="<?php the_permalink() ?>">+ Read More</a></span>
						</p>
					</li>
					<?php endwhile; ?>
				</ul>
			</div>
		</section>
	</div>
<?php } ?>
<?php } ?>
<?php } ?>