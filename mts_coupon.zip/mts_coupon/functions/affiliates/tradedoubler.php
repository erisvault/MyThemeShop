<?php
class MTS_TradeDoubler {
	public $url = "http://api.tradedoubler.com/%s/%s";

	/**
	 * API Key for authenticating requests
	 *
	 * @var string
	 */
	protected $token;
	/**
	 * The Commission Junction API Client is completely self contained with it's own API key.
	 * The cURL resource used for the actual querying can be overidden in the contstructor for
	 * testing or performance tweaks, or via the setCurl() method.
	 *
	 * @param string $api_key API Key
	 */
	public function __construct() {
		global $mts_options;
		if(isset($mts_options['mts_tradedoubler_token']) && !empty($mts_options['mts_tradedoubler_token'])) {
			$this->token = $mts_options['mts_tradedoubler_token'];
		}
	}

	public function couponSearch( $params = array() ) {
		$data = array();
		$data[] = 'vouchers.json';
		foreach($params as $key => $param) {
			$data[] = $key.'='.$param;
		}
		return $this->Api(implode(';', $data));
	}

	public function Api( $resource, $version = '1.0' ) {

		if( empty( $this->token ) ) {
			throw new \Exception( 'Token is not set, check your <a href="?plugin=CJApiPro/options.php">settings</a> and try again.' );
		}

		$url = sprintf( $this->url, $version, $resource) . '?token='.$this->token;

		$result = file_get_contents( $url );

		$matches = array();
		preg_match( '#HTTP/\d+\.\d+ (\d+)#', $http_response_header[0], $matches );

		switch( $matches[1] ) {
			case 200:
				return (array)json_decode($result, true);
			break;

			case 401:
				throw new \Exception( 'Unauthorized!' );
			break;

			default:
				throw new \Exception( 'Unexpected.' );
			break;
		}
	}
}