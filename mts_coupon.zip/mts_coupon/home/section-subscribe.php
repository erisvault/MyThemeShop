<?php if ( is_active_sidebar( 'widget-subscribe' ) ) { ?>
<section id="subscribe" class="subscribe-container">
	<div class="container clearfix">
		<?php dynamic_sidebar( 'widget-subscribe' ); ?>
	</div>
</section>
<?php } ?>