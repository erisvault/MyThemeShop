<?php $options = get_option('trendy'); ?>
<?php get_header(); ?>
<div id="page">
	<div class="content">
		<article class="article">
			<div id="content_box">
<?php if (is_home() && !is_paged()) { ?>
	<?php if($options['mts_featured_slider'] == '1') { ?>
	<div class="flex-container">
    <h3>Featured Posts:</h3>
  <div class="flexslider">
    <ul class="slides">
	<?php
$my_query = new WP_Query('cat='.$options['mts_featured_cat'].'&posts_per_page=3');
while ($my_query->have_posts()) : $my_query->the_post();
?>    
      <li><a href="<?php the_permalink() ?>"><div class="slideTitle"><?php the_title()?></div>
<?php if ( has_post_thumbnail() ) { ?> 
        <?php the_post_thumbnail('slider',array('title' => '')); ?>
<?php } else { ?>
        <img width="600" height="300" src="<?php echo get_template_directory_uri(); ?>/images/slidernothumb.png" class="attachment-slider wp-post-image" alt="<?php the_title(); ?>">
<?php } ?>
		</a>
      </li>
   <?php endwhile; ?> </ul>
  </div>
</div>
<?php } ?>
<?php } ?>
<div class="leftCatBox">
<div class="mainTitle">Latest Posts:</div>
<?php global $wpdb; $i = 1; $args=array( 'posts_per_page'=> 2 ); $my_query = new wp_query( $args ); ?>
				<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>                      
						<div class="post excerptsmall">
 								<h2 class="title front-view-title-small">
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
								</h2>                       
                                <div class="frontThumb">                            
								<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" id="featured-thumbnail">
								<?php if ( has_post_thumbnail() ) { ?> 
								<?php echo '<div class="featured-thumbnail-small">'; the_post_thumbnail('featured',array('title' => '')); echo '</div>'; ?>
								<?php } else { ?>
								<div class="featured-thumbnail-small">
								<img width="50" height="50" src="<?php echo get_template_directory_uri(); ?>/images/nothumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
								</div>
								<?php } ?>
								</a>
                                </div>
                                <div class="frontContentSmall">							
							<div class="post-content image-caption-format-1 front-view-text-small">
								<?php echo excerpt(11);?>
							</div>
                            <?php if($i == 2){?>
                            <span><a href="<?php echo home_url(); ?>/latest">See all latest posts</a></span>
                            <?php } ?>
                            </div>
						</div><!--.post excerpt-->   
					<?php $i++; endwhile; else: ?>
						<div class="post excerpt">
							<div class="no-results">
								<p><strong><?php _e('There has been an error.', 'mythemeshop'); ?></strong></p>
								<p><?php _e('We apologize for any inconvenience, please hit back on your browser or use the search form below.', 'mythemeshop'); ?></p>
								<?php get_search_form(); ?>
							</div><!--noResults-->
						</div>                       
					<?php endif; ?>
			</div>
            
                    <div class="rightCatBox">
                    <div class="mainTitle">Popular this Week:</div>
                    <?php    
							$i = 1;
							$args=array(
								'posts_per_page'=> 2,
							    'orderby'=>'comment_count',
								'order'=>'DESC'
								);
							$my_query = new wp_query( $args );
					?>
					<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
                        
						<div class="post excerptsmall">
							<h2 class="title front-view-title-small">
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
								</h2>
                                <div class="frontThumb">                            
								<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" id="featured-thumbnail">
								<?php if ( has_post_thumbnail() ) { ?> 
								<?php echo '<div class="featured-thumbnail-small">'; the_post_thumbnail('featured',array('title' => '')); echo '</div>'; ?>
								<?php } else { ?>
								<div class="featured-thumbnail-small">
								<img width="50" height="50" src="<?php echo get_template_directory_uri(); ?>/images/nothumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
								</div>
								<?php } ?>
								</a>
                                </div>
                                <div class="frontContentSmall">
							<div class="post-content image-caption-format-1 front-view-text-small">
								<?php echo excerpt(11);?>
							</div>
                            <?php if($i == 2){?>
                            <span><a href="<?php echo home_url(); ?>/popular">See all popular posts</a></span>
                            <?php } ?>
                            </div>
						</div><!--.post excerpt-->  
			
					<?php $i++; endwhile; else: ?>
						<div class="post excerpt">
							<div class="no-results">
								<p><strong><?php _e('There has been an error.', 'mythemeshop'); ?></strong></p>
								<p><?php _e('We apologize for any inconvenience, please hit back on your browser or use the search form below.', 'mythemeshop'); ?></p>
								<?php get_search_form(); ?>
							</div><!--noResults-->
						</div>                       
					<?php endif; ?>
			</div>
<div style="clear:both; width:100%; height:15px;"></div>
<div class="leftCatBox">
<div class="mainTitle"><?php $first_cat = $options['mts_featured_first_cat']; echo get_cat_name( $first_cat ); ?>:</div>
                    <?php    
                            global $wpdb;
							$i = 1;$j =0;
							$my_query = new WP_Query('cat='.$options['mts_featured_first_cat'].'&posts_per_page=2');
					?>
					<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>                      
						<div class="post excerptsmall<?php echo (++$j % 2 == 0) ? ' last' : ''; ?>">
                        
 								<h2 class="title front-view-title-small">
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
								</h2>                       
                                <div class="frontThumb">                            
								<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" id="featured-thumbnail">
								<?php if ( has_post_thumbnail() ) { ?> 
								<?php echo '<div class="featured-thumbnail-small">'; the_post_thumbnail('featured',array('title' => '')); echo '</div>'; ?>
								<?php } else { ?>
								<div class="featured-thumbnail-small">
								<img width="50" height="50" src="<?php echo get_template_directory_uri(); ?>/images/nothumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
								</div>
								<?php } ?>
								</a>
                                </div>
                                <div class="frontContentSmall">							
							<div class="post-content image-caption-format-1 front-view-text-small">
								<?php echo excerpt(11);?>
							</div>
                            <?php if($i == 2){?>
                            <span><a href="<?php echo get_category_link( $first_cat ); ?> ">See all <?php echo get_cat_name( $first_cat ); ?> posts</a></span>
                            <?php } ?>
                            </div>
						</div><!--.post excerpt-->   
					<?php $i++; endwhile; else: ?>
						<div class="post excerpt">
							<div class="no-results">
								<p><strong><?php _e('There has been an error.', 'mythemeshop'); ?></strong></p>
								<p><?php _e('We apologize for any inconvenience, please hit back on your browser or use the search form below.', 'mythemeshop'); ?></p>
								<?php get_search_form(); ?>
							</div><!--noResults-->
						</div>                       
					<?php endif; ?>
			</div>
            
                    <div class="rightCatBox">
                    <div class="mainTitle"><?php $second_cat = $options['mts_featured_second_cat']; echo get_cat_name( $second_cat ); ?>:</div>
                    <?php    
							$i = 1;$j=0;
							$my_query = new WP_Query('cat='.$options['mts_featured_second_cat'].'&posts_per_page=2');
					?>
					<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
                        
						<div class="post excerptsmall<?php echo (++$j % 2 == 0) ? ' last' : ''; ?>">
							<h2 class="title front-view-title-small">
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
								</h2>
                                <div class="frontThumb">                            
								<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" id="featured-thumbnail">
								<?php if ( has_post_thumbnail() ) { ?> 
								<?php echo '<div class="featured-thumbnail-small">'; the_post_thumbnail('featured',array('title' => '')); echo '</div>'; ?>
								<?php } else { ?>
								<div class="featured-thumbnail-small">
								<img width="50" height="50" src="<?php echo get_template_directory_uri(); ?>/images/nothumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
								</div>
								<?php } ?>
								</a>
                                </div>
                                <div class="frontContentSmall">
							<div class="post-content image-caption-format-1 front-view-text-small">
								<?php echo excerpt(11);?>
							</div>
                            <?php if($i == 2){?>
                            <span><a href="<?php echo get_category_link( $second_cat ); ?> ">See all <?php echo get_cat_name( $second_cat ); ?> posts</a></span>
                            <?php } ?>
                            </div>
						</div><!--.post excerpt-->  
			
					<?php $i++; endwhile; else: ?>
						<div class="post excerpt">
							<div class="no-results">
								<p><strong><?php _e('There has been an error.', 'mythemeshop'); ?></strong></p>
								<p><?php _e('We apologize for any inconvenience, please hit back on your browser or use the search form below.', 'mythemeshop'); ?></p>
								<?php get_search_form(); ?>
							</div><!--noResults-->
						</div>                       
					<?php endif; ?>
			</div>									
			</div>
		</article>
<?php get_sidebar(); ?>
<?php get_footer(); ?>