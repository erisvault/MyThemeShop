<?php
/**
 * The template for displaying search results pages.
 *
 * @package Purple
 */

get_header(); ?>

	<div id="wrapper" class="archives">

		<?php purple_action( 'archive_top' ); ?>

		<div class="container">

			<div class="article">

				<?php purple_action( 'before_content' ); ?>

				<div id="content_box">

					<?php if ( have_posts() ) : ?>
					<?php else : ?>
						<h1 class="page-title"><?php esc_html_e( 'Nothing Found', 'purple' ); ?></h1>
					<?php endif; ?>

					<?php
					if ( 'above' === purple_get_settings( 'search_position' ) ) {
						get_search_form();
					}

					$j = 0;
					if ( have_posts() ) {
						while ( have_posts() ) {
							the_post();
							purple_blog_articles( 'default' );
						}
					} else {
						get_template_part( 'template-parts/no', 'results' );
					}

					if ( 0 !== $j ) {
						purple_pagination( purple_get_settings( 'mts_pagenavigation_type' ) );
					}

					if ( 'below' === purple_get_settings( 'search_position' ) ) {
						get_search_form();
					}
					?>
				</div>

				<?php purple_action( 'after_content' ); ?>

			</div>

			<?php get_sidebar(); ?>

		</div>

<?php
get_footer();
