<?php
/**
 * The template for displaying 404 (Not Found) pages.
 *
 * @package Purple
 */

get_header(); ?>

<div id="wrapper" class="archives">

	<?php purple_action( 'archive_top' ); ?>

		<div class="container">

			<article class="article">

				<div id="content_box" >
					<div class="post-content">
						<p><?php esc_html_e( 'Oops! We couldn\'t find this Page.', 'purple' ); ?></p>
						<p><?php esc_html_e( 'Please check your URL or use the search form below.', 'purple' ); ?></p>
						<?php get_search_form(); ?>
					</div><!--.post-content--><!--#error404 .post-->

				</div><!--#content-->

			</article>

			<?php get_sidebar(); ?>

		</div>
<?php
get_footer();
