<?php
/**
 * Tweaks for the footer of the document.
 *
 * @package Purple
 */

defined( 'WPINC' ) || exit;

/**
 * Tweaks for the <head> of the document.
 */
class Purple_Footer extends Purple_Base {

	/**
	 * Constructor
	 */
	public function __construct() {

		$this->add_action( 'wp_footer', 'tracking_field', 999 );
	}

	/**
	 * Add tracking field code
	 */
	public function tracking_field() {
		echo purple_get_settings( 'mts_analytics_code' );
	}
}

/**
 * Init
 */
new Purple_Footer;
