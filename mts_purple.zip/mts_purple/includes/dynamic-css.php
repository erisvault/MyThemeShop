<?php
/**
 * Dynamic CSS for the frontend.
 *
 * @package Purple
 */

defined( 'WPINC' ) || exit;

/**
 * Helper function.
 * Merge and combine the CSS elements.
 *
 * @param  string|array $elements An array of our elements.
 *                                If we use a string then it is directly returned.
 * @return string
 */
function purple_implode( $elements = array() ) {

	if ( ! is_array( $elements ) ) {
		return $elements;
	}

	// Make sure our values are unique.
	$elements = array_unique( $elements );

	// Sort elements alphabetically.
	// This way all duplicate items will be merged in the final CSS array.
	sort( $elements );

	// Implode items and return the value.
	return implode( ',', $elements );

}

/**
 * Maps elements from dynamic css to the selector.
 *
 * @param  array  $elements The elements.
 * @param  string $selector The selector.
 * @return array
 */
function purple_map_selector( $elements, $selector ) {
	$array = array();

	foreach ( $elements as $element ) {
		$array[] = $element . $selector;
	}

	return $array;
}

/**
 * Map CSS selectors from values.
 *
 * @param array $css    Array of dynamic CSS.
 * @param array $values Array of values.
 */
function purple_map_css_selectors( &$css, $values ) {
	if ( isset( $values['css-selectors'] ) ) {
		$elements = $values['css-selectors'];
		unset( $values['css-selectors'] );

		$css[ $elements ] = $values;
	}
}

/**
 * Merge CSS values.
 *
 * @param array $css    Array of dynamic CSS.
 * @param array $values Array of values.
 */
function purple_merge_value( &$css, $values ) {
	foreach ( (array) $values as $id => $val ) {
		$css[ $id ] = $val;
	}
}

/**
 * Format of the $css array:
 * $css['media-query']['element']['property'] = value
 *
 * If no media query is required then set it to 'global'
 *
 * If we want to add multiple values for the same property then we have to make it an array like this:
 * $css[media-query][element]['property'][] = value1
 * $css[media-query][element]['property'][] = value2
 *
 * Multiple values defined as an array above will be parsed separately.
 */
function purple_dynamic_css_array() {

	global $wp_version;

	$css       = array();
	$c_page_id = purple()->get_page_id();

	// Site Background.
	$css['global']['html body'] = Purple_Sanitize::background( purple_get_settings( 'mts_background' ) );

	// Top bar Background.
	$css['global']['.featured-area-section'] = Purple_Sanitize::background( purple_get_settings( 'featured_area_background' ) );

	// Header Background.
	$css['global']['body #header, .header-search .searchbox-open #s, #header.sticky-navigation.sticky-navigation-active'] = Purple_Sanitize::background( purple_get_settings( 'mts_main_navigation_background' ) );

	// Content Font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'content_font' ) ) );
	// Logo Font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'purple_logo' ) ) );

	// Secondary Navigation font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'secondary_navigation_font' ) ) );

	// Homepage post title font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'home_title_font' ) ) );
	// Breadcrumbs font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'breadcrumb_font' ) ) );
	// Single post title font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'single_title_font' ) ) );
	// Page title font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'page_title_font' ) ) );
	// Single Page titles font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'single_page_titles_font' ) ) );
	// Related Posts Section title font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'related_post_title_font' ) ) );
	// Single subscribe box.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'single_subscribe_title_font' ) ) );
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'single_subscribe_text_font' ) ) );
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'single_subscribe_input_font' ) ) );
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'single_subscribe_submit_font' ) ) );
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'single_subscribe_small_text_font' ) ) );
	// Author Box.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'single_authorbox_author_name_font' ) ) );
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'single_authorbox_text_font' ) ) );
	// Sidebar widget title font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'sidebar_title_font' ) ) );
	// Sidebar widget font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'sidebar_url' ) ) );
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'sidebar_post_title' ) ) );
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'sidebar_font' ) ) );
	// Footer widget title font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'top_footer_title_font' ) ) );
	// Footer link font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'top_footer_link_font' ) ) );
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'top_footer_post_title' ) ) );
	// Footer widget font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'top_footer_font' ) ) );
	// Footer meta font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'top_footer_meta_font' ) ) );
	// Copyrights section font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'copyrights_font' ) ) );
	// H1 title in the content.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'h1_headline' ) ) );
	// H2 title in the content.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'h2_headline' ) ) );
	// H3 title in the content.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'h3_headline' ) ) );
	// H4 title in the content.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'h4_headline' ) ) );
	// H5 title in the content.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'h5_headline' ) ) );
	// H6 title in the content.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'h6_headline' ) ) );

	// Footer background.
	$css['global']['#site-footer'] = Purple_Sanitize::background( purple_get_settings( 'mts_footer_background' ) );
	// Copyrights background.
	$css['global']['.copyrights'] = Purple_Sanitize::background( purple_get_settings( 'mts_copyrights_background' ) );

	purple_dynamic_css_skin( $css );
	purple_sidebar_position( $css );
	purple_header( $css );
	purple_sidebar_styling( $css );
	purple_post_layouts( $css );
	purple_featured_area( $css );
	purple_post_pagination( $css );
	purple_footer( $css );
	purple_copyrights( $css );
	purple_single( $css );
	purple_single_social_buttons( $css );
	purple_misc_css( $css );

	return apply_filters( 'purple_dynamic_css_array', $css );
}

/**
 * Skin CSS
 *
 * @param array $css Array of dynamic CSS.
 */
function purple_dynamic_css_skin( &$css ) {

	// Theme Color.
	$purple_color_scheme = Purple_Sanitize::color( purple_get_settings( 'mts_color_scheme' ) );
	//Light Color
	$light_color_scheme = purple_luminance( purple_get_settings( 'mts_color_scheme' ), 0.8 );
	//Footer Light Background
	$footer_light_bg = purple_luminance( purple_get_settings( 'mts_color_scheme' ), 0.1 );

	// Text Color.
	$elements = array(
		'a',
		'cite',
		'a:hover',
		'.breadcrumb a',
		'.reply a',
		'.reply i',
		'.ago',
		'.latestPost .title a:hover',
		'.related-posts .title a:hover',
		'.layout-default .latestPost .title a:hover',
		'.layout-1 .latestPost .title a:hover',
		'#primary-navigation a:hover',
		'.shareit-circular.standard a:hover',
		'.postauthor h5',
		'.textwidget a',
		'#wp-calendar td#today',
		'.pnavigation2 a',
		'.sidebar.c-4-12 a:hover',
		'.sidebar.c-4-12 a:hover',
		'.title a:hover',
		'.post-info a:hover',
		'#tabber .inside li a:hover',
		'.related-posts .title a:hover',
		'.layout-subscribe .widget #wp-subscribe .title span',
		'.footer-nav li a:hover',
		'.f-widget .widget .wp-subscribe-wrap input.submit',
		'blockquote:after',
		'article ul li::before',
		'.post-info > span::before',
		'#site-header .header-search .searchbox-open .searchbox-icon',
		'.widget .post-info',
		'#sidebar .widget .post-info a',
		'.widget .wpt_widget_content .wpt-postmeta',
		'.wp_review_tab_widget_content .wp-review-tab-postmeta',
		'.share-text',
		'.shareit-circular.standard a',
	);

	$css['global'][ purple_implode( $elements ) ]['color'] = $purple_color_scheme;
	$css['global']['.sidebar .widget a:hover']['color']    = $purple_color_scheme;

	// Buttons Background Color.
	$elements = array(
		'.error404 .sbutton',
		'.search .sbutton',
		'.pace .pace-progress',
		'#mobile-menu-wrapper ul li a:hover',
		'.navigation #wpmm-megamenu .wpmm-pagination a',
		'.wpmm-megamenu-showing.wpmm-light-scheme',
		'.mts-subscribe input[type="submit"]',
		'.widget_product_search button[type="submit"]',
		'#move-to-top:hover',
		'#tabber ul.tabs li a.selected',
		'.tagcloud a',
		'.navigation ul .sfHover a',
		'.widget-slider .slide-caption',
		'.owl-prev, .owl-next',
		'.owl-prev:hover, .owl-next:hover',
		'.widget .wp-subscribe-wrap h4.title span.decor:after',
		'.mobile-menu-active .navigation.mobile-menu-wrapper',
		'.woocommerce a.button',
		'.woocommerce-page a.button',
		'.woocommerce button.button',
		'.woocommerce-page button.button',
		'.woocommerce input.button',
		'.woocommerce-page input.button',
		'.woocommerce #respond input#submit',
		'.woocommerce-page #respond input#submit',
		'.woocommerce #content input.button',
		'.woocommerce-page #content input.button',
		'.woocommerce .bypostauthor:after',
		'.woocommerce nav.woocommerce-pagination ul li span.current',
		'.woocommerce-page nav.woocommerce-pagination ul li span.current',
		'.woocommerce #content nav.woocommerce-pagination ul li span.current',
		'.woocommerce-page #content nav.woocommerce-pagination ul li span.current',
		'.woocommerce nav.woocommerce-pagination ul li a:hover',
		'.woocommerce-page nav.woocommerce-pagination ul li a:hover',
		'.woocommerce #content nav.woocommerce-pagination ul li a:hover',
		'.woocommerce-page #content nav.woocommerce-pagination ul li a:hover',
		'.woocommerce nav.woocommerce-pagination ul li a:focus',
		'.woocommerce-page nav.woocommerce-pagination ul li a:focus',
		'.woocommerce #content nav.woocommerce-pagination ul li a:focus',
		'.woocommerce-page #content nav.woocommerce-pagination ul li a:focus',
		'.woocommerce a.button',
		'.woocommerce-page a.button',
		'.woocommerce button.button',
		'.woocommerce-page button.button',
		'.woocommerce input.button',
		'.woocommerce-page input.button',
		'.woocommerce #respond input#submit',
		'.woocommerce-page #respond input#submit',
		'.woocommerce #content input.button',
		'.woocommerce-page #content input.button',
		'.woocommerce #respond input#submit.alt.disabled',
		'.woocommerce #respond input#submit.alt.disabled:hover',
		'.woocommerce #respond input#submit.alt:disabled',
		'.woocommerce #respond input#submit.alt:disabled:hover',
		'.woocommerce #respond input#submit.alt:disabled[disabled]',
		'.woocommerce #respond input#submit.alt:disabled[disabled]:hover',
		'.woocommerce a.button.alt.disabled, .woocommerce a.button.alt.disabled:hover',
		'.woocommerce a.button.alt:disabled',
		'.woocommerce a.button.alt:disabled:hover',
		'.woocommerce a.button.alt:disabled[disabled]',
		'.woocommerce a.button.alt:disabled[disabled]:hover',
		'.woocommerce button.button.alt.disabled',
		'.woocommerce button.button.alt.disabled:hover',
		'.woocommerce button.button.alt:disabled',
		'.woocommerce button.button.alt:disabled:hover',
		'.woocommerce button.button.alt:disabled[disabled]',
		'.woocommerce button.button.alt:disabled[disabled]:hover',
		'.woocommerce input.button.alt.disabled',
		'.woocommerce input.button.alt.disabled:hover',
		'.woocommerce input.button.alt:disabled',
		'.woocommerce input.button.alt:disabled:hover',
		'.woocommerce input.button.alt:disabled[disabled]',
		'.woocommerce input.button.alt:disabled[disabled]:hover',
		'#wpmm-megamenu .review-total-only',
		'#searchsubmit',
		'.widget .wpt_widget_content #tags-tab-content ul li a',
		'#add_payment_method .wc-proceed-to-checkout a.checkout-button',
		'.woocommerce-cart .wc-proceed-to-checkout a.checkout-button',
		'.woocommerce-checkout .wc-proceed-to-checkout a.checkout-button',
		'.woocommerce #respond input#submit.alt',
		'.woocommerce a.button.alt',
		'.woocommerce button.button.alt',
		'.woocommerce input.button.alt',
		'.woocommerce-account .woocommerce-MyAccount-navigation li.is-active',
		'.widget #wp-subscribe form::after',
		'.button',
		'.instagram-button a',
		'.woocommerce .woocommerce-widget-layered-nav-dropdown__submit',
		'.layout-subscribe form:after',
		'.f-widget .widget #wp-subscribe form:after',
		'.widget .sbutton',
		'.owl-prev:hover, .owl-next:hover',
		'.woocommerce .widget_price_filter .ui-slider .ui-slider-handle',
		'.woocommerce .widget_price_filter .ui-slider .ui-slider-range',
		'.latestPost-review-wrapper',
		'.latestPost .review-type-circle.latestPost-review-wrapper',
		'.woocommerce span.onsale',
		'.post-info > span::after',
		'.widget .widget_wp_review_tab .review-total-only.large-thumb',
		'.widget .review-total-only.large-thumb',
		'.widget #wp-subscribe .title:after',
		'.widget #wp-subscribe input.submit',
		'#sidebar .widget .wpt_widget_content .tab_title.selected a',
		'#sidebar .widget .wp_review_tab_widget_content .tab_title.selected a',
		'.tags a',
		'#move-to-top',
		'.sidebar .widget.widget_categories li.current-cat a',
		'.sidebar .widget.widget_categories li.current-cat a:hover',
		'.aboutme-widget .aboutme-social a',
		'.page-numbers.prev',
		'.page-numbers.next',
		'.shareit.shareit-circular.circular .social-icon',
		'.author-social a',
		'#commentform input#submit',
		'#mtscontact_submit',
	);

	purple_merge_value( $css['global'][ purple_implode( $elements ) ], Purple_Sanitize::background( purple_get_settings( 'mts_button_background' ) ) );

	//-webkit-linear-gradient( 65deg, rgb(108,98,255) 0%, rgb(161,121,255) 100%);

	//Buttons Background Hover Color
	$elements = array(
		'.shareit.shareit-circular.circular .social-icon:hover',
		'#commentform input#submit:hover',
		'#mtscontact_submit:hover',
		'.author-social a:hover',
		'.tags a:hover',
		'.tagcloud a:hover',
		'#move-to-top:hover',
		'.aboutme-widget .aboutme-social a:hover',
		'.widget #wp-subscribe input.submit:hover',
		'.error404 .sbutton:hover',
		'.search .sbutton:hover',
		'.widget .sbutton:hover',
		'.mts-subscribe input[type="submit"]:hover',
		'.widget_product_search button[type="submit"]:hover',
		'.instagram-button a:hover',
	);
	$css['global'][ purple_implode( $elements ) ]['background'] = Purple_Sanitize::color( purple_get_settings( 'mts_button_hover_background' ) );

	//Primary Color Background
	$elements = array(
		'.single-full-width-header',
	);
	$css['global'][ purple_implode( $elements ) ]['background'] = $purple_color_scheme;

	//Paged header background color
	$paged_header = Purple_Sanitize::background( purple_get_settings( 'mts_main_navigation_background' ) );
	if ( empty( $paged_header['background'] ) ) {
		$css['global']['.paged #header']['background']                   = $purple_color_scheme;
		$css['global']['#header.sticky-navigation-active']['background'] = $purple_color_scheme;
	}

	// Border Color.
	$elements = array(
		'.flex-control-thumbs .flex-active',
		'blockquote',
	);

	$css['global'][ purple_implode( $elements ) ]['border-color'] = $purple_color_scheme;

	// Light Background Color.
	$elements = array(
		'.sidebar .widget.widget_categories li a:hover',
		'.sidebar .widget.widget_archive li a:hover',
		'.sidebar .widget.widget_meta li a:hover',
	);

	$css['global'][ purple_implode( $elements ) ]['background']   = $light_color_scheme;
	$css['global'][ purple_implode( $elements ) ]['border-color'] = $light_color_scheme;

	// Footer Light Background.
	$elements = array(
		'.f-widget ul#recentcomments li',
		'.f-widget .advanced-recent-posts li',
		'.f-widget .popular-posts li',
		'.f-widget .category-posts li ',
		'.f-widget .related-posts-widget li',
		'.f-widget .author-posts-widget li',
		'.f-widget .widget.widget_recent_entries li',
		'.f-widget .widget.widget_rss li',
		'.f-widget .aboutme-widget',
		'footer .wpt_widget_content .tab_title.selected a',
		'footer .wp_review_tab_widget_content .tab_title.selected a',
		'.f-widget .widget_mts_instagram_widget',

	);

	$css['global'][ purple_implode( $elements ) ]['background']   = $footer_light_bg;
	$css['global'][ purple_implode( $elements ) ]['border-color'] = Purple_Sanitize::color( purple_get_settings( 'mts_pagenavigation_hover_bgcolor' ) );

	$css['global']['#secondary-navigation li:hover > a']['border-color'] = Purple_Sanitize::color( purple_get_settings( 'mts_pagenavigation_hover_bgcolor' ) );
	//current item
	$css['global']['#secondary-navigation li.current-menu-item > a']['border-color'] = Purple_Sanitize::color( purple_get_settings( 'mts_pagenavigation_hover_bgcolor' ) );

	$elements = array(
		'#site-footer .f-widget a:hover',
		'.featured-area-section .widget a:hover',
		'.nowidget a',
		'#copyright-note a:hover',
	);
	$css['global'][ purple_implode( $elements ) ]['color'] = Purple_Sanitize::color( purple_get_settings( 'mts_pagenavigation_hover_bgcolor' ) );

	$elements = array(
		'footer .wpt_widget_content .tab_title.selected a',
		'footer .wp_review_tab_widget_content .tab_title.selected a',
		'#site-footer .widget #wp-subscribe input.submit',
	);
	$css['global'][ purple_implode( $elements ) ]['background'] = Purple_Sanitize::color( purple_get_settings( 'mts_pagenavigation_hover_bgcolor' ) );

}

/**
 * Sidebar Position
 *
 * @param array $css Array of dynamic CSS.
 */
function purple_sidebar_position( &$css ) {

	// Sidebar position.
	$sidebar_position = purple_get_settings( 'mts_layout' );

	$sidebar_metabox_location = '';
	if ( is_page() || is_single() ) {
		$sidebar_metabox_location = get_post_meta( get_the_ID(), '_mts_sidebar_location', true );
	}

	if ( 'right' !== $sidebar_metabox_location && ( 'sclayout' === $sidebar_position || 'left' === $sidebar_metabox_location ) ) {
		$css['global']['.article']['float']                = 'right';
		$css['global']['.sidebar.c-4-12']['float']         = 'left';
		$css['global']['.sidebar.c-4-12']['padding-right'] = 0;

		if ( null !== purple_get_settings( 'mts_social_button_position' ) && 'floating' === purple_get_settings( 'mts_social_button_position' ) ) {
			$css['global']['.shareit.floating']['margin']                = '0 760px 0';
			$css['global']['.shareit.floating']['border-left']           = '0';
			$css['global']['.shareit.shareit-circular.floating']['left'] = '97%';
		}
	}
}

/**
 * Header
 *
 * @param array $css Array of dynamic CSS.
 */
function purple_header( &$css ) {

	// header class.
	$header_class = array(
		'#header',
	);
	purple_merge_value( $css['global'][ purple_implode( $header_class ) ], Purple_Sanitize::margin( purple_get_settings( 'mts_header_margin' ) ) );
	purple_merge_value( $css['global'][ purple_implode( $header_class ) ], Purple_Sanitize::padding( purple_get_settings( 'mts_header_padding' ) ) );
	// Header Border.
	$header_border = Purple_Sanitize::border( purple_get_settings( 'mts_header_border' ) );
	$css['global'][ purple_implode( $header_class ) ][ $header_border ['direction'] ] = $header_border ['value'];

	// Main Nav.
	$main_nav_classes = array(
		'#secondary-navigation .navigation ul ul a',
		'#secondary-navigation .navigation ul ul a:link',
		'#secondary-navigation .navigation ul ul a:visited',
	);
	$css['global'][ purple_implode( $main_nav_classes ) ]['color']             = Purple_Sanitize::color( purple_get_settings( 'main_navigation_dropdown_color' ) );
	$css['global']['#secondary-navigation .navigation ul ul a:hover']['color'] = Purple_Sanitize::color( purple_get_settings( 'main_navigation_dropdown_hover_color' ) );

	// Social icons.
	$header_style = purple_get_settings( 'mts_header_style' );
	if ( 'header-default' === $header_style ) {
		$prefix = 'mts';
	} else {
		$prefix = 'top';
	}
	// Header Ad.
	purple_merge_value( $css['global']['.widget-header, .small-header .widget-header'], Purple_Sanitize::margin( purple_get_settings( 'mts_header_adcode_margin' ) ) );

	// Ad-Blocker.
	$css['global']['.navigation-banner']['background'] = Purple_Sanitize::color( purple_get_settings( 'navigation_ad_background' ) );
}

/**
 * Social Share Styling
 *
 * @param array $css Array of dynamic CSS.
 */
function purple_single_social_buttons( &$css ) {

	$social_shadow = purple_get_settings( 'social_styling_box_shadow' );

	// Social share.
	$css['global']['.shareit.floating'] = Purple_Sanitize::background( purple_get_settings( 'social_styling_background' ) );
	purple_merge_value( $css['global']['.shareit.floating'], Purple_Sanitize::margin( purple_get_settings( 'social_styling_margin' ) ) );

	// Social share border.
	$social_border = Purple_Sanitize::border( purple_get_settings( 'social_styling_border' ) );
	$css['global']['.shareit.floating'][ $social_border ['direction'] ] = $social_border ['value'];

	if ( 0 === $social_shadow ) {
		$css['global']['.shareit.floating']['box-shadow'] = 'none';
	}
	$social_button_layout   = purple_get_settings( 'social_button_layout' );
	$social_button_position = purple_get_settings( 'social_floating_button_position' );
	if ( ! empty( $social_button_position ) && is_array( $social_button_position ) ) {
		foreach ( $social_button_position as $key => $position ) {
			$css['global'][ '.shareit.shareit-' . $social_button_layout . '.floating' ][ $key ] = $position;
		}
	}
}

/**
 * Sidebar styling
 *
 * @param array $css Array of dynamic CSS.
 */
function purple_sidebar_styling( &$css ) {

	// Sidebar.
	purple_merge_value( $css['global']['#sidebar .widget'], Purple_Sanitize::background( purple_get_settings( 'mts_sidebar_styling_background' ) ) );
	purple_merge_value( $css['global']['#sidebar .widget'], Purple_Sanitize::margin( purple_get_settings( 'mts_sidebar_styling_margin' ) ) );
	purple_merge_value( $css['global']['#sidebar .widget'], Purple_Sanitize::padding( purple_get_settings( 'mts_sidebar_styling_padding' ) ) );

	// Instagram Full width.
	$sidebar_padding = Purple_Sanitize::padding( purple_get_settings( 'mts_sidebar_styling_padding' ) );
	$total_padding   = (int) $sidebar_padding['padding-left'] / 2 + (int) $sidebar_padding['padding-right'] / 2 . 'px';

	$css['global']['.instagram-posts']['margin'] = '0 -' . $total_padding;
	// Sidebar border.
	$sidebar_border = Purple_Sanitize::border( purple_get_settings( 'sidebar_styling_border' ) );
	$css['global']['#sidebar .widget'][ $sidebar_border['direction'] ] = $sidebar_border['value'];

	// Sidebar title.
	$css['global']['#sidebar .widget h3'] = Purple_Sanitize::background( purple_get_settings( 'mts_sidebar_title_styling_background' ) );
	purple_merge_value( $css['global']['#sidebar .widget h3'], Purple_Sanitize::padding( purple_get_settings( 'mts_sidebar_title_styling_padding' ) ) );
	purple_merge_value( $css['global']['#sidebar .widget h3'], Purple_Sanitize::margin( purple_get_settings( 'mts_sidebar_title_styling_margin' ) ) );
	// Sidebar Title border.
	$sidebar_title_border = Purple_Sanitize::border( purple_get_settings( 'widget_title_border' ) );
	$css['global']['#sidebar .widget h3'][ $sidebar_title_border['direction'] ] = $sidebar_title_border['value'];
}

/**
 * Layout CSS
 *
 * @param array $css Array of dynamic CSS.
 */
function purple_post_layouts( &$css ) {

	$features = purple_get_settings( 'mts_featured_categories' );
	foreach ( $features as $feature ) :

		if ( ! isset( $feature['unique_id'] ) ) {
			continue;
		}

		$category     = $feature['mts_featured_category'];
		$posts_layout = isset( $feature['mts_thumb_layout'] ) ? $feature['mts_thumb_layout'] : '';
		$unique_id    = $feature['unique_id'];

		if ( 'layout-default' === $posts_layout ) :
			$posts_layout = 'default';
		endif;

		// Container Class.
		if ( ! in_array( $posts_layout, array( 'default' ) ) ) :
			$container_class                                     = array(
				'.layout-' . $unique_id,
			);
			$css['global'][ purple_implode( $container_class ) ] = array(
				'width'    => '100%',
				'float'    => 'none',
				'overflow' => 'visible',
				'position' => 'relative',
			);
		endif;

		// Post area.
		$cat_class = 'cat-latest';
		if ( 'latest' !== $category ) {
			$category  = get_term_by( 'slug', $category, 'category' );
			$cat_class = sanitize_key( $category->name );
		}

		$title_class = '.title-container.title-id-' . $unique_id . ' h3';

		$css['global'][ $title_class ] = Purple_Sanitize::background( purple_get_settings( 'mts_featured_category_title_background_' . $unique_id ) );
		purple_merge_value( $css['global'][ $title_class ], Purple_Sanitize::margin( purple_get_settings( 'mts_featured_category_title_margin_' . $unique_id ) ) );
		purple_merge_value( $css['global'][ $title_class ], Purple_Sanitize::padding( purple_get_settings( 'mts_featured_category_title_padding_' . $unique_id ) ) );
		// Section title border.
		$post_title_border = Purple_Sanitize::border( purple_get_settings( 'post_title_border_' . $unique_id ) );
		$css['global'][ $title_class ][ $post_title_border['direction'] ] = $post_title_border['value'];

		purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'mts_featured_category_title_font_' . $unique_id ) ) );

		if ( 'default' === $posts_layout ) {
			$post_class = '.layout-' . $unique_id;
		} else {
			$post_class = '.article.layout-' . $unique_id;
		}
		//$post_class = '.layout-' . $unique_id;

		if ( ! in_array( $posts_layout, array( 'layout-partners', 'layout-category', 'layout-subscribe', 'layout-ad' ) ) ) :
			// Post border.
			$post_border = Purple_Sanitize::border( purple_get_settings( 'post_border_' . $unique_id ) );
			$css['global'][ $post_class ][ $post_border['direction'] ] = $post_border['value'];
		endif;

		purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'mts_featured_category_font_' . $unique_id ) ) );
		purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'mts_featured_category_excerpt_font_' . $unique_id ) ) );
		purple_merge_value( $css['global'][ $post_class . ' .latestPost .post-info' ], Purple_Sanitize::padding( purple_get_settings( 'mts_meta_info_padding_' . $unique_id ) ) );

		/**
		 * Meta info
		 */
		purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'mts_meta_info_font_' . $unique_id ) ) );
		purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'post_number_font_' . $unique_id ) ) );
		purple_merge_value( $css['global'][ $post_class . ' .latestPost .post-info' ], Purple_Sanitize::margin( purple_get_settings( 'mts_meta_info_margin_' . $unique_id ) ) );
		//Post Number
		purple_merge_value( $css['global'][ $post_class . ' .post-number' ], Purple_Sanitize::background( purple_get_settings( 'post_number_background_' . $unique_id ) ) );
		if ( is_paged() ) {
			$post_class = '.layout-' . $unique_id;
			purple_merge_value( $css['global'][ $post_class . ' .post-number' ], Purple_Sanitize::background( purple_get_settings( 'post_number_background_' . $unique_id ) ) );
		}
		// Post border.
		$meta_info_border = Purple_Sanitize::border( purple_get_settings( 'post_meta_info_border_' . $unique_id ) );
		$css['global'][ purple_implode( $post_class . ' .latestPost .post-info' ) ][ $meta_info_border['direction'] ] = $meta_info_border['value'];

		// Layout Partners, Layout Subscribe and Layout ad.
		if ( in_array( $posts_layout, array( 'default', 'layout-1', 'layout-partners', 'layout-subscribe', 'layout-ad' ) ) ) :
			if ( 'default' === $posts_layout ) {
				$class = array(
					'.layout-' . $unique_id,
				);
			} else {
				$class = array(
					'.article.layout-' . $unique_id,
				);
			}
			$css['global'][ purple_implode( $class ) ] = Purple_Sanitize::background( purple_get_settings( 'mts_featured_category_background_' . $unique_id ) );
			purple_merge_value( $css['global'][ purple_implode( $class ) ], Purple_Sanitize::margin( purple_get_settings( 'mts_featured_category_margin_' . $unique_id ) ) );
			purple_merge_value( $css['global'][ purple_implode( $class ) ], Purple_Sanitize::padding( purple_get_settings( 'mts_featured_category_padding_' . $unique_id ) ) );

			// Post border.
			$post_border = Purple_Sanitize::border( purple_get_settings( 'post_border_' . $unique_id ) );
			$css['global'][ purple_implode( $class ) ][ $post_border['direction'] ] = $post_border['value'];
		endif;

		// Layout Category.
		if ( 'layout-category' === $posts_layout && ! empty( purple_get_settings( 'cat_section_' . $unique_id ) ) && is_array( purple_get_settings( 'cat_section_' . $unique_id ) ) ) :
			$categories = purple_get_settings( 'cat_section_' . $unique_id );

			// Background Margin Padding for layout category.
			$class = array(
				'.article.layout-' . $unique_id . ' .layout-category .wrapper',
			);

			$css['global'][ purple_implode( $class ) ] = Purple_Sanitize::background( purple_get_settings( 'mts_featured_category_background_' . $unique_id ) );
			purple_merge_value( $css['global'][ purple_implode( $class ) ], Purple_Sanitize::margin( purple_get_settings( 'mts_featured_category_margin_' . $unique_id ) ) );
			purple_merge_value( $css['global'][ purple_implode( $class ) ], Purple_Sanitize::padding( purple_get_settings( 'mts_featured_category_padding_' . $unique_id ) ) );

			// Post border.
			$post_border = Purple_Sanitize::border( purple_get_settings( 'post_border_' . $unique_id ) );
			$css['global'][ purple_implode( $class ) ][ $post_border['direction'] ] = $post_border['value'];

		endif;

		// Layout Partners.
		if ( 'layout-partners' === $posts_layout ) :
			purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'partners_title_font_' . $unique_id ) ) );
		endif;

		// Layout Subscribe.
		if ( 'layout-subscribe' === $posts_layout ) :
			$input_class                                 = '.article.layout-' . $unique_id . ' .layout-subscribe #wp-subscribe input.email-field, .article.layout-' . $unique_id . ' .layout-subscribe #wp-subscribe input.name-field';
			$css['global'][ $input_class ]['background'] = Purple_Sanitize::color( purple_get_settings( 'subscribe_input_background_' . $unique_id ) );
			purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'subscribe_title_font_' . $unique_id ) ) );
			purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'subscribe_input_font_' . $unique_id ) ) );
			purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'subscribe_text_font_' . $unique_id ) ) );
			purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'subscribe_small_text_font_' . $unique_id ) ) );

			// Alignment.
			$alignment   = purple_get_settings( 'subscribe_alignment_' . $unique_id );
			$align_class = array(
				'.article.layout-' . $unique_id . ' .wp-subscribe-wrap',
				'.article.layout-' . $unique_id . ' #wp-subscribe p.text',
			);
			if ( 'left' === $alignment ) :
				$css['global'][ purple_implode( $align_class ) ]['text-align'] = 'left';
			elseif ( 'right' === $alignment ) :
				$css['global'][ purple_implode( $align_class ) ]['text-align'] = 'right';
			endif;

			// Input fields size.
			$input_size  = purple_get_settings( 'subscribe_input_size_' . $unique_id );
			$input_class = array(
				'.layout-' . $unique_id . ' .layout-subscribe #wp-subscribe input.email-field',
				'.layout-' . $unique_id . ' .layout-subscribe #wp-subscribe input.name-field',
				'.layout-' . $unique_id . ' .layout-subscribe .widget #wp-subscribe input.submit',
			);
			if ( 'large' === $input_size ) :
				$css['global'][ purple_implode( $input_class ) ]['width'] = '100%';
			endif;

			// Subscribe Social icons
			if ( purple_get_settings( 'subscribe_social_icons_' . $unique_id ) && ! empty( purple_get_settings( 'subscribe_social_' . $unique_id ) ) && is_array( purple_get_settings( 'subscribe_social_' . $unique_id ) ) ) :
				$subscribe_icons = purple_get_settings( 'subscribe_social_' . $unique_id );
				foreach ( $subscribe_icons as $subscribe_icon ) :
					//$footer_icons[] = $footer_nav_icon['footer_logo_social_icon'];
					$css['global'][ '.layout-' . $unique_id . ' .subscribe-social-icons a.subscribe-' . $subscribe_icon['subscribe_social_icon'] ]['background-color']            = Purple_Sanitize::color( $subscribe_icon['subscribe_social_bgcolor'] );
					$css['global'][ '.layout-' . $unique_id . ' .subscribe-social-icons a.subscribe-' . $subscribe_icon['subscribe_social_icon'] . ':hover' ]['background-color'] = Purple_Sanitize::color( $subscribe_icon['subscribe_social_hover_bgcolor'] );
					$css['global'][ '.layout-' . $unique_id . ' .subscribe-social-icons a.subscribe-' . $subscribe_icon['subscribe_social_icon'] ]['color']                       = Purple_Sanitize::color( $subscribe_icon['subscribe_social_color'] );
					$css['global'][ '.layout-' . $unique_id . ' .subscribe-social-icons a.subscribe-' . $subscribe_icon['subscribe_social_icon'] . ':hover' ]['color']            = Purple_Sanitize::color( $subscribe_icon['subscribe_social_hover_color'] );
					//Border radius
					$css['global'][ '.layout-' . $unique_id . ' .subscribe-social-icons a.subscribe-' . $subscribe_icon['subscribe_social_icon'] ]['border-radius'] = Purple_Sanitize::size( $subscribe_icon['subscribe_social_border_radius'] . 'px' );
				endforeach;
				// Footer Nav Social icons font size.
				//foreach ( $subscribe_icons as $subscribe_icon ) :
					$css['global'][ '.layout-' . $unique_id . ' .subscribe-social-icons  a' ]['width']       = Purple_Sanitize::size( purple_get_settings( 'subscribe_social_width_' . $unique_id ) . 'px' );
					$css['global'][ '.layout-' . $unique_id . ' .subscribe-social-icons  a' ]['line-height'] = Purple_Sanitize::size( purple_get_settings( 'subscribe_social_height_' . $unique_id ) . 'px' );
					//font size
					$css['global'][ '.layout-' . $unique_id . ' .subscribe-social-icons  a' ]['font-size'] = Purple_Sanitize::size( purple_get_settings( 'subscribe_social_font_size_' . $unique_id ) . 'px' );
				//endforeach;
			endif;

		endif;

	endforeach;
}

/**
 * Featured Area
 *
 * @param array $css Array of dynamic CSS.
 */
function purple_featured_area( &$css ) {
	// Featured title font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'featured_area_title_font' ) ) );
	// Featured Subtitle font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'featured_area_subtitle_font' ) ) );
	// Featured description font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'featured_area_desc_font' ) ) );
	// Featured subscribe title font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'featured_subscribe_title_font' ) ) );
	// Featured subscribe subtitle font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'featured_subscribe_text_font' ) ) );
	// Featured subscribe input font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'featured_subscribe_input_font' ) ) );
	// Featured subscribe submit font.
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'featured_subscribe_submit_font' ) ) );
	// Subscribe Box Input fields.
	$featured_subscribe_input_class = array(
		'.featured-subscribe #wp-subscribe input.email-field',
		'.featured-subscribe #wp-subscribe input.name-field',
	);
	$css['global'][ purple_implode( $featured_subscribe_input_class ) ]['background-color']   = Purple_Sanitize::color( purple_get_settings( 'featured_subscribe_input_background' ) );
	$css['global'][ purple_implode( $featured_subscribe_input_class ) ]['height']             = Purple_Sanitize::size( purple_get_settings( 'featured_subscribe_input_height' ) . 'px' );
	$css['global'][ purple_implode( $featured_subscribe_input_class ) ]['line-height']        = Purple_Sanitize::size( purple_get_settings( 'featured_subscribe_input_height' ) . 'px' );
	$css['global']['.featured-subscribe .widget #wp-subscribe input.submit']['height']        = Purple_Sanitize::size( purple_get_settings( 'featured_subscribe_input_height' ) . 'px' );
	$css['global']['.featured-subscribe .widget #wp-subscribe input.submit']['line-height']   = Purple_Sanitize::size( purple_get_settings( 'featured_subscribe_input_height' ) . 'px' );
	$css['global'][ purple_implode( $featured_subscribe_input_class ) ]['border-radius']      = Purple_Sanitize::size( purple_get_settings( 'featured_subscribe_input_border_radius' ) . 'px' );
	$css['global']['.featured-subscribe .widget #wp-subscribe input.submit']['border-radius'] = Purple_Sanitize::size( purple_get_settings( 'featured_subscribe_input_border_radius' ) . 'px' );
	purple_merge_value( $css['global']['.featured-subscribe .widget #wp-subscribe input.submit'], Purple_Sanitize::background( purple_get_settings( 'featured_subscribe_submit_background' ) ) );

	$alignment = purple_get_settings( 'featured_area_image_position' );
	if ( 'left' === $alignment ) {
		$css['global']['.featured-area-section .featured-left']['float']              = 'right';
		$css['global']['.featured-area-section .featured-left']['text-align']         = 'right';
		$css['global']['.featured-area-section .featured-subscribe']['padding-left']  = '20px';
		$css['global']['.featured-area-section .featured-subscribe']['padding-right'] = '0!important';
		$css['global']['.featured-area-section .featured-right']['right']             = 'inherit';
		$css['global']['.featured-area-section .featured-right']['left']              = '0';
	}

	// featured Subscribe Box Input border.
	$featured_subscribe_box_input_border = Purple_Sanitize::border( purple_get_settings( 'featured_subscribe_input_border' ) );
	$css['global'][ purple_implode( $featured_subscribe_input_class ) ][ $featured_subscribe_box_input_border ['direction'] ] = $featured_subscribe_box_input_border ['value'];
}

/**
 * Pagination
 *
 * @param array $css Array of dynamic CSS.
 */
function purple_post_pagination( &$css ) {

	// Pagination Active class.
	$pagination_class_active = array(
		'.pace .pace-progress',
		'.page-numbers.current',
		'.pagination a:hover',
		'#mobile-menu-wrapper ul li a:hover',
		'#load-posts a:hover',
	);
	$pagination_class        = array(
		'.pagination a',
		'#load-posts a',
		'.single .pagination > .current > .currenttext',
		'.pagination .page-numbers.dots',
	);
	if ( '1' == purple_get_settings( 'mts_pagenavigation_type' ) ) {
		purple_merge_value( $css['global'][ purple_implode( array_merge( $pagination_class_active, $pagination_class ) ) ], Purple_Sanitize::margin( purple_get_settings( 'mts_pagenavigation_margin' ) ) );
		purple_merge_value( $css['global'][ purple_implode( array_merge( $pagination_class_active, $pagination_class ) ) ], Purple_Sanitize::padding( purple_get_settings( 'mts_pagenavigation_padding' ) ) );
		//Border Radius
		$css['global'][ purple_implode( $pagination_class ) ]['border-radius']        = Purple_Sanitize::size( purple_get_settings( 'mts_pagenavigation_border_radius' ) . 'px' );
		$css['global'][ purple_implode( $pagination_class_active ) ]['border-radius'] = Purple_Sanitize::size( purple_get_settings( 'mts_pagenavigation_border_radius' ) . 'px' );
		// Pagination border.
		$pagination_border = Purple_Sanitize::border( purple_get_settings( 'pagenavigation_border' ) );
		$css['global'][ purple_implode( $pagination_class ) ][ $pagination_border ['direction'] ] = $pagination_border ['value'];
	} else {
		purple_merge_value( $css['global'][ purple_implode( array_merge( $pagination_class_active, $pagination_class ) ) ], Purple_Sanitize::padding( purple_get_settings( 'load_more_padding' ) ) );
		purple_merge_value( $css['global'][ purple_implode( array_merge( $pagination_class_active, $pagination_class ) ) ], Purple_Sanitize::margin( purple_get_settings( 'load_more_margin' ) ) );
		//Border Radius
		$css['global'][ purple_implode( $pagination_class ) ]['border-radius']        = Purple_Sanitize::size( purple_get_settings( 'mts_loadmore_border_radius' ) . 'px' );
		$css['global'][ purple_implode( $pagination_class_active ) ]['border-radius'] = Purple_Sanitize::size( purple_get_settings( 'mts_loadmore_border_radius' ) . 'px' );
		// Load More border.
		$load_more_border = Purple_Sanitize::border( purple_get_settings( 'load_more_border' ) );
		$css['global'][ purple_implode( $pagination_class ) ][ $load_more_border ['direction'] ] = $load_more_border ['value'];
	}
	$css['global'][ purple_implode( $pagination_class ) ]['background-color']        = Purple_Sanitize::color( purple_get_settings( 'mts_pagenavigation_bgcolor' ) );
	$css['global'][ purple_implode( $pagination_class_active ) ]['background-color'] = Purple_Sanitize::color( purple_get_settings( 'mts_pagenavigation_hover_bgcolor' ) );
	$css['global'][ purple_implode( $pagination_class ) ]['color']                   = Purple_Sanitize::color( purple_get_settings( 'mts_pagenavigation_color' ) );
	$css['global'][ purple_implode( $pagination_class_active ) ]['color']            = Purple_Sanitize::color( purple_get_settings( 'mts_pagenavigation_hover_color' ) );

	// Load more Alignment.
	$load_more_align = purple_get_settings( 'load_more_alignment' );
	if ( 'left' === $load_more_align ) :
		$css['global']['#load-posts']['text-align'] = 'left';
	elseif ( 'right' === $load_more_align ) :
		$css['global']['#load-posts']['text-align'] = 'right';
	elseif ( 'full' === $load_more_align ) :
		$css['global']['#load-posts a']['width'] = '100%';
	endif;
}

/**
 * Single
 *
 * @param array $css Array of dynamic CSS.
 */
function purple_single( &$css ) {

	// Single, Page, Archive, Search, Category and 404 Page Background.
	$page_classes = array(
		'.single .single_post',
		'.page .article',
		'.error404 .article',
	);

	$css['global'][ purple_implode( $page_classes ) ] = Purple_Sanitize::background( purple_get_settings( 'single_background' ) );

	// Margin, Padding, Border and Box Shadow.
	purple_merge_value( $css['global'][ purple_implode( $page_classes ) ], Purple_Sanitize::margin( purple_get_settings( 'mts_single_styling_margin' ) ) );
	purple_merge_value( $css['global'][ purple_implode( $page_classes ) ], Purple_Sanitize::padding( purple_get_settings( 'mts_single_styling_padding' ) ) );
	// Single border.
	$single_border = Purple_Sanitize::border( purple_get_settings( 'single_styling_border' ) );
	$css['global'][ purple_implode( $page_classes ) ][ $single_border ['direction'] ] = $single_border ['value'];

	// Featured image Full width.
	$single_padding = Purple_Sanitize::padding( purple_get_settings( 'mts_single_styling_padding' ) );
	$total_padding  = (int) $single_padding['padding-left'] / 2 + (int) $single_padding['padding-right'] / 2 . 'px';
	$total_width    = (int) $single_padding['padding-left'] + (int) $single_padding['padding-right'] . 'px';

	$css['global']['.single-featured-image']['width']     = 'calc(100% + ' . $total_width . ')';
	$css['global']['.single-featured-image']['max-width'] = 'calc(100% + ' . $total_width . ')';
	$css['global']['.single-featured-image']['margin']    = '-' . $single_padding['padding-top'] . ' -' . $total_padding . ' 30px -' . $total_padding;

	//Gutenberg alignwide
	$css['global']['article .alignwide']['width']     = 'calc(100% + ' . $total_width . ')';
	$css['global']['article .alignwide']['max-width'] = 'calc(100% + ' . $total_width . ')';
	$css['global']['article .alignwide']['margin']    = '0  -' . $total_padding . ' 30px -' . $total_padding;
	//Gutenberg alignfull
	$css['global']['article .sidebar-right .alignfull']['margin-right'] = '-' . $total_padding;
	$css['global']['article .sidebar-left .alignfull']['margin-left']   = '-' . $total_padding;

	// Min height of single post full width header from here
	$css['global']['.single-full-width-header .container']['min-height'] = Purple_Sanitize::size( purple_get_settings( 'full_width_header_height' ) . 'px' );

	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'mts_single_meta_info_font' ) ) );

	// Related Posts.
	if ( 'default' !== purple_get_settings( 'related_posts_layouts' ) ) :
		$css['global']['.related-posts'] = Purple_Sanitize::background( purple_get_settings( 'related_posts_background' ) );
	endif;
	// Default.
	if ( 'default' === purple_get_settings( 'related_posts_layouts' ) ) :
		$css['global']['.related-posts:after'] = Purple_Sanitize::background( purple_get_settings( 'related_posts_background' ) );
	endif;
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'related_posts_font' ) ) );
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'related_posts_meta_font' ) ) );
	purple_merge_value( $css['global']['.related-posts'], Purple_Sanitize::margin( purple_get_settings( 'related_posts_margin' ) ) );
	purple_merge_value( $css['global']['.related-posts'], Purple_Sanitize::padding( purple_get_settings( 'related_posts_padding' ) ) );
	if ( 'default' === purple_get_settings( 'related_posts_layouts' ) ) :
		purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'related_posts_excerpt_font' ) ) );
	endif;
	purple_map_css_selectors( $css['global'], Purple_Sanitize::typography( purple_get_settings( 'related_post_number_font' ) ) );
	purple_merge_value( $css['global']['.related-posts .post-number'], Purple_Sanitize::background( purple_get_settings( 'related_post_number_background' ) ) );

	// Related Posts articles.
	$css['global']['.related-posts article'] = Purple_Sanitize::background( purple_get_settings( 'related_article_background' ) );
	purple_merge_value( $css['global']['.related-posts article'], Purple_Sanitize::padding( purple_get_settings( 'related_article_padding' ) ) );
	purple_merge_value( $css['global']['.related-posts article header'], Purple_Sanitize::padding( purple_get_settings( 'related_article_text_padding' ) ) );

	// Meta info Background.
	$css['global']['.full-header-wrapper .post-info']['background-color'] = Purple_Sanitize::color( purple_get_settings( 'single_meta_info_background' ) );

	// Subscribe Box.
	$css['global']['.single-subscribe .widget #wp-subscribe'] = Purple_Sanitize::background( purple_get_settings( 'single_subscribe_background' ) );
	purple_merge_value( $css['global']['.single-subscribe .widget #wp-subscribe'], Purple_Sanitize::margin( purple_get_settings( 'single_subscribe_margin' ) ) );
	purple_merge_value( $css['global']['.single-subscribe .widget #wp-subscribe'], Purple_Sanitize::padding( purple_get_settings( 'single_subscribe_padding' ) ) );
	$css['global']['.single-subscribe .widget #wp-subscribe']['border-radius'] = Purple_Sanitize::size( purple_get_settings( 'single_subscribe_border_radius' ) . 'px' );

	// Subscribe border.
	$subscribe_box = Purple_Sanitize::border( purple_get_settings( 'single_subscribe_border' ) );
	$css['global']['.single-subscribe .widget #wp-subscribe'][ $subscribe_box ['direction'] ] = $subscribe_box ['value'];

	// Subscribe Box Input fields.
	$subscribe_input_class = array(
		'.single-subscribe #wp-subscribe input.email-field',
		'.single-subscribe #wp-subscribe input.name-field',
	);
	$css['global'][ purple_implode( $subscribe_input_class ) ]['background-color']   = Purple_Sanitize::color( purple_get_settings( 'single_subscribe_input_background' ) );
	$css['global'][ purple_implode( $subscribe_input_class ) ]['height']             = Purple_Sanitize::size( purple_get_settings( 'single_subscribe_input_height' ) . 'px' );
	$css['global']['.single-subscribe .widget #wp-subscribe input.submit']['height'] = Purple_Sanitize::size( purple_get_settings( 'single_subscribe_input_height' ) . 'px' );
	$css['global'][ purple_implode( $subscribe_input_class ) ]['border-radius']      = Purple_Sanitize::size( purple_get_settings( 'single_subscribe_input_border_radius' ) . 'px' );
	// Subscribe Box Input border.
	$subscribe_box_input_border = Purple_Sanitize::border( purple_get_settings( 'single_subscribe_input_border' ) );
	$css['global'][ purple_implode( $subscribe_input_class ) ][ $subscribe_box_input_border ['direction'] ] = $subscribe_box_input_border ['value'];

	// Subscribe Box Submit button.
	$css['global']['.single-subscribe .widget #wp-subscribe input.submit']['background']    = Purple_Sanitize::color( purple_get_settings( 'single_subscribe_submit_backgroud' ) );
	$css['global']['.single-subscribe .widget #wp-subscribe input.submit']['border-radius'] = Purple_Sanitize::size( purple_get_settings( 'single_subscribe_submit_border_radius' ) . 'px' );

	// Subscribe Box Submit border.
	$subscribe_box_submit_border = Purple_Sanitize::border( purple_get_settings( 'single_subscribe_submit_border' ) );
	$css['global']['.single-subscribe .widget #wp-subscribe input.submit'][ $subscribe_box_submit_border ['direction'] ] = $subscribe_box_submit_border ['value'];

	purple_merge_value( $css['global']['.single-subscribe .widget #wp-subscribe input.submit'], Purple_Sanitize::padding( purple_get_settings( 'single_subscribe_submit_padding' ) ) );

	// Author Box.
	$css['global']['.postauthor'] = Purple_Sanitize::background( purple_get_settings( 'single_authorbox_background' ) );
	purple_merge_value( $css['global']['.postauthor'], Purple_Sanitize::margin( purple_get_settings( 'single_authorbox_margin' ) ) );
	purple_merge_value( $css['global']['.postauthor'], Purple_Sanitize::padding( purple_get_settings( 'single_authorbox_padding' ) ) );
	$single_authorbox_border = Purple_Sanitize::border( purple_get_settings( 'single_authorbox_border' ) );
	$css['global']['.postauthor'][ $single_authorbox_border ['direction'] ] = $single_authorbox_border ['value'];
	// Author image.
	purple_merge_value( $css['global']['.postauthor img'], Purple_Sanitize::margin( purple_get_settings( 'single_author_image_margin' ) ) );
	$css['global']['.postauthor img']['border-radius'] = Purple_Sanitize::size( purple_get_settings( 'single_author_image_border_radius' ) . 'px' );
	// Author Social
	purple_merge_value( $css['global']['.author-social a'], Purple_Sanitize::margin( purple_get_settings( 'author_social_margin' ) ) );
	purple_merge_value( $css['global']['.author-social a'], Purple_Sanitize::padding( purple_get_settings( 'author_social_padding' ) ) );
	$css['global']['.author-social a']['border-radius'] = Purple_Sanitize::size( purple_get_settings( 'author_social_border_radius' ) . 'px' );

	// Single Page titles Styling.
	$titles_align_class                               = array(
		'.comment-title',
		'#respond',
		'.related-posts-title',
	);
	$titles_class                                     = array(
		'#respond h4',
		'.total-comments',
		'.related-posts h4',
	);
	$css['global'][ purple_implode( $titles_class ) ] = Purple_Sanitize::background( purple_get_settings( 'single_title_background' ) );
	purple_merge_value( $css['global'][ purple_implode( $titles_class ) ], Purple_Sanitize::padding( purple_get_settings( 'single_title_padding' ) ) );
	// Single title border.
	$single_titles_border = Purple_Sanitize::border( purple_get_settings( 'single_title_border' ) );
	$css['global'][ purple_implode( $titles_class ) ][ $single_titles_border ['direction'] ] = $single_titles_border ['value'];

}

/**
 * Copyrights
 *
 * @param array $css Array of dynamic CSS.
 */
function purple_copyrights( &$css ) {

	// copyrights border.
	$copyrights_border = Purple_Sanitize::border( purple_get_settings( 'copyrights_border' ) );
	$css['global']['.copyrights'][ $copyrights_border ['direction'] ] = $copyrights_border ['value'];

}

/**
 * Footer
 *
 * @param array $css Array of dynamic CSS.
 */
function purple_footer( &$css ) {

	// Footer.
	purple_merge_value( $css['global']['#site-footer'], Purple_Sanitize::margin( purple_get_settings( 'mts_top_footer_margin' ) ) );
	purple_merge_value( $css['global']['#site-footer'], Purple_Sanitize::padding( purple_get_settings( 'mts_top_footer_padding' ) ) );

	// Footer widgets.
	if ( 1 === purple_get_settings( 'mts_top_footer' ) && 1 === purple_get_settings( 'mts_top_footer_num' ) ) :
		$css['global']['.footer-widgets']['display']                = 'flex';
		$css['global']['.footer-widgets']['justify-content']        = 'center';
		$css['global']['.footer-widgets .f-widget']['width']        = 'auto';
		$css['global']['.footer-widgets .f-widget']['text-align']   = 'center';
		$css['global']['.footer-widgets .f-widget']['margin-right'] = '0px';
	endif;

	// footer Nav position.
	$footer_sections_position = purple_get_settings( 'footer_sections_position' );
	if ( 1 === purple_get_settings( 'footer_brands_section' ) ) :
		if ( 'left' === $footer_sections_position || 'right' === $footer_sections_position ) :
			$css['global']['#site-footer .container']['display']   = 'flex';
			$css['global']['#site-footer .container']['flex-flow'] = 'row wrap';
			$css['global']['.footer-sections']['flex-basis']       = 'calc(25% - 20px )';
			$css['global']['.footer-sections']['padding-right']    = '20px';
			$css['global']['.footer-widgets']['flex-basis']        = '75%';
			$css['global']['.brands-container']['display']         = 'block';
			$css['global']['.brands-items li']['max-width']        = '100%';
			$css['global']['.brands-items li']['flex-basis']       = '60%';
		endif;
		if ( 'right' === $footer_sections_position ) :
			$css['global']['#site-footer .container']['flex-direction'] = 'row-reverse';
			$css['global']['.footer-sections']['padding-right']         = '0';
			$css['global']['.footer-sections']['padding-left']          = '20px';
			$css['global']['.brands-container']['text-align']           = 'right';
			$css['global']['.brands-items']['justify-content']          = 'flex-end';
		endif;
	endif;

	// Footer Logo Social icons.
	if ( purple_get_settings( 'footer_logo_social_icons' ) && ! empty( purple_get_settings( 'footer_logo_social' ) ) && is_array( purple_get_settings( 'footer_logo_social' ) ) ) :
		$footer_nav_icons = purple_get_settings( 'footer_logo_social' );
		foreach ( $footer_nav_icons as $footer_nav_icon ) :
			$footer_icons[]               = $footer_nav_icon['footer_logo_social_icon'];
			$footer_nav_icon_border_size  = $footer_nav_icon['footer_logo_social_border_size'];
			$footer_nav_icon_border_style = $footer_nav_icon['footer_logo_social_border_style'];
			$footer_nav_icon_border_color = $footer_nav_icon['footer_logo_social_border_color'];
			$footer_nav_icon_border       = $footer_nav_icon_border_size . 'px ' . $footer_nav_icon_border_style . ' ' . $footer_nav_icon_border_color;
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ]['background-color']            = Purple_Sanitize::color( $footer_nav_icon['footer_logo_social_bgcolor'] );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] . ':hover' ]['background-color'] = Purple_Sanitize::color( $footer_nav_icon['footer_logo_social_hover_bgcolor'] );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ]['color']                       = Purple_Sanitize::color( $footer_nav_icon['footer_logo_social_color'] );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] . ':hover' ]['color']            = Purple_Sanitize::color( $footer_nav_icon['footer_logo_social_hover_color'] );
			//Border radius
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ]['border-radius'] = Purple_Sanitize::size( $footer_nav_icon['footer_logo_social_border_radius'] . 'px' );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_nav_icon['footer_logo_social_icon'] ]['border']        = $footer_nav_icon_border;
		endforeach;
		// Footer Nav Social icons font size.
		foreach ( $footer_icons as $footer_icon ) :
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_icon ]['width']       = Purple_Sanitize::size( purple_get_settings( 'footer_logo_social_width' ) . 'px' );
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_icon ]['line-height'] = Purple_Sanitize::size( purple_get_settings( 'footer_logo_social_height' ) . 'px' );
			//font size
			$css['global'][ '.footer-logo-social-icons a.footer-logo-' . $footer_icon ]['font-size'] = Purple_Sanitize::size( purple_get_settings( 'footer_logo_social_font_size' ) . 'px' );
		endforeach;
	endif;

	// Footer Brands Sections.
	$brands_border = Purple_Sanitize::border( purple_get_settings( 'brands_border' ) );
	$css['global']['.brands-container'][ $brands_border ['direction'] ] = $brands_border ['value'];

	// footer brands alignment.
	$footer_brands_align = purple_get_settings( 'footer_brands_alignment' );
	if ( 'center' === $footer_brands_align ) :
		$css['global']['.brands-container']['justify-content'] = 'center';
	elseif ( 'right' === $footer_brands_align ) :
		$css['global']['.brands-container']['justify-content'] = 'flex-end';
	endif;

	// brand container.
	purple_merge_value( $css['global']['.brands-container'], Purple_Sanitize::margin( purple_get_settings( 'brands_margin' ) ) );
	purple_merge_value( $css['global']['.brands-container'], Purple_Sanitize::padding( purple_get_settings( 'brands_padding' ) ) );

}

/**
 * Misc
 *
 * @param array $css Array of dynamic CSS.
 */
function purple_misc_css( &$css ) {

	// Show Logo.
	$show_logo = purple_get_settings( 'mts_header_section2' );

	if ( 0 === $show_logo ) {
		$css['global']['.logo-wrap']['display'] = 'none';
	}

	// Back to top.
	// Border.
	$top_button_border = Purple_Sanitize::border( purple_get_settings( 'top_button_border' ) );
	$css['global']['#move-to-top'][ $top_button_border ['direction'] ] = $top_button_border ['value'];
	// Font-size, Padding and Position.
	$css['global']['#move-to-top .fa']['font-size'] = Purple_Sanitize::size( purple_get_settings( 'top_button_font_size' ) . 'px' );
	purple_merge_value( $css['global']['#move-to-top'], Purple_Sanitize::padding( purple_get_settings( 'top_button_padding' ) ) );
	$top_button_position = purple_get_settings( 'top_button_position' );
	foreach ( $top_button_position as $key => $position ) {
		$css['global']['#move-to-top'][ $key ] = $position;
	}
	// Border-radius.
	$top_border_radius = Purple_Sanitize::margin( purple_get_settings( 'button_border_top_radius' ) );
	//Top, Right, Bottom, Left Radius
	$css['global']['#move-to-top']['border-top-left-radius']     = $top_border_radius['margin-top'];
	$css['global']['#move-to-top']['border-top-right-radius']    = $top_border_radius['margin-right'];
	$css['global']['#move-to-top']['border-bottom-right-radius'] = $top_border_radius['margin-bottom'];
	$css['global']['#move-to-top']['border-bottom-left-radius']  = $top_border_radius['margin-left'];

	// Colors.
	$css['global']['#move-to-top']['color'] = Purple_Sanitize::color( purple_get_settings( 'top_button_color' ) );

	// Subscribe Fields Hover effect
	$purple_color_scheme = Purple_Sanitize::color( purple_get_settings( 'mts_color_scheme' ) );

	$css['global']['.widget #wp-subscribe input.email-field:focus, .widget #wp-subscribe input.name-field:focus']['border']        = '1px solid ' . $purple_color_scheme;
	$css['global']['.widget #wp-subscribe input.email-field:focus, .widget #wp-subscribe input.name-field:focus']['border-left']   = '10px solid ' . $purple_color_scheme;
	$css['global']['.widget #wp-subscribe input.email-field:focus, .widget #wp-subscribe input.name-field:focus']['border-radius'] = '0 4px 4px 0';
}
