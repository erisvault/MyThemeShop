<?php
/**
 * Single Subscribe
 *
 * @package Purple
 */

$menus['single-authorbox'] = array(
	'title' => esc_html__( 'Author Box', 'purple' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of Author box in single posts page.', 'purple' ),
);

$mts_patterns = array(
	'nobg' => array( 'img' => $uri . 'bg-patterns/nobg.png' ),
);
for ( $i = 0; $i <= 52; $i++ ) {
	$mts_patterns[ 'pattern' . $i ] = array( 'img' => $uri . 'bg-patterns/pattern' . $i . '.png' );
}

for ( $i = 1; $i <= 29; $i++ ) {
	$mts_patterns[ 'hbg' . $i ] = array( 'img' => $uri . 'bg-patterns/hbg' . $i . '.png' );
}

$sections['single-authorbox'] = array(

	array(
		'id'    => 'single_authorbox_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Author box Settings', 'purple' ),
	),
	array(
		'id'       => 'single_authorbox_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Author box Background', 'purple' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image for subscribe box from here.', 'purple' ),
		'options'  => array(
			'color'         => '#ffffff',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'single_authorbox_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Margin', 'purple' ),
		'sub_desc' => esc_html__( 'Set Author box margin from here.', 'purple' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '42',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_authorbox_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'purple' ),
		'sub_desc' => esc_html__( 'Set Author box padding from here.', 'purple' ),
		'std'      => array(
			'top'    => '30',
			'right'  => '10%',
			'bottom' => '10',
			'left'   => '10%',
		),
	),
	array(
		'id'       => 'single_authorbox_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'purple' ),
		'sub_desc' => esc_html__( 'Author box border radius.', 'purple' ),
		'std'      => '0',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'single_authorbox_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'purple' ),
		'sub_desc' => esc_html__( 'Select border', 'purple' ),
	),
	array(
		'id'    => 'single_authorbox_author_name_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Author Box Name Font', 'purple' ),
		'std'   => array(
			'preview-text'  => 'Author Box Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '700',
			'font-size'     => '22px',
			'line-height'   => '30px',
			'color'         => '#6c62ff',
			'css-selectors' => '.postauthor h5, .postauthor h5 a',
		),
	),
	array(
		'id'    => 'single_authorbox_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Author Box Text Font', 'purple' ),
		'std'   => array(
			'preview-text'  => 'Author Box Text Font',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '500',
			'font-size'     => '14px',
			'line-height'   => '25px',
			'color'         => '#5e6c84',
			'css-selectors' => '.postauthor p',
		),
	),

	array(
		'id'    => 'single_author_img_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Author Image Settings', 'purple' ),
	),
	array(
		'id'       => 'single_author_image_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Margin', 'purple' ),
		'sub_desc' => esc_html__( 'Set Author image margin from here.', 'purple' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '10',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_author_image_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Border Radius', 'purple' ),
		'sub_desc' => esc_html__( 'Author image border radius.', 'purple' ),
		'std'      => '150',
		'args'     => array( 'type' => 'number' ),
	),

	array(
		'id'    => 'single_authorbox_social_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Author box Social Settings', 'purple' ),
	),

	array(
		'id'       => 'authorbox_social_share',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Author Social Share', 'purple' ),
		'sub_desc' => esc_html__( 'Enable/Disable author social share in the authorbox.', 'purple' ),
		'std'      => '1',
	),
	array(
		'id'         => 'author_social_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'purple' ),
		'sub_desc'   => esc_html__( 'Set author social share margin from here.', 'purple' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '10',
			'bottom' => '20',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'authorbox_social_share',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'author_social_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'purple' ),
		'sub_desc'   => esc_html__( 'Set author social share padding from here.', 'purple' ),
		'std'        => array(
			'top'    => '8',
			'right'  => '8',
			'bottom' => '8',
			'left'   => '8',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'authorbox_social_share',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'author_social_border_radius',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Social border radius', 'purple' ),
		'std'        => '20',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'authorbox_social_share',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

);
