<?php
/**
 * Single Related Posts
 *
 * @package Purple
 */

$menus['single-related'] = array(
	'title' => esc_html__( 'Related Posts', 'purple' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of related posts in single posts page.', 'purple' ),
);

$sections['single-related'] = array(

	array(
		'id'       => 'related_posts_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Related Posts Background', 'purple' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'purple' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'related_posts_layouts',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Related Posts Layouts', 'purple' ),
		'sub_desc' => esc_html__( 'Choose the Related Posts layouts for your site.', 'purple' ),
		'options'  => array(
			'default'  => array( 'img' => $uri . 'related/r1.jpg' ),
			'related2' => array( 'img' => $uri . 'related/r2.jpg' ),
			'related3' => array( 'img' => $uri . 'related/r3.jpg' ),
			'related5' => array( 'img' => $uri . 'related/r5.jpg' ),
			'related6' => array( 'img' => $uri . 'related/r6.jpg' ),
		),
		'std'      => 'default',
	),

	array(
		'id'         => 'related_posts_grid',
		'type'       => 'select',
		'class'      => 'small',
		'title'      => esc_html__( 'Grid', 'purple' ),
		'sub_desc'   => esc_html__( 'Select the number of grid for Related Posts.', 'purple' ),
		'options'    => array(
			'grid2' => esc_html__( '2', 'purple' ),
			'grid3' => esc_html__( '3', 'purple' ),
			'grid4' => esc_html__( '4', 'purple' ),
			'grid5' => esc_html__( '5', 'purple' ),
			'grid6' => esc_html__( '6', 'purple' ),
		),
		'std'        => 'grid2',
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'default',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_related_postsnum',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Number of related posts', 'purple' ),
		'sub_desc' => esc_html__( 'Enter the number of posts to show in the related posts section.', 'purple' ),
		'std'      => '2',
		'args'     => array(
			'type' => 'number',
		),
	),

	array(
		'id'         => 'related_post_number',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Post Number', 'blocks' ),
		'sub_desc'   => esc_html__( 'Use this button to show or hide post numbers.', 'blocks' ),
		'std'        => '1',
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'default',
				'comparison' => '==',
			),
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'related2',
				'comparison' => '==',
			),
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'related5',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'related_post_number_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Post Number Background', 'purple' ),
		'sub_desc'   => esc_html__( 'Set post number background color, pattern and image from here.', 'purple' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '#6c62ff',
			'use'           => 'gradient',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => '',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#6C62FF',
				'to'        => '#A179FF',
				'direction' => '60deg',
			),
			'parallax'      => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'related_post_number',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'related_post_number_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Post Number Font', 'purple' ),
		'std'        => array(
			'preview-text'  => 'Post Number Font',
			'preview-color' => 'dark',
			'font-family'   => 'Montserrat',
			'font-weight'   => '900',
			'font-size'     => '35px',
			'color'         => '#ffffff',
			'css-selectors' => '.related-posts .post-number',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'related_post_number',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'related_posts_adcode',
		'type'       => 'ace_editor',
		'mode'       => 'html',
		'title'      => esc_html__( 'Related Posts Ad', 'purple' ),
		'sub_desc'   => esc_html__( 'Paste your Adsense, BSA or other ad code here to show ads in Related Posts Area.', 'purple' ),
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'related5',
				'comparison' => '==',
			),
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'related6',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'related_posts_position',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Related Posts Position', 'purple' ),
		'sub_desc' => esc_html__( 'Choose the position for related posts, below content will be Full width', 'purple' ),
		'options'  => array(
			'default' => esc_html__( 'Default', 'purple' ),
			'full'    => esc_html__( 'Below Content', 'purple' ),
		),
		'std'      => 'default',
	),

	array(
		'id'       => 'related_post_meta_info',
		'type'     => 'multi_checkbox',
		'title'    => esc_html__( 'Post Meta Info', 'purple' ),
		'sub_desc' => esc_html__( 'Show or hide post meta info.', 'purple' ),
		'options'  => array(
			'author'   => esc_html__( 'Author Name', 'purple' ),
			'time'     => esc_html__( 'Time/Date', 'purple' ),
			'category' => esc_html__( 'Category', 'purple' ),
			'comment'  => esc_html__( 'Comments', 'purple' ),
		),
		'std'      => array(),
	),

	array(
		'id'       => 'related_posts_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Margin', 'purple' ),
		'sub_desc' => esc_html__( 'Set related posts margin from here.', 'purple' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '30px',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'related_posts_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'purple' ),
		'sub_desc' => esc_html__( 'Set related posts padding from here.', 'purple' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),

	array(
		'id'    => 'related_post_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Related Post Section Title Typography', 'purple' ),
		'std'   => array(
			'preview-text'   => 'Related Post Section Title Typography',
			'preview-color'  => 'light',
			'font-family'    => 'Montserrat',
			'font-weight'    => '700',
			'font-size'      => '22px',
			'line-height'    => '42px',
			'color'          => '#6a61fc',
			'additional-css' => 'text-align: center;',
			'css-selectors'  => '.related-posts h4',
		),
	),

	array(
		'id'    => 'related_posts_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Related Posts Title', 'purple' ),
		'std'   => array(
			'preview-text'  => 'Related Posts Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '700',
			'font-size'     => '27px',
			'line-height'   => '40px',
			'color'         => '#253858',
			'css-selectors' => '.related-posts .title a',
		),
	),

	array(
		'id'         => 'related_posts_excerpt_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Related Posts Excerpt', 'purple' ),
		'std'        => array(
			'preview-text'  => 'Related Posts Excerpt Font',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '500',
			'font-size'     => '14px',
			'line-height'   => '25px',
			'color'         => '#5e6c84',
			'css-selectors' => '.related-posts .front-view-content',
		),
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'related_posts_layouts',
				'value'      => 'default',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'    => 'related_posts_meta_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Related Posts Meta Info', 'purple' ),
		'std'   => array(
			'preview-text'  => 'Related Posts Meta Info Font',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '500',
			'font-size'     => '14px',
			'color'         => '#6c62ff',
			'css-selectors' => '.related-posts .post-info, .related-posts .post-info a',
			'dependency'    => array(
				'relation' => 'and',
				array(
					'field'      => 'related_posts_layouts',
					'value'      => 'default',
					'comparison' => '==',
				),
			),
		),
	),

	array(
		'id'    => 'related_posts_article_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Related Posts Articles', 'purple' ),
	),

	array(
		'id'       => 'related_article_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Related Posts Background', 'purple' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'purple' ),
		'options'  => array(
			'color'         => '#ffffff',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'related_article_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Articles Padding', 'purple' ),
		'sub_desc' => esc_html__( 'Set related posts articles padding from here.', 'purple' ),
		'std'      => array(
			'left'   => '0',
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
		),
	),

	array(
		'id'       => 'related_article_text_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Articles Text Padding', 'purple' ),
		'sub_desc' => esc_html__( 'Set related posts articles text padding from here.', 'purple' ),
		'std'      => array(
			'top'    => '40px',
			'right'  => '40px',
			'bottom' => '35px',
			'left'   => '40px',
		),
	),

);
