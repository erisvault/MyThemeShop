<?php
/**
 * Top Bar
 *
 * @package Purple
 */

$menus['header']['child']['header-featured-section'] = array(
	'title' => esc_html__( 'Featured Area', 'purple' ),
	'desc'  => esc_html__( 'From here, you can control the featured area section from here.', 'purple' ),
);

$sections['header-featured-section'] = array(

	array(
		'id'       => 'featured_area',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Featured Area', 'purple' ),
		// translators: Primary Navigation Menu with strong tag.
		'sub_desc' => sprintf( esc_html__( 'Use this button to enable %s.', 'purple' ), '<strong>' . esc_html__( 'Featured Area', 'purple' ) . '</strong>' ),
		'std'      => '1',
	),

	array(
		'id'         => 'featured_area_title',
		'type'       => 'text',
		'title'      => esc_html__( 'Featured Title', 'purple' ),
		'sub_desc'   => esc_html__( 'Enter title from here.', 'purple' ),
		'std'        => esc_html__( 'Julia Conner', 'purple' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_area_subtitle',
		'type'       => 'text',
		'title'      => esc_html__( 'Featured Subtitle', 'purple' ),
		'sub_desc'   => esc_html__( 'Enter subtitle from here.', 'purple' ),
		'std'        => esc_html__( 'Professional Blogger', 'purple' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_area_desc',
		'type'       => 'text',
		'title'      => esc_html__( 'Featured Description', 'purple' ),
		'sub_desc'   => esc_html__( 'Enter description from here.', 'purple' ),
		'std'        => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo enim ipsam voluptatem ', 'purple' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_area_image',
		'type'       => 'upload',
		'title'      => esc_html__( 'Upload Image', 'purple' ),
		'sub_desc'   => wp_kses( __( 'Upload Featured Area Image from here <strong>Recommend Size 555x462px</strong>. This image will be shown on the right side of Featured Area section', 'purple' ), array( 'strong' => array() ) ),
		'return'     => 'url',
		'std'        => get_template_directory_uri() . '/images/featured-area-author.png',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_area_image_position',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Image Position', 'purple' ),
		'options'    => array(
			'right' => esc_html__( 'Left Side', 'purple' ),
			'left'  => esc_html__( 'Right Side', 'purple' ),
		),
		'sub_desc'   => esc_html__( 'Choose image position for featured area section.', 'purple' ),
		'std'        => 'right',
		'class'      => 'green',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_area_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Featured Area Background', 'purple' ),
		'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'purple' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '',
			'use'           => 'upload',
			'image_pattern' => 'nobg',
			'image_upload'  => get_template_directory_uri() . '/images/featured-area.jpg',
			'repeat'        => 'no-repeat',
			'attachment'    => 'scroll',
			'position'      => '',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_area_title_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Featured Title Font', 'purple' ),
		'std'        => array(
			'preview-text'   => 'Featured Title Font',
			'preview-color'  => 'dark',
			'font-family'    => 'Montserrat',
			'font-weight'    => '900',
			'font-size'      => '60px',
			'line-height'    => '1.1',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.featured-area-title',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_area_subtitle_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Featured Subtitle Font', 'purple' ),
		'std'        => array(
			'preview-text'   => 'Featured Title Font',
			'preview-color'  => 'dark',
			'font-family'    => 'Montserrat',
			'font-weight'    => '600',
			'font-size'      => '20px',
			'color'          => '#cbbfff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.featured-area-subtitle',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_area_desc_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Featured Description Font', 'purple' ),
		'std'        => array(
			'preview-text'  => 'Featured Title Font',
			'preview-color' => 'dark',
			'font-family'   => 'Montserrat',
			'font-weight'   => '500',
			'font-size'     => '18px',
			'line-height'   => '35px',
			'color'         => '#e7e1ff',
			'css-selectors' => '.featured-area-desc',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	// Featured Subscribe
	array(
		'id'         => 'featured_subscribe_heading',
		'type'       => 'heading',
		'title'      => esc_html__( 'Featured Subscribe Widget', 'purple' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_subscribe_title_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Subscribe Title Typography', 'purple' ),
		'std'        => array(
			'preview-text'  => 'Title Font',
			'preview-color' => 'dark',
			'font-family'   => 'Montserrat',
			'font-weight'   => '700',
			'font-size'     => '20px',
			'line-height'   => '1.4',
			'color'         => '#ffffff',
			'css-selectors' => '.featured-subscribe .widget #wp-subscribe .title, .featured-subscribe .widget h3',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_subscribe_text_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Text Typography', 'purple' ),
		'std'        => array(
			'preview-text'  => 'Text Font',
			'preview-color' => 'dark',
			'font-family'   => 'Montserrat',
			'font-weight'   => '500',
			'font-size'     => '14px',
			'line-height'   => '28px',
			'color'         => '#ffffff',
			'css-selectors' => '.featured-subscribe, .featured-subscribe .widget #wp-subscribe p, .featured-subscribe .widget .wp-subscribe .wps-consent-wrapper label, .featured-subscribe .post-info',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_subscribe_input_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Input Fields Typography', 'purple' ),
		'std'        => array(
			'preview-text'  => 'Input Fields Font',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '500',
			'font-size'     => '14px',
			'color'         => '#6554c0',
			'css-selectors' => '.featured-subscribe #wp-subscribe input.email-field, .featured-subscribe #wp-subscribe input.name-field',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_subscribe_input_height',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Height', 'purple' ),
		'sub_desc'   => esc_html__( 'Subscribe box input fields height.', 'purple' ),
		'std'        => '46',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_subscribe_input_border_radius',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Border Radius', 'purple' ),
		'sub_desc'   => esc_html__( 'Subscribe box input fields border radius.', 'purple' ),
		'std'        => '4',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_subscribe_input_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'purple' ),
		'sub_desc'   => esc_html__( 'Select border', 'purple' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_subscribe_input_background',
		'type'       => 'color',
		'title'      => esc_html__( 'Input Fields Background Color', 'purple' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'purple' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_subscribe_submit_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Submit Background Color', 'purple' ),
		'sub_desc'   => esc_html__( 'Set submit button background color, pattern and image from here.', 'purple' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '#a179ff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'featured_subscribe_submit_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Submit Button Typography', 'purple' ),
		'std'        => array(
			'preview-text'  => 'Submit Button Font',
			'preview-color' => 'dark',
			'font-family'   => 'Montserrat',
			'font-weight'   => '700',
			'font-size'     => '14px',
			'color'         => '#ffffff',
			'css-selectors' => '.featured-subscribe .widget #wp-subscribe input.submit',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_area',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

);
