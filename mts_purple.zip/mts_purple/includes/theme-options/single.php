<?php
/**
 * Single Tab
 *
 * @package Purple
 */

$menus['single-general'] = array(
	'title' => esc_html__( 'General', 'purple' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of your single posts page.', 'purple' ),
);

$sections['single-general'] = array(

	array(
		'id'       => 'mts_show_featured',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Featured image', 'purple' ),
		'sub_desc' => esc_html__( 'Enable/Disable the Featured images in the single post.', 'purple' ),
		'std'      => '1',
	),

	array(
		'id'       => 'full_width_header_height',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Pages Full Width Header Height', 'purple' ),
		'sub_desc' => esc_html__( 'Set full width header height of single post from here in px.', 'purple' ),
		'std'      => '500',
		'args'     => array( 'type' => 'number' ),
	),

	/*array(
		'id'       => 'page_full_width_header_height',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Full Width Header Height', 'purple' ),
		'sub_desc' => esc_html__( 'Set full width header height of all the other pages except single post from here in px.', 'purple' ),
		'std'      => '400',
		'args'     => array( 'type' => 'number' ),
	),*/

	array(
		'id'         => 'show_prev_next',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show preview and next article buttons', 'purple' ),
		'sub_desc'   => esc_html__( 'Use this button to show or hide preview and next article buttons.', 'purple' ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_single_post_layout',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Post Layout', 'purple' ),
		'sub_desc' => esc_html__( 'Customize the look of single posts', 'purple' ),
		'options'  => array(
			'enabled'  => array(
				'content' => array(
					'label'     => esc_html__( 'Post Content', 'purple' ),
					'subfields' => array(),
				),
				'tags'    => array(
					'label'     => esc_html__( 'Tags', 'purple' ),
					'subfields' => array(),
				),
				'author'  => array(
					'label'     => esc_html__( 'Author Box', 'purple' ),
					'subfields' => array(
						array(
							'id'       => 'mts_related_posts_taxonomy',
							'type'     => 'switch',
							'title'    => esc_html__( 'Related Posts Taxonomy', 'purple' ),
							'options'  => array(
								'tags'       => esc_html__( 'Tags', 'purple' ),
								'categories' => esc_html__( 'Categories', 'purple' ),
							),
							'class'    => 'green',
							'sub_desc' => esc_html__( 'Related Posts based on tags or categories.', 'purple' ),
							'std'      => 'categories',
						),
					),
				),
				'related' => array(
					'label'     => esc_html__( 'Related Posts', 'purple' ),
					'subfields' => array(
						array(
							'id'       => 'related_post_title',
							'type'     => 'text',
							'title'    => esc_html__( 'Related Posts Title', 'purple' ),
							'sub_desc' => esc_html__( 'Enter the title text to show in the related posts section.', 'purple' ),
							'std'      => 'Related Posts',

						),
						array(
							'id'       => 'mts_related_posts_taxonomy',
							'type'     => 'switch',
							'title'    => esc_html__( 'Related Posts Taxonomy', 'purple' ),
							'options'  => array(
								'tags'       => esc_html__( 'Tags', 'purple' ),
								'categories' => esc_html__( 'Categories', 'purple' ),
							),
							'class'    => 'green',
							'sub_desc' => esc_html__( 'Related Posts based on tags or categories.', 'purple' ),
							'std'      => 'categories',
						),
					),
				),
			),
			'disabled' => array(
				'subscribe' => array(
					'label'     => esc_html__( 'Subscribe Box', 'purple' ),
					'subfields' => array(),
				),
			),
		),
	),

	array(
		'id'       => 'mts_single_headline_meta_info',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Meta Info', 'purple' ),
		'sub_desc' => esc_html__( 'Organize how you want the post meta info to appear on single page', 'purple' ),
		'options'  => array(
			'enabled'  => array(
				'author'  => array(
					'label'     => esc_html__( 'Author Name', 'purple' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_author_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'purple' ),
							'std'   => esc_html__( 'circle', 'purple' ),
						),
					),
				),
				'date'    => array(
					'label'     => esc_html__( 'Date', 'purple' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_date_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'purple' ),
							'std'   => esc_html__( 'circle', 'purple' ),
						),
					),
				),
				'comment' => array(
					'label'     => esc_html__( 'Comment Count', 'purple' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_comment_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'purple' ),
							'std'   => esc_html__( 'circle', 'purple' ),
						),
					),
				),
			),
			'disabled' => array(
				'category' => array(
					'label'     => esc_html__( 'Categories', 'purple' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_category_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'purple' ),
							'std'   => esc_html__( 'circle', 'purple' ),
						),
					),
				),
			),
		),
	),

	array(
		'id'       => 'single_meta_info_background',
		'type'     => 'color',
		'title'    => esc_html__( 'Single Meta Info Background Color', 'purple' ),
		'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'purple' ),
		'std'      => '',
	),

	array(
		'id'       => 'mts_breadcrumb',
		'type'     => 'switch',
		'title'    => esc_html__( 'Breadcrumbs', 'purple' ),
		'sub_desc' => esc_html__( 'Breadcrumbs are a great way to make your site more user-friendly. You can enable them by checking this box.', 'purple' ),
		'std'      => '0',
	),

	array(
		'id'         => 'breadcrumb_icon',
		'type'       => 'icon_select',
		'title'      => esc_html__( 'Icon', 'purple' ),
		'sub_desc'   => esc_html__( 'Select divider icons from here.', 'purple' ),
		'std'        => 'angle-right',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_author_comment',
		'type'     => 'switch',
		'title'    => esc_html__( 'Highlight Author Comment', 'purple' ),
		'sub_desc' => esc_html__( 'Use this button to highlight author comments.', 'purple' ),
		'std'      => '1',
	),

	array(
		'id'       => 'mts_comment_date',
		'type'     => 'switch',
		'title'    => esc_html__( 'Date in Comments', 'purple' ),
		'sub_desc' => esc_html__( 'Use this button to show the date for comments.', 'purple' ),
		'std'      => '1',
	),
);
