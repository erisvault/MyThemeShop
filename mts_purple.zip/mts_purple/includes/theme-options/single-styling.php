<?php
/**
 * Single Styling
 *
 * @package Purple
 */

$menus['single-styling'] = array(
	'title' => esc_html__( 'Single Styling', 'purple' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of your single posts page.', 'purple' ),
);

$sections['single-styling'] = array(

	array(
		'id'    => 'single_title_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Single Titles Styling', 'purple' ),
	),

	array(
		'id'       => 'single_title_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Single Page Title Background Color', 'purple' ),
		'sub_desc' => esc_html__( 'Set Single Page Title( Comments & Comments form ) section background color, pattern and image from here.', 'purple' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'single_title_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Page Title( Related Posts, Comments & Comments form ) Padding', 'purple' ),
		'sub_desc' => esc_html__( 'Set single page title padding from here.', 'purple' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_title_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Single Page Title( Related Posts, Comments & Comments form ) Border', 'purple' ),
		'sub_desc' => esc_html__( 'Select border', 'purple' ),
	),
	array(
		'id'    => 'single_page_titles_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Section Title Typography', 'purple' ),
		'std'   => array(
			'preview-text'   => 'Title Font',
			'preview-color'  => 'light',
			'font-family'    => 'Montserrat',
			'font-weight'    => '700',
			'font-size'      => '22px',
			'color'          => purple_get_settings( 'mts_color_scheme' ),
			'additional-css' => 'text-align: center;',
			'css-selectors'  => '#respond h4, .total-comments',
		),
	),

	array(
		'id'    => 'mts_single_styling_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Single Styling', 'purple' ),
	),

	array(
		'id'       => 'single_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Background', 'purple' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image of Single Post content, Page content, and 404 Page content from here.', 'purple' ),
		'options'  => array(
			'color'         => '#ffffff',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'mts_single_styling_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Margin', 'purple' ),
		'sub_desc' => esc_html__( 'Set Single Post content, Page content, and 404 Page content margin from here.', 'purple' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '40px',
		),
	),
	array(
		'id'       => 'mts_single_styling_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Padding', 'purple' ),
		'sub_desc' => esc_html__( 'Set Single Post content, Page content, and 404 Page content padding from here.', 'purple' ),
		'std'      => array(
			'left'   => '50px',
			'top'    => '40px',
			'right'  => '50px',
			'bottom' => '40px',
		),
	),
	array(
		'id'       => 'single_styling_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'purple' ),
		'sub_desc' => esc_html__( 'Set Single Post content, Page content, and 404 Page content border from here', 'purple' ),
	),
	array(
		'id'         => 'breadcrumb_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Breadcrumbs Font', 'purple' ),
		'std'        => array(
			'preview-text'  => 'Breadcrumbs',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '600',
			'font-size'     => '14px',
			'color'         => '#253858',
			'css-selectors' => '.breadcrumb, .rank-math-breadcrumb',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'    => 'mts_single_meta_info_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Single Meta Info Font', 'purple' ),
		'std'   => array(
			'preview-text'  => 'Post Font',
			'preview-color' => 'dark',
			'font-family'   => 'Montserrat',
			'font-weight'   => '500',
			'font-size'     => '14px',
			'color'         => purple_get_settings( 'mts_color_scheme' ),
			'css-selectors' => '.single_post .post-info, .single_post .post-info a',
		),
	),

);
