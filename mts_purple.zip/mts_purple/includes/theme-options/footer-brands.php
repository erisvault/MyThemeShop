<?php
/**
 * Brands
 *
 * @package Purple
 */

$menus['footer']['child']['footer-brands'] = array(
	'title' => esc_html__( 'Brands Section', 'purple' ),
	'desc'  => esc_html__( 'From here, you can control the Brands Section.', 'purple' ),
);

$sections['footer-brands'] = array(

	array(
		'id'       => 'footer_brands_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Brands Section', 'purple' ),
		'sub_desc' => esc_html__( 'Enable or disable Brands Section with this option.', 'purple' ),
		'std'      => '0',
	),

	array(
		'id'         => 'footer_brands_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Brands Section Alignment', 'purple' ),
		'sub_desc'   => esc_html__( 'Choose alignment of Brands Section.', 'purple' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'purple' ),
			'center' => esc_html__( 'Center', 'purple' ),
			'right'  => esc_html__( 'Right', 'purple' ),
		),
		'std'        => 'center',
		'class'      => 'green',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'brands_section_title',
		'type'       => 'text',
		'title'      => esc_html__( 'Brands Title', 'purple' ),
		'sub_desc'   => esc_html__( 'Enter brands title here.', 'purple' ),
		'std'        => esc_html__( 'Our Brands:', 'purple' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),

	),

	array(
		'id'         => 'footer_brands_items',
		'type'       => 'group',
		'title'      => esc_html__( 'Brands', 'purple' ),
		'groupname'  => esc_html__( 'Brand', 'purple' ), // Group name.
		'subfields'  => array(
			array(
				'id'       => 'brand_title',
				'type'     => 'text',
				'title'    => esc_html__( 'Title', 'purple' ),
				'sub_desc' => esc_html__( 'The title will not be shown.', 'purple' ),
			),
			array(
				'id'       => 'brand_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Image', 'purple' ),
				'sub_desc' => esc_html__( 'Upload or select an image for brand', 'purple' ),
			),
			array(
				'id'       => 'brand_url',
				'type'     => 'text',
				'title'    => esc_html__( 'Link', 'purple' ),
				'sub_desc' => esc_html__( 'Insert a link URL of brand', 'purple' ),
				'std'      => '#',
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'brands_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Margin', 'purple' ),
		'sub_desc'   => esc_html__( 'Brands Section margin.', 'purple' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'brands_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'purple' ),
		'sub_desc'   => esc_html__( 'Brands Section padding.', 'purple' ),
		'std'        => array(
			'top'    => '30px',
			'right'  => '0',
			'bottom' => '27px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'brands_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'purple' ),
		'sub_desc'   => esc_html__( 'Select border', 'purple' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
);
