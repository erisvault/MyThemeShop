<?php
/**
 * HomePage Posts
 *
 * @package Purple
 */

$features = purple_get_settings( 'mts_featured_categories' );
if ( empty( $features ) ) {
	return;
}
foreach ( $features as $feature ) :
	$title        = isset( $feature['mts_featured_title'] ) ? $feature['mts_featured_title'] : 'No Title';
	$posts_layout = isset( $feature['mts_thumb_layout'] ) ? $feature['mts_thumb_layout'] : '';
	if ( 'layout-default' === $posts_layout ) {
		$posts_layout = 'default';
	}
	$unique_id = isset( $feature['unique_id'] ) ? $feature['unique_id'] : '';

	$menus[ 'homepage-' . $unique_id ] = array(
		'title' => $title,
		// translators: description.
		'desc'  => sprintf( wp_kses_post( __( 'From here, you can control the elements of %s', 'purple' ) ), $title ),
	);

	$sections[ 'homepage-' . $unique_id ] = array(

		/**
		 * Layout Default Settings
		 *
		 * @package Purple
		 */

		// Section Title.
		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'purple' ),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'purple' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'purple' ),
			'std'      => '0',
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'purple' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'purple' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'purple' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'purple' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '30px',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'purple' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'purple' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'purple' ),
			'sub_desc'   => esc_html__( 'Select border', 'purple' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'purple' ),
			'std'        => array(
				'preview-text'  => 'Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Montserrat',
				'font-weight'   => '700',
				'font-size'     => '27px',
				'color'         => '#253858',
				'css-selectors' => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		// Post Number
		( 'default' === $posts_layout ) ? array(
			'id'       => 'post_number_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show Post Number', 'blocks' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide post number.', 'blocks' ),
			'std'      => '1',
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'         => 'post_number_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Number Background', 'purple' ),
			'sub_desc'   => esc_html__( 'Set post number background color, pattern and image from here.', 'purple' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '#6c62ff',
				'use'           => 'gradient',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => '',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#6C62FF',
					'to'        => '#A179FF',
					'direction' => '60deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'post_number_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'         => 'post_number_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Post Number Font', 'purple' ),
			'std'        => array(
				'preview-text'  => 'Post Number Font',
				'preview-color' => 'dark',
				'font-family'   => 'Montserrat',
				'font-weight'   => '900',
				'font-size'     => '35px',
				'color'         => '#ffffff',
				'css-selectors' => '.layout-' . $unique_id . ' .post-number',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'post_number_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		// Meta info.
		( 'default' === $posts_layout ) ? array(
			'id'    => 'post_meta_info_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Meta Info', 'purple' ),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_home_headline_meta_info' . $unique_id,
			'type'     => 'layout2',
			// translators: title.
			'title'    => sprintf( wp_kses_post( __( '%s Meta Info', 'purple' ) ), $title ),
			// translators: description.
			'sub_desc' => sprintf( wp_kses_post( __( 'Organize how you want the post meta info to appear on %s', 'purple' ) ), $title ),
			'options'  => array(
				'enabled'  => array(
					'author'  => array(
						'label'     => __( 'Author Name', 'purple' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_author_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'purple' ),
								'std'   => esc_html__( 'circle', 'purple' ),
							),
						),
					),
					'date'    => array(
						'label'     => esc_html__( 'Date', 'purple' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_date_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'purple' ),
								'std'   => esc_html__( 'circle', 'purple' ),
							),
						),
					),
					'comment' => array(
						'label'     => esc_html__( 'Comment Count', 'purple' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_comment_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'purple' ),
								'std'   => esc_html__( 'circle', 'purple' ),
							),
						),
					),
				),
				'disabled' => array(
					'category' => array(
						'label'     => esc_html__( 'Categories', 'purple' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_category_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'purple' ),
								'std'   => esc_html__( 'circle', 'purple' ),
							),
						),
					),
				),
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'purple' ),
			'sub_desc' => esc_html__( 'Post Meta Info margin.', 'purple' ),
			'std'      => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'purple' ),
			'sub_desc' => esc_html__( 'Post Meta Info padding.', 'purple' ),
			'std'      => array(
				'left'   => '50px',
				'top'    => '38px',
				'right'  => '50px',
				'bottom' => '38px',
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'post_meta_info_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Meta Info Border', 'purple' ),
			'sub_desc' => esc_html__( 'Select border', 'purple' ),
			'std'      => array(
				'direction' => 'top',
				'size'      => '2',
				'style'     => 'solid',
				'color'     => '#eaebef',
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_meta_info_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Meta Info Typography', 'purple' ),
			'std'   => array(
				'preview-text'  => 'Post Meta Info Font',
				'preview-color' => 'light',
				'font-family'   => 'Montserrat',
				'font-weight'   => '500',
				'font-size'     => '14px',
				'color'         => '#6c62ff',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .post-info, .layout-' . $unique_id . ' .latestPost .post-info a',
			),
		) : null,

		// Post Container.
		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'purple' ),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'purple' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'purple' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'purple' ),
			'sub_desc' => esc_html__( 'Select border', 'purple' ),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'purple' ),
			'sub_desc' => esc_html__( 'Post margin.', 'purple' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '0',
				'bottom' => '0',
			),
		) : null,
		( 'default' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'purple' ),
			'sub_desc' => esc_html__( 'Post padding.', 'purple' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_featured_category_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'purple' ),
			'std'   => array(
				'preview-text'  => 'Post Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Montserrat',
				'font-weight'   => '700',
				'font-size'     => '27px',
				'line-height'   => '40px',
				'color'         => '#253858',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		) : null,

		( 'default' === $posts_layout ) ? array(
			'id'    => 'mts_featured_category_excerpt_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Excerpt Font', 'purple' ),
			'std'   => array(
				'preview-text'  => 'Post Excerpt Font',
				'preview-color' => 'light',
				'font-family'   => 'Montserrat',
				'font-weight'   => '500',
				'font-size'     => '14px',
				'line-height'   => '25px',
				'color'         => '#5e6c84',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .front-view-content',
			),
		) : null,

		/**
		 * Layout 1.
		 *
		 * @package Purple
		 */

		// Section Title.
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'purple' ),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'purple' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'purple' ),
			'std'      => '1',
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'purple' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'purple' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'purple' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'purple' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '30px',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'purple' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'purple' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'purple' ),
			'sub_desc'   => esc_html__( 'Select border', 'purple' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'purple' ),
			'std'        => array(
				'preview-text'  => 'Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Montserrat',
				'font-weight'   => '700',
				'font-size'     => '26px',
				'line-height'   => '42px',
				'color'         => '#253858',
				'css-selectors' => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		// Post Number
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'post_number_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show Post Number', 'blocks' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide post number.', 'blocks' ),
			'std'      => '1',
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'post_number_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Number Background', 'purple' ),
			'sub_desc'   => esc_html__( 'Set post number background color, pattern and image from here.', 'purple' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '#6c62ff',
				'use'           => 'gradient',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => '',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#6C62FF',
					'to'        => '#A179FF',
					'direction' => '60deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'post_number_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'         => 'post_number_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Post Number Font', 'purple' ),
			'std'        => array(
				'preview-text'  => 'Post Number Font',
				'preview-color' => 'dark',
				'font-family'   => 'Montserrat',
				'font-weight'   => '900',
				'font-size'     => '35px',
				'color'         => '#ffffff',
				'css-selectors' => '.layout-' . $unique_id . ' .post-number',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'post_number_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		// Meta info.
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_home_headline_meta_info' . $unique_id,
			'type'     => 'layout2',
			// translators: title.
			'title'    => sprintf( wp_kses_post( __( '%s Meta Info', 'purple' ) ), $title ),
			// translators: description.
			'sub_desc' => sprintf( wp_kses_post( __( 'Organize how you want the post meta info to appear on %s', 'purple' ) ), $title ),
			'options'  => array(
				'enabled'  => array(
					'author'  => array(
						'label'     => __( 'Author Name', 'purple' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_author_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'purple' ),
								'std'   => esc_html__( 'circle', 'purple' ),
							),
						),
					),
					'date'    => array(
						'label'     => esc_html__( 'Date', 'purple' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_date_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'purple' ),
								'std'   => esc_html__( 'circle', 'purple' ),
							),
						),
					),
					'comment' => array(
						'label'     => esc_html__( 'Comment Count', 'purple' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_comment_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'purple' ),
								'std'   => esc_html__( 'circle', 'purple' ),
							),
						),
					),
				),
				'disabled' => array(
					'category' => array(
						'label'     => esc_html__( 'Categories', 'purple' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_category_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'purple' ),
								'std'   => esc_html__( 'circle', 'purple' ),
							),
						),
					),
				),
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'purple' ),
			'sub_desc' => esc_html__( 'Post Meta Info margin.', 'purple' ),
			'std'      => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_meta_info_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'purple' ),
			'sub_desc' => esc_html__( 'Post Meta Info padding.', 'purple' ),
			'std'      => array(
				'left'   => '35px',
				'top'    => '30px',
				'right'  => '35px',
				'bottom' => '30px',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'post_meta_info_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Meta Info Border', 'purple' ),
			'sub_desc' => esc_html__( 'Select border', 'purple' ),
			'std'      => array(
				'direction' => 'top',
				'size'      => '2',
				'style'     => 'solid',
				'color'     => '#eaebef',
			),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'mts_meta_info_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Meta Info Typography', 'purple' ),
			'std'   => array(
				'preview-text'  => 'Post Meta Info Font',
				'preview-color' => 'light',
				'font-family'   => 'Montserrat',
				'font-weight'   => '500',
				'font-size'     => '13px',
				'color'         => '#6c62ff',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .post-info, .layout-' . $unique_id . ' .latestPost .post-info a',
			),
		) : null,

		// Post Container.
		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'purple' ),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'purple' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'purple' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'purple' ),
			'sub_desc' => esc_html__( 'Select border', 'purple' ),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'purple' ),
			'sub_desc' => esc_html__( 'Post margin.', 'purple' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '30px',
				'bottom' => '30px',
			),
		) : null,
		( 'layout-1' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'purple' ),
			'sub_desc' => esc_html__( 'Post padding.', 'purple' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		( 'layout-1' === $posts_layout ) ? array(
			'id'    => 'mts_featured_category_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'purple' ),
			'std'   => array(
				'preview-text'  => 'Post Font',
				'preview-color' => 'light',
				'font-family'   => 'Montserrat',
				'font-weight'   => '700',
				'font-size'     => '25px',
				'line-height'   => '35px',
				'color'         => '#253858',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		) : null,

		/**
		 * Layout Partners.
		 *
		 * @package Purple
		 */

		( 'layout-partners' === $posts_layout ) ? array(
			'id'        => 'partners_section_' . $unique_id,
			'type'      => 'group',
			'title'     => esc_html__( 'Partners Items', 'purple' ),
			'groupname' => esc_html__( 'Partner Item', 'purple' ),
			'subfields' => array(
				array(
					'id'    => 'partner_title',
					'type'  => 'text',
					'title' => esc_html__( 'Title', 'purple' ),
				),
				array(
					'id'       => 'partner_image',
					'type'     => 'upload',
					'title'    => esc_html__( 'Image', 'purple' ),
					'sub_desc' => esc_html__( 'Upload or select an image for partner. Recommended Size(190X70px)', 'purple' ),
				),
				array(
					'id'       => 'partner_url',
					'type'     => 'text',
					'title'    => esc_html__( 'Link', 'purple' ),
					'sub_desc' => esc_html__( 'Insert a link URL of partner', 'purple' ),
					'std'      => '#',
				),
			),
		) : null,

		// Section Title.
		( 'layout-partners' === $posts_layout ) ? array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'purple' ),
		) : null,

		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'purple' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'purple' ),
			'std'      => '1',
		) : null,

		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'partner_section_title_' . $unique_id,
			'type'       => 'text',
			'title'      => esc_html__( 'Section Title', 'purple' ),
			'sub_desc'   => esc_html__( 'Partners section title.', 'purple' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'partners_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Partners Title Font', 'purple' ),
			'std'        => array(
				'preview-text'  => 'Partners Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Montserrat',
				'font-weight'   => '700',
				'font-size'     => '26px',
				'line-height'   => '42px',
				'color'         => '#253858',
				'css-selectors' => '.article.layout-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'purple' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'purple' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'post_title_shadow' . $unique_id,
			'type'       => 'switch',
			'title'      => esc_html__( 'Box Shadow', 'purple' ),
			'sub_desc'   => esc_html__( 'Use this button to show or hide box shadow in post container.', 'purple' ),
			'std'        => '1',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'purple' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'purple' ),
			'left'       => false,
			'right'      => false,
			'std'        => array(
				'top'    => '0',
				'bottom' => '30px',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'purple' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'purple' ),
			'std'        => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'purple' ),
			'sub_desc'   => esc_html__( 'Select border', 'purple' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'mts_featured_category_title_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Post Container.
		( 'layout-partners' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'purple' ),
		) : null,

		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'purple' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'purple' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'purple' ),
			'sub_desc' => esc_html__( 'Select border', 'purple' ),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'purple' ),
			'sub_desc' => esc_html__( 'Post margin.', 'purple' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '30px',
				'bottom' => '30px',
			),
		) : null,
		( 'layout-partners' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'purple' ),
			'sub_desc' => esc_html__( 'Post padding.', 'purple' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

		/**
		 * Layout Category.
		 *
		 * @package Purple
		 */

		( 'layout-category' === $posts_layout ) ? array(
			'id'        => 'cat_section_' . $unique_id,
			'type'      => 'group',
			'title'     => esc_html__( 'Category items', 'purple' ),
			'sub_desc'  => esc_html__( 'Add category Item from here', 'purple' ),
			'groupname' => esc_html__( 'Category item', 'purple' ),
			'subfields' => array(
				array(
					'id'    => 'cat_section_title',
					'type'  => 'text',
					'title' => esc_html__( 'Title', 'purple' ),
				),
				array(
					'id'       => 'cat_section_category',
					'type'     => 'select',
					'title'    => esc_html__( 'Category', 'purple' ),
					'sub_desc' => esc_html__( 'Select a category for this section', 'purple' ),
					'data'     => 'category',
				),
				array(
					'id'       => 'cat_section_icon',
					'type'     => 'icon_select',
					'title'    => esc_html__( 'Icon', 'blocks' ),
					'sub_desc' => esc_html__( 'Upload or select an icon for category.', 'purple' ),
				),
				array(
					'id'    => 'cat_section_color',
					'type'  => 'color',
					'title' => esc_html__( 'Select color for your category', 'purple' ),
					//'args'  => array( 'opacity' => true ),
					'std'   => '#6c62ff',
				),
			),
			'std'       => array(
				'flask' => array(
					'group_title'       => 'Life Style',
					'group_sort'        => '1',
					'cat_section_title' => 'Life Style',
					'cat_section_icon'  => 'flask',
					'cat_section_color' => '#6c62ff',
				),
			),
		) : null,

		// Post Container.
		( 'layout-category' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'purple' ),
		) : null,

		( 'layout-category' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'purple' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'purple' ),
			'options'  => array(
				'color'         => '#ffffff',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '#ffffff',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-category' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'purple' ),
			'sub_desc' => esc_html__( 'Select border', 'purple' ),
		) : null,
		( 'layout-category' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'purple' ),
			'sub_desc' => esc_html__( 'Post margin.', 'purple' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '-110px',
				'bottom' => '30px',
			),
		) : null,
		( 'layout-category' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'purple' ),
			'sub_desc' => esc_html__( 'Post padding.', 'purple' ),
			'std'      => array(
				'left'   => '10px',
				'top'    => '30px',
				'right'  => '10px',
				'bottom' => '30px',
			),
		) : null,
		( 'layout-category' === $posts_layout ) ? array(
			'id'       => 'post_category_shadow' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Box Shadow', 'purple' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide box shadow in post container.', 'purple' ),
			'std'      => '1',
		) : null,

		/**
		 * Layout Subscribe.
		 *
		 * @package Purple
		 */

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_size_' . $unique_id,
			'type'     => 'button_set',
			'title'    => esc_html__( 'Section Size', 'purple' ),
			'sub_desc' => esc_html__( 'Select the size of subscribe widget.', 'purple' ),
			'options'  => array(
				'full'      => esc_html__( 'Full', 'purple' ),
				'container' => esc_html__( 'Container', 'purple' ),
			),
			'std'      => 'full',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_alignment_' . $unique_id,
			'type'     => 'button_set',
			'title'    => esc_html__( 'Alignment', 'purple' ),
			'sub_desc' => esc_html__( 'Alignment of subscribe widget content', 'purple' ),
			'options'  => array(
				'left'   => esc_html__( 'Left', 'purple' ),
				'center' => esc_html__( 'Center', 'purple' ),
				'right'  => esc_html__( 'Right', 'purple' ),
			),
			'std'      => 'center',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Title Typography', 'purple' ),
			'std'   => array(
				'preview-text'  => 'Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Montserrat',
				'font-weight'   => '700',
				'font-size'     => '28px',
				'line-height'   => '1.4',
				'color'         => '#253858',
				'css-selectors' => '.layout-' . $unique_id . ' .widget #wp-subscribe .title, .layout-' . $unique_id . ' .layout-subscribe .left-content h4',
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_input_background_' . $unique_id,
			'type'     => 'color',
			'title'    => esc_html__( 'Input Fields Background Color', 'purple' ),
			'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'purple' ),
			'std'      => '#ffffff',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_input_size_' . $unique_id,
			'type'     => 'button_set',
			'title'    => esc_html__( 'Input Field Size', 'purple' ),
			'sub_desc' => esc_html__( 'Select the size of input fields.', 'purple' ),
			'options'  => array(
				'large' => esc_html__( 'Large', 'purple' ),
				'small' => esc_html__( 'Small', 'purple' ),
			),
			'std'      => 'large',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_input_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Input Fields Typography', 'purple' ),
			'std'   => array(
				'preview-text'  => 'Input Fields Font',
				'preview-color' => 'dark',
				'font-family'   => 'Montserrat',
				'font-weight'   => '500',
				'font-size'     => '14px',
				'color'         => '#505f79',
				'css-selectors' => '.layout-' . $unique_id . ' .layout-subscribe #wp-subscribe input.email-field, .layout-' . $unique_id . ' .layout-subscribe #wp-subscribe input.name-field',
			),
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_text_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Text Typography', 'purple' ),
			'std'   => array(
				'preview-text'  => 'Text Font',
				'preview-color' => 'dark',
				'font-family'   => 'Montserrat',
				'font-weight'   => '500',
				'font-size'     => '15px',
				'line-height'   => '28px',
				'color'         => '#505f79',
				'css-selectors' => '.layout-' . $unique_id . ' .layout-subscribe #wp-subscribe p.text, .layout-' . $unique_id . ' .subscribe-icons-container p, .layout-' . $unique_id . ' .layout-subscribe .left-content p',
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_small_text_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Small Text Typography', 'purple' ),
			'std'   => array(
				'preview-text'  => 'Text Font',
				'preview-color' => 'dark',
				'font-family'   => 'Montserrat',
				'font-weight'   => '500',
				'font-size'     => '14px',
				'color'         => '#505f79',
				'css-selectors' => '.layout-' . $unique_id . ' .layout-subscribe #sidebar .wp-subscribe-wrap p.footer-text, .layout-' . $unique_id . ' .layout-subscribe #sidebar .widget .wp-subscribe .wps-consent-wrapper',
			),
		) : null,

		// Left Content.
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_left_content_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Subscribe Left Content', 'purple' ),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_left_content_logo_' . $unique_id,
			'type'     => 'upload',
			'title'    => esc_html__( 'Left Content Logo', 'purple' ),
			'sub_desc' => esc_html__( 'Select an image file for left content logo.', 'purple' ),
			'return'   => 'url',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_left_content_title_' . $unique_id,
			'type'  => 'text',
			'title' => esc_html__( 'Left Content Title', 'purple' ),
			'std'   => 'Know where to go!',
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_left_content_text_' . $unique_id,
			'type'  => 'textarea',
			'title' => esc_html__( 'Left Content Text', 'purple' ),
			'std'   => 'Sign up for our daily tips to make your best vacation.',
		) : null,

		// Social Icons.
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'subscribe_icon_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Subscribe Social Icons', 'purple' ),
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'subscribe_social_icons_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Subscribe Social Icons', 'purple' ),
			'sub_desc' => esc_html__( 'Enable or disable subscribe social icons with this option.', 'purple' ),
			'std'      => '1',
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'         => 'subscribe_icon_title_' . $unique_id,
			'type'       => 'text',
			'title'      => esc_html__( 'Title', 'purple' ),
			'sub_desc'   => esc_html__( 'Subscribe icon title.', 'purple' ),
			'std'        => 'Follow Us',
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'subscribe_social_icons_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'         => 'subscribe_social_' . $unique_id,
			'title'      => esc_html__( 'Subscribe Social Icons', 'purple' ),
			'sub_desc'   => esc_html__( 'Add Social Media icons in subscribe section.', 'purple' ),
			'type'       => 'group',
			'groupname'  => esc_html__( 'Social Icons', 'purple' ), // Group name.
			'subfields'  => array(
				array(
					'id'    => 'subscribe_social_title',
					'type'  => 'text',
					'title' => esc_html__( 'Title', 'purple' ),
				),
				array(
					'id'    => 'subscribe_social_icon',
					'type'  => 'icon_select',
					'title' => esc_html__( 'Icon', 'purple' ),
				),
				array(
					'id'    => 'subscribe_social_link',
					'type'  => 'text',
					'title' => esc_html__( 'URL', 'purple' ),
				),
				array(
					'id'    => 'subscribe_social_bgcolor',
					'type'  => 'color',
					'title' => esc_html__( 'Background color', 'purple' ),
				),
				array(
					'id'    => 'subscribe_social_hover_bgcolor',
					'type'  => 'color',
					'title' => esc_html__( 'Background hover color', 'purple' ),
				),
				array(
					'id'    => 'subscribe_social_color',
					'type'  => 'color',
					'title' => esc_html__( 'Icon color', 'purple' ),
				),
				array(
					'id'    => 'subscribe_social_hover_color',
					'type'  => 'color',
					'title' => esc_html__( 'Icon hover color', 'purple' ),
				),
				array(
					'id'    => 'subscribe_social_border_radius',
					'type'  => 'text',
					'class' => 'small-text',
					'title' => esc_html__( 'Border radius', 'purple' ),
					'args'  => array( 'type' => 'number' ),
				),
			),
			'std'        => array(
				'facebook'  => array(
					'group_title'                    => 'Facebook',
					'group_sort'                     => '1',
					'subscribe_social_title'         => 'Facebook',
					'subscribe_social_icon'          => 'facebook',
					'subscribe_social_link'          => '#',
					'subscribe_social_bgcolor'       => '#6c62ff',
					'subscribe_social_hover_bgcolor' => '',
					'subscribe_social_color'         => '#ffffff',
					'subscribe_social_hover_color'   => '',
					'subscribe_social_border_radius' => '20',
				),
				'twitter'   => array(
					'group_title'                    => 'Twitter',
					'group_sort'                     => '2',
					'subscribe_social_title'         => 'Twitter',
					'subscribe_social_icon'          => 'twitter',
					'subscribe_social_link'          => '#',
					'subscribe_social_bgcolor'       => '#6c62ff',
					'subscribe_social_hover_bgcolor' => '',
					'subscribe_social_color'         => '#ffffff',
					'subscribe_social_hover_color'   => '',
					'subscribe_social_border_radius' => '20',
				),
				'instagram' => array(
					'group_title'                    => 'Instagram',
					'group_sort'                     => '3',
					'subscribe_social_title'         => 'Instagram',
					'subscribe_social_icon'          => 'instagram',
					'subscribe_social_link'          => '#',
					'subscribe_social_bgcolor'       => '#6c62ff',
					'subscribe_social_hover_bgcolor' => '',
					'subscribe_social_color'         => '#ffffff',
					'subscribe_social_hover_color'   => '',
					'subscribe_social_border_radius' => '20',
				),
			),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'subscribe_social_icons_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'         => 'subscribe_social_width_' . $unique_id,
			'type'       => 'text',
			'class'      => 'small-text',
			'title'      => esc_html__( 'Width', 'purple' ),
			'std'        => '40',
			'args'       => array( 'type' => 'number' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'subscribe_social_icons_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'         => 'subscribe_social_height_' . $unique_id,
			'type'       => 'text',
			'class'      => 'small-text',
			'title'      => esc_html__( 'Height', 'purple' ),
			'std'        => '40',
			'args'       => array( 'type' => 'number' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'subscribe_social_icons_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'         => 'subscribe_social_font_size_' . $unique_id,
			'type'       => 'text',
			'class'      => 'small-text',
			'title'      => esc_html__( 'Font Size', 'purple' ),
			'sub_desc'   => esc_html__( 'Set font size of footer nav social icons in px.', 'purple' ),
			'std'        => '15',
			'args'       => array( 'type' => 'number' ),
			'dependency' => array(
				'relation' => 'and',
				array(
					'field'      => 'subscribe_social_icons_' . $unique_id,
					'value'      => '1',
					'comparison' => '==',
				),
			),
		) : null,

		// Post Container.
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'purple' ),
		) : null,

		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'purple' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'purple' ),
			'options'  => array(
				'color'         => '#f7f8fa',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '#f7f8fa',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'purple' ),
			'sub_desc' => esc_html__( 'Select border', 'purple' ),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'purple' ),
			'sub_desc' => esc_html__( 'Post margin.', 'purple' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '30px',
				'bottom' => '30px',
			),
		) : null,
		( 'layout-subscribe' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'purple' ),
			'sub_desc' => esc_html__( 'Post padding.', 'purple' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '50px',
				'right'  => '0',
				'bottom' => '50px',
			),
		) : null,

		/**
		 * Layout Ad.
		 *
		 * @package Purple
		 */

		( 'layout-ad' === $posts_layout ) ? array(
			'id'       => 'adcode_' . $unique_id,
			'type'     => 'ace_editor',
			'mode'     => 'html',
			'title'    => esc_html__( 'Ad Code', 'purple' ),
			'sub_desc' => esc_html__( 'Paste your Adsense, BSA or other ad code here to show ads.', 'purple' ),
		) : null,

		// Post Container.
		( 'layout-ad' === $posts_layout ) ? array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'purple' ),
		) : null,

		( 'layout-ad' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'purple' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'purple' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		) : null,
		( 'layout-ad' === $posts_layout ) ? array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'purple' ),
			'sub_desc' => esc_html__( 'Select border', 'purple' ),
		) : null,
		( 'layout-ad' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'purple' ),
			'sub_desc' => esc_html__( 'Post margin.', 'purple' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '30px',
				'bottom' => '30px',
			),
		) : null,
		( 'layout-ad' === $posts_layout ) ? array(
			'id'       => 'mts_featured_category_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'purple' ),
			'sub_desc' => esc_html__( 'Post padding.', 'purple' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		) : null,

	);
endforeach;
