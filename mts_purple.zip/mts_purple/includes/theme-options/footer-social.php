<?php
/**
 * Back to top
 *
 * @package Purple
 */

$menus['footer']['child']['footer-social'] = array(
	'title' => esc_html__( 'Footer Social Share', 'purple' ),
	'desc'  => esc_html__( 'From here, you can control the styling of social share in footer section.', 'purple' ),
);

$sections['footer-social'] = array(

	array(
		'id'    => 'footer_social_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Social Icons', 'purple' ),
	),

	array(
		'id'       => 'footer_logo_social_icons',
		'type'     => 'switch',
		'title'    => esc_html__( 'Social Icons', 'purple' ),
		'sub_desc' => esc_html__( 'Enable or disable social icons with this option.', 'purple' ),
		'std'      => '1',
	),

	array(
		'id'         => 'footer_logo_social',
		'title'      => esc_html__( 'Footer Social Icons', 'purple' ),
		'sub_desc'   => esc_html__( 'Add Social Media icons in footer logo section.', 'purple' ),
		'type'       => 'group',
		'groupname'  => esc_html__( 'Social Icons', 'purple' ), // Group name.
		'subfields'  => array(
			array(
				'id'    => 'footer_logo_social_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'purple' ),
			),
			array(
				'id'    => 'footer_logo_social_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Icon', 'purple' ),
			),
			array(
				'id'    => 'footer_logo_social_link',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'purple' ),
			),
			array(
				'id'    => 'footer_logo_social_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Background color', 'purple' ),
			),
			array(
				'id'    => 'footer_logo_social_hover_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Background hover color', 'purple' ),
			),
			array(
				'id'    => 'footer_logo_social_color',
				'type'  => 'color',
				'title' => esc_html__( 'Icon color', 'purple' ),
			),
			array(
				'id'    => 'footer_logo_social_hover_color',
				'type'  => 'color',
				'title' => esc_html__( 'Icon hover color', 'purple' ),
			),
			array(
				'id'    => 'footer_logo_social_border_radius',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Border radius', 'purple' ),
				'args'  => array( 'type' => 'number' ),
			),
			array(
				'id'    => 'footer_logo_social_border_size',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Border Size', 'purple' ),
				'args'  => array( 'type' => 'number' ),
			),
			array(
				'id'      => 'footer_logo_social_border_style',
				'type'    => 'select',
				'title'   => esc_html__( 'Border Style', 'purple' ),
				'options' => array(
					'none'   => esc_html__( 'None', 'purple' ),
					'solid'  => esc_html__( 'Solid', 'purple' ),
					'dotted' => esc_html__( 'Dotted', 'purple' ),
					'dashed' => esc_html__( 'Dashed', 'purple' ),
					'double' => esc_html__( 'Double', 'purple' ),
					'groove' => esc_html__( 'Groove', 'purple' ),
					'ridge'  => esc_html__( 'Ridge', 'purple' ),
					'inset'  => esc_html__( 'Inset', 'purple' ),
					'outset' => esc_html__( 'Outset', 'purple' ),
				),
			),
			array(
				'id'    => 'footer_logo_social_border_color',
				'type'  => 'color',
				'title' => esc_html__( 'Border Color', 'purple' ),
			),
		),
		'std'        => array(
			'facebook'  => array(
				'group_title'                      => 'Facebook',
				'group_sort'                       => '1',
				'footer_logo_social_title'         => 'Facebook',
				'footer_logo_social_icon'          => 'facebook',
				'footer_logo_social_link'          => '#',
				'footer_logo_social_bgcolor'       => '#a792ff',
				'footer_logo_social_hover_bgcolor' => '',
				'footer_logo_social_color'         => '#ffffff',
				'footer_logo_social_hover_color'   => '',
				'footer_logo_social_border_radius' => '20',
				'footer_logo_social_border_size'   => '1',
				'footer_logo_social_border_style'  => 'none',
				'footer_logo_social_border_color'  => '',
			),
			'twitter'   => array(
				'group_title'                      => 'Twitter',
				'group_sort'                       => '2',
				'footer_logo_social_title'         => 'Twitter',
				'footer_logo_social_icon'          => 'twitter',
				'footer_logo_social_link'          => '#',
				'footer_logo_social_bgcolor'       => '#a792ff',
				'footer_logo_social_hover_bgcolor' => '',
				'footer_logo_social_color'         => '#ffffff',
				'footer_logo_social_hover_color'   => '',
				'footer_logo_social_border_radius' => '20',
				'footer_logo_social_border_size'   => '1',
				'footer_logo_social_border_style'  => 'none',
				'footer_logo_social_border_color'  => '',
			),
			'instagram' => array(
				'group_title'                      => 'Instagram',
				'group_sort'                       => '3',
				'footer_logo_social_title'         => 'Instagram',
				'footer_logo_social_icon'          => 'instagram',
				'footer_logo_social_link'          => '#',
				'footer_logo_social_bgcolor'       => '#a792ff',
				'footer_logo_social_hover_bgcolor' => '',
				'footer_logo_social_color'         => '#ffffff',
				'footer_logo_social_hover_color'   => '',
				'footer_logo_social_border_radius' => '20',
				'footer_logo_social_border_size'   => '1',
				'footer_logo_social_border_style'  => 'none',
				'footer_logo_social_border_color'  => '',
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_social_icons',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_logo_social_width',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Width', 'purple' ),
		'std'        => '40',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_social_icons',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'footer_logo_social_height',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Height', 'purple' ),
		'std'        => '40',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_social_icons',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_logo_social_font_size',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Font Size', 'purple' ),
		'sub_desc'   => esc_html__( 'Set font size of footer nav social icons in px.', 'purple' ),
		'std'        => '15',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'footer_logo_social_icons',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

);
