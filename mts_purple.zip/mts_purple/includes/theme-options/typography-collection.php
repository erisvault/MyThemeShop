<?php
/**
 * Typography tab
 *
 * @package Purple
 */

$menus['typography-collection'] = array(
	'icon'       => 'fa-text-width',
	'title'      => esc_html__( 'Typography', 'purple' ),
	'hide_title' => true,
);

$sections['typography-collection'] = array(

	array(
		'id'    => 'typography-collections',
		'type'  => 'typography_collections',
		'title' => esc_html__( 'Theme Typography', 'purple' ),
		'desc'  => esc_html__( 'From here, you can control the fonts used on your site. You can choose from 17 standard font sets, or from the Google Fonts Library containing 800+ fonts.', 'purple' ),
	),

	array(
		'id'    => 'purple_logo',
		'type'  => 'typography',
		'title' => esc_html__( 'Logo Font', 'purple' ),
		'std'   => array(
			'preview-text'  => 'Logo',
			'preview-color' => 'dark',
			'font-family'   => 'Montserrat',
			'font-weight'   => '900',
			'font-size'     => '35px',
			'color'         => '#ffffff',
			'css-selectors' => '#logo a',
		),
	),

	array(
		'id'    => 'secondary_navigation_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Secondary Navigation', 'purple' ),
		'std'   => array(
			'preview-text'  => 'Secondary Navigation Font',
			'preview-color' => 'dark',
			'font-family'   => 'Montserrat',
			'font-weight'   => '600',
			'font-size'     => '16px',
			'color'         => '#e4dffe',
			'css-selectors' => '#secondary-navigation a, .header-default .header-search span.sbutton',
		),
	),

	array(
		'id'    => 'home_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Archive Post Titles', 'purple' ),
		'std'   => array(
			'preview-text'  => 'Archive Article Title',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '700',
			'font-size'     => '27px',
			'line-height'   => '40px',
			'color'         => '#253858',
			'css-selectors' => '.latestPost .title a',
		),
	),

	array(
		'id'    => 'single_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Single Post Title', 'purple' ),
		'std'   => array(
			'preview-text'  => 'Single Article Title',
			'preview-color' => 'dark',
			'font-family'   => 'Montserrat',
			'font-weight'   => '800',
			'font-size'     => '40px',
			'line-height'   => '1.375',
			'color'         => '#ffffff',
			'css-selectors' => '.single-title',
		),
	),

	array(
		'id'       => 'page_title_font',
		'type'     => 'typography',
		'title'    => esc_html__( 'Page Title', 'purple' ),
		'sub_desc' => esc_html__( 'Set Archive Page , Single Page, title from here.', 'purple' ),
		'std'      => array(
			'preview-text'  => 'Page Title',
			'preview-color' => 'dark',
			'font-family'   => 'Montserrat',
			'font-weight'   => '800',
			'font-size'     => '40px',
			'line-height'   => '1.375',
			'color'         => '#ffffff',
			'css-selectors' => '.page-title, .title.entry-title',
		),
	),

	array(
		'id'    => 'content_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Content Font', 'purple' ),
		'std'   => array(
			'preview-text'  => 'Content Font',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '500',
			'font-size'     => '14px',
			'line-height'   => '25px',
			'color'         => '#5e6c84',
			'css-selectors' => 'body',
		),
	),

	array(
		'id'    => 'sidebar_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Widget Title', 'purple' ),
		'std'   => array(
			'preview-text'   => 'Sidebar Title Font',
			'preview-color'  => 'light',
			'font-family'    => 'Montserrat',
			'font-weight'    => '700',
			'font-size'      => '22px',
			'line-height'    => '32px',
			'color'          => '#6c62ff',
			'additional-css' => 'text-align: center;',
			'css-selectors'  => '#sidebar .widget h3.widget-title, .widget #wp-subscribe .title',
		),
	),

	array(
		'id'    => 'sidebar_url',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Links', 'purple' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Links',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '500',
			'font-size'     => '14px',
			'line-height'   => '23px',
			'color'         => '#6c62ff',
			'css-selectors' => '.sidebar .widget a',
		),
	),

	array(
		'id'    => 'sidebar_post_title',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Posts Title', 'purple' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Posts Titles',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '700',
			'font-size'     => '16px',
			'line-height'   => '23px',
			'color'         => '#253858',
			'css-selectors' => '.sidebar .post-title a, .sidebar .entry-title a',
		),
	),

	array(
		'id'    => 'sidebar_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Font', 'purple' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Font',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '500',
			'font-size'     => '14px',
			'line-height'   => '25px',
			'color'         => '#5e6c84',
			'css-selectors' => '#sidebar .widget, #sidebar .widget p, #sidebar .widget .post-excerpt',
		),
	),

	array(
		'id'    => 'top_footer_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Widget Title', 'purple' ),
		'std'   => array(
			'preview-text'   => 'Footer Title Font',
			'preview-color'  => 'dark',
			'font-family'    => 'Montserrat',
			'font-weight'    => '700',
			'font-size'      => '16px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.footer-widgets h3, .brands-title, .f-widget .widget #wp-subscribe .title',
		),
	),

	array(
		'id'    => 'top_footer_link_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Link', 'purple' ),
		'std'   => array(
			'preview-text'  => 'Footer Links',
			'preview-color' => 'dark',
			'font-family'   => 'Montserrat',
			'font-weight'   => '500',
			'font-size'     => '14px',
			'line-height'   => '23px',
			'color'         => '#ffffff',
			'css-selectors' => '.f-widget a, #site-footer .wpt_widget_content a, #site-footer .wp_review_tab_widget_content a',
		),
	),

	array(
		'id'    => 'top_footer_post_title',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Post Title', 'purple' ),
		'std'   => array(
			'preview-text'  => 'Footer Links',
			'preview-color' => 'dark',
			'font-family'   => 'Montserrat',
			'font-weight'   => '600',
			'font-size'     => '14px',
			'line-height'   => '23px',
			'color'         => '#ffffff',
			'css-selectors' => '#site-footer .post-title a, #site-footer .entry-title a',
		),
	),

	array(
		'id'    => 'top_footer_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer font', 'purple' ),
		'std'   => array(
			'preview-text'  => 'Footer Font',
			'preview-color' => 'dark',
			'font-family'   => 'Montserrat',
			'font-weight'   => '500',
			'font-size'     => '14px',
			'line-height'   => '23px',
			'color'         => '#ffffff',
			'css-selectors' => '.footer-widgets, footer .widget .wpt_excerpt, footer .advanced-recent-posts p, footer .popular-posts p, footer .category-posts p',
		),
	),

	array(
		'id'    => 'top_footer_meta_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Meta font', 'purple' ),
		'std'   => array(
			'preview-text'   => 'Footer Font',
			'preview-color'  => 'dark',
			'font-family'    => 'Montserrat',
			'font-weight'    => '500',
			'font-size'      => '12px',
			'line-height'    => '1.5',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '#site-footer .widget .post-info, #site-footer .widget .post-info a, #site-footer .widget .wpt_widget_content .wpt-postmeta, #site-footer .wp_review_tab_widget_content .wp-review-tab-postmeta',
		),
	),

	array(
		'id'    => 'copyrights_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Copyrights Section', 'purple' ),
		'std'   => array(
			'preview-text'  => 'Copyrights Font',
			'preview-color' => 'dark',
			'font-family'   => 'Montserrat',
			'font-weight'   => '500',
			'font-size'     => '14px',
			'color'         => '#ffffff',
			'css-selectors' => '#copyright-note, #copyright-note a',
		),
	),

	array(
		'id'    => 'h1_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H1 Heading in Content', 'purple' ),
		'std'   => array(
			'preview-text'  => 'H1 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '700',
			'font-size'     => '28px',
			'color'         => '#6c62ff',
			'css-selectors' => 'h1',
		),
	),

	array(
		'id'    => 'h2_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H2 Heading in Content', 'purple' ),
		'std'   => array(
			'preview-text'  => 'H2 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '700',
			'font-size'     => '24px',
			'color'         => '#6c62ff',
			'css-selectors' => 'h2',
		),
	),

	array(
		'id'    => 'h3_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H3 Heading in Content', 'purple' ),
		'std'   => array(
			'preview-text'  => 'H3 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '700',
			'font-size'     => '22px',
			'color'         => '#6c62ff',
			'css-selectors' => 'h3',
		),
	),

	array(
		'id'    => 'h4_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H4 Heading in Content', 'purple' ),
		'std'   => array(
			'preview-text'  => 'H4 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '700',
			'font-size'     => '20px',
			'color'         => '#6c62ff',
			'css-selectors' => 'h4',
		),
	),

	array(
		'id'    => 'h5_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H5 Heading in Content', 'purple' ),
		'std'   => array(
			'preview-text'  => 'H5 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '700',
			'font-size'     => '18px',
			'color'         => '#6c62ff',
			'css-selectors' => 'h5',
		),
	),

	array(
		'id'    => 'h6_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H6 Heading in Content', 'purple' ),
		'std'   => array(
			'preview-text'  => 'H6 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Montserrat',
			'font-weight'   => '700',
			'font-size'     => '16px',
			'color'         => '#6c62ff',
			'css-selectors' => 'h6',
		),
	),

	array(
		'id'       => 'typography-subsets',
		'type'     => 'multi_checkbox',
		'title'    => esc_html__( 'Character sets', 'purple' ),
		'sub_desc' => esc_html__( 'Choose the character sets you wish to include. Please note that not all sets are available for all fonts.', 'purple' ),
		'options'  => array(
			'latin'        => esc_html__( 'Latin', 'purple' ),
			'latin-ext'    => esc_html__( 'Latin Extended', 'purple' ),
			'cyrillic'     => esc_html__( 'Cyrillic', 'purple' ),
			'cyrillic-ext' => esc_html__( 'Cyrillic Extended', 'purple' ),
			'greek'        => esc_html__( 'Greek', 'purple' ),
			'greek-ext'    => esc_html__( 'Greek Extended', 'purple' ),
			'vietnamese'   => esc_html__( 'Vietnamese', 'purple' ),
			'khmer'        => esc_html__( 'Khmer', 'purple' ),
			'devanagari'   => esc_html__( 'Devanagari', 'purple' ),
		),
		'std'      => array( 'latin' ),
	),
);
