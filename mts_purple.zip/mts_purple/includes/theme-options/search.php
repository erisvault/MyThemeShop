<?php
/**
 * Search Tab
 *
 * @package Purple
 */

$menus['search'] = array(
	'icon'  => 'fa fa-search',
	'title' => esc_html__( 'Search', 'purple' ),
	'desc'  => esc_html__( 'Setting here apply to search pages.', 'purple' ),
);

$sections['search'] = array(

	array(
		'id'       => 'search_content',
		'type'     => 'select',
		'title'    => esc_html__( 'Search Results Content', 'purple' ),
		'sub_desc' => esc_html__( 'Controls the type of content that displays in search results.', 'purple' ),
		'options'  => array(
			'all'          => esc_html__( 'All Post Types and Pages', 'purple' ),
			'all-no-pages' => esc_html__( 'All Post Types without Pages', 'purple' ),
			'pages'        => esc_html__( 'Only Pages', 'purple' ),
			'posts'        => esc_html__( 'Only Blog Posts', 'purple' ),
			'woocommerce'  => esc_html__( 'Only WooCommerce Products', 'purple' ),
		),
		'std'      => 'posts_pages',
	),

	array(
		'id'       => 'search_results_per_page',
		'type'     => 'text',
		'title'    => esc_html__( 'Number of Search Results Per Page', 'purple' ),
		'sub_desc' => esc_html__( 'Controls the number of search results per page.', 'purple' ),
		'validate' => 'numeric',
		'std'      => '9',
		'class'    => 'small-text',
	),

	array(
		'id'       => 'search_position',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Search Form Position', 'purple' ),
		'sub_desc' => esc_html__( 'Controls the position of the search bar on the search results page.', 'purple' ),
		'options'  => array(
			'above' => esc_html__( 'Above Results', 'purple' ),
			'below' => esc_html__( 'Below Results', 'purple' ),
			'hide'  => esc_html__( 'Hide', 'purple' ),
		),
		'std'      => 'above',
	),
);
