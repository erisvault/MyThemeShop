<?php
/**
 * WooCommerce Tab
 *
 * @package Purple
 */

if ( ! purple_is_woocommerce_active() ) {
	return;
}

$menus['woocommerce'] = array(
	'icon'  => 'fa-shopping-cart',
	'title' => esc_html__( 'Woocommerce', 'purple' ),
	'desc'  => esc_html__( 'Setting here apply both for the archive and search pages.', 'purple' ),
);

$sections['woocommerce'] = array(

	array(
		'id'       => 'woocommerce_shop_items',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'WooCommerce Number of Products per Page', 'purple' ),
		'sub_desc' => esc_html__( 'Controls the number of products that display per page.', 'purple' ),
		'args'     => array( 'type' => 'number' ),
		'std'      => '12',
	),

	array(
		'id'       => 'woocommerce_shop_page_columns',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'WooCommerce Number of Product Columns', 'purple' ),
		'sub_desc' => esc_html__( 'Controls the number of columns for the main shop and archive pages.', 'purple' ),
		'args'     => array( 'type' => 'number' ),
		'std'      => '3',
	),

	array(
		'id'       => 'woocommerce_related_items',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'WooCommerce Related/Up-Sell/Cross-Sell Product Number', 'purple' ),
		'sub_desc' => esc_html__( 'Controls the number of products for the related and up-sell products on single posts and cross-sells on cart page.', 'purple' ),
		'args'     => array( 'type' => 'number' ),
		'std'      => '3',
	),

	array(
		'id'       => 'woocommerce_related_columns',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'WooCommerce Related/Up-Sell/Cross-Sell Product Number of Columns', 'purple' ),
		'sub_desc' => esc_html__( 'Controls the number of columns for the related and up-sell products on single posts and cross-sells on cart page.', 'purple' ),
		'args'     => array( 'type' => 'number' ),
		'std'      => '4',
	),
);
