<?php
/**
 * Header Tab
 *
 * @package Purple
 */

$menus['header'] = array(
	'icon'  => 'fa-header',
	'title' => esc_html__( 'Header', 'purple' ),
);

$menus['header']['child']['header-general'] = array(
	'title' => esc_html__( 'General', 'purple' ),
	'desc'  => esc_html__( 'From here, you can control the elements of header section.', 'purple' ),
);

$sections['header-general'] = array(

	array(
		'id'       => 'mts_header_style',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Header Styling', 'purple' ),
		'sub_desc' => wp_kses( __( 'Choose the <strong>Header design</strong> for your site.', 'purple' ), array( 'strong' => '' ) ),
		'options'  => array(
			'header-default' => array( 'img' => $uri . 'headers/header-default.jpg' ),
			'header-layout2' => array( 'img' => $uri . 'headers/header-layout2.jpg' ),
		),
		'std'      => 'header-default',
	),

	array(
		'id'       => 'mts_sticky_nav',
		'type'     => 'switch',
		'title'    => esc_html__( 'Floating Navigation Menu', 'purple' ),
		// translators: Floating Navigation Menu with strong tag.
		'sub_desc' => sprintf( esc_html__( 'Use this button to enable %s.', 'purple' ), '<strong>' . esc_html__( 'Floating Navigation Menu', 'purple' ) . '</strong>' ),
		'std'      => '0',
	),

	array(
		'id'       => 'mts_header_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Header Margin', 'purple' ),
		'sub_desc' => esc_html__( 'Set header margin from here.', 'purple' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '0',
		),
	),
	array(
		'id'       => 'mts_header_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Header Padding', 'purple' ),
		'sub_desc' => esc_html__( 'Set header padding from here.', 'purple' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '20px',
			'bottom' => '20px',
		),
	),

	array(
		'id'       => 'mts_header_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'purple' ),
		'sub_desc' => esc_html__( 'Select border.', 'purple' ),
	),

	array(
		'id'         => 'header_search_box',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Header Search Form', 'purple' ),
		'sub_desc'   => wp_kses( __( 'Use this button to Show or Hide the <strong>Header Search Form</strong> completely.', 'purple' ), array( 'strong' => '' ) ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_header_style',
				'value'      => 'header-default',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_header_section2',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Logo', 'purple' ),
		'sub_desc' => wp_kses( __( 'Use this button to Show or Hide the <strong>Logo</strong> completely.', 'purple' ), array( 'strong' => '' ) ),
		'std'      => '1',
	),

	array(
		'id'       => 'mts_main_navigation_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Header Background', 'purple' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'purple' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'main_navigation_dropdown_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Color', 'purple' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'purple' ),
		'std'      => '#6c62ff',
	),
	array(
		'id'       => 'main_navigation_dropdown_hover_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Hover Color', 'purple' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'purple' ),
		'std'      => '#253858',
	),

);
