<?php
/**
 * Back to top
 *
 * @package Purple
 */

$menus['footer']['child']['footer-back-to-top'] = array(
	'title' => esc_html__( 'Back to Top', 'purple' ),
	'desc'  => esc_html__( 'From here, you can control the back to top button.', 'purple' ),
);

$sections['footer-back-to-top'] = array(

	array(
		'id'       => 'show_top_button',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Top Button', 'purple' ),
		'sub_desc' => esc_html__( 'Enable or disable back to top button with this option.', 'purple' ),
		'std'      => '1',
	),

	array(
		'id'         => 'bt_top_button_position',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Top Buttons Position', 'purple' ),
		'options'    => array(
			'floating' => esc_html__( 'Floating', 'purple' ),
			'bottom'   => esc_html__( 'Bottom', 'purple' ),
		),
		'sub_desc'   => esc_html__( 'Choose position for Top Button.', 'purple' ),
		'std'        => 'floating',
		'class'      => 'green',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_icon',
		'type'       => 'icon_select',
		'title'      => esc_html__( 'Top Button Icon', 'purple' ),
		'sub_desc'   => esc_html__( 'Set icon for top button icon with this option.', 'purple' ),
		'std'        => 'angle-up',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_text',
		'type'       => 'text',
		'title'      => esc_html__( 'Top Button Text', 'purple' ),
		'sub_desc'   => esc_html__( 'Set Top button text from here.', 'purple' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Button Color', 'purple' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'purple' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_font_size',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Font Size', 'purple' ),
		'sub_desc'   => esc_html__( 'Set font size of top button in px.', 'purple' ),
		'std'        => '40',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'purple' ),
		'sub_desc'   => esc_html__( 'Set Top button padding from here.', 'purple' ),
		'std'        => array(
			'top'    => '25px',
			'right'  => '35px',
			'bottom' => '25px',
			'left'   => '32px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'top_button_position',
		'type'       => 'margin',
		'title'      => esc_html__( 'Button Position', 'purple' ),
		'sub_desc'   => esc_html__( 'Set button position from here.', 'purple' ),
		'std'        => array(
			'top'    => 'auto',
			'right'  => '0px',
			'bottom' => '100px',
			'left'   => 'auto',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'bt_top_button_position',
				'value'      => 'floating',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'button_border_top_radius',
		'type'       => 'margin',
		'title'      => esc_html__( 'Border Radius', 'purple' ),
		'sub_desc'   => esc_html__( 'Set top border radius of top button in px.', 'purple' ),
		'std'        => array(
			'top'    => '100px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '100px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'purple' ),
		'sub_desc'   => esc_html__( 'Select border', 'purple' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

);
