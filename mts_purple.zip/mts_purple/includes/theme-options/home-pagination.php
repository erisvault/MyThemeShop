<?php
/**
 * HomePage Pagination
 *
 * @package Purple
 */

$menus['home-pagination'] = array(
	'title' => esc_html__( 'Pagination', 'purple' ),
	'desc'  => esc_html__( 'From here, you can control the elements of homepage pagination.', 'purple' ),
);

$sections['home-pagination'] = array(

	array(
		'id'       => 'mts_pagenavigation_type',
		'type'     => 'radio',
		'title'    => esc_html__( 'Pagination Type', 'purple' ),
		'sub_desc' => esc_html__( 'Select pagination type.', 'purple' ),
		'options'  => array(
			'0' => esc_html__( 'Default (Next / Previous)', 'purple' ),
			'1' => esc_html__( 'Numbered (1 2 3 4...)', 'purple' ),
			'2' => esc_html__( 'AJAX (Load More Button)', 'purple' ),
			'3' => esc_html__( 'AJAX (Auto Infinite Scroll)', 'purple' ),
		),
		'std'      => '1',
	),

	array(
		'id'         => 'load_more_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Load More Alignment', 'purple' ),
		'sub_desc'   => esc_html__( 'Choose the load more alignment from here.', 'purple' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'purple' ),
			'center' => esc_html__( 'Center', 'purple' ),
			'right'  => esc_html__( 'Right', 'purple' ),
			'full'   => esc_html__( 'Full Width', 'purple' ),
		),
		'std'        => 'center',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_pagenavigation_bgcolor',
		'type'     => 'color',
		'title'    => esc_html__( 'Pagination background color', 'purple' ),
		'sub_desc' => esc_html__( 'Select pagination background hover color.', 'purple' ),
		'std'      => '#e7e4fd',
	),

	array(
		'id'       => 'mts_pagenavigation_hover_bgcolor',
		'type'     => 'color',
		'title'    => esc_html__( 'Pagination background hover color', 'purple' ),
		'sub_desc' => esc_html__( 'Select pagination background hover color. This color will be used in footer hover links, border color and subscribe button.', 'purple' ),
		'std'      => '#fbcd39',
	),

	array(
		'id'       => 'mts_pagenavigation_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Pagination color', 'purple' ),
		'sub_desc' => esc_html__( 'Select pagination color.', 'purple' ),
		'std'      => '#6c62ff',
	),

	array(
		'id'       => 'mts_pagenavigation_hover_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Pagination hover color', 'purple' ),
		'sub_desc' => esc_html__( 'Select pagination hover color.', 'purple' ),
		'std'      => '#253858',
	),

	array(
		'id'         => 'mts_pagenavigation_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Pagination Margin', 'purple' ),
		'sub_desc'   => esc_html__( 'Update pagination margin from here.', 'purple' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '8px',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Pagination Padding', 'purple' ),
		'sub_desc'   => esc_html__( 'Update pagination padding from here.', 'purple' ),
		'std'        => array(
			'top'    => '12px',
			'right'  => '15px',
			'bottom' => '13px',
			'left'   => '15px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Load More Margin', 'purple' ),
		'sub_desc'   => esc_html__( 'Update margin for load more button from here.', 'purple' ),
		'std'        => array(
			'top'    => '20px',
			'right'  => '0',
			'bottom' => '30px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'load_more_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Load More Padding', 'purple' ),
		'sub_desc'   => esc_html__( 'Update padding for load more button from here.', 'purple' ),
		'std'        => array(
			'top'    => '13px',
			'right'  => '25px',
			'bottom' => '13px',
			'left'   => '25px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_border_radius',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Pagination border radius', 'purple' ),
		'sub_desc'   => esc_html__( 'Update pagination border radius in px.', 'purple' ),
		'std'        => '20',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'mts_loadmore_border_radius',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Pagination border radius', 'purple' ),
		'sub_desc'   => esc_html__( 'Update pagination border radius in px.', 'purple' ),
		'std'        => '4',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'pagenavigation_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'purple' ),
		'sub_desc'   => esc_html__( 'Select border', 'purple' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'purple' ),
		'sub_desc'   => esc_html__( 'Select border', 'purple' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),

);
