<?php
/**
 * Set purple layout according to options
 *
 * @package Purple
 */

defined( 'WPINC' ) || exit;

/**
 * Layout manager.
 */
class Purple_Layout extends Purple_Base {

	/**
	 * The Construct
	 */
	public function __construct() {
		$this->add_action( 'purple_before_wrapper', 'add_header' );
		$this->add_action( 'purple_single_top', 'single_post_full_width_header' );
		$this->add_action( 'purple_single_post_header', 'single_post_header' );
		$this->add_action( 'purple_archive_top', 'archive_post_header' );
	}

	/**
	 * Add header
	 */
	public function add_header() {
		$hash = array(
			'header-default' => 'default',
			'header-layout2' => 'layout2',
		);

		$layout = purple_get_settings( 'mts_header_style' );
		get_template_part( 'template-parts/header/header', isset( $hash[ $layout ] ) ? $hash[ $layout ] : $layout );
	}

	/**
	 * Single post header layout
	 */
	public function single_post_full_width_header() {
		//$img_size = purple_get_settings( 'featured_image_size' );

		if ( have_posts() ) :
			while ( have_posts() ) :
				the_post();
				?>
					<header class="single-full-width-header">
						<div class="container">
							<div class="header-wrapper clearfix">
								<h1 class="title single-title"><?php the_title(); ?></h1>
							</div>
						</div>
				</header>
				<?php
			endwhile;
		endif; /* end loop */

	}

	/**
	 * Single post header
	 */
	public function single_post_header() {
		?>
			<header>
				<?php
				if ( purple_get_settings( 'mts_show_featured' ) ) {
					the_post_thumbnail( 'purple-single-featured', array( 'class' => 'single-featured-image' ) );
				}
				?>
				<?php purple_the_post_meta( 'single' ); ?>
			</header><!--.headline_area-->
		<?php
	}

	/**
	 * Archive page header layout
	 */
	public function archive_post_header() {
		?>
			<header class="single-full-width-header archives">
				<div class="container">
					<div class="header-wrapper clearfix">
						<?php
						if ( is_archive() ) {
							the_archive_title( '<h1 class="page-title">', '</h1>' );
						} elseif ( is_search() ) {
							?>
								<h1 class="page-title"><?php printf( esc_html__( 'Search Results for: %s', 'purple' ), '<span>' . get_search_query() . '</span>' ); ?></h1>
							<?php
						} elseif ( is_page() ) {
							?>
								<h1 class="title entry-title"><?php the_title(); ?></h1>
								<?php
						} elseif ( is_404() ) {
							?>
								<h1 class="page-title"><?php esc_html_e( 'Error 404 Not Found', 'purple' ); ?></h1>
							<?php
						} elseif ( purple_is_woocommerce_active() ) {
							if ( is_shop() || is_product_taxonomy() ) {
								?>
								<h1 class="page-title"><?php woocommerce_page_title(); ?></h1>
								<?php
							}
							if ( is_product() || is_cart() || is_checkout() || is_account_page() ) {
								?>
								<h1 class="page-title"><?php the_title(); ?></h1>
								<?php
							}
						}
						?>
					</div>
				</div>
		</header>
		<?php

	}

}

// Init.
new Purple_Layout;
