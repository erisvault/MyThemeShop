<?php

if ( ! class_exists( 'MTS_Options_GoogleFonts' ) ) :

	class MTS_Options_GoogleFonts {

		private static $instance = null;

		public $fonts = array();

		public static function get_instance() {

			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		private function __construct() {
			$this->fonts = $this->get_fonts_array();
		}

		public function get_fonts_array() {

			if ( $transient = get_transient( 'purple_options_googlefonts' ) ) {
				return $transient;
			}

			$fonts = $this->get_transformed_data();
			set_transient( 'purple_options_googlefonts', $fonts, 7 * 24 * HOUR_IN_SECONDS );

			return $fonts;
		}

		private function get_transformed_data() {
			$final_fonts = array();
			$fonts_array = $this->get_fonts_data();
			$dir_path    = get_template_directory() . '/includes/admin/libs/mts-options/img/fonts/';
			$dir_url     = get_template_directory_uri() . '/includes/admin/libs/mts-options/img/fonts/';

			if ( isset( $fonts_array['items'] ) ) {
				$all_variants = array();

				foreach ( $fonts_array['items'] as $font ) {
					// If font-family is not set then skip this item.
					if ( ! isset( $font['family'] ) ) {
						continue;
					}

					$font_slug = str_replace( ' ', '', strtolower( $font['family'] ) );
					$exists    = file_exists( $dir_path . $font_slug . '.png' );

					$final_fonts[ $font['family'] ] = array(
						'text'        => $font['family'],
						'variants'    => array(),
						'has-preview' => $exists ? $font_slug : false,
					);

					if ( isset( $font['variants'] ) && is_array( $font['variants'] ) ) {
						foreach ( $font['variants'] as $variant ) {
							$final_fonts[ $font['family'] ]['variants'][] = $this->convert_font_variants( $variant );
						}
					}
				}
			}
			return $final_fonts;
		}

		private function get_fonts_data() {
			$request = wp_remote_get(
				'https://www.googleapis.com/webfonts/v1/webfonts?key=AIzaSyCjae0lAeI-4JLvCgxJExjurC4whgoOigA',
				array( 'sslverify' => false )
			);

			// Fallback: Get the contents from file.
			if ( is_wp_error( $request ) ) {
				$path = wp_normalize_path( dirname( __FILE__ ) . '/googlefonts-array.php' );
				return include_once $path;
			}

			$fonts_array = wp_remote_retrieve_body( $request );
			return json_decode( $fonts_array, true );
		}

		private function convert_font_variants( $variant ) {

			$variants = array(
				'regular'   => array(
					'id'   => '400',
					'name' => esc_attr__( 'Normal 400', 'lawyer' ),
				),
				'italic'    => array(
					'id'   => '400italic',
					'name' => esc_attr__( 'Normal 400 Italic', 'lawyer' ),
				),
				'100'       => array(
					'id'   => '100',
					'name' => esc_attr__( 'Ultra-Light 100', 'lawyer' ),
				),
				'200'       => array(
					'id'   => '200',
					'name' => esc_attr__( 'Light 200', 'lawyer' ),
				),
				'300'       => array(
					'id'   => '300',
					'name' => esc_attr__( 'Book 300', 'lawyer' ),
				),
				'500'       => array(
					'id'   => '500',
					'name' => esc_attr__( 'Medium 500', 'lawyer' ),
				),
				'600'       => array(
					'id'   => '600',
					'name' => esc_attr__( 'Semi-Bold 600', 'lawyer' ),
				),
				'700'       => array(
					'id'   => '700',
					'name' => esc_attr__( 'Bold 700', 'lawyer' ),
				),
				'700italic' => array(
					'id'   => '700italic',
					'name' => esc_attr__( 'Bold 700 Italic', 'lawyer' ),
				),
				'900'       => array(
					'id'   => '900',
					'name' => esc_attr__( 'Ultra-Bold 900', 'lawyer' ),
				),
				'900italic' => array(
					'id'   => '900italic',
					'name' => esc_attr__( 'Ultra-Bold 900 Italic', 'lawyer' ),
				),
				'100italic' => array(
					'id'   => '100italic',
					'name' => esc_attr__( 'Ultra-Light 100 Italic', 'lawyer' ),
				),
				'300italic' => array(
					'id'   => '300italic',
					'name' => esc_attr__( 'Book 300 Italic', 'lawyer' ),
				),
				'500italic' => array(
					'id'   => '500italic',
					'name' => esc_attr__( 'Medium 500 Italic', 'lawyer' ),
				),
				'800'       => array(
					'id'   => '800',
					'name' => esc_attr__( 'Extra-Bold 800', 'lawyer' ),
				),
				'800italic' => array(
					'id'   => '800italic',
					'name' => esc_attr__( 'Extra-Bold 800 Italic', 'lawyer' ),
				),
				'600italic' => array(
					'id'   => '600italic',
					'name' => esc_attr__( 'Semi-Bold 600 Italic', 'lawyer' ),
				),
				'200italic' => array(
					'id'   => '200italic',
					'name' => esc_attr__( 'Light 200 Italic', 'lawyer' ),
				),
			);

			if ( array_key_exists( $variant, $variants ) ) {
				return $variants[ $variant ];
			}

			return array(
				'id'   => $variant,
				'name' => $variant,
			);
		}
	}

	$googlefonts = MTS_Options_GoogleFonts::get_instance();
	return $googlefonts->fonts;

endif;
