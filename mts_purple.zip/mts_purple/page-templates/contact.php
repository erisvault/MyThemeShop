<?php
/**
 * Template Name: Contact Page
 * The template for displaying the page with a slug of `contact`.
 */
get_header(); ?>

<div id="wrapper" class="<?php purple_single_page_class(); ?>">

	<?php purple_action( 'archive_top' ); ?>

	<?php purple_single_featured_image_effect(); ?>

	<div class="container clearfix">

		<article class="<?php purple_article_class(); ?>">
			<div id="content_box" >
			<?php
			if ( have_posts() ) :
				while ( have_posts() ) :
					the_post();
					?>
					<div id="post-<?php the_ID(); ?>" <?php post_class( 'g post' ); ?>>

						<div class="single_page">
							<?php
							if ( purple_get_settings( 'mts_breadcrumb' ) ) {
								if ( function_exists( 'rank_math' ) && rank_math()->breadcrumbs ) {
									rank_math_the_breadcrumbs();
								} else {
									purple_breadcrumbs();
								}
							}
							?>
							<div class="post-content box mark-links entry-content">
								<?php the_content(); ?>
								<?php
									wp_link_pages(
										array(
											'before'       => '<div class="pagination">',
											'after'        => '</div>',
											'link_before'  => '<span class="current"><span class="currenttext">',
											'link_after'   => '</span></span>',
											'next_or_number' => 'next_and_number',
											'nextpagelink' => '<i class="fa fa-chevron-right"></i>',
											'previouspagelink' => '<i class="fa fa-chevron-left"></i>',
											'pagelink'     => '%',
											'echo'         => 1,
										)
									);
									?>
								<?php mts_contact_form(); ?>
							</div><!--.post-content box mark-links-->
						</div>
					</div>
					<?php //comments_template( '', true ); ?>
				<?php endwhile; ?>
			<?php endif; ?>
			</div>
		</article>
		<?php get_sidebar(); ?>
	</div>
<?php get_footer(); ?>
