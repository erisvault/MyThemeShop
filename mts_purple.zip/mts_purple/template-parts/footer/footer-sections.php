<?php
/**
 * Footer Sections
 *
 * @package Purple
 */
if ( 1 === purple_get_settings( 'footer_brands_section' ) ) :
?>
	<div class="footer-sections">
		<div class="brands-container">

		<?php if ( ! empty( purple_get_settings( 'brands_section_title' ) ) ) : ?>
		<h3 class="brands-title"><?php echo purple_get_settings( 'brands_section_title' ); ?></h3>
		<?php endif; ?>

		<ul class="brands-items">
		<?php
		if ( ! empty( purple_get_settings( 'footer_brands_items' ) ) && is_array( purple_get_settings( 'footer_brands_items' ) ) ) :
			$brands = purple_get_settings( 'footer_brands_items' );
			foreach ( $brands as $brand ) :
				$img          = ! empty( $brand['brand_image'] ) ? sprintf( '<img src="%1$s" alt="%2$s">', $brand['brand_image'], $brand['brand_title'] ) : '';
				$archor_start = ! empty( $brand['brand_url'] ) ? sprintf( '<a href="%1$s">', $brand['brand_url'] ) : '';
				$archor_end   = ! empty( $brand['brand_url'] ) ? '</a>' : '';
				printf( '<li class="brand-info">%1$s%2$s%3$s</li>', $archor_start, $img, $archor_end );
			endforeach;
		endif;
		?>
		</ul>

		</div>
	</div>
<?php
endif;
