<?php
/**
 * Posts Layout - layout category
 *
 * @package Purple
 */

$featured = purple()->featured_layouts;
?>
<div class="<?php purple_article_class(); ?> <?php $featured->get_post_container_class(); ?>>">

	<section class="<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">

		<div class="container">

			<div class="wrapper">

				<div class="purple-category-post">

				<?php
				if ( ! empty( purple_get_settings( 'cat_section_' . $featured->current['unique_id'] ) ) && is_array( purple_get_settings( 'cat_section_' . $featured->current['unique_id'] ) ) ) :
					$categories = purple_get_settings( 'cat_section_' . $featured->current['unique_id'] );
					foreach ( $categories as $category ) :
						$title = ! empty( $category['cat_section_title'] ) ? sprintf( '%1$s', get_the_category_by_ID( $category['cat_section_category'] ) ) : '';
						$icon  = ! empty( $category['cat_section_icon'] ) ? sprintf( '%1$s', $category['cat_section_icon'] ) : '';
						$color = ! empty( $category['cat_section_color'] ) ? sprintf( '%1$s', $category['cat_section_color'] ) : '';
						printf( '<a href="%1$s" style="color:%2$s"><div class="overlay" style="background:%2$s"></div><div class="fa fa-%3$s"></div><div class="category-title">%4$s</div></a>', get_category_link( $category['cat_section_category'] ), $color, $icon, get_the_category_by_ID( $category['cat_section_category'] ) );
					endforeach;
				endif;
				?>

				</div>

			</div>

		</div>

	</section><!--#latest-posts-->

</div>
