<?php
/**
 * Posts Layout - layout default
 *
 * @package Purple
 */
$featured = purple()->featured_layouts;
?>
<div class="<?php $featured->get_post_container_class(); ?> clear ">

	<div class="container">

		<div class="<?php purple_article_class(); ?>">

			<div id="content_box">

				<?php purple_action( 'start_content_box' ); ?>

				<?php $featured->get_section_title(); ?>

				<section id="latest-posts" class="layout-<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">
					<?php
					while ( have_posts() ) :
						the_post();
						?>
					<article class="latestPost excerpt">

						<?php $featured->get_post_thumbnail(); ?>

						<?php $featured->purple_get_post_number(); ?>

							<div class="wrapper">

								<?php $featured->get_post_title(); ?>

								<?php $featured->get_post_content(); ?>

							</div>

							<?php $featured->get_post_meta_info( true ); ?>

						</article>
						<?php
						endwhile;

						$featured->get_post_pagination();
					?>

				</section><!--#latest-posts-->

			</div>

		</div>

		<?php
		if ( ! is_paged() ) {
			$featured->get_sidebar();
		} else {
			get_sidebar();
		}
		?>

</div>

</div>
