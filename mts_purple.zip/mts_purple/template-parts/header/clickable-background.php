<?php
/**
 * Clickable Background
 *
 */

if ( purple_get_settings( 'background_clickable' ) && purple_get_settings( 'background_link' ) ) {
	$target = ( 1 === purple_get_settings( 'background_link_new_tab' ) ) ? 'target="_blank"' : '';
	printf( '<a href="%1$s" rel="nofollow" class="clickable-background" %2$s>', purple_get_settings( 'background_link' ), $target );
}
