<?php if ( purple_get_settings( 'navigation_ad' ) && purple_get_settings( 'navigation_adcode' ) ) { ?>
	<div class="navigation-banner">
		<div class="container">
			<div style="<?php ad_size_value( purple_get_settings( 'navigation_ad_size' ) ); ?>">
				<?php echo purple_get_settings( 'navigation_adcode' ); ?>
			</div>
		</div>
	</div>
<?php } ?>
