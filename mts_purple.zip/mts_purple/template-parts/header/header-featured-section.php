<?php
$title    = purple_get_settings( 'featured_area_title' );
$subtitle = purple_get_settings( 'featured_area_subtitle' );
$desc     = purple_get_settings( 'featured_area_desc' );
$img      = purple_get_settings( 'featured_area_image' );

if ( purple_get_settings( 'featured_area' ) ) {
?>
<div class="featured-area-section clearfix">

<div class="container">

<div class="featured-left">
	<?php
		if ( ! empty( $title ) ) {
			?>
			<h1 class="featured-area-title"><?php echo $title; ?></h1>
			<?php
		}

		if ( ! empty( $subtitle ) ) {
			?>
			<h3 class="featured-area-subtitle"><?php echo $subtitle; ?></h3>
			<?php
		}

		if ( ! empty( $desc ) ) {
			?>
			<div class="featured-area-desc"><?php echo $desc; ?></div>
			<?php
		}

		if ( is_active_sidebar( 'featured-subscribe' ) ) {
			?>
			<div class="featured-subscribe">
				<?php dynamic_sidebar( 'featured-subscribe' ); ?>
			</div>
			<?php
		} else {
			?>
			<div class="featured-subscribe nowidget"><?php echo wp_kses( __( 'Please install <a href="https://wordpress.org/plugins/wp-subscribe/" target="_blank"><strong>WP Subscribe</strong></a> and add Subscribe Widget in the <strong>Featured Subscribe</strong> widget area.', 'purple' ), array( 'strong' => '', 'a' => array( 'href' => array(), 'target' => array() ) ) ); ?></div>
		<?php
		}
		?>
</div>

<div class="featured-right">
	<?php
	if ( ! empty( $img ) ) {
		printf( '<img src="%1$s">', $img );
	}
	?>
</div>

</div>

</div>
<?php
}
