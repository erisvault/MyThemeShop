<?php
/**
 * Header Layout 2
 *
 * @package Purple
 */

?>

<header id="site-header" class="main-header <?php echo esc_attr( purple_get_settings( 'mts_header_style' ) ); ?>" role="banner" itemscope itemtype="http://schema.org/WPHeader">

	<?php if ( purple_get_settings( 'mts_sticky_nav' ) ) { ?>
	<div class="clear" id="catcher"></div>
	<div id="header" class="sticky-navigation">
	<?php } else { ?>
	<div id="header">
	<?php } ?>
		<div class="container">

			<div class="logo-wrap">
				<?php purple_logo(); ?>
			</div>

			<div id="secondary-navigation" class="secondary-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
				<a href="#" id="pull" class="toggle-mobile-menu"><span><?php esc_html_e( 'Menu', 'purple' ); ?></span></a>
				<?php if ( has_nav_menu( 'mobile' ) ) { ?>

					<nav class="navigation clearfix">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'secondary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new purple_menu_walker(),
							));
						}
						?>
					</nav>
					<nav class="navigation mobile-only clearfix mobile-menu-wrapper">
						<?php
						// Mobile Navigation.
						if ( has_nav_menu( 'mobile' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'mobile',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new purple_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } else { ?>

					<nav class="navigation clearfix mobile-menu-wrapper">
						<?php
						// Secondary Navigation.
						if ( has_nav_menu( 'secondary-menu' ) ) {
							wp_nav_menu( array(
								'theme_location' => 'secondary-menu',
								'menu_class'     => 'menu clearfix',
								'container'      => '',
								'walker'         => new purple_menu_walker(),
							));
						}
						?>
					</nav>

				<?php } ?>
			</div>

		</div><!--.container-->

	</div>
</header>
<?php
if ( is_front_page() && ! is_paged() ) {
	get_template_part( 'template-parts/header/header', 'featured-section' );
}
?>
<?php get_template_part( 'template-parts/header/header', 'nav-adcode' ); ?>
<?php get_template_part( 'template-parts/header/header', 'adcode' ); ?>
