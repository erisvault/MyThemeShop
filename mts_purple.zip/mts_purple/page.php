<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package Purple
 */

get_header(); ?>

	<div id="wrapper" class="<?php purple_single_page_class(); ?>">

		<?php purple_action( 'archive_top' ); ?>

		<?php purple_single_featured_image_effect(); ?>

		<div class="container clearfix">

			<article class="<?php purple_article_class(); ?>">

				<?php purple_action( 'before_content' ); ?>

				<div id="content_box" >

				<?php
				if ( have_posts() ) :
					while ( have_posts() ) :
						the_post();
						?>
						<div id="post-<?php the_ID(); ?>" <?php post_class( 'g post' ); ?>>
							<?php
							if ( 1 === purple_get_settings( 'mts_breadcrumb' ) ) {
								if( function_exists( 'rank_math' ) && rank_math()->breadcrumbs ) {
								    rank_math_the_breadcrumbs();
								  } else {
								    purple_breadcrumbs();
								}
							}
							?>
							<div class="single_page">

								<div class="post-content box mark-links entry-content">
									<?php
									if ( ! empty( purple_get_settings( 'mts_social_buttons_on_pages' ) ) && null !== purple_get_settings( 'mts_social_button_position' ) && 'top' === purple_get_settings( 'mts_social_button_position' ) ) {
										purple_social_buttons();
									}

									the_content();

									// Single Page Pagination.
									$args = array(
										'before'           => '<div class="pagination">',
										'after'            => '</div>',
										'link_before'      => '<span class="current"><span class="currenttext">',
										'link_after'       => '</span></span>',
										'next_or_number'   => 'next_and_number',
										'nextpagelink'     => '<i class="fa fa-chevron-right"></i>',
										'previouspagelink' => '<i class="fa fa-chevron-left"></i>',
										'pagelink'         => '%',
										'echo'             => 1,
									);
									wp_link_pages( $args );

									if ( ( ! empty( purple_get_settings( 'mts_social_buttons_on_pages' ) ) && null !== purple_get_settings( 'mts_social_button_position' ) ) && 'top' !== purple_get_settings( 'mts_social_button_position' ) ) {
										purple_social_buttons();
									}
									?>

								</div><!--.post-content box mark-links-->

							</div>

						</div>
						<?php
						// Comment area.
						comments_template( '', true );

					endwhile;

				endif;
				?>

				</div>

			</article>

		<?php get_sidebar(); ?>

	</div>

<?php
get_footer();
