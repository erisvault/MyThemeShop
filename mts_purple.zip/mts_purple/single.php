<?php
/**
 * The template for displaying all single posts.
 *
 * @package Purple
 */

get_header(); ?>

	<div id="wrapper" class="<?php purple_single_page_class(); ?>">

		<?php purple_action( 'single_top' ); ?>

		<div class="container clearfix">

			<?php
			purple_single_featured_image_effect();

			purple_action( 'before_content' );

			purple_single_sections();

			purple_action( 'after_content' );

			get_sidebar();
			?>

		</div>

		<?php
		if ( 'full' === purple_get_settings( 'related_posts_position' ) ) {
			purple_related_posts();
		}
		?>

<?php
get_footer();
