<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="page">
 *
 * @package Purple
 */

?><!doctype html>
<html<?php purple_attr( 'html' ); ?>>
<head<?php purple_attr( 'head' ); ?>>
	<?php wp_head(); ?>
</head>

<body<?php purple_attr( 'body' ); ?>>

	<?php get_template_part( 'template-parts/header/clickable', 'background' ); ?>

	<div<?php purple_attr( 'main' ); ?>>

		<?php purple_action( 'before_wrapper' ); ?>
