<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Purple
 */

get_template_part( 'template-parts/footer/footer', 'ad' );
?>
	</div><!--#wrapper-->

	<footer<?php purple_attr( 'footer' ); ?>>

		<div class="container">
			<?php

			//get_template_part( 'template-parts/footer/footer', 'logo' );

			if ( 'bottom' !== purple_get_settings( 'footer_sections_position' ) ) {
				get_template_part( 'template-parts/footer/footer', 'sections' );
			}

			if ( purple_get_settings( 'mts_top_footer' ) ) {
				purple_footer_widget_columns();
			}

			if ( 'bottom' === purple_get_settings( 'footer_sections_position' ) ) {
				get_template_part( 'template-parts/footer/footer', 'sections' );
			}
			if ( 'bottom' === purple_get_settings( 'bt_top_button_position' ) ) {
				?>
				<a id="move-to-top" class="animate filling move-to-top" href="#blog"><span class="top-text"><?php echo purple_get_settings( 'top_button_text' ); ?></span><i class="fa fa-<?php echo purple_get_settings( 'top_button_icon' ); ?>"></i></a>
				<?php
			}
			?>
		</div>

		<?php purple_footer_copyrights(); ?>

	</footer><!--#site-footer-->

</div><!--.main-container-->

<?php get_template_part( 'template-parts/footer/footer', 'detect-adblocker' ); ?>

<?php wp_footer(); ?>

</body>
</html>
