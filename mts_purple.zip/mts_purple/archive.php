<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Purple
 */

get_header(); ?>

	<div id="wrapper" class="archives">

		<?php purple_action( 'archive_top' ); ?>

		<div class="container">

			<div class="<?php purple_article_class(); ?>">

				<?php purple_action( 'before_content' ); ?>

				<div id="content_box">
					<?php
					the_archive_description( '<div class="taxonomy-description">', '</div>' );

					$j = 0;
					if ( have_posts() ) {
						while ( have_posts() ) {
							the_post();
							purple_blog_articles( 'default' );
						}
					}

					if ( 0 !== ++$j ) {
						purple_pagination( purple_get_settings( 'mts_pagenavigation_type' ) );
					}
					?>
				</div>

				<?php purple_action( 'after_content' ); ?>

			</div>

			<?php get_sidebar(); ?>

		</div>

<?php
get_footer();
