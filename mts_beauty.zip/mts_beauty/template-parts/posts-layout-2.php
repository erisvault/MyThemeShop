<?php
/**
 * Posts Layout - layout 2
 *
 * @package Beauty
 */
$featured = beauty()->featured_layouts;
?>
<div class="<?php beauty_article_class(); ?> <?php $featured->get_post_container_class(); ?> clear ">

	<div class="container">

		<div id="content_box">

			<?php beauty_action( 'start_content_box' ); ?>

			<?php $featured->get_section_title(); ?>

			<?php
			$sidebar_position = beauty_get_settings( 'post_sidebar_position_' . $featured->current['unique_id'] );
			if ( ! empty( $sidebar_position ) ) {
				$post_class = $sidebar_position;
			} else {
				$post_class = '';
			}
			?>

			<div class="<?php echo esc_attr( $featured->current['layout'] ); ?> <?php echo $post_class; ?> clearfix">

			<section id="latest-posts" class="layout-2-posts">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<article class="latestPost excerpt <?php echo ( 0 === ++$j % 2 ) ? 'last' : ''; ?>">

						<div class="latestPost-inner">

							<?php $featured->get_post_thumbnail(); ?>

							<div class="post-overlay"></div>

							<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php the_title_attribute(); ?>" id="featured-thumbnail" class="post-overlay-link-hidden"></a>

							<div class="wrapper">

								<?php $featured->get_post_title( true ); ?>

								<?php $featured->get_post_content(); ?>

							</div>

							<?php $featured->get_post_readmore(); ?>

						</div>

					</article>
					<?php
					endwhile;

					$featured->get_post_pagination();
				?>

			</section><!--#latest-posts-->

			<?php
			if ( ! is_paged() ) {
				$featured->get_sidebar();
			} else {
				get_sidebar();
			}
			?>

		</div>

		</div>

	</div>

</div>
