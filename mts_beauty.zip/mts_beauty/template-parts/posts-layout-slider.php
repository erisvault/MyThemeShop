<?php
/**
 * Posts Layout - layout Slider
 *
 * @package Beauty
 */
$featured = beauty()->featured_layouts;
?>
<div class="<?php beauty_article_class(); ?> <?php $featured->get_post_container_class(); ?> clear ">

	<div class="container">

		<div id="content_box">

			<?php beauty_action( 'start_content_box' ); ?>

			<?php $featured->get_section_title(); ?>

			<?php //$featured->get_view_more_button(); ?>

			<section id="latest-posts" class="<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">
				<?php $featured->beauty_get_slider(); ?>
			</section><!--#latest-posts-->

		</div>

	</div>

</div>
