<?php
/**
 * Posts Layout - layout default
 *
 * @package Beauty
 */
$featured = beauty()->featured_layouts;
?>
<div class="<?php $featured->get_post_container_class(); ?> clear ">

	<div class="container">

		<div class="<?php beauty_article_class(); ?>">

			<?php
			// Elementor 'archive' location.
			if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'archive' ) ) {
				?>

				<div id="content_box">

					<?php beauty_action( 'start_content_box' ); ?>

					<?php $featured->get_section_title(); ?>

					<section id="latest-posts" class="layout-<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">
						<?php
						while ( have_posts() ) :
							the_post();
							?>
						<article class="latestPost excerpt <?php echo ( 0 === ++$j % 3 ) ? 'last' : ''; ?>">

								<div class="latestPost-inner">

									<?php $featured->get_post_thumbnail(); ?>

									<div class="post-overlay"></div>

									<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php the_title_attribute(); ?>" id="featured-thumbnail" class="post-overlay-link-hidden"></a>

									<div class="wrapper">

										<?php $featured->get_post_title( true ); ?>

										<?php $featured->get_post_content(); ?>

									</div>

									<?php $featured->get_post_readmore(); ?>

								</div>

							</article>
							<?php
							endwhile;

							$featured->get_post_pagination();
						?>

					</section><!--#latest-posts-->

				</div>

				<?php
			}
			?>

		</div>

</div>

</div>
