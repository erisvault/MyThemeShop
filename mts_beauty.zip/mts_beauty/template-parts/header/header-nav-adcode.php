<?php if ( beauty_get_settings( 'navigation_ad' ) && beauty_get_settings( 'navigation_adcode' ) ) { ?>
	<div class="navigation-banner">
		<div class="container">
			<div style="<?php ad_size_value( beauty_get_settings( 'navigation_ad_size' ) ); ?>">
				<?php echo beauty_get_settings( 'navigation_adcode' ); ?>
			</div>
		</div>
	</div>
<?php } ?>
