<?php
/**
 * Posts Layout - layout 1
 *
 * @package Beauty
 */
$featured = beauty()->featured_layouts;
?>
<div class="<?php beauty_article_class(); ?> <?php $featured->get_post_container_class(); ?> clear ">

	<div class="container">

		<div id="content_box">

			<?php beauty_action( 'start_content_box' ); ?>

			<?php $featured->get_section_title(); ?>

			<?php //$featured->get_view_more_button(); ?>

			<section id="latest-posts" class="<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">
				<?php
				$j = 0;
				while ( have_posts() ) :
					the_post();

					$image_position = beauty_get_settings( 'post_image_position_' . $featured->current['unique_id'] );
					if ( ! empty( $image_position ) ) {
						$post_class = $image_position;
					} else {
						$post_class = '';
					}
					?>
					<article class="latestPost excerpt <?php echo $post_class; ?>">

						<?php $featured->get_post_thumbnail(); ?>

						<div class="wrapper">

							<?php $featured->get_post_title( true ); ?>

							<?php $featured->get_post_content(); ?>

						</div>

					</article>
					<?php
					endwhile;
				?>

				<?php wp_reset_query(); ?>

			</section><!--#latest-posts-->

		</div>

	</div>

</div>
