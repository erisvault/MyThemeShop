<?php
/**
 * Posts Layout - layout cta
 *
 * @package Beauty
 */
$featured = beauty()->featured_layouts;
?>
<?php
if ( 'container' === beauty_get_settings( 'cta_size_' . $featured->current['unique_id'] ) ) :
?>
<div class="container clear clearfix">
<?php
endif;
?>
	<div class="<?php beauty_article_class(); ?> <?php $featured->get_post_container_class(); ?>">

		<section class="<?php echo esc_attr( $featured->current['layout'] ); ?> clearfix">

			<div class="container">

				<div class="wrapper">

					<div class="layout-cta-inner left-content">
						<?php $featured->get_sidebar(); ?>
					</div>

					<div class="layout-cta-inner right-content">

						<?php

						//$title = ! empty( beauty_get_settings( 'cta_title_' . $featured->current['unique_id'] ) ) ? beauty_get_settings( 'cta_title_' . $featured->current['unique_id'] ) : '';
						$title   = beauty_get_settings( 'cta_title_' . $featured->current['unique_id'] );
						$cta_url = beauty_get_settings( 'cta_url_' . $featured->current['unique_id'] );
						if ( ! empty( $title ) ) {
							printf(
								'<h3 class="cta-title">%s</h3>',
								$title
							);
						}
						if ( ! empty( beauty_get_settings( 'cta_social_icons_' . $featured->current['unique_id'] ) ) ) {
							?>
						<div class="cta-icons-container">
							<?php
							if ( ! empty( beauty_get_settings( 'cta_icon_title_' . $featured->current['unique_id'] ) ) ) {
								printf( '<p class="cta-icons-title">%s</p>', beauty_get_settings( 'cta_icon_title_' . $featured->current['unique_id'] ) );
							}

							// Subscribe Icons
							if ( ! empty( beauty_get_settings( 'cta_social_' . $featured->current['unique_id'] ) ) && is_array( beauty_get_settings( 'cta_social_' . $featured->current['unique_id'] ) ) ) {
								$cta_icons = beauty_get_settings( 'cta_social_' . $featured->current['unique_id'] );
								echo '<div class="cta-social-icons">';

								foreach ( $cta_icons as $item ) {
									printf(
										'<a href="%1$s" title="%2$s" class="cta-%3$s" target="_blank"><span class="fa fa-%3$s"></span></a>',
										$item['cta_social_link'],
										$item['cta_social_title'],
										$item['cta_social_icon']
									);
								}

								echo '</div>';
							}
							?>
						</div>
							<?php
						}
						if ( ! empty( $cta_url ) ) {
							printf(
								'<a class="cta-button" href="%s"><svg class="svg-icon" viewBox="0 0 20 20"><path fill="#efeeee" d="M14.989,9.491L6.071,0.537C5.78,0.246,5.308,0.244,5.017,0.535c-0.294,0.29-0.294,0.763-0.003,1.054l8.394,8.428L5.014,18.41c-0.291,0.291-0.291,0.763,0,1.054c0.146,0.146,0.335,0.218,0.527,0.218c0.19,0,0.382-0.073,0.527-0.218l8.918-8.919C15.277,10.254,15.277,9.784,14.989,9.491z"></path></svg></a>',
								$cta_url
							);
						}
						?>

					</div>

				</div>

			</div>

		</section><!--#latest-posts-->

	</div>
<?php
if ( 'container' === beauty_get_settings( 'cta_size_' . $featured->current['unique_id'] ) ) :
?>
</div>
<?php
endif;
?>
