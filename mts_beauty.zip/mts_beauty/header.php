<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="page">
 *
 * @package Beauty
 */

?><!doctype html>
<html<?php beauty_attr( 'html' ); ?>>
<head<?php beauty_attr( 'head' ); ?>>
	<?php wp_head(); ?>
</head>

<body<?php beauty_attr( 'body' ); ?>>

	<?php get_template_part( 'template-parts/header/clickable', 'background' ); ?>

	<div<?php beauty_attr( 'main' ); ?>>

		<?php beauty_action( 'before_wrapper' ); ?>
