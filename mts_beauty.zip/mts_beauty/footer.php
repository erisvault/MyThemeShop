<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Beauty
 */

get_template_part( 'template-parts/footer/footer', 'ad' );
?>
	</div><!--#wrapper-->

	<footer<?php beauty_attr( 'footer' ); ?>>

	<?php
	// Elementor 'footer' location.
	if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'footer' ) ) {
		?>

		<div class="container">
			<?php

			get_template_part( 'template-parts/footer/footer', 'logo' );

			if ( 'bottom' !== beauty_get_settings( 'footer_sections_position' ) ) {
				get_template_part( 'template-parts/footer/footer', 'sections' );
			}

			if ( beauty_get_settings( 'mts_top_footer' ) ) {
				beauty_footer_widget_columns();
			}

			if ( 'bottom' === beauty_get_settings( 'footer_sections_position' ) ) {
				get_template_part( 'template-parts/footer/footer', 'sections' );
			}
			if ( 'bottom' === beauty_get_settings( 'bt_top_button_position' ) ) {
				?>
				<a id="move-to-top" class="animate filling move-to-top" href="#blog"><span class="top-text"><?php echo beauty_get_settings( 'top_button_text' ); ?></span><i class="fa fa-<?php echo beauty_get_settings( 'top_button_icon' ); ?>"></i></a>
				<?php
			}
			?>
		</div>

		<?php beauty_footer_copyrights(); ?>

		<?php
	}
	?>

	</footer><!--#site-footer-->

</div><!--.main-container-->

<?php get_template_part( 'template-parts/footer/footer', 'detect-adblocker' ); ?>

<?php wp_footer(); ?>

</body>
</html>
