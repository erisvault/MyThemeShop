<?php
/**
 * The template for displaying search results pages.
 *
 * @package Beauty
 */

get_header(); ?>

	<div id="wrapper">

		<div class="container">

			<div class="article">

				<?php
				// Elementor 'archive' location.
				if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'archive' ) ) {
					?>

					<?php beauty_action( 'before_content' ); ?>

					<div id="content_box">

						<?php if ( have_posts() ) : ?>

							<h1 class="page-title">
								<?php
								// translators: search query.
								printf( esc_html__( 'Search Results for: %s', 'beauty' ), '<span>' . get_search_query() . '</span>' );
								?>
							</h1>
						<?php else : ?>
							<h1 class="page-title"><?php esc_html_e( 'Nothing Found', 'beauty' ); ?></h1>
						<?php endif; ?>

						<?php
						if ( 'above' === beauty_get_settings( 'search_position' ) ) {
							get_search_form();
						}
						?>
						<section id="latest-posts" class="layout-2 layout-default">
						<?php
						$j = 0;
						if ( have_posts() ) {
							while ( have_posts() ) {
								the_post();
								beauty_blog_articles( 'default' );
							}
						} else {
							get_template_part( 'template-parts/no', 'results' );
						}

						if ( 0 !== ++$j ) {
							beauty_pagination( beauty_get_settings( 'mts_pagenavigation_type' ) );
						}
						?>
						</section>

						<?php
						if ( 'below' === beauty_get_settings( 'search_position' ) ) {
							get_search_form();
						}
						?>
					</div>

					<?php beauty_action( 'after_content' ); ?>

					<?php
				}
				?>

			</div>

			<?php get_sidebar(); ?>

		</div>

<?php
get_footer();
