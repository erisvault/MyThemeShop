<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Beauty
 */

get_header(); ?>

	<div id="wrapper">

		<div class="container">

			<div class="<?php beauty_article_class(); ?>">

				<?php
				// Elementor 'archive' location.
				if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'archive' ) ) {

					beauty_action( 'before_content' );
					?>

					<div id="content_box">
						<?php
						the_archive_title( '<h1 class="page-title">', '</h1>' );
						the_archive_description( '<div class="taxonomy-description">', '</div>' );
						?>
							<section id="latest-posts" class="layout-2 layout-default">
							<?php
							$j = 0;
							if ( have_posts() ) {
								while ( have_posts() ) {
									the_post();
									beauty_blog_articles( 'default' );
								}
							}
							if ( 0 !== ++$j ) {
								beauty_pagination( beauty_get_settings( 'mts_pagenavigation_type' ) );
							}
							?>
						</section>
					</div>

					<?php
					beauty_action( 'after_content' );
				}
				?>

			</div>

			<?php get_sidebar(); ?>

		</div>

<?php
get_footer();
