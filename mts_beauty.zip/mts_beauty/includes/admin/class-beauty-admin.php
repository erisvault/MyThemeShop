<?php
/**
 * Theme administration functions used with other components of the framework admin.
 *
 * @package Beauty
 */

defined( 'WPINC' ) || exit;

/**
 * Admin
 */
class Beauty_Admin extends Beauty_Base {

	/**
	 * The Constructor
	 */
	public function __construct() {
		$this->includes();
		$this->add_action( 'admin_init', 'theme_activated' );
		$this->add_action( 'admin_enqueue_scripts', 'enqueue_scripts' );
		$this->add_action( 'admin_bar_menu', 'admin_bar_menu', 99 );
		$this->add_action( 'admin_menu', 'add_theme_option_submenu', 999 );
	}

	/**
	 * Include core
	 */
	private function includes() {
		include_once $this->admin_path() . 'class-beauty-admin-pages.php';
		include_once $this->admin_path() . 'class-beauty-admin-metabox.php';
		include_once $this->admin_path() . 'libs/class-tgm-plugin-activation.php';
		include_once $this->admin_path() . 'beauty-tgm-functions.php';
		include_once $this->admin_path() . 'class-beauty-demo-importer.php';
	}

	/**
	 * Theme activated
	 *
	 * @param string $stylesheet Theme name.
	 */
	public function theme_activated( $stylesheet ) {

		if ( isset( $_GET['activated'] ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=install-required-plugins' ) );
		}

	}

	/**
	 * Fix first submenu name.
	 */
	public function add_theme_option_submenu() {
		global $submenu;

		$submenu['themes.php'][] = array(
			esc_html__( 'Theme Options', 'beauty' ),
			'manage_options',
			admin_url( 'admin.php?page=beauty-options' ),
			'beauty-options',
		);
	}

	/**
	 * Enqueue scripts
	 */
	public function enqueue_scripts() {
		$screen = get_current_screen();
		$pages  = array(
			'toplevel_page_beauty',
			'beauty_page_beauty-support',
			'beauty_page_beauty-plugins',
			'beauty_page_beauty-system-status',
			'theme-options_page_beauty_demos',
		);

		if ( in_array( $screen->base, $pages ) ) {
			wp_enqueue_style( 'beauty-admin', $this->admin_uri() . 'assets/css/beauty-admin.css' );
		}

		if ( 'theme-options_page_beauty_demos' === $screen->base ) {
			wp_enqueue_style( 'beauty-demo', $this->admin_uri() . 'assets/css/beauty-demo.css' );
			wp_enqueue_script( 'beauty-importer', $this->admin_uri() . 'assets/js/beauty-importer.js', array( 'jquery' ), null, true );
		}

		wp_enqueue_script( 'clipboard', $this->admin_uri() . 'assets/vendors/clipboard.min.js', null, null, true );
		wp_enqueue_script( 'beauty-admin', $this->admin_uri() . 'assets/js/beauty-admin.js', array( 'clipboard' ), null, true );
	}

	/**
	 * Admin node
	 */
	public function admin_bar_menu() {
		global $menu, $submenu, $wp_admin_bar;

		if ( ! is_super_admin() || ! is_admin_bar_showing() || ! $submenu ) {
			return;
		}

		// Parent node.
		$parent = false;
		foreach ( $menu as $m ) {
			if ( 'beauty' === $m[2] ) {
				$parent = $m;
				break;
			}
		}

		if ( ! $parent ) {
			return;
		}

		$wp_admin_bar->add_menu( array(
			'id'    => $parent[2],
			'title' => '<span class="ab-icon"></span>' . $parent[0],
			'href'  => admin_url( 'admin.php?page=' . $parent[2] ),
		) );

		// Submenu.
		$submenus = $submenu['beauty'];
		unset( $submenus[0] );
		foreach ( $submenus as $item ) {
			$wp_admin_bar->add_menu( array(
				'id'     => $item[2],
				'title'  => $item[0],
				'parent' => $parent[2],
				'href'   => admin_url( 'admin.php?page=' . $item[2] ),
			) );
		}
	}
}

/**
 * Init
 */
new Beauty_Admin;
