<?php
/**
 * Sidebars
 *
 * @package Beauty
 */

defined( 'WPINC' ) || exit;

/**
 * Single sections
 */
class Beauty_Single_Sections extends Beauty_Base {

	public function render() {
		?>
		<article class="<?php beauty_article_class(); ?>">
			<?php
			if ( 'mts_nosidebar' !== mts_custom_sidebar() ) {
				$sidebar = beauty_custom_sidebar_layout();
			} else {
				$sidebar = 'nosidebar';
			}
			?>
			<div id="content_box" class="<?php echo $sidebar; ?>">
				<?php
				// Elementor `single` location.
				if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'single' ) ) {
					if ( have_posts() ) :
						while ( have_posts() ) :
							the_post();
							?>
							<div id="post-<?php the_ID(); ?>" <?php post_class( 'g post' ); ?>>
								<?php
								if ( beauty_get_settings( 'mts_breadcrumb' ) ) {
									beauty_breadcrumbs();
								}
								// Single post parts ordering.
								if ( ( null !== beauty_get_settings( 'mts_single_post_layout' ) ) && is_array( beauty_get_settings( 'mts_single_post_layout' ) ) && array_key_exists( 'enabled', beauty_get_settings( 'mts_single_post_layout' ) ) ) {
									$single_post_parts = beauty_get_settings( 'mts_single_post_layout' )['enabled'];
								} else {
									$single_post_parts = array(
										'content'   => 'content',
										'related'   => 'related',
										'author'    => 'author',
										'subscribe' => 'subscribe',
									);
								}

								foreach ( $single_post_parts as $part => $label ) {
									switch ( $part ) {
										// Content area.
										case 'content':
											beauty()->single_sections->single_post();
											break;

										// Post tags.
										case 'tags':
											beauty_post_tags( '<div class="tags">', ' ' );
											break;

										// Related Posts.
										case 'related':
											if ( 'default' === beauty_get_settings( 'related_posts_position' ) ) {
												beauty_related_posts();
											}
											break;

										// Author box.
										case 'author':
											beauty()->single_sections->single_author_section();
											break;

										// Subscribe box.
										case 'subscribe':
											if ( 'subscribe-default' === beauty_get_settings( 'single_subscribe_position' ) ) {
													beauty()->single_sections->single_subscribe_box();
											}
											break;
									}
								}
								?>
							</div><!--.g post-->
							<?php
							// Comment area.
							comments_template( '', true );

						endwhile;
					endif; /* end loop */
				}
				?>
			</div>
		</article>
		<?php
	}

	public function single_post() {
		?>
		<div class="single_post">

			<?php beauty_action( 'single_post_header' ); ?>

			<div class="post-single-content box mark-links entry-content">

				<?php
				$this->single_post_ads( 'above' );

				$this->single_post_social_icons( 'above' );
				?>

				<div class="thecontent">
					<?php the_content(); ?>
				</div>

				<?php
				$this->single_post_pagination();

				$this->single_post_social_icons( 'below' );

				$this->single_post_ads( 'below' );

				//$this->single_post_social_icons( 'below' );
				?>

			</div><!--.post-single-content-->
		</div><!--.single_post-->
		<?php
	}

	public function single_post_pagination() {
		// Single Post Pagination.
		$args = array(
			'before'           => '<div class="pagination">',
			'after'            => '</div>',
			'link_before'      => '<span class="current"><span class="currenttext">',
			'link_after'       => '</span></span>',
			'next_or_number'   => 'next_and_number',
			'nextpagelink'     => '<i class="fa fa-chevron-right"></i>',
			'previouspagelink' => '<i class="fa fa-chevron-left"></i>',
			'pagelink'         => '%',
			'echo'             => 1,
		);
		wp_link_pages( $args );
	}

	public function single_author_section() {
		?>
		<div class="postauthor">
			<?php
			// Author gravatar.
			if ( function_exists( 'get_avatar' ) ) {
				echo get_avatar( get_the_author_meta( 'email' ), '200' ); // Gravatar size.
			}
			?>
			<h5 class="vcard author">
				<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" class="fn">
					<?php the_author_meta( 'display_name' ); ?>
				</a>
			</h5>
			<p><?php the_author_meta( 'description' ); ?></p>
			<?php
			if ( beauty_get_settings( 'authorbox_social_share' ) ) {
				$userid      = get_current_user_id();
				$facebook    = get_the_author_meta( 'facebook', $userid );
				$twitter     = get_the_author_meta( 'twitter', $userid );
				$instagram   = get_the_author_meta( 'instagram', $userid );
				$pinterest   = get_the_author_meta( 'pinterest', $userid );
				$stumbleupon = get_the_author_meta( 'stumbleupon', $userid );
				$linkedin    = get_the_author_meta( 'linkedin', $userid );

				if ( ! empty( $facebook ) || ! empty( $twitter ) || ! empty( $instagram ) || ! empty( $pinterest ) || ! empty( $stumbleupon ) || ! empty( $linkedin ) ) {
					echo '<div class="author-social clearfix">';
					if ( ! empty( $facebook ) ) {
						echo '<a href="' . $facebook . '" class="facebook"><i class="fa fa-facebook"></i></a>';
					}
					if ( ! empty( $twitter ) ) {
						echo '<a href="' . $twitter . '" class="twitter"><i class="fa fa-twitter"></i></a>';
					}
					if ( ! empty( $instagram ) ) {
						echo '<a href="' . $instagram . '" class="instagram"><i class="fa fa-instagram"></i></a>';
					}
					if ( ! empty( $pinterest ) ) {
						echo '<a href="' . $pinterest . '" class="pinterest"><i class="fa fa-pinterest"></i></a>';
					}
					if ( ! empty( $stumbleupon ) ) {
						echo '<a href="' . $stumbleupon . '" class="stumble"><i class="fa fa-stumbleupon"></i></a>';
					}
					if ( ! empty( $linkedin ) ) {
						echo '<a href="' . $linkedin . '" class="linkedin"><i class="fa fa-linkedin"></i></a>';
					}
					echo '</div>';
				}
			}
			?>
		</div>
		<?php
	}

	public function single_subscribe_box() {
		$position = ! empty( beauty_get_settings( 'single_subscribe_position' ) ) ? beauty_get_settings( 'single_subscribe_position' ) : 'subscribe-default';
		?>
		<div class="single-subscribe <?php echo $position; ?> clear">
			<?php echo ( 'subscribe-full' === $position ) ? '<div class="container">' : ''; ?>
		<?php
		if ( is_active_sidebar( 'single-subscribe' ) ) {
			?>
				<div class="single-subscribe-inner left-content">
					<?php dynamic_sidebar( 'single-subscribe' ); ?>
				</div>
			<?php
		}
		$single_title = beauty_get_settings( 'single_subscribe_custom_title' );
		$single_url   = beauty_get_settings( 'single_subscribe_custom_url' );
		if ( ! empty( $single_title ) ) {
			?>
			<div class="single-subscribe-inner right-content">
				<?php
				if ( ! empty( $single_title ) ) {
					printf(
						'<h3 class="single-subscribe-title">%s</h3>',
						$single_title
					);
				}
				if ( ! empty( $single_url ) ) {
					printf(
						'<a class="cta-button" href="%s"><svg class="svg-icon" viewBox="0 0 20 20"><path fill="#efeeee" d="M14.989,9.491L6.071,0.537C5.78,0.246,5.308,0.244,5.017,0.535c-0.294,0.29-0.294,0.763-0.003,1.054l8.394,8.428L5.014,18.41c-0.291,0.291-0.291,0.763,0,1.054c0.146,0.146,0.335,0.218,0.527,0.218c0.19,0,0.382-0.073,0.527-0.218l8.918-8.919C15.277,10.254,15.277,9.784,14.989,9.491z"></path></svg></a>',
						$single_url
					);
				}
				?>
			</div>
			<?php
		}
		echo ( 'subscribe-full' === $position ) ? '</div>' : '';
		?>
		</div>
		<?php
	}

	public function single_post_ads( $location ) {
		// Above Content Ad Code.
		if ( ! empty( beauty_get_settings( 'mts_posttop_adcode' ) ) && 'above' == $location ) {
			$toptime = ! empty( beauty_get_settings( 'mts_posttop_adcode_time' ) ) ? beauty_get_settings( 'mts_posttop_adcode_time' ) : '0';
			if ( strcmp( date( 'Y-m-d', strtotime( -$toptime . ' day' ) ), get_the_time( 'Y-m-d' ) ) >= 0 ) {
				?>
				<div class="topad">
					<?php echo do_shortcode( beauty_get_settings( 'mts_posttop_adcode' ) ); ?>
				</div>
				<?php
			}
		}
		// Below Content Ad Code.
		if ( ! empty( beauty_get_settings( 'mts_postend_adcode' ) ) && 'below' == $location ) {
			$endtime = ! empty( beauty_get_settings( 'mts_postend_adcode_time' ) ) ? beauty_get_settings( 'mts_postend_adcode_time' ) : '0';
			if ( strcmp( date( 'Y-m-d', strtotime( -$endtime . ' day' ) ), get_the_time( 'Y-m-d' ) ) >= 0 ) {
				?>
				<div class="bottomad">
					<?php echo do_shortcode( beauty_get_settings( 'mts_postend_adcode' ) ); ?>
				</div>
				<?php
			}
		}
	}

	public function single_post_social_icons( $location ) {
		// Social Share icons above content.
		if ( null !== beauty_get_settings( 'mts_social_button_position' ) && 'top' === beauty_get_settings( 'mts_social_button_position' ) && 'above' == $location ) {
			beauty_social_buttons();
		}
		// Social Share icons below content and floating.
		if ( ( null !== beauty_get_settings( 'mts_social_button_position' ) ) && 'top' !== beauty_get_settings( 'mts_social_button_position' ) && 'below' == $location ) {
			beauty_social_buttons();
		}
	}

}
