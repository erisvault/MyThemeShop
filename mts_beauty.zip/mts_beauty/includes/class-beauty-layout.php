<?php
/**
 * Set beauty layout according to options
 *
 * @package Beauty
 */

defined( 'WPINC' ) || exit;

/**
 * Layout manager.
 */
class Beauty_Layout extends Beauty_Base {

	/**
	 * The Construct
	 */
	public function __construct() {
		$this->add_action( 'beauty_before_wrapper', 'add_header' );
		$this->add_action( 'beauty_single_top', 'full_single_post_header' );
		$this->add_action( 'beauty_single_post_header', 'single_post_header' );
	}

	/**
	 * Add header
	 */
	public function add_header() {
		$hash = array(
			'header-default' => 'default',
			'header-layout2' => 'layout2',
		);

		$layout = beauty_get_settings( 'mts_header_style' );
		get_template_part( 'template-parts/header/header', isset( $hash[ $layout ] ) ? $hash[ $layout ] : $layout );
	}

	/**
	 * Single post header if fullwidth layout
	 */
	public function full_single_post_header() {
		$img_size = beauty_get_settings( 'featured_image_size' );

		if ( 'full' === $img_size ) {

			if ( have_posts() ) :
				while ( have_posts() ) :
					the_post();

					$featured_image = array();
					if ( beauty_get_settings( 'mts_show_featured' ) ) {
						if ( has_post_thumbnail() ) {
							$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'beauty-full-header' );
							$class          = 'with-featured';
						} else {
							$nothumb = get_parent_theme_file_uri() . '/images/nothumb-beauty-full-header.png';
							$class   = 'with-featured';
						}
					}
					?>
						<header class="single-full-header <?php echo isset( $class ) ? $class : ''; ?> clearfix" style="background-image: url('<?php echo has_post_thumbnail() ? $featured_image[0] : $nothumb; ?>');">
						<?php
						if ( beauty_get_settings( 'show_prev_next' ) ) {
						?>
							<div class="prev-next">
								<?php
								previous_post_link( '<div class="prev">%link</div>', '<i class="fa fa-angle-left"></i>', true );
								next_post_link( '<div class="next">%link</div>', '<i class="fa fa-angle-right"></i>', true );
								?>
							</div>
						<?php
						}
						?>
						<div class="content">
							<div class="container">
								<div class="full-header-wrapper clearfix">
									<?php
									// Author gravatar.
									if ( beauty_get_settings( 'author_image_on_full' ) && beauty_get_settings( 'mts_show_featured' ) && function_exists( 'get_avatar' ) ) {
										echo get_avatar( get_the_author_meta( 'email' ), '70' ); // Gravatar size.
									}
									?>
									<h1 class="title single-title entry-title"><?php the_title(); ?></h1>
									<?php beauty_the_post_meta( 'single' ); ?>
								</div>
							</div>
						</div>
					</header>
				<?php
				endwhile;
			endif; /* end loop */

		}
	}

	/**
	 * Single post header
	 */
	public function single_post_header() {

		$img_size = beauty_get_settings( 'featured_image_size' );

		if ( 'default' === $img_size ) {
		?>
			<header>
				<?php beauty_the_post_meta( 'single' ); ?>
				<h1 class="title single-title entry-title"><?php the_title(); ?></h1>
				<?php
				$header_animation = beauty_get_post_header_effect();
				if ( beauty_get_settings( 'mts_show_featured' ) && empty( $header_animation ) ) {
					the_post_thumbnail( 'beauty-slider', array( 'class' => 'single-featured-image' ) );
				}
				if ( beauty_get_settings( 'secondary_single_meta_info' ) ) {
					?>
					<div class="secondary-meta-info-wrap">
						<div class="secondary-meta-info">
							<div class="secondary-meta-info-inner">
								<?php
								$sec_meta_info = beauty_get_settings( 'secondary_author_image' );
								if ( isset( $sec_meta_info['author-image'] ) ) :
									echo get_avatar( get_the_author_meta( 'email' ), '72' ); // Gravatar size.
								endif;
								if ( isset( $sec_meta_info['author-name'] ) ) :
									printf( '<div class="theauthor"><span>%s</span></div>', get_the_author_posts_link() );
								endif;
								beauty_the_post_meta( 'secondary_single' );
								?>
							</div>
						</div>
					</div>
					<?php
				}
				?>
			</header><!--.headline_area-->
		<?php
		}
	}
}

// Init.
new Beauty_Layout;
