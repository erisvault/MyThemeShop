<?php
/**
 * The featured layouts
 *
 * @package Beauty
 */

defined( 'WPINC' ) || exit;

/**
 * Class for featured layouts.
 */
class Beauty_Featured_Layouts extends Beauty_Base {

	/**
	 * Current layout.
	 *
	 * @var string
	 */
	public $current = null;

	/**
	 * Hold sections.
	 *
	 * @var array
	 */
	private $sections = null;

	/**
	 * The Construct
	 */
	public function __construct() {
		$this->sections = beauty_get_settings( 'mts_featured_categories' );
	}

	/**
	 * Render layout
	 */
	public function render() {

		if ( empty( $this->sections ) ) {
			$this->current = array(
				'layout'         => 'default',
				'posts_layout'   => 'layout-default',
				'excerpt_length' => 20,
				'unique_id'      => 'nothing',
				'is_latest'      => true,
			);

			get_template_part( 'template-parts/posts', 'default' );
			return;
		}

		foreach ( $this->sections as $section ) :

			$flag         = false;
			$posts_layout = $section['mts_thumb_layout'];
			if ( 'layout-slider' == $posts_layout || 'layout-partners' == $posts_layout || 'layout-category' == $posts_layout || 'layout-cta' == $posts_layout || 'layout-ad' == $posts_layout ) {
				$flag = true;
			}

			if ( is_paged() && ( 'latest' !== $section['mts_featured_category'] || $flag ) ) {
				continue;
			}

			if ( ! is_paged() ) {
				$layout = $posts_layout;
			} else {
				$layout = '';
			}
			if ( 'layout-default' === $posts_layout ) {
				$layout = 'default';
			} else {
				$layout = $posts_layout;
			}

			$section = wp_parse_args(
				array_filter( $section ),
				array(
					'mts_thumb_layout'               => '',
					'mts_featured_category_postsnum' => 3,
					'mts_featured_category_excerpt'  => 20,
					'unique_id'                      => '',
				)
			);

			$category = $section['mts_featured_category'];

			if ( 'latest' == $category && 'layout-1' == $posts_layout ) {

				global $wp_query;
				$wp_query = new WP_Query( array( 'posts_per_page' => 1 ) );

			} elseif ( 'latest' === $category && 'layout-1' !== $posts_layout ) {

				global $wp_query;
				$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

				$wp_query = new WP_Query( array(
					'posts_per_page' => $section['mts_featured_category_postsnum'],
					'paged'          => $paged,
				) );
			}

			if ( 'latest' !== $category ) {
				if ( 'layout-1' === $posts_layout ) {
					$section['mts_featured_category_postsnum'] = 1;
				}
				$this->category_posts( $category, $section['mts_featured_category_postsnum'] );
			}

			$this->current = array(
				'layout'         => $layout,
				'category'       => $category,
				'unique_id'      => $section['unique_id'],
				'is_latest'      => 'latest' !== $category,
				'posts_layout'   => $posts_layout,
				'posts_count'    => $section['mts_featured_category_postsnum'],
				'excerpt_length' => $section['mts_featured_category_excerpt'],
			);

			if ( have_posts() ) {
				get_template_part( 'template-parts/posts', $layout );
			}

		endforeach;
	}

	/**
	 * Genrate post_container classes
	 */
	public function get_post_container_class() {
		$classes   = array();
		$classes[] = 'layout-' . $this->current['unique_id'];
		$classes[] = $this->current['layout'] . '-container';
		$classes[] = 'clearfix';

		echo join( ' ', $classes );
	}

	/**
	 * Set category in main query
	 *
	 * @param  int $category    Category ID.
	 * @param  int $posts_count Number of posts.
	 */
	public function category_posts( $category, $posts_count ) {
		global $wp_query;

		$wp_query = new WP_Query( 'ignore_sticky_posts=1&category_name=' . $category . '&posts_per_page=' . $posts_count );
	}

	/**
	 * Get section title.
	 *
	 * @param int $category Category id or name.
	 */
	public function get_section_title( $category = false ) {
		if ( beauty_get_settings( 'mts_featured_category_title_' . $this->current['unique_id'] ) ) :
			$category = ! $category ? $this->current['category'] : $category;
		?>
		<div class="title-container title-id-<?php echo $this->current['unique_id']; ?>">
			<?php
			if ( ! $this->current['is_latest'] && 'latest' === $category ) {
				echo '<h3 class="featured-category-title">';
				_e( 'Latest', 'beauty' );
				echo '</h3></div>';
				return;
			}
			$category_name = beauty_get_cat_name( $category );
			$category_id   = get_cat_ID( $category_name );
			?>
			<h3 class="featured-category-title"><a href="<?php echo esc_url( get_category_link( $category_id ) ); ?>" title="<?php echo esc_attr( $category_name ); ?>"><?php echo esc_html( $category_name ); ?></a></h3>
		</div>
		<?php
		endif;
	}

	/**
	 * Get Slider
	 *
	 * @param int $slider_category Category id or name.
	 */
	public function beauty_get_slider() {
		?>
		<div class="primary-slider-container clearfix loading">
			<div id="primary-slider" class="primary-slider">
				<?php
				$slider_category = beauty_get_settings( 'mts_featured_slider_category_' . $this->current['unique_id'] );
				$slider_num      = ! empty( beauty_get_settings( 'mts_featured_slider_num_' . $this->current['unique_id'] ) ) ? beauty_get_settings( 'mts_featured_slider_num_' . $this->current['unique_id'] ) : 3;

				// prevent implode error
				if ( empty( $slider_category ) || ! is_array( $slider_category ) ) {
					$slider_category = array( '0' );
				}
				$slider_cat   = implode( ',', $slider_category );
				$slider_query = new WP_Query( 'cat=' . $slider_cat . '&posts_per_page=' . $slider_num );

				while ( $slider_query->have_posts() ) :
					$slider_query->the_post();
						?>
					<div class="primary-slider-item">
						<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>" id="featured-thumbnail" class="post-image post-image-left <?php echo 'layout-default'; ?>">
							<div class="featured-thumbnail">
								<?php the_post_thumbnail( 'beauty-slider', array( 'title' => '' ) ); ?>
							</div>
						</a>
						<div class="slide-caption">
							<?php beauty_the_post_meta( 'home', $this->current['unique_id'] ); ?>
							<h2 class="title front-view-title"><a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>"><?php the_title(); ?></a></h2>
							<div class="front-view-content">
								<?php
								if ( empty( beauty_excerpt() ) ) {
									echo beauty_truncate( get_the_content(), '24', 'words' );
								} else {
									echo beauty_excerpt( '24' );
								}
								?>
							</div>
						</div>
					</div>
					<?php
				endwhile;
				wp_reset_postdata();
				?>
			</div><!-- .primary-slider -->
		</div><!-- .primary-slider-container -->
		<?php
	}

	/**
	 * Get post title
	 *
	 * @param  boolean $meta     Display meta.
	 * @param  string  $position Position to display meta at.
	 */
	public function get_post_title( $meta = true ) {

		?>
		<header>
			<?php
			if ( $meta ) {
				beauty_the_post_meta( 'home', $this->current['unique_id'] );
			}
			?>
			<h2 class="title front-view-title">
				<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php the_title_attribute(); ?>"><?php echo the_title(); ?></a>
			</h2>
		</header>
		<?php
	}

	/**
	 * Get post thumbnail according to layout
	 *
	 * @param  integer $j      Even or Odd.
	 * @param  boolean $avatar Display avatar.
	 */
	public function get_post_thumbnail( $j = 0, $avatar = false ) {
		$default_thumb = 'beauty-featured';
		$thumbs        = array(
			'layout-1' => 'beauty-slider',
		);

		$size = isset( $thumbs[ $this->current['posts_layout'] ] ) ? $thumbs[ $this->current['posts_layout'] ] : $default_thumb;
		?>
		<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php the_title_attribute(); ?>" id="featured-thumbnail" class="post-image post-image-left <?php echo $size; ?>">
			<div class="featured-thumbnail">
				<?php
				if ( has_post_thumbnail() ) {
					the_post_thumbnail( $size, array( 'title' => '' ) );
				} else {
					echo '<img src="' . get_template_directory_uri() . '/images/nothumb-' . $size . '.png" alt="' . __( 'No Preview', 'beauty' ) . '"  class="wp-post-image" />';
				}
				?>
			</div>
			<?php
			if ( function_exists( 'wp_review_show_total' ) ) {
				wp_review_show_total( true, 'latestPost-review-wrapper' );
			}

			// Author gravatar.
			if ( $avatar && function_exists( 'get_avatar' ) ) {
				echo get_avatar( get_the_author_meta( 'email' ), '57' ); // Gravatar size.
			}
			?>
		</a>
		<?php
	}

	/**
	 * Get post content
	 *
	 * @param  boolean $meta Display meta.
	 */
	public function get_post_content() {

		//if ( 'layout-2' !== $this->current['layout'] ) {
		?>
			<div class="front-view-content">
				<?php
				if ( empty( beauty_excerpt() ) ) {
					echo beauty_truncate( get_the_content(), $this->current['excerpt_length'], 'words' );
				} else {
					echo beauty_excerpt( $this->current['excerpt_length'] );
				}
				?>
			</div>
			<?php
			//}
	}

	/**
	 * Get post content
	 *
	 * @param  boolean $meta Display meta.
	 */
	public function get_post_readmore() {
		if ( beauty_get_settings( 'readmore_' . $this->current['unique_id'] ) ) :
			beauty_readmore();
		endif;
	}

	/**
	 * Get sidebar
	 */
	public function get_sidebar() {
		$cat_name = __( 'Latest ', 'beauty' );
		if ( 'latest' !== $this->current['category'] ) {
			$cat_name = ucwords( beauty_get_cat_name( $this->current['category'] ) );
		}
		if ( 'default' == $this->current['layout'] ) {
			$this->current['layout'] = 'layout-default';
		}
		?>
		<aside id="sidebar" class="sidebar c-4-12 post-<?php echo $this->current['layout']; ?>" role="complementary" itemscope itemtype="http://schema.org/WPSideBar">
			<?php
			dynamic_sidebar( sanitize_title( strtolower( 'post-' . $this->current['layout'] . $cat_name ) ) );
			?>
		</aside>
		<?php
	}

	/**
	 * Get post pagination
	 */
	public function get_post_pagination() {
		if ( ! $this->current['is_latest'] ) {
			beauty_pagination( beauty_get_settings( 'mts_pagenavigation_type' ) );
		}
		wp_reset_query();
	}
}
