<?php
/**
 * Tweaks for the footer of the document.
 *
 * @package Beauty
 */

defined( 'WPINC' ) || exit;

/**
 * Tweaks for the <head> of the document.
 */
class Beauty_Footer extends Beauty_Base {

	/**
	 * Constructor
	 */
	public function __construct() {

		$this->add_action( 'wp_footer', 'tracking_field', 999 );
	}

	/**
	 * Add tracking field code
	 */
	public function tracking_field() {
		echo beauty_get_settings( 'mts_analytics_code' );
	}
}

/**
 * Init
 */
new Beauty_Footer;
