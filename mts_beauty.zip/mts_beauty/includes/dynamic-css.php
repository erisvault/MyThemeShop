<?php
/**
 * Dynamic CSS for the frontend.
 *
 * @package Beauty
 */

defined( 'WPINC' ) || exit;

/**
 * Helper function.
 * Merge and combine the CSS elements.
 *
 * @param  string|array $elements An array of our elements.
 *                                If we use a string then it is directly returned.
 * @return string
 */
function beauty_implode( $elements = array() ) {

	if ( ! is_array( $elements ) ) {
		return $elements;
	}

	// Make sure our values are unique.
	$elements = array_unique( $elements );

	// Sort elements alphabetically.
	// This way all duplicate items will be merged in the final CSS array.
	sort( $elements );

	// Implode items and return the value.
	return implode( ',', $elements );

}

/**
 * Maps elements from dynamic css to the selector.
 *
 * @param  array  $elements The elements.
 * @param  string $selector The selector.
 * @return array
 */
function beauty_map_selector( $elements, $selector ) {
	$array = array();

	foreach ( $elements as $element ) {
		$array[] = $element . $selector;
	}

	return $array;
}

/**
 * Map CSS selectors from values.
 *
 * @param array $css    Array of dynamic CSS.
 * @param array $values Array of values.
 */
function beauty_map_css_selectors( &$css, $values ) {
	if ( isset( $values['css-selectors'] ) ) {
		$elements = $values['css-selectors'];
		unset( $values['css-selectors'] );

		$css[ $elements ] = $values;
	}
}

/**
 * Merge CSS values.
 *
 * @param array $css    Array of dynamic CSS.
 * @param array $values Array of values.
 */
function beauty_merge_value( &$css, $values ) {
	foreach ( $values as $id => $val ) {
		$css[ $id ] = $val;
	}
}

/**
 * Format of the $css array:
 * $css['media-query']['element']['property'] = value
 *
 * If no media query is required then set it to 'global'
 *
 * If we want to add multiple values for the same property then we have to make it an array like this:
 * $css[media-query][element]['property'][] = value1
 * $css[media-query][element]['property'][] = value2
 *
 * Multiple values defined as an array above will be parsed separately.
 */
function beauty_dynamic_css_array() {

	global $wp_version;

	$css       = array();
	$c_page_id = beauty()->get_page_id();

	// Site Background.
	$css['global']['html body'] = Beauty_Sanitize::background( beauty_get_settings( 'mts_background' ) );

	// Top bar Background.
	$css['global']['#primary-nav, #primary-nav .sub-menu, .header-layout2 .header-search .searchbox-open #s'] = Beauty_Sanitize::background( beauty_get_settings( 'mts_top_bar_background' ) );

	// Header Background.
	$css['global']['#header, .header-default .header-search .searchbox-open #s'] = Beauty_Sanitize::background( beauty_get_settings( 'mts_main_navigation_background' ) );

	// Content Font.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'content_font' ) ) );
	// Logo Font.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'beauty_logo' ) ) );
	// Primary Navigation font.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'primary_navigation_font' ) ) );
	// Secondary Navigation font.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'secondary_navigation_font' ) ) );

	// Homepage post title font.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'home_title_font' ) ) );
	// Breadcrumbs font.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'breadcrumb_font' ) ) );
	// Single post title font.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'single_title_font' ) ) );
	// Single Page titles font.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'single_page_titles_font' ) ) );
	// Related Posts Section title font.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'related_post_title_font' ) ) );
	// Single subscribe box.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'single_subscribe_title_font' ) ) );
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'single_subscribe_text_font' ) ) );
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'single_subscribe_input_font' ) ) );
	//beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'single_subscribe_submit_font' ) ) );
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'single_subscribe_small_text_font' ) ) );
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'single_subscribe_custom_title_font' ) ) );
	// Author Box.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'single_authorbox_author_name_font' ) ) );
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'single_authorbox_text_font' ) ) );
	// Sidebar widget title font.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'sidebar_title_font' ) ) );
	// Sidebar widget font.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'sidebar_url' ) ) );
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'sidebar_font' ) ) );
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'sidebar_post_title' ) ) );
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'sidebar_large_post_title' ) ) );
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'sidebar_postinfo_font' ) ) );
	// Footer widget title font.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'top_footer_title_font' ) ) );
	// Footer link font.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'top_footer_link_font' ) ) );
	// Footer widget font.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'top_footer_font' ) ) );
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'top_footer_post_title' ) ) );
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'footer_large_post_title' ) ) );
	// Footer meta font.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'top_footer_meta_font' ) ) );
	// Copyrights section font.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'copyrights_font' ) ) );
	// H1 title in the content.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'h1_headline' ) ) );
	// H2 title in the content.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'h2_headline' ) ) );
	// H3 title in the content.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'h3_headline' ) ) );
	// H4 title in the content.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'h4_headline' ) ) );
	// H5 title in the content.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'h5_headline' ) ) );
	// H6 title in the content.
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'h6_headline' ) ) );

	// Footer background.
	$css['global']['#site-footer'] = Beauty_Sanitize::background( beauty_get_settings( 'mts_footer_background' ) );
	// Copyrights background.
	$css['global']['.copyrights'] = Beauty_Sanitize::background( beauty_get_settings( 'mts_copyrights_background' ) );

	beauty_dynamic_css_skin( $css );
	beauty_sidebar_position( $css );
	beauty_header( $css );
	beauty_sidebar_styling( $css );
	beauty_post_layouts( $css );
	beauty_post_pagination( $css );
	beauty_footer( $css );
	beauty_copyrights( $css );
	beauty_single( $css );
	beauty_single_social_buttons( $css );
	beauty_misc_css( $css );

	return apply_filters( 'beauty_dynamic_css_array', $css );
}

/**
 * Skin CSS
 *
 * @param array $css Array of dynamic CSS.
 */
function beauty_dynamic_css_skin( &$css ) {

	// Theme Color.
	$beauty_color_scheme     = Beauty_Sanitize::color( beauty_get_settings( 'mts_color_scheme' ) );
	$sec_beauty_color_scheme = Beauty_Sanitize::color( beauty_get_settings( 'mts_secondary_color_scheme' ) );
	$beauty_hover_bg         = Beauty_Sanitize::color( beauty_get_settings( 'mts_hover_color_scheme' ) );
	$light_sec_color         = beauty_luminance( beauty_get_settings( 'mts_secondary_color_scheme' ), 0.75 );

	// Text Color.
	$elements = array(
		'a',
		'cite',
		'.woocommerce ul.products li.product .price',
		'.product_list_widget .amount',
		'.woocommerce div.product p.price, .woocommerce div.product span.price',
		'.postauthor h5',
		'.textwidget a',
		'#wp-calendar td#today',
		'.pnavigation2 a',
		'.title a:hover',
		'#tabber .inside li a:hover',
		'.related-posts .title a:hover',
		'.layout-cta .widget #wp-subscribe .title span',
		'.footer-nav li a:hover',
		'blockquote:after',
		'article ul li::before',
		'#site-header .header-search .searchbox-open .searchbox-icon',
		'.widget .sbutton',
		'.error404 .sbutton',
		'.search .sbutton',
		'.tags a',
		'.widget .wpt_widget_content .tab_title.selected a',
		'.widget .wp_review_tab_widget_content .tab_title.selected a',
		'.prev-next .prev a',
		'.prev-next .next a',
		'.layout-default .latestPost .title a:hover',
	);

	$css['global'][ beauty_implode( $elements ) ]['color'] = $beauty_color_scheme;

	// Background Color.
	$elements = array(
		'.pace .pace-progress',
		'#mobile-menu-wrapper ul li a:hover',
		'.navigation #wpmm-megamenu .wpmm-pagination a',
		'.wpmm-megamenu-showing.wpmm-light-scheme',
		'.mts-subscribe input[type="submit"]',
		'.widget_product_search button[type="submit"]',
		'#move-to-top:hover',
		'.navigation ul .sfHover a',
		'.widget-slider .slide-caption',
		'.owl-prev, .owl-next',
		'.owl-prev:hover, .owl-next:hover',
		'.widget .wp-subscribe-wrap h4.title span.decor:after',
		'.mobile-menu-active .navigation.mobile-menu-wrapper',
		'.readMore a:hover',
		'.woocommerce a.button',
		'.woocommerce-page a.button',
		'.woocommerce button.button',
		'.woocommerce-page button.button',
		'.woocommerce input.button',
		'.woocommerce-page input.button',
		'.woocommerce #respond input#submit',
		'.woocommerce-page #respond input#submit',
		'.woocommerce #content input.button',
		'.woocommerce-page #content input.button',
		'.woocommerce .bypostauthor:after',
		'.woocommerce nav.woocommerce-pagination ul li span.current',
		'.woocommerce-page nav.woocommerce-pagination ul li span.current',
		'.woocommerce #content nav.woocommerce-pagination ul li span.current',
		'.woocommerce-page #content nav.woocommerce-pagination ul li span.current',
		'.woocommerce nav.woocommerce-pagination ul li a:hover',
		'.woocommerce-page nav.woocommerce-pagination ul li a:hover',
		'.woocommerce #content nav.woocommerce-pagination ul li a:hover',
		'.woocommerce-page #content nav.woocommerce-pagination ul li a:hover',
		'.woocommerce nav.woocommerce-pagination ul li a:focus',
		'.woocommerce-page nav.woocommerce-pagination ul li a:focus',
		'.woocommerce #content nav.woocommerce-pagination ul li a:focus',
		'.woocommerce-page #content nav.woocommerce-pagination ul li a:focus',
		'.woocommerce a.button',
		'.woocommerce-page a.button',
		'.woocommerce button.button',
		'.woocommerce-page button.button',
		'.woocommerce input.button',
		'.woocommerce-page input.button',
		'.woocommerce #respond input#submit',
		'.woocommerce-page #respond input#submit',
		'.woocommerce #content input.button',
		'.woocommerce-page #content input.button',
		'.woocommerce #respond input#submit.alt.disabled',
		'.woocommerce #respond input#submit.alt.disabled:hover',
		'.woocommerce #respond input#submit.alt:disabled',
		'.woocommerce #respond input#submit.alt:disabled:hover',
		'.woocommerce #respond input#submit.alt:disabled[disabled]',
		'.woocommerce #respond input#submit.alt:disabled[disabled]:hover',
		'.woocommerce a.button.alt.disabled, .woocommerce a.button.alt.disabled:hover',
		'.woocommerce a.button.alt:disabled',
		'.woocommerce a.button.alt:disabled:hover',
		'.woocommerce a.button.alt:disabled[disabled]',
		'.woocommerce a.button.alt:disabled[disabled]:hover',
		'.woocommerce button.button.alt.disabled',
		'.woocommerce button.button.alt.disabled:hover',
		'.woocommerce button.button.alt:disabled',
		'.woocommerce button.button.alt:disabled:hover',
		'.woocommerce button.button.alt:disabled[disabled]',
		'.woocommerce button.button.alt:disabled[disabled]:hover',
		'.woocommerce input.button.alt.disabled',
		'.woocommerce input.button.alt.disabled:hover',
		'.woocommerce input.button.alt:disabled',
		'.woocommerce input.button.alt:disabled:hover',
		'.woocommerce input.button.alt:disabled[disabled]',
		'.woocommerce input.button.alt:disabled[disabled]:hover',
		'#wpmm-megamenu .review-total-only',
		'#searchsubmit',
		'.widget .wpt_widget_content #tags-tab-content ul li a:hover',
		'#add_payment_method .wc-proceed-to-checkout a.checkout-button',
		'.woocommerce-cart .wc-proceed-to-checkout a.checkout-button',
		'.woocommerce-checkout .wc-proceed-to-checkout a.checkout-button',
		'.woocommerce #respond input#submit.alt',
		'.woocommerce a.button.alt',
		'.woocommerce button.button.alt',
		'.woocommerce input.button.alt',
		'.woocommerce-account .woocommerce-MyAccount-navigation li.is-active',
		'.button',
		'.instagram-button a',
		'.woocommerce .woocommerce-widget-layered-nav-dropdown__submit',
		'.woocommerce .widget_price_filter .ui-slider .ui-slider-handle',
		'.woocommerce .widget_price_filter .ui-slider .ui-slider-range',
		'.woocommerce span.onsale',
		'.widget .widget_wp_review_tab .review-total-only.large-thumb',
		'.widget .review-total-only.large-thumb',
		'.widget #wp-subscribe .title:after',
		'.reply a',
		'#commentform input#submit',
		'#mtscontact_submit',
		'.page-numbers.current',
		'.pagination a:hover',
		'.latestPost-review-wrapper',
		'.latestPost .review-type-circle.latestPost-review-wrapper',
	);

	$css['global'][ beauty_implode( $elements ) ]['background-color'] = $beauty_color_scheme;

	// Sec Text Color.
	$elements = array(
		'body a:hover',
		'.f-widget a:hover',
		'.sidebar .widget a:hover',
		'.latestPost .title a:hover',
		'.related-posts .title a:hover',
		'.layout-1 .latestPost .title a:hover',
		'.layout-2 .latestPost .title a:hover',
		'.sidebar li.vertical-small .post-title a:hover',
		'.sidebar .widget .wpt_thumb_large + .entry-title a:hover',
		'.shareit-circular.standard a:hover',
		'.shareit.shareit-circular a:hover',
		'.breadcrumb a',
		'.rank-math-breadcrumb a',
	);

	$css['global'][ beauty_implode( $elements ) ]['color'] = $sec_beauty_color_scheme;

	$elements = array(
		'.post-info a:hover',
		'.aboutme-widget .aboutme-social a:hover',
		'.post-title a:hover',
		'.entry-title a:hover',
		'.aboutme-social a:hover',
		'.author-social a:hover',
		'.slide-caption .front-view-title a:hover',
		'.review-result',
	);
	$css['global'][ beauty_implode( $elements ) ]['color'] = $sec_beauty_color_scheme . '!important';

	// Sec Background Color.
	$elements = array(
		'.tagcloud a:hover',
		'.tags a:hover',
		'.widget .wpt_widget_content #tags-tab-content ul li a:hover',
		'#secondary-navigation a:before',
		'#primary-navigation a:before',
	);

	$css['global'][ beauty_implode( $elements ) ]['background-color'] = $sec_beauty_color_scheme;
	$css['global']['.header-search']['border-color']                  = $sec_beauty_color_scheme . '!important';

	// Border Color.
	$light_elements = array(
		'.tagcloud a',
		'.tags a',
		'#searchform',
		'.widget .wpt-tabs',
		'.widget .wp-review-tabs',
		'.widget .wpt_widget_content .tab_title a',
		'.widget .wp_review_tab_widget_content .tab_title a',
		'.widget .wpt_widget_content #tags-tab-content ul li a',
	);

	$css['global'][ beauty_implode( $light_elements ) ]['border-color'] = $light_sec_color . '!important';

	// Light Background color.
	$elements = array(
		'.single-subscribe .right-content',
		'.layout-cta .right-content',
		'.widget .wpt-tabs li:before',
		'.widget .wp-review-tabs li:before',
		'.primary-slider .slide-caption',
		'.post-overlay',
		'.header-search',
	);

	$css['global'][ beauty_implode( $elements ) ]['background-color'] = $light_sec_color . ' !important ';

	//Hover Background Color
	$elements = array(
		'.tagcloud a:hover',
		'.tags a:hover',
		'.reply a:hover',
		'.widget .wpt_widget_content #tags-tab-content ul li a:hover',
		'#commentform input#submit:hover',
		'#mtscontact_submit:hover',
		'.pagination a:hover',
		'#load-posts a:hover',
		'.page-numbers.current',
		'.owl-prev:hover',
		'.owl-next:hover',
		'.instagram-button a:hover',
	);
	$css['global'][ beauty_implode( $elements ) ]['background-color'] = $beauty_hover_bg;
	$css['global'][ beauty_implode( $elements ) ]['border-color']     = $beauty_hover_bg . '!important';
	$css['global']['.readMore a:hover']['background']                 = $beauty_hover_bg . ' !important ';
	$css['global']['.cta-button:hover']['background']                 = $beauty_hover_bg . ' !important ';
	//subscribe submit hover
	$css['global']['.widget #wp-subscribe form:hover:after']['background']          = $beauty_hover_bg . ' !important ';
	$css['global']['.widget #wp-subscribe input.email-field:focus']['border-color'] = $beauty_hover_bg . ' !important ';
	$css['global']['.widget #wp-subscribe input.name-field:focus']['border-color']  = $beauty_hover_bg . ' !important ';
}

/**
 * Sidebar Position
 *
 * @param array $css Array of dynamic CSS.
 */
function beauty_sidebar_position( &$css ) {

	// Sidebar position.
	$sidebar_position = beauty_get_settings( 'mts_layout' );

	$sidebar_metabox_location = '';
	if ( is_page() || is_single() ) {
		$sidebar_metabox_location = get_post_meta( get_the_ID(), '_mts_sidebar_location', true );
	}

	if ( 'right' !== $sidebar_metabox_location && ( 'sclayout' === $sidebar_position || 'left' === $sidebar_metabox_location ) ) {
		$css['global']['.article']['float']                = 'right';
		$css['global']['.sidebar.c-4-12']['float']         = 'left';
		$css['global']['.sidebar.c-4-12']['padding-right'] = 0;

		if ( null !== beauty_get_settings( 'mts_social_button_position' ) && 'floating' === beauty_get_settings( 'mts_social_button_position' ) ) {
			$elements = array(
				'.shareit.shareit-default.floating',
				'.shareit.shareit-circular.floating',
				'.shareit.shareit-rectwithname.floating',
			);
			$css['global'][ beauty_implode( $elements ) ]['margin'] = '0 740px 0';
		}
	}
}

/**
 * Header
 *
 * @param array $css Array of dynamic CSS.
 */
function beauty_header( &$css ) {

	// header class.
	$header_class = array(
		'#header',
	);
	beauty_merge_value( $css['global'][ beauty_implode( $header_class ) ], Beauty_Sanitize::margin( beauty_get_settings( 'mts_header_margin' ) ) );
	beauty_merge_value( $css['global'][ beauty_implode( $header_class ) ], Beauty_Sanitize::padding( beauty_get_settings( 'mts_header_padding' ) ) );
	// Header Border.
	$header_border = Beauty_Sanitize::border( beauty_get_settings( 'mts_header_border' ) );
	$css['global'][ beauty_implode( $header_class ) ][ $header_border ['direction'] ] = $header_border ['value'];

	$top_header_class = array(
		'div#primary-nav',
	);
	// Top Header Border.
	$header_border = Beauty_Sanitize::border( beauty_get_settings( 'mts_top_header_border' ) );
	$css['global'][ beauty_implode( $top_header_class ) ][ $header_border ['direction'] ] = $header_border ['value'];

	// Main Nav.
	$main_nav_classes = array(
		'#secondary-navigation .navigation ul ul a',
		'#secondary-navigation .navigation ul ul a:link',
		'#secondary-navigation .navigation ul ul a:visited',
	);
	$css['global'][ beauty_implode( $main_nav_classes ) ]['color']             = Beauty_Sanitize::color( beauty_get_settings( 'main_navigation_dropdown_color' ) );
	$css['global']['#secondary-navigation .navigation ul ul a:hover']['color'] = Beauty_Sanitize::color( beauty_get_settings( 'main_navigation_dropdown_hover_color' ) );
	$css['global']['#secondary-navigation .navigation ul ul li']['background'] = Beauty_Sanitize::color( beauty_get_settings( 'main_navigation_dropdown_bg' ) );

	// Primary Nav.
	$main_nav_classes = array(
		'#primary-navigation .navigation ul ul a',
		'#primary-navigation .navigation ul ul a:link',
		'#primary-navigation .navigation ul ul a:visited',
	);
	$css['global'][ beauty_implode( $main_nav_classes ) ]['color']           = Beauty_Sanitize::color( beauty_get_settings( 'primary_navigation_dropdown_color' ) );
	$css['global']['#primary-navigation .navigation ul ul a:hover']['color'] = Beauty_Sanitize::color( beauty_get_settings( 'primary_navigation_dropdown_hover_color' ) );
	$css['global']['#primary-navigation .navigation ul ul li']['background'] = Beauty_Sanitize::color( beauty_get_settings( 'primary_navigation_dropdown_bg' ) );

	// Social icons.
	$header_style = beauty_get_settings( 'mts_header_style' );
	if ( 'header-default' === $header_style ) {
		$prefix = 'mts';
	} else {
		$prefix = 'top';
	}
	if ( ! empty( beauty_get_settings( $prefix . '_header_social_share' ) ) && ! empty( beauty_get_settings( $prefix . '_header_social' ) ) && is_array( beauty_get_settings( $prefix . '_header_social' ) ) ) :
		$header_icons = beauty_get_settings( $prefix . '_header_social' );
		foreach ( $header_icons as $header_icon ) :
			// Header border.
			$header_border = Beauty_Sanitize::border( $header_icon[ $prefix . '_header_icon_border' ] );
			$css['global'][ '.header-social-icons a.header-' . $header_icon[ $prefix . '_header_icon' ] ][ $header_border ['direction'] ] = $header_border ['value'];

			$css['global'][ '.header-social-icons a.header-' . $header_icon[ $prefix . '_header_icon' ] ]['background-color']            = Beauty_Sanitize::color( $header_icon[ $prefix . '_header_icon_bgcolor' ] );
			$css['global'][ '.header-social-icons a.header-' . $header_icon[ $prefix . '_header_icon' ] . ':hover' ]['background-color'] = Beauty_Sanitize::color( $header_icon[ $prefix . '_header_icon_hover_bgcolor' ] );
			$css['global'][ '.header-social-icons a.header-' . $header_icon[ $prefix . '_header_icon' ] ]['color']                       = Beauty_Sanitize::color( $header_icon[ $prefix . '_header_icon_color' ] );
			$css['global'][ '.header-social-icons a.header-' . $header_icon[ $prefix . '_header_icon' ] . ':hover' ]['color']            = Beauty_Sanitize::color( $header_icon[ $prefix . '_header_icon_hover_color' ] );

			beauty_merge_value( $css['global'][ '.header-social-icons a.header-' . $header_icon[ $prefix . '_header_icon' ] ], Beauty_Sanitize::margin( $header_icon[ $prefix . '_header_icon_margin' ] ) );
			beauty_merge_value( $css['global'][ '.header-social-icons a.header-' . $header_icon[ $prefix . '_header_icon' ] ], Beauty_Sanitize::padding( $header_icon[ $prefix . '_header_icon_padding' ] ) );
			$css['global'][ '.header-social-icons a.header-' . $header_icon[ $prefix . '_header_icon' ] ]['border-radius'] = Beauty_Sanitize::size( $header_icon[ $prefix . '_header_icon_border_radius' ] . 'px' );
		endforeach;
	endif;

	// Header Ad.
	beauty_merge_value( $css['global']['.widget-header, .small-header .widget-header'], Beauty_Sanitize::margin( beauty_get_settings( 'mts_header_adcode_margin' ) ) );

	// Ad-Blocker.
	$css['global']['.navigation-banner']['background'] = Beauty_Sanitize::color( beauty_get_settings( 'navigation_ad_background' ) );
}

/**
 * Social Share Styling
 *
 * @param array $css Array of dynamic CSS.
 */
function beauty_single_social_buttons( &$css ) {

	$social_shadow = beauty_get_settings( 'social_styling_box_shadow' );

	// Social share.
	$css['global']['.shareit.floating'] = Beauty_Sanitize::background( beauty_get_settings( 'social_styling_background' ) );
	//beauty_merge_value( $css['global']['.shareit.floating'], Beauty_Sanitize::margin( beauty_get_settings( 'social_styling_margin' ) ) );
	$elements = array(
		'.shareit.floating',
		'.ss-full-width .shareit.shareit-default.floating',
		'.ss-full-width .shareit.shareit-circular.floating',
		'.ss-full-width .shareit.shareit-rectwithname.floating',
	);
	beauty_merge_value( $css['global'][ beauty_implode( $elements ) ], Beauty_Sanitize::margin( beauty_get_settings( 'social_styling_margin' ) ) );

	// Social share border.
	$social_border = Beauty_Sanitize::border( beauty_get_settings( 'social_styling_border' ) );
	$css['global']['.shareit.floating'][ $social_border ['direction'] ] = $social_border ['value'];

	if ( 0 === $social_shadow ) {
		$css['global']['.shareit.floating']['box-shadow'] = 'none';
	}
	$social_button_layout   = beauty_get_settings( 'social_button_layout' );
	$social_button_position = beauty_get_settings( 'social_floating_button_position' );
	if ( ! empty( $social_button_position ) && is_array( $social_button_position ) ) {
		foreach ( $social_button_position as $key => $position ) {
			$css['global'][ '.shareit.shareit-' . $social_button_layout . '.floating' ][ $key ] = $position;
		}
	}
}

/**
 * Sidebar styling
 *
 * @param array $css Array of dynamic CSS.
 */
function beauty_sidebar_styling( &$css ) {

	// Sidebar.
	beauty_merge_value( $css['global']['#sidebar .widget'], Beauty_Sanitize::background( beauty_get_settings( 'mts_sidebar_styling_background' ) ) );
	beauty_merge_value( $css['global']['#sidebar .widget'], Beauty_Sanitize::margin( beauty_get_settings( 'mts_sidebar_styling_margin' ) ) );
	beauty_merge_value( $css['global']['#sidebar .widget'], Beauty_Sanitize::padding( beauty_get_settings( 'mts_sidebar_styling_padding' ) ) );
	// Sidebar border.
	$sidebar_border = Beauty_Sanitize::border( beauty_get_settings( 'sidebar_styling_border' ) );
	$css['global']['#sidebar .widget'][ $sidebar_border['direction'] ] = $sidebar_border['value'];

	// Sidebar title.
	$css['global']['#sidebar .widget h3'] = Beauty_Sanitize::background( beauty_get_settings( 'mts_sidebar_title_styling_background' ) );
	beauty_merge_value( $css['global']['#sidebar .widget h3'], Beauty_Sanitize::padding( beauty_get_settings( 'mts_sidebar_title_styling_padding' ) ) );
	beauty_merge_value( $css['global']['#sidebar .widget h3'], Beauty_Sanitize::margin( beauty_get_settings( 'mts_sidebar_title_styling_margin' ) ) );
	// Sidebar Title border.
	$sidebar_title_border = Beauty_Sanitize::border( beauty_get_settings( 'widget_title_border' ) );
	$css['global']['#sidebar .widget h3'][ $sidebar_title_border['direction'] ] = $sidebar_title_border['value'];
}

/**
 * Layout CSS
 *
 * @param array $css Array of dynamic CSS.
 */
function beauty_post_layouts( &$css ) {

	$features = beauty_get_settings( 'mts_featured_categories' );
	foreach ( $features as $feature ) :

		if ( ! isset( $feature['unique_id'] ) ) {
			continue;
		}

		$category     = $feature['mts_featured_category'];
		$posts_layout = isset( $feature['mts_thumb_layout'] ) ? $feature['mts_thumb_layout'] : '';
		$unique_id    = $feature['unique_id'];

		if ( 'layout-default' === $posts_layout ) :
			$posts_layout = 'default';
		endif;

		// Container Class.
		if ( ! in_array( $posts_layout, array( 'default' ) ) ) :
			$container_class                                     = array(
				'.layout-' . $unique_id,
			);
			$css['global'][ beauty_implode( $container_class ) ] = array(
				'width'    => '100%',
				'float'    => 'none',
				'overflow' => 'visible',
				'position' => 'relative',
			);
		endif;

		// Section title align.
		$post_title_align = beauty_get_settings( 'mts_post_title_alignment_' . $unique_id );

		// Post area.
		$cat_class = 'cat-latest';
		if ( 'latest' !== $category ) {
			$category  = get_term_by( 'slug', $category, 'category' );
			$cat_class = sanitize_key( $category->name );
		}

		$title_class = '.title-container.title-id-' . $unique_id . ' h3';

		$css['global'][ $title_class ] = Beauty_Sanitize::background( beauty_get_settings( 'mts_featured_category_title_background_' . $unique_id ) );
		beauty_merge_value( $css['global'][ $title_class ], Beauty_Sanitize::margin( beauty_get_settings( 'mts_featured_category_title_margin_' . $unique_id ) ) );
		beauty_merge_value( $css['global'][ $title_class ], Beauty_Sanitize::padding( beauty_get_settings( 'mts_featured_category_title_padding_' . $unique_id ) ) );
		// Section title border.
		$post_title_border = Beauty_Sanitize::border( beauty_get_settings( 'post_title_border_' . $unique_id ) );
		$css['global'][ $title_class ][ $post_title_border['direction'] ] = $post_title_border['value'];

		// Title alignment.
		$align_class = '.title-container.title-id-' . $unique_id;
		if ( 'center' === $post_title_align ) :
			$css['global'][ $align_class ]['text-align'] = 'center';
		elseif ( 'right' === $post_title_align ) :
			$css['global'][ $align_class ]['text-align'] = 'right';
		elseif ( 'full' === $post_title_align ) :
			$css['global'][ $title_class ]['width'] = '100%';
		endif;

		beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'mts_featured_category_title_font_' . $unique_id ) ) );

		if ( 'default' === $posts_layout ) {
			$post_class = '.layout-' . $unique_id;
		} else {
			$post_class = '.article.layout-' . $unique_id;
		}
		//$post_class = '.layout-' . $unique_id;

		if ( ! in_array( $posts_layout, array( 'layout-partners', 'layout-category', 'layout-cta', 'layout-ad' ) ) ) :
			// Post border.
			$post_border = Beauty_Sanitize::border( beauty_get_settings( 'post_border_' . $unique_id ) );
			$css['global'][ $post_class ][ $post_border['direction'] ] = $post_border['value'];
		endif;

		//beauty_merge_value( $css['global'][ $post_class ], Beauty_Sanitize::margin( beauty_get_settings( 'mts_featured_category_margin_' . $unique_id ) ) );
		//beauty_merge_value( $css['global'][ $post_class ], Beauty_Sanitize::padding( beauty_get_settings( 'mts_featured_category_padding_' . $unique_id ) ) );
		beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'mts_featured_category_font_' . $unique_id ) ) );
		beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'mts_featured_category_excerpt_font_' . $unique_id ) ) );

		/**
		 * Meta info
		 */
		beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'mts_meta_info_font_' . $unique_id ) ) );
		//beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'post_category_font_' . $unique_id ) ) );
		beauty_merge_value( $css['global'][ $post_class . ' .latestPost .post-info' ], Beauty_Sanitize::margin( beauty_get_settings( 'mts_meta_info_margin_' . $unique_id ) ) );
		beauty_merge_value( $css['global'][ $post_class . ' .slide-caption .post-info' ], Beauty_Sanitize::margin( beauty_get_settings( 'mts_meta_info_margin_' . $unique_id ) ) );

		//if ( 'layout-3' === $posts_layout ) :
		$css['global'][ $post_class ] = Beauty_Sanitize::background( beauty_get_settings( 'mts_featured_category_background_' . $unique_id ) );
		//endif;

		// Layout Partners, Layout Subscribe, Layout Category and Layout ad.
		if ( in_array( $posts_layout, array( 'layout-slider', 'default', 'layout-1', 'layout-2', 'layout-partners', 'layout-category', 'layout-cta', 'layout-ad' ) ) ) :
			if ( 'default' === $posts_layout ) {
				$class = array(
					'.layout-' . $unique_id,
				);
			} else {
				$class = array(
					'.article.layout-' . $unique_id,
				);
			}
			$css['global'][ beauty_implode( $class ) ] = Beauty_Sanitize::background( beauty_get_settings( 'mts_featured_category_background_' . $unique_id ) );
			beauty_merge_value( $css['global'][ beauty_implode( $class ) ], Beauty_Sanitize::margin( beauty_get_settings( 'mts_featured_category_margin_' . $unique_id ) ) );
			beauty_merge_value( $css['global'][ beauty_implode( $class ) ], Beauty_Sanitize::padding( beauty_get_settings( 'mts_featured_category_padding_' . $unique_id ) ) );

			// Post border.
			$post_border = Beauty_Sanitize::border( beauty_get_settings( 'post_border_' . $unique_id ) );
			$css['global'][ beauty_implode( $class ) ][ $post_border['direction'] ] = $post_border['value'];
		endif;

		if ( in_array( $posts_layout, array( 'default', 'layout-1', 'layout-2' ) ) ) :
			$css['global'][ '.layout-' . $unique_id . ' .readMore a'  ]['background-color'] = Beauty_Sanitize::color( beauty_get_settings( 'readmore_bg_' . $unique_id ) );
		endif;

		// Layout Category.
		if ( 'layout-category' === $posts_layout && ! empty( beauty_get_settings( 'cat_section_' . $unique_id ) ) && is_array( beauty_get_settings( 'cat_section_' . $unique_id ) ) ) :
			$categories = beauty_get_settings( 'cat_section_' . $unique_id );
			foreach ( $categories as $category ) :
				$css['global'][ '.article.layout-' . $unique_id . ' .layout-category .overlay' ]['background']       = Beauty_Sanitize::color( $category['cat_section_background'] );
				$css['global'][ '.article.layout-' . $unique_id . ' .layout-category .overlay:hover' ]['background'] = Beauty_Sanitize::color( $category['cat_section_hover_background'] );
			endforeach;
		endif;

		// Layout Partners.
		if ( 'layout-partners' === $posts_layout ) :
			beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'partners_title_font_' . $unique_id ) ) );
		endif;

		// Layout Subscribe.
		if ( 'layout-cta' === $posts_layout ) :
			$input_class                                 = '.article.layout-' . $unique_id . ' .layout-cta #wp-subscribe input.email-field, .article.layout-' . $unique_id . ' .layout-cta #wp-subscribe input.name-field';
			$css['global'][ $input_class ]['background'] = Beauty_Sanitize::color( beauty_get_settings( 'subscribe_input_background_' . $unique_id ) );
			beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'subscribe_title_font_' . $unique_id ) ) );
			beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'subscribe_input_font_' . $unique_id ) ) );
			beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'subscribe_text_font_' . $unique_id ) ) );
			beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'subscribe_small_text_font_' . $unique_id ) ) );
			beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'cta_title_font_' . $unique_id ) ) );
			$css['global'][ '.layout-' . $unique_id . ' .cta-button'  ]['background-color'] = Beauty_Sanitize::color( beauty_get_settings( 'cta_button_bg_' . $unique_id ) );

			// Alignment.
			$alignment = beauty_get_settings( 'subscribe_alignment_' . $unique_id );
			if ( 'center' === $alignment ) :
				$css['global'][ '.article.layout-' . $unique_id . ' .layout-cta .left-content' ]['text-align'] = 'center';
			elseif ( 'right' === $alignment ) :
				$css['global'][ '.article.layout-' . $unique_id . ' .layout-cta .left-content' ]['text-align'] = 'right';
			endif;
			//CTA Right Content Alignment
			$alignment = beauty_get_settings( 'subscribe_right_alignment_' . $unique_id );
			if ( 'center' === $alignment ) :
				$css['global'][ '.article.layout-' . $unique_id . ' .layout-cta .right-content' ]['text-align'] = 'center';
				$css['global'][ '.article.layout-' . $unique_id . ' .cta-title' ]['max-width']                  = '100%';
			elseif ( 'right' === $alignment ) :
				$css['global'][ '.article.layout-' . $unique_id . ' .layout-cta .right-content' ]['text-align'] = 'right';
				$css['global'][ '.article.layout-' . $unique_id . ' .cta-title' ]['max-width']                  = '100%';
			endif;

			// Subscribe Social icons
			if ( beauty_get_settings( 'cta_social_icons_' . $unique_id ) && ! empty( beauty_get_settings( 'cta_social_' . $unique_id ) ) && is_array( beauty_get_settings( 'cta_social_' . $unique_id ) ) ) :
				$cta_social_icons = beauty_get_settings( 'cta_social_' . $unique_id );
				foreach ( $cta_social_icons as $cta_social_icon ) :
					// $footer_icons[] = $cta_social_icon['cta_social_icon'];
					$css['global'][ '.cta-social-icons a.cta-' . $cta_social_icon['cta_social_icon'] ]['color'] = Beauty_Sanitize::color( $cta_social_icon['cta_social_color'] );

					$css['global'][ '.cta-social-icons a.cta-' . $cta_social_icon['cta_social_icon'] . ':hover' ]['color'] = Beauty_Sanitize::color( $cta_social_icon['cta_social_hover_color'] );

					beauty_merge_value( $css['global'][ '.cta-social-icons a.cta-' . $cta_social_icon['cta_social_icon'] ], Beauty_Sanitize::margin( $cta_social_icon['cta_social_margin'] ) );

					beauty_merge_value( $css['global'][ '.cta-social-icons a.cta-' . $cta_social_icon['cta_social_icon'] ], Beauty_Sanitize::padding( $cta_social_icon['cta_social_padding'] ) );
				endforeach;
			endif;

		endif;

	endforeach;
}

/**
 * Pagination
 *
 * @param array $css Array of dynamic CSS.
 */
function beauty_post_pagination( &$css ) {

	// Pagination Active class.
	$pagination_class_active = array(
		'.pace .pace-progress',
		'.page-numbers.current',
		'.pagination a:hover',
		'#mobile-menu-wrapper ul li a:hover',
		'#load-posts a:hover',
	);
	$pagination_class        = array(
		'.pagination a',
		'#load-posts a',
		'.single .pagination > .current .currenttext',
		'.pagination .page-numbers.dots',
		'.page-numbers.current',
	);
	if ( '2' !== beauty_get_settings( 'mts_pagenavigation_type' ) ) {
		$css['global'][ beauty_implode( $pagination_class ) ]['background-color']        = Beauty_Sanitize::color( beauty_get_settings( 'mts_pagenavigation_bgcolor' ) );
		$css['global'][ beauty_implode( $pagination_class_active ) ]['background-color'] = Beauty_Sanitize::color( beauty_get_settings( 'mts_pagenavigation_hover_bgcolor' ) );
		$css['global'][ beauty_implode( $pagination_class ) ]['color']                   = Beauty_Sanitize::color( beauty_get_settings( 'mts_pagenavigation_color' ) );
		$css['global'][ beauty_implode( $pagination_class_active ) ]['color']            = Beauty_Sanitize::color( beauty_get_settings( 'mts_pagenavigation_hover_color' ) );
		$css['global'][ beauty_implode( $pagination_class_active ) ]['border-color']     = Beauty_Sanitize::color( beauty_get_settings( 'mts_pagenavigation_hover_bgcolor' ) );
		beauty_merge_value( $css['global'][ beauty_implode( array_merge( $pagination_class_active, $pagination_class ) ) ], Beauty_Sanitize::margin( beauty_get_settings( 'mts_pagenavigation_margin' ) ) );
		beauty_merge_value( $css['global'][ beauty_implode( array_merge( $pagination_class_active, $pagination_class ) ) ], Beauty_Sanitize::padding( beauty_get_settings( 'mts_pagenavigation_padding' ) ) );
		// Pagination border.
		$pagination_border = Beauty_Sanitize::border( beauty_get_settings( 'pagenavigation_border' ) );
		$css['global'][ beauty_implode( $pagination_class ) ][ $pagination_border ['direction'] ] = $pagination_border ['value'];
	} else {
		$css['global'][ beauty_implode( $pagination_class ) ]['background-color']        = Beauty_Sanitize::color( beauty_get_settings( 'load_more_bgcolor' ) );
		$css['global'][ beauty_implode( $pagination_class_active ) ]['background-color'] = Beauty_Sanitize::color( beauty_get_settings( 'load_more_hover_bgcolor' ) );
		$css['global'][ beauty_implode( $pagination_class ) ]['color']                   = Beauty_Sanitize::color( beauty_get_settings( 'load_more_color' ) );
		$css['global'][ beauty_implode( $pagination_class_active ) ]['color']            = Beauty_Sanitize::color( beauty_get_settings( 'load_more_hover_color' ) );
		beauty_merge_value( $css['global'][ beauty_implode( array_merge( $pagination_class_active, $pagination_class ) ) ], Beauty_Sanitize::padding( beauty_get_settings( 'load_more_padding' ) ) );
		beauty_merge_value( $css['global'][ beauty_implode( array_merge( $pagination_class_active, $pagination_class ) ) ], Beauty_Sanitize::margin( beauty_get_settings( 'load_more_margin' ) ) );
		$css['global'][ beauty_implode( $pagination_class_active ) ]['border-color']  = Beauty_Sanitize::color( beauty_get_settings( 'load_more_hover_bgcolor' ) );
		$css['global'][ beauty_implode( $pagination_class ) ]['border-radius']        = Beauty_Sanitize::size( beauty_get_settings( 'mts_pagenavigation_border_radius' ) . 'px' );
		$css['global'][ beauty_implode( $pagination_class_active ) ]['border-radius'] = Beauty_Sanitize::size( beauty_get_settings( 'mts_pagenavigation_border_radius' ) . 'px' );
		// Load More border.
		$load_more_border = Beauty_Sanitize::border( beauty_get_settings( 'load_more_border' ) );
		$css['global'][ beauty_implode( $pagination_class ) ][ $load_more_border ['direction'] ] = $load_more_border ['value'];
	}

	// Load more Alignment.
	$load_more_align = beauty_get_settings( 'load_more_alignment' );
	if ( 'left' === $load_more_align ) :
		$css['global']['#load-posts']['text-align'] = 'left';
	elseif ( 'right' === $load_more_align ) :
		$css['global']['#load-posts']['text-align'] = 'right';
	elseif ( 'full' === $load_more_align ) :
		$css['global']['#load-posts a']['width'] = '100%';
	endif;
}

/**
 * Single
 *
 * @param array $css Array of dynamic CSS.
 */
function beauty_single( &$css ) {

	// Single, Page, Archive, Search, Category and 404 Page Background.
	$page_classes = array(
		'.single .article',
		'.page .article',
		'.error404 .article',
	);

	$css['global'][ beauty_implode( $page_classes ) ] = Beauty_Sanitize::background( beauty_get_settings( 'single_background' ) );

	// Margin, Padding, Border and Box Shadow.
	beauty_merge_value( $css['global'][ beauty_implode( $page_classes ) ], Beauty_Sanitize::margin( beauty_get_settings( 'mts_single_styling_margin' ) ) );
	beauty_merge_value( $css['global'][ beauty_implode( $page_classes ) ], Beauty_Sanitize::padding( beauty_get_settings( 'mts_single_styling_padding' ) ) );
	// Single border.
	$single_border = Beauty_Sanitize::border( beauty_get_settings( 'single_styling_border' ) );
	$css['global'][ beauty_implode( $page_classes ) ][ $single_border ['direction'] ] = $single_border ['value'];

	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'mts_single_meta_info_font' ) ) );
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'mts_sec_single_meta_info_font' ) ) );
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'mts_tags_font' ) ) );

	// Related Posts.
	if ( 'default' !== beauty_get_settings( 'related_posts_layouts' ) ) :
		$css['global']['.related-posts'] = Beauty_Sanitize::background( beauty_get_settings( 'related_posts_background' ) );
	endif;
	// Default.
	if ( 'default' === beauty_get_settings( 'related_posts_layouts' ) ) :
		$css['global']['.related-posts:after'] = Beauty_Sanitize::background( beauty_get_settings( 'related_posts_background' ) );
	endif;
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'related_posts_font' ) ) );
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'related_posts_meta_font' ) ) );
	beauty_merge_value( $css['global']['.related-posts'], Beauty_Sanitize::margin( beauty_get_settings( 'related_posts_margin' ) ) );
	beauty_merge_value( $css['global']['.related-posts'], Beauty_Sanitize::padding( beauty_get_settings( 'related_posts_padding' ) ) );
	beauty_map_css_selectors( $css['global'], Beauty_Sanitize::typography( beauty_get_settings( 'related_posts_excerpt_font' ) ) );

	// Related Posts articles.
	$css['global']['.related-posts article'] = Beauty_Sanitize::background( beauty_get_settings( 'related_article_background' ) );
	beauty_merge_value( $css['global']['.related-posts article'], Beauty_Sanitize::padding( beauty_get_settings( 'related_article_padding' ) ) );
	beauty_merge_value( $css['global']['.related-posts article header'], Beauty_Sanitize::padding( beauty_get_settings( 'related_article_text_padding' ) ) );

	// Secondary Meta Info.
	beauty_merge_value( $css['global']['.single-full-header'], Beauty_Sanitize::margin( beauty_get_settings( 'featured_image_margin' ) ) );
	beauty_merge_value( $css['global']['.secondary-meta-info-wrap'], Beauty_Sanitize::padding( beauty_get_settings( 'secondary_single_meta_info_padding' ) ) );
	beauty_merge_value( $css['global']['.secondary-meta-info-wrap'], Beauty_Sanitize::margin( beauty_get_settings( 'secondary_single_meta_info_margin' ) ) );
	// Social share border.
	$sec_meta_border = Beauty_Sanitize::border( beauty_get_settings( 'secondary_single_meta_info_border' ) );
	$css['global']['.secondary-meta-info-wrap'][ $sec_meta_border ['direction'] ] = $sec_meta_border ['value'];

	// Post FullHeader Alignment.
	$text_align = beauty_get_settings( 'featured_text_alignment' );
	if ( 'center' === $text_align ) :
		$css['global']['.single-full-header .content']['text-align'] = 'center';
		if ( 1 === beauty_get_settings( 'mts_show_featured' ) ) :
			$css['global']['.single-full-header .single-title']['padding']     = '0 12%';
			$css['global']['.single-full-header .single-title']['box-sizing']  = 'border-box';
			$css['global']['.single-full-header .post-info > span']['float']   = 'none';
			$css['global']['.single-full-header .post-info > span']['clear']   = 'both';
			$css['global']['.single-full-header .post-info > span']['display'] = 'inline-block';
			$css['global']['.single-full-header .post-info > span']['margin']  = '5px 5px 5px 0';
		endif;
	elseif ( 'right' === $text_align ) :
		$css['global']['.single-full-header .content']['text-align'] = 'right';
	endif;
	if ( 0 === beauty_get_settings( 'mts_show_featured' ) && 'full' === beauty_get_settings( 'featured_image_size' ) ) {
		$css['global']['.single-full-header .content']['position'] = 'static';
	}

	if ( 1 !== beauty_get_settings( 'mts_show_featured' ) && 'full' === beauty_get_settings( 'featured_image_size' ) ) {
		$css['global']['.single-full-header .content .full-header-wrapper']['width'] = '100%';
	}

	// Meta info Background.
	$css['global']['.full-header-wrapper .post-info']['background-color'] = Beauty_Sanitize::color( beauty_get_settings( 'single_meta_info_background' ) );
	$css['global']['.secondary-meta-info-inner']['background-color']      = Beauty_Sanitize::color( beauty_get_settings( 'secondary_single_meta_info_background' ) );
	$css['global']['.secondary-meta-info .theauthor a']['color']          = Beauty_Sanitize::color( beauty_get_settings( 'secondary_meta_info_author_color' ) );

	// Subscribe Box.
	$css['global']['.single-subscribe .widget #wp-subscribe'] = Beauty_Sanitize::background( beauty_get_settings( 'single_subscribe_background' ) );
	beauty_merge_value( $css['global']['.single-subscribe'], Beauty_Sanitize::margin( beauty_get_settings( 'single_subscribe_margin' ) ) );
	beauty_merge_value( $css['global']['.single-subscribe'], Beauty_Sanitize::padding( beauty_get_settings( 'single_subscribe_padding' ) ) );

	// Subscribe Box Input fields.
	$subscribe_input_class = array(
		'.single-subscribe #wp-subscribe input.email-field',
		'.single-subscribe #wp-subscribe input.name-field',
	);
	$css['global'][ beauty_implode( $subscribe_input_class ) ]['background-color'] = Beauty_Sanitize::color( beauty_get_settings( 'single_subscribe_input_background' ) );
	// Subscribe Box Input border.
	$subscribe_box_input_border = Beauty_Sanitize::border( beauty_get_settings( 'single_subscribe_input_border' ) );
	$css['global'][ beauty_implode( $subscribe_input_class ) ][ $subscribe_box_input_border ['direction'] ] = $subscribe_box_input_border ['value'];

	// Subscribe Box Submit button.
	$css['global']['.single-subscribe .widget #wp-subscribe input.submit']['background'] = Beauty_Sanitize::color( beauty_get_settings( 'single_subscribe_submit_backgroud' ) );
	$css['global']['.single-subscribe .cta-button']['background']                        = Beauty_Sanitize::color( beauty_get_settings( 'single_subscribe_button_bg' ) );
	// Single Subscribe Left Content alignment.
	$single_subscribe_align = beauty_get_settings( 'single_subscribe_leftcontent_alignment' );
	if ( 'center' === $single_subscribe_align ) :
		$css['global']['.single-subscribe .left-content']['text-align'] = 'center';
	elseif ( 'right' === $single_subscribe_align ) :
		$css['global']['.single-subscribe .left-content']['text-align'] = 'right';
	endif;

	// Single Subscribe Right Content alignment.
	$single_subscribe_align = beauty_get_settings( 'single_subscribe_rightcontent_alignment' );
	if ( 'center' === $single_subscribe_align ) :
		$css['global']['.single-subscribe .right-content']['text-align']         = 'center';
		$css['global']['.single-subscribe .single-subscribe-title']['max-width'] = '100%';
	elseif ( 'right' === $single_subscribe_align ) :
		$css['global']['.single-subscribe .right-content']['text-align']         = 'right';
		$css['global']['.single-subscribe .single-subscribe-title']['max-width'] = '100%';
	endif;

	// Author Box.
	$css['global']['.postauthor'] = Beauty_Sanitize::background( beauty_get_settings( 'single_authorbox_background' ) );
	beauty_merge_value( $css['global']['.postauthor'], Beauty_Sanitize::margin( beauty_get_settings( 'single_authorbox_margin' ) ) );
	beauty_merge_value( $css['global']['.postauthor'], Beauty_Sanitize::padding( beauty_get_settings( 'single_authorbox_padding' ) ) );
	$single_authorbox_border = Beauty_Sanitize::border( beauty_get_settings( 'single_authorbox_border' ) );
	$css['global']['.postauthor'][ $single_authorbox_border ['direction'] ] = $single_authorbox_border ['value'];
	// Author image.
	beauty_merge_value( $css['global']['.postauthor img'], Beauty_Sanitize::margin( beauty_get_settings( 'single_author_image_margin' ) ) );
	$css['global']['.postauthor img']['border-radius'] = Beauty_Sanitize::size( beauty_get_settings( 'single_author_image_border_radius' ) . 'px' );
	// Author Social
	beauty_merge_value( $css['global']['.author-social a'], Beauty_Sanitize::margin( beauty_get_settings( 'author_social_margin' ) ) );
	beauty_merge_value( $css['global']['.author-social a'], Beauty_Sanitize::padding( beauty_get_settings( 'author_social_padding' ) ) );
	$css['global']['.author-social a'] ['background']       = Beauty_Sanitize::color( beauty_get_settings( 'author_social_background' ) );
	$css['global']['.author-social a:hover'] ['background'] = Beauty_Sanitize::color( beauty_get_settings( 'author_social_hover_background' ) );
	$css['global']['.author-social a']['color']             = Beauty_Sanitize::color( beauty_get_settings( 'author_social_color' ) );
	$css['global']['.author-social a:hover']['color']       = Beauty_Sanitize::color( beauty_get_settings( 'author_social_hover_color' ) );
	$css['global']['.author-social a']['border-radius']     = Beauty_Sanitize::size( beauty_get_settings( 'author_social_border_radius' ) . 'px' );

	// Single Page titles Styling.
	$titles_align_class                               = array(
		'.comment-title',
		'#respond',
		'.related-posts-title',
	);
	$titles_class                                     = array(
		'#respond h4',
		'.total-comments',
		'.related-posts h4',
	);
	$css['global'][ beauty_implode( $titles_class ) ] = Beauty_Sanitize::background( beauty_get_settings( 'single_title_background' ) );
	beauty_merge_value( $css['global'][ beauty_implode( $titles_class ) ], Beauty_Sanitize::padding( beauty_get_settings( 'single_title_padding' ) ) );
	// Single title border.
	$single_titles_border = Beauty_Sanitize::border( beauty_get_settings( 'single_title_border' ) );
	$css['global'][ beauty_implode( $titles_class ) ][ $single_titles_border ['direction'] ] = $single_titles_border ['value'];

}

/**
 * Copyrights
 *
 * @param array $css Array of dynamic CSS.
 */
function beauty_copyrights( &$css ) {

	// copyrights border.
	$copyrights_border = Beauty_Sanitize::border( beauty_get_settings( 'copyrights_border' ) );
	$css['global']['.copyrights'][ $copyrights_border ['direction'] ] = $copyrights_border ['value'];

}

/**
 * Footer
 *
 * @param array $css Array of dynamic CSS.
 */
function beauty_footer( &$css ) {

	// Footer.
	beauty_merge_value( $css['global']['#site-footer'], Beauty_Sanitize::margin( beauty_get_settings( 'mts_top_footer_margin' ) ) );
	beauty_merge_value( $css['global']['#site-footer'], Beauty_Sanitize::padding( beauty_get_settings( 'mts_top_footer_padding' ) ) );
	beauty_merge_value( $css['global']['.copyrights'], Beauty_Sanitize::margin( beauty_get_settings( 'mts_copyrights_margin' ) ) );
	beauty_merge_value( $css['global']['.copyrights'], Beauty_Sanitize::padding( beauty_get_settings( 'mts_copyrights_padding' ) ) );

	// Footer widgets.
	if ( 1 === beauty_get_settings( 'mts_top_footer' ) && 1 === beauty_get_settings( 'mts_top_footer_num' ) ) :
		$css['global']['.footer-widgets']['display']                = 'flex';
		$css['global']['.footer-widgets']['justify-content']        = 'center';
		$css['global']['.footer-widgets .f-widget']['width']        = 'auto';
		$css['global']['.footer-widgets .f-widget']['text-align']   = 'center';
		$css['global']['.footer-widgets .f-widget']['margin-right'] = '0px';
	endif;

	// footer Nav position.
	$footer_sections_position = beauty_get_settings( 'footer_sections_position' );
	if ( 1 === beauty_get_settings( 'footer_brands_section' ) ) :
		if ( 'left' === $footer_sections_position || 'right' === $footer_sections_position ) :
			$css['global']['#site-footer .container']['display']   = 'flex';
			$css['global']['#site-footer .container']['flex-flow'] = 'row wrap';
			$css['global']['.footer-sections']['flex-basis']       = 'calc(25% - 20px )';
			$css['global']['.footer-sections']['padding-right']    = '20px';
			$css['global']['.footer-widgets']['flex-basis']        = '75%';
			$css['global']['.brands-container']['display']         = 'block';
			$css['global']['.brands-items li']['max-width']        = '100%';
			$css['global']['.brands-items li']['flex-basis']       = '60%';
		endif;
		if ( 'right' === $footer_sections_position ) :
			$css['global']['#site-footer .container']['flex-direction'] = 'row-reverse';
			$css['global']['.footer-sections']['padding-right']         = '0';
			$css['global']['.footer-sections']['padding-left']          = '20px';
			$css['global']['.brands-container']['text-align']           = 'right';
			$css['global']['.brands-items']['justify-content']          = 'flex-end';
		endif;
	endif;

	// Footer Brands Sections.
	$brands_border = Beauty_Sanitize::border( beauty_get_settings( 'brands_border' ) );
	$css['global']['.brands-container'][ $brands_border ['direction'] ] = $brands_border ['value'];

	// footer brands alignment.
	$footer_brands_align = beauty_get_settings( 'footer_brands_alignment' );
	if ( 'center' === $footer_brands_align ) :
		$css['global']['.brands-container']['justify-content'] = 'center';
	elseif ( 'right' === $footer_brands_align ) :
		$css['global']['.brands-container']['justify-content'] = 'flex-end';
	endif;

	// brand container.
	beauty_merge_value( $css['global']['.brands-container'], Beauty_Sanitize::margin( beauty_get_settings( 'brands_margin' ) ) );
	beauty_merge_value( $css['global']['.brands-container'], Beauty_Sanitize::padding( beauty_get_settings( 'brands_padding' ) ) );

}

/**
 * Misc
 *
 * @param array $css Array of dynamic CSS.
 */
function beauty_misc_css( &$css ) {

	// Show Logo.
	$show_logo = beauty_get_settings( 'mts_header_section2' );

	if ( 0 === $show_logo ) {
		$css['global']['.logo-wrap']['display'] = 'none';
	}

	// Back to top.
	// Border.
	$top_button_border = Beauty_Sanitize::border( beauty_get_settings( 'top_button_border' ) );
	$css['global']['#move-to-top'][ $top_button_border ['direction'] ] = $top_button_border ['value'];
	// Font-size, Padding and Position.
	$css['global']['#move-to-top .fa']['font-size'] = Beauty_Sanitize::size( beauty_get_settings( 'top_button_font_size' ) . 'px' );
	beauty_merge_value( $css['global']['#move-to-top'], Beauty_Sanitize::padding( beauty_get_settings( 'top_button_padding' ) ) );
	$top_button_position = beauty_get_settings( 'top_button_position' );
	foreach ( $top_button_position as $key => $position ) {
		$css['global']['#move-to-top'][ $key ] = $position;
	}
	// Border-radius.
	$css['global']['#move-to-top']['border-radius'] = Beauty_Sanitize::size( beauty_get_settings( 'top_button_border_radius' ) . 'px' );
	// Colors.
	$css['global']['#move-to-top']['color']            = Beauty_Sanitize::color( beauty_get_settings( 'top_button_color' ) );
	$css['global']['#move-to-top:hover']['color']      = Beauty_Sanitize::color( beauty_get_settings( 'top_button_color_hover' ) );
	$css['global']['#move-to-top']['background']       = Beauty_Sanitize::color( beauty_get_settings( 'top_button_background' ) );
	$css['global']['#move-to-top:hover']['background'] = Beauty_Sanitize::color( beauty_get_settings( 'top_button_background_hover' ) );
}
