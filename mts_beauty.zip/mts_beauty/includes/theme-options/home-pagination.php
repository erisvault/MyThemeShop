<?php
/**
 * HomePage Pagination
 *
 * @package Beauty
 */

$menus['home-pagination'] = array(
	'title' => esc_html__( 'Pagination', 'beauty' ),
	'desc'  => esc_html__( 'From here, you can control the elements of homepage pagination.', 'beauty' ),
);

$sections['home-pagination'] = array(

	array(
		'id'       => 'mts_pagenavigation_type',
		'type'     => 'radio',
		'title'    => esc_html__( 'Pagination Type', 'beauty' ),
		'sub_desc' => esc_html__( 'Select pagination type.', 'beauty' ),
		'options'  => array(
			'0' => esc_html__( 'Default (Next / Previous)', 'beauty' ),
			'1' => esc_html__( 'Numbered (1 2 3 4...)', 'beauty' ),
			'2' => esc_html__( 'AJAX (Load More Button)', 'beauty' ),
			'3' => esc_html__( 'AJAX (Auto Infinite Scroll)', 'beauty' ),
		),
		'std'      => '1',
	),

	array(
		'id'         => 'load_more_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Load More Alignment', 'beauty' ),
		'sub_desc'   => esc_html__( 'Choose the load more alignment from here.', 'beauty' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'beauty' ),
			'center' => esc_html__( 'Center', 'beauty' ),
			'right'  => esc_html__( 'Right', 'beauty' ),
			'full'   => esc_html__( 'Full Width', 'beauty' ),
		),
		'std'        => 'center',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'mts_pagenavigation_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination background color', 'beauty' ),
		'sub_desc'   => esc_html__( 'Select pagination background color.', 'beauty' ),
		'std'        => '#fff2f0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More background color', 'beauty' ),
		'sub_desc'   => esc_html__( 'Select background color for load more button.', 'beauty' ),
		'std'        => '#fff2f0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_hover_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination background hover color', 'beauty' ),
		'sub_desc'   => esc_html__( 'Select pagination background hover color.', 'beauty' ),
		'std'        => beauty_get_settings( 'mts_hover_color_scheme' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_hover_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More background hover color', 'beauty' ),
		'sub_desc'   => esc_html__( 'Select background hover color for load more button.', 'beauty' ),
		'std'        => beauty_get_settings( 'mts_hover_color_scheme' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination color', 'beauty' ),
		'sub_desc'   => esc_html__( 'Select pagination color.', 'beauty' ),
		'std'        => beauty_get_settings( 'mts_hover_color_scheme' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More color', 'beauty' ),
		'sub_desc'   => esc_html__( 'Select color for load more button.', 'beauty' ),
		'std'        => beauty_get_settings( 'mts_hover_color_scheme' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_hover_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination hover color', 'beauty' ),
		'sub_desc'   => esc_html__( 'Select pagination hover color.', 'beauty' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_hover_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More hover color', 'beauty' ),
		'sub_desc'   => esc_html__( 'Select hover color for load more button.', 'beauty' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Pagination Margin', 'beauty' ),
		'sub_desc'   => esc_html__( 'Update pagination margin from here.', 'beauty' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '5px',
			'bottom' => '10px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Pagination Padding', 'beauty' ),
		'sub_desc'   => esc_html__( 'Update pagination padding from here.', 'beauty' ),
		'std'        => array(
			'top'    => '13px',
			'right'  => '16px',
			'bottom' => '12px',
			'left'   => '16px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Load More Margin', 'beauty' ),
		'sub_desc'   => esc_html__( 'Update margin for load more button from here.', 'beauty' ),
		'std'        => array(
			'top'    => '20px',
			'right'  => '0',
			'bottom' => '40px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'load_more_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Load More Padding', 'beauty' ),
		'sub_desc'   => esc_html__( 'Update padding for load more button from here.', 'beauty' ),
		'std'        => array(
			'top'    => '13px',
			'right'  => '35px',
			'bottom' => '13px',
			'left'   => '35px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'mts_pagenavigation_border_radius',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Pagination border radius', 'beauty' ),
		'sub_desc'   => esc_html__( 'Update pagination border radius in px.', 'beauty' ),
		'std'        => '0',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'pagenavigation_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'beauty' ),
		'sub_desc'   => esc_html__( 'Select border', 'beauty' ),
		'std'        => array(
			'direction' => 'all',
			'size'      => '1',
			'style'     => 'solid',
			'color'     => '#fff2f0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '!=',
			),
		),
	),
	array(
		'id'         => 'load_more_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'beauty' ),
		'sub_desc'   => esc_html__( 'Select border', 'beauty' ),
		'std'        => array(
			'direction' => 'all',
			'size'      => '1',
			'style'     => 'solid',
			'color'     => '#fff2f0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_pagenavigation_type',
				'value'      => '2',
				'comparison' => '==',
			),
		),
	),

);
