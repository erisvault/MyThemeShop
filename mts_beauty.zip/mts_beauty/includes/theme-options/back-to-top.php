<?php
/**
 * Back to top
 *
 * @package Beauty
 */

$menus['footer']['child']['footer-back-to-top'] = array(
	'title' => esc_html__( 'Back to Top', 'beauty' ),
	'desc'  => esc_html__( 'From here, you can control the back to top button.', 'beauty' ),
);

$sections['footer-back-to-top'] = array(

	array(
		'id'       => 'show_top_button',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Top Button', 'beauty' ),
		'sub_desc' => esc_html__( 'Enable or disable back to top button with this option.', 'beauty' ),
		'std'      => '1',
	),

	array(
		'id'         => 'bt_top_button_position',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Top Buttons Position', 'beauty' ),
		'options'    => array(
			'floating' => esc_html__( 'Floating', 'beauty' ),
			'bottom'   => esc_html__( 'Bottom', 'beauty' ),
		),
		'sub_desc'   => esc_html__( 'Choose position for Top Button.', 'beauty' ),
		'std'        => 'floating',
		'class'      => 'green',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_icon',
		'type'       => 'icon_select',
		'title'      => esc_html__( 'Top Button Icon', 'beauty' ),
		'sub_desc'   => esc_html__( 'Set icon for top button icon with this option.', 'beauty' ),
		'std'        => 'angle-double-up',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_text',
		'type'       => 'text',
		'title'      => esc_html__( 'Top Button Text', 'beauty' ),
		'sub_desc'   => esc_html__( 'Set Top button text from here.', 'beauty' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Button Color', 'beauty' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'beauty' ),
		'std'        => '#f2f0f1',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'top_button_color_hover',
		'type'       => 'color',
		'title'      => esc_html__( 'Button Hover Color', 'beauty' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'beauty' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_background',
		'type'       => 'color',
		'title'      => esc_html__( 'Top Button Background', 'beauty' ),
		'sub_desc'   => esc_html__( 'Set top button background color, pattern and image from here.', 'beauty' ),
		'std'        => '#2d2628',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'top_button_background_hover',
		'type'       => 'color',
		'title'      => esc_html__( 'Top Button Hover Background', 'beauty' ),
		'sub_desc'   => esc_html__( 'Set top button background color, pattern and image from here.', 'beauty' ),
		'std'        => '#5a4047',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_font_size',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Font Size', 'beauty' ),
		'sub_desc'   => esc_html__( 'Set font size of top button in px.', 'beauty' ),
		'std'        => '28',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Padding', 'beauty' ),
		'sub_desc'   => esc_html__( 'Set Top button padding from here.', 'beauty' ),
		'std'        => array(
			'top'    => '18px',
			'right'  => '22px',
			'bottom' => '18px',
			'left'   => '22px',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'top_button_position',
		'type'       => 'margin',
		'title'      => esc_html__( 'Button Position', 'beauty' ),
		'sub_desc'   => esc_html__( 'Set button position from here.', 'beauty' ),
		'std'        => array(
			'top'    => 'auto',
			'right'  => '40px',
			'bottom' => '100px',
			'left'   => 'auto',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'bt_top_button_position',
				'value'      => 'floating',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_border_radius',
		'type'       => 'text',
		'class'      => 'small-text',
		'title'      => esc_html__( 'Border Radius', 'beauty' ),
		'sub_desc'   => esc_html__( 'Set border radius of top button in px.', 'beauty' ),
		'std'        => '0',
		'args'       => array( 'type' => 'number' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_button_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'beauty' ),
		'sub_desc'   => esc_html__( 'Select border', 'beauty' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'show_top_button',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

);
