<?php
/**
 * Top Bar
 *
 * @package Beauty
 */

$menus['header']['child']['header-top-bar'] = array(
	'title' => esc_html__( 'Topbar', 'beauty' ),
	'desc'  => esc_html__( 'From here, you can control the topbar of header section.', 'beauty' ),
);

$sections['header-top-bar'] = array(

	array(
		'id'       => 'mts_show_primary_nav',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Primary Menu', 'beauty' ),
		// translators: Primary Navigation Menu with strong tag.
		'sub_desc' => sprintf( esc_html__( 'Use this button to enable %s.', 'beauty' ), '<strong>' . esc_html__( 'Primary Navigation Menu', 'beauty' ) . '</strong>' ),
		'std'      => '0',
	),

	array(
		'id'         => 'mts_top_bar_background',
		'type'       => 'background',
		'title'      => esc_html__( 'Top Bar Background', 'beauty' ),
		'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'beauty' ),
		'options'    => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'        => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'primary_navigation_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Primary Navigation', 'beauty' ),
		'std'        => array(
			'preview-text'   => 'Primary Navigation Font',
			'preview-color'  => 'light',
			'font-family'    => 'Karla',
			'font-weight'    => '400',
			'font-size'      => '14px',
			'letter-spacing' => '0.5px',
			'color'          => '#000000',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '#primary-navigation a, .header-layout2 .header-search span.sbutton',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'mts_top_header_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Border', 'beauty' ),
		'sub_desc'   => esc_html__( 'Select border.', 'beauty' ),
		'std'        => array(
			'direction' => 'bottom',
			'size'      => '1',
			'style'     => 'solid',
			'color'     => '#ecedf1',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_header_social_share',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Header Social Icons', 'beauty' ),
		'sub_desc'   => wp_kses( __( 'Use this button to Show or Hide the <strong>Header social icons</strong> in Header Layout2 completely.', 'beauty' ), array( 'strong' => '' ) ),
		'std'        => '1',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_header_style',
				'value'      => 'header-layout2',
				'comparison' => '==',
			),
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_header_social',
		'title'      => esc_html__( 'Header Social Icons', 'beauty' ),
		'sub_desc'   => esc_html__( 'Add Social Media icons in header.', 'beauty' ),
		'type'       => 'group',
		'groupname'  => esc_html__( 'Header Icons', 'beauty' ), // Group name.
		'subfields'  => array(
			array(
				'id'    => 'top_header_icon_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'beauty' ),
			),
			array(
				'id'    => 'top_header_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Icon', 'beauty' ),
			),
			array(
				'id'    => 'top_header_icon_link',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'beauty' ),
			),
			array(
				'id'    => 'top_header_icon_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background color', 'beauty' ),
			),
			array(
				'id'    => 'top_header_icon_hover_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background hover color', 'beauty' ),
			),
			array(
				'id'    => 'top_header_icon_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon color', 'beauty' ),
			),
			array(
				'id'    => 'top_header_icon_hover_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon hover color', 'beauty' ),
			),
			array(
				'id'    => 'top_header_icon_margin',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Margin', 'beauty' ),
			),
			array(
				'id'    => 'top_header_icon_padding',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Padding', 'beauty' ),
			),
			array(
				'id'       => 'top_header_icon_border',
				'type'     => 'border',
				'title'    => esc_html__( 'Border', 'beauty' ),
				'sub_desc' => esc_html__( 'Select border.', 'beauty' ),
			),
			array(
				'id'    => 'top_header_icon_border_radius',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Header icon border radius', 'beauty' ),
				'args'  => array( 'type' => 'number' ),
			),
		),
		'std'        => array(
			'facebook'  => array(
				'group_title'                   => 'Facebook',
				'group_sort'                    => '1',
				'top_header_icon_title'         => 'Facebook',
				'top_header_icon'               => 'facebook',
				'top_header_icon_link'          => '#',
				'top_header_icon_bgcolor'       => '',
				'top_header_icon_hover_bgcolor' => '',
				'top_header_icon_color'         => beauty_get_settings( 'mts_color_scheme' ),
				'top_header_icon_hover_color'   => beauty_get_settings( 'mts_secondary_color_scheme' ),
				'top_header_icon_margin'        => array(
					'top'    => '12px',
					'right'  => '12px',
					'bottom' => '12px',
					'left'   => '12px',
				),
				'top_header_icon_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'top_header_icon_border_radius' => '0',
			),
			'instagram' => array(
				'group_title'                   => 'Instagram',
				'group_sort'                    => '2',
				'top_header_icon_title'         => 'Instagram',
				'top_header_icon'               => 'instagram',
				'top_header_icon_link'          => '#',
				'top_header_icon_bgcolor'       => '',
				'top_header_icon_hover_bgcolor' => '',
				'top_header_icon_color'         => beauty_get_settings( 'mts_color_scheme' ),
				'top_header_icon_hover_color'   => beauty_get_settings( 'mts_secondary_color_scheme' ),
				'top_header_icon_margin'        => array(
					'top'    => '12px',
					'right'  => '12px',
					'bottom' => '12px',
					'left'   => '12px',
				),
				'top_header_icon_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'top_header_icon_border_radius' => '0',
			),
			'twitter'   => array(
				'group_title'                   => 'Twitter',
				'group_sort'                    => '3',
				'top_header_icon_title'         => 'Twitter',
				'top_header_icon'               => 'twitter',
				'top_header_icon_link'          => '#',
				'top_header_icon_bgcolor'       => '',
				'top_header_icon_hover_bgcolor' => '',
				'top_header_icon_color'         => beauty_get_settings( 'mts_color_scheme' ),
				'top_header_icon_hover_color'   => beauty_get_settings( 'mts_secondary_color_scheme' ),
				'top_header_icon_margin'        => array(
					'top'    => '12px',
					'right'  => '12px',
					'bottom' => '12px',
					'left'   => '12px',
				),
				'top_header_icon_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'top_header_icon_border_radius' => '0',
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'top_header_social_share',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'mts_header_style',
				'value'      => 'header-layout2',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'top_header_search_box',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Header Search Form', 'beauty' ),
		'sub_desc'   => wp_kses( __( 'Use this button to Show or Hide the <strong>Header Search Form</strong> completely in Header Layout2.', 'beauty' ), array( 'strong' => '' ) ),
		'std'        => '1',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'mts_header_style',
				'value'      => 'header-layout2',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'primary_navigation_dropdown_bg',
		'type'       => 'color',
		'title'      => esc_html__( 'Dropdown Background Color', 'beauty' ),
		'sub_desc'   => esc_html__( 'Select dropdown background color for primary navigation from here.', 'beauty' ),
		'std'        => '#2d2628',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'primary_navigation_dropdown_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Dropdown Text Color', 'beauty' ),
		'sub_desc'   => esc_html__( 'Select dropdown text color for primary navigation from here.', 'beauty' ),
		'std'        => '#b7b5b6',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'primary_navigation_dropdown_hover_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Dropdown Text Hover Color', 'beauty' ),
		'sub_desc'   => esc_html__( 'Select dropdown text color for primary navigation from here.', 'beauty' ),
		'std'        => beauty_get_settings( 'mts_secondary_color_scheme' ),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_show_primary_nav',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

);
