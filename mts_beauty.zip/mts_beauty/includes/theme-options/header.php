<?php
/**
 * Header Tab
 *
 * @package Beauty
 */

$menus['header'] = array(
	'icon'  => 'fa-header',
	'title' => esc_html__( 'Header', 'beauty' ),
);

$menus['header']['child']['header-general'] = array(
	'title' => esc_html__( 'General', 'beauty' ),
	'desc'  => esc_html__( 'From here, you can control the elements of header section.', 'beauty' ),
);

$sections['header-general'] = array(

	array(
		'id'       => 'mts_header_style',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Header Styling', 'beauty' ),
		'sub_desc' => wp_kses( __( 'Choose the <strong>Header design</strong> for your site.', 'beauty' ), array( 'strong' => '' ) ),
		'options'  => array(
			'header-default' => array( 'img' => $uri . 'headers/header-default.jpg' ),
			'header-layout2' => array( 'img' => $uri . 'headers/header-layout2.jpg' ),
		),
		'std'      => 'header-default',
	),

	array(
		'id'       => 'mts_sticky_nav',
		'type'     => 'switch',
		'title'    => esc_html__( 'Floating Navigation Menu', 'beauty' ),
		// translators: Floating Navigation Menu with strong tag.
		'sub_desc' => sprintf( esc_html__( 'Use this button to enable %s.', 'beauty' ), '<strong>' . esc_html__( 'Floating Navigation Menu', 'beauty' ) . '</strong>' ),
		'std'      => '0',
	),

	array(
		'id'       => 'mts_header_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Header Margin', 'beauty' ),
		'sub_desc' => esc_html__( 'Set header margin from here.', 'beauty' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '0',
		),
	),
	array(
		'id'       => 'mts_header_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Header Padding', 'beauty' ),
		'sub_desc' => esc_html__( 'Set header padding from here.', 'beauty' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '48px',
			'bottom' => '35px',
		),
	),

	array(
		'id'       => 'mts_header_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'beauty' ),
		'sub_desc' => esc_html__( 'Select border.', 'beauty' ),
	),

	array(
		'id'         => 'mts_header_social_share',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Header Social Icons', 'beauty' ),
		'sub_desc'   => wp_kses( __( 'Use this button to Show or Hide the <strong>Header social icons</strong> completely.', 'beauty' ), array( 'strong' => '' ) ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_header_style',
				'value'      => 'header-default',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'mts_header_social',
		'title'      => esc_html__( 'Header Social Icons', 'beauty' ),
		'sub_desc'   => esc_html__( 'Add Social Media icons in header.', 'beauty' ),
		'type'       => 'group',
		'groupname'  => esc_html__( 'Header Icons', 'beauty' ), // Group name.
		'subfields'  => array(
			array(
				'id'    => 'mts_header_icon_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'beauty' ),
			),
			array(
				'id'    => 'mts_header_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Icon', 'beauty' ),
			),
			array(
				'id'    => 'mts_header_icon_link',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'beauty' ),
			),
			array(
				'id'    => 'mts_header_icon_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background color', 'beauty' ),
			),
			array(
				'id'    => 'mts_header_icon_hover_bgcolor',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon background hover color', 'beauty' ),
			),
			array(
				'id'    => 'mts_header_icon_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon color', 'beauty' ),
			),
			array(
				'id'    => 'mts_header_icon_hover_color',
				'type'  => 'color',
				'title' => esc_html__( 'Header icon hover color', 'beauty' ),
			),
			array(
				'id'    => 'mts_header_icon_margin',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Margin', 'beauty' ),
			),
			array(
				'id'    => 'mts_header_icon_padding',
				'type'  => 'margin',
				'title' => esc_html__( 'Header icon Padding', 'beauty' ),
			),
			array(
				'id'       => 'mts_header_icon_border',
				'type'     => 'border',
				'title'    => esc_html__( 'Border', 'beauty' ),
				'sub_desc' => esc_html__( 'Select border.', 'beauty' ),
			),
			array(
				'id'    => 'mts_header_icon_border_radius',
				'type'  => 'text',
				'class' => 'small-text',
				'title' => esc_html__( 'Header icon border radius', 'beauty' ),
				'args'  => array( 'type' => 'number' ),
			),
		),
		'std'        => array(
			'facebook'  => array(
				'group_title'                   => 'Facebook',
				'group_sort'                    => '1',
				'mts_header_icon_title'         => 'Facebook',
				'mts_header_icon'               => 'facebook-official',
				'mts_header_icon_link'          => '#',
				'mts_header_icon_bgcolor'       => '',
				'mts_header_icon_hover_bgcolor' => '',
				'mts_header_icon_color'         => beauty_get_settings( 'mts_color_scheme' ),
				'mts_header_icon_hover_color'   => beauty_get_settings( 'mts_secondary_color_scheme' ),
				'mts_header_icon_margin'        => array(
					'top'    => '12px',
					'right'  => '12px',
					'bottom' => '12px',
					'left'   => '12px',
				),
				'mts_header_icon_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'mts_header_icon_border_radius' => '0',
			),
			'instagram' => array(
				'group_title'                   => 'Instagram',
				'group_sort'                    => '2',
				'mts_header_icon_title'         => 'Instagram',
				'mts_header_icon'               => 'instagram',
				'mts_header_icon_link'          => '#',
				'mts_header_icon_bgcolor'       => '',
				'mts_header_icon_hover_bgcolor' => '',
				'mts_header_icon_color'         => beauty_get_settings( 'mts_color_scheme' ),
				'mts_header_icon_hover_color'   => beauty_get_settings( 'mts_secondary_color_scheme' ),
				'mts_header_icon_margin'        => array(
					'top'    => '12px',
					'right'  => '12px',
					'bottom' => '12px',
					'left'   => '12px',
				),
				'mts_header_icon_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'mts_header_icon_border_radius' => '0',
			),
			'twitter'   => array(
				'group_title'                   => 'Twitter',
				'group_sort'                    => '3',
				'mts_header_icon_title'         => 'Twitter',
				'mts_header_icon'               => 'twitter',
				'mts_header_icon_link'          => '#',
				'mts_header_icon_bgcolor'       => '',
				'mts_header_icon_hover_bgcolor' => '',
				'mts_header_icon_color'         => beauty_get_settings( 'mts_color_scheme' ),
				'mts_header_icon_hover_color'   => beauty_get_settings( 'mts_secondary_color_scheme' ),
				'mts_header_icon_margin'        => array(
					'top'    => '12px',
					'right'  => '12px',
					'bottom' => '12px',
					'left'   => '12px',
				),
				'mts_header_icon_padding'       => array(
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
				),
				'mts_header_icon_border_radius' => '0',
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_header_social_share',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'mts_header_style',
				'value'      => 'header-default',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'header_search_box',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Header Search Form', 'beauty' ),
		'sub_desc'   => wp_kses( __( 'Use this button to Show or Hide the <strong>Header Search Form</strong> completely.', 'beauty' ), array( 'strong' => '' ) ),
		'std'        => '1',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_header_style',
				'value'      => 'header-default',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_header_section2',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Logo', 'beauty' ),
		'sub_desc' => wp_kses( __( 'Use this button to Show or Hide the <strong>Logo</strong> completely.', 'beauty' ), array( 'strong' => '' ) ),
		'std'      => '1',
	),

	array(
		'id'       => 'mts_main_navigation_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Header Background', 'beauty' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'beauty' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'main_navigation_dropdown_bg',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Background Color', 'beauty' ),
		'sub_desc' => esc_html__( 'Select dropdown background color for main navigation from here.', 'beauty' ),
		'std'      => '#2d2628',
	),
	array(
		'id'       => 'main_navigation_dropdown_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Color', 'beauty' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'beauty' ),
		'std'      => '#b7b5b6',
	),
	array(
		'id'       => 'main_navigation_dropdown_hover_color',
		'type'     => 'color',
		'title'    => esc_html__( 'Dropdown Text Hover Color', 'beauty' ),
		'sub_desc' => esc_html__( 'Select dropdown text color for main navigation from here.', 'beauty' ),
		'std'      => beauty_get_settings( 'mts_secondary_color_scheme' ),
	),

);
