<?php
/**
 * Single Styling
 *
 * @package Beauty
 */

$menus['single-styling'] = array(
	'title' => esc_html__( 'Single Styling', 'beauty' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of your single posts page.', 'beauty' ),
);

$sections['single-styling'] = array(

	array(
		'id'    => 'single_title_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Single Titles Styling', 'beauty' ),
	),

	array(
		'id'       => 'single_title_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Single Page Title Background Color', 'beauty' ),
		'sub_desc' => esc_html__( 'Set Single Page Title( Comments & Comments form ) background color, pattern and image from here.', 'beauty' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),
	array(
		'id'       => 'single_title_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Page Title Padding', 'beauty' ),
		'sub_desc' => esc_html__( 'Set single page title padding from here.', 'beauty' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '25px',
			'left'   => '0',
		),
	),
	array(
		'id'       => 'single_title_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'beauty' ),
		'sub_desc' => esc_html__( 'Select border', 'beauty' ),
	),
	array(
		'id'    => 'single_page_titles_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Section Title Typography', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '30px',
			'line-height'   => '1.6',
			'color'         => '#2d2628',
			'css-selectors' => '#respond h4, .total-comments',
		),
	),

	array(
		'id'    => 'mts_single_styling_heading',
		'type'  => 'heading',
		'title' => esc_html__( 'Single Styling', 'beauty' ),
	),

	array(
		'id'       => 'single_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Background', 'beauty' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image of Single, Page, and 404 Page from here.', 'beauty' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'mts_single_styling_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Margin', 'beauty' ),
		'sub_desc' => esc_html__( 'Set single post margin from here.', 'beauty' ),
		'left'     => false,
		'right'    => false,
		'std'      => array(
			'top'    => '0',
			'bottom' => '40px',
		),
	),
	array(
		'id'       => 'mts_single_styling_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Single Padding', 'beauty' ),
		'sub_desc' => esc_html__( 'Set single post padding from here.', 'beauty' ),
		'std'      => array(
			'left'   => '0',
			'top'    => '0',
			'right'  => '0',
			'bottom' => '20px',
		),
	),
	array(
		'id'       => 'single_styling_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'beauty' ),
		'sub_desc' => esc_html__( 'Select border', 'beauty' ),
	),
	array(
		'id'         => 'breadcrumb_font',
		'type'       => 'typography',
		'title'      => esc_html__( 'Breadcrumbs Font', 'beauty' ),
		'std'        => array(
			'preview-text'  => 'Breadcrumbs',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '400',
			'font-size'     => '18px',
			'color'         => '#2d2628',
			'css-selectors' => '.breadcrumb, .rank-math-breadcrumb',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'    => 'mts_single_meta_info_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Single Meta Info Font', 'beauty' ),
		'std'   => array(
			'preview-text'   => 'Post Meta Font',
			'preview-color'  => 'light',
			'font-family'    => 'Karla',
			'font-weight'    => '400',
			'font-size'      => '15px',
			'line-height'    => '24px',
			'letter-spacing' => '2px',
			'color'          => '#5a4047',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.single_post .post-info, .single-full-header .post-info',
		),
	),
	array(
		'id'    => 'mts_sec_single_meta_info_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Secondary Single Meta Info Font', 'beauty' ),
		'std'   => array(
			'preview-text'   => 'Secondary Post Meta Font',
			'preview-color'  => 'light',
			'font-family'    => 'Karla',
			'font-weight'    => '400',
			'font-size'      => '18px',
			'line-height'    => '24px',
			'color'          => '#969394',
			'letter-spacing' => '0',
			'additional-css' => 'text-transform: none;',
			'css-selectors'  => '.single_post .secondary-meta-info, .single_post .secondary-meta-info .post-info',
		),
	),
	array(
		'id'       => 'mts_tags_font',
		'type'     => 'typography',
		'title'    => esc_html__( 'Tags Font', 'beauty' ),
		'sub_desc' => esc_html__( 'Set Tags font from here, comments date, reply button and submit button font can also be changed from here as well.', 'beauty' ),
		'std'      => array(
			'preview-text'  => 'Tags Font',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '18px',
			'color'         => '#2d2628',
			'css-selectors' => '.tags a, .ago, .reply, #commentform input#submit, #mtscontact_submit',
		),
	),

);
