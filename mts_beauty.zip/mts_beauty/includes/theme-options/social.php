<?php
/**
 * Social Tab
 *
 * @package Beauty
 */

$menus['social'] = array(
	'icon'  => 'fa-users',
	'title' => esc_html__( 'Social Share', 'beauty' ),
	'desc'  => esc_html__( 'Enable or disable social sharing buttons on single posts using these buttons.', 'beauty' ),
);

$menus['social']['child']['social-general'] = array(
	'title' => esc_html__( 'General', 'beauty' ),
	'desc'  => esc_html__( 'From here, you can control the elements of social sharing buttons.', 'beauty' ),
);

$sections['social-general'] = array(

	array(
		'id'       => 'social_button_layout',
		'type'     => 'radio_img',
		'title'    => esc_html__( 'Social Sharing Buttons Layout', 'beauty' ),
		'sub_desc' => wp_kses( __( 'Choose default <strong>social sharing buttons</strong> layout or modern <strong>social sharing buttons</strong> layout for your site. ', 'beauty' ), array( 'strong' => array() ) ),
		'options'  => array(
			'default'      => array( 'img' => $uri . 'social/default.jpg' ),
			'rectwithname' => array( 'img' => $uri . 'social/modern.jpg' ),
			'circwithname' => array( 'img' => $uri . 'social/circwithname.jpg' ),
			//'rectwithcount' => array( 'img' => $uri . 'social/rectwithcount.jpg' ),
			'standard'     => array( 'img' => $uri . 'social/standard.jpg' ),
			'circular'     => array( 'img' => $uri . 'social/circular.jpg' ),
		),
		'std'      => 'standard',
	),

	array(
		'id'       => 'mts_social_button_position',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Social Sharing Buttons Position', 'beauty' ),
		'options'  => array(
			'top'      => esc_html__( 'Above Content', 'beauty' ),
			'bottom'   => esc_html__( 'Below Content', 'beauty' ),
			'floating' => esc_html__( 'Floating', 'beauty' ),
		),
		'sub_desc' => esc_html__( 'Choose position for Social Sharing Buttons.', 'beauty' ),
		'std'      => 'floating',
		'class'    => 'green',
	),

	array(
		'id'       => 'mts_social_buttons_on_pages',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Social Sharing Buttons on Pages', 'beauty' ),
		'options'  => array(
			'0' => esc_html__( 'Off', 'beauty' ),
			'1' => esc_html__( 'On', 'beauty' ),
		),
		'sub_desc' => esc_html__( 'Enable the sharing buttons for pages too, not just posts.', 'beauty' ),
		'std'      => '0',
	),

	array(
		'id'       => 'mts_social_buttons',
		'type'     => 'layout',
		'title'    => esc_html__( 'Social Media Buttons', 'beauty' ),
		'sub_desc' => esc_html__( 'Organize how you want the social sharing buttons to appear on single posts', 'beauty' ),
		'options'  => array(
			'enabled'  => array(
				'facebookshare' => esc_html__( 'Facebook Share', 'beauty' ),
				'twitter'       => esc_html__( 'Twitter', 'beauty' ),
				'pinterest'     => esc_html__( 'Pinterest', 'beauty' ),
			),
			'disabled' => array(
				'facebook' => esc_html__( 'Facebook Like', 'beauty' ),
				'linkedin' => esc_html__( 'LinkedIn', 'beauty' ),
				'stumble'  => esc_html__( 'StumbleUpon', 'beauty' ),
				'reddit'   => esc_html__( 'Reddit', 'beauty' ),
			),
		),
		'std'      => array(
			'enabled'  => array(
				'facebookshare' => esc_html__( 'Facebook Share', 'beauty' ),
				'twitter'       => esc_html__( 'Twitter', 'beauty' ),
				'pinterest'     => esc_html__( 'Pinterest', 'beauty' ),
			),
			'disabled' => array(
				'facebook' => esc_html__( 'Facebook Like', 'beauty' ),
				'linkedin' => esc_html__( 'LinkedIn', 'beauty' ),
				'stumble'  => esc_html__( 'StumbleUpon', 'beauty' ),
				'reddit'   => esc_html__( 'Reddit', 'beauty' ),
			),
		),
	),

);
