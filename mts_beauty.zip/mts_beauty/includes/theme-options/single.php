<?php
/**
 * Single Tab
 *
 * @package Beauty
 */

$menus['single-general'] = array(
	'title' => esc_html__( 'General', 'beauty' ),
	'desc'  => esc_html__( 'From here, you can control the appearance and functionality of your single posts page.', 'beauty' ),
);

$sections['single-general'] = array(

	array(
		'id'       => 'mts_show_featured',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Featured image', 'beauty' ),
		'sub_desc' => esc_html__( 'Enable/Disable the Featured images in the single post.', 'beauty' ),
		'std'      => '1',
	),
	array(
		'id'       => 'featured_image_size',
		'type'     => 'button_set',
		'title'    => esc_html__( 'Header Size', 'beauty' ),
		'sub_desc' => esc_html__( 'Choose the featured image size', 'beauty' ),
		'options'  => array(
			'default' => esc_html__( 'Content Size', 'beauty' ),
			'full'    => esc_html__( 'Full Width', 'beauty' ),
		),
		'std'      => 'default',
	),
	array(
		'id'         => 'featured_image_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Header Image Margin', 'beauty' ),
		'sub_desc'   => esc_html__( 'Set header image margin from here.', 'beauty' ),
		'std'        => array(
			'top'    => '-80px',
			'right'  => '0',
			'bottom' => '64px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'featured_text_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Alignment', 'beauty' ),
		'sub_desc'   => esc_html__( 'Choose the featured image text alignment', 'beauty' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'beauty' ),
			'center' => esc_html__( 'Center', 'beauty' ),
			'right'  => esc_html__( 'Right', 'beauty' ),
		),
		'std'        => 'center',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'author_image_on_full',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show Author Image', 'beauty' ),
		'sub_desc'   => esc_html__( 'Enable or disable author image with this option', 'beauty' ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'show_prev_next',
		'type'       => 'switch',
		'title'      => esc_html__( 'Show preview and next article buttons', 'beauty' ),
		'sub_desc'   => esc_html__( 'Use this button to show or hide preview and next article buttons.', 'beauty' ),
		'std'        => '0',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured_image_size',
				'value'      => 'full',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_single_post_layout',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Post Layout', 'beauty' ),
		'sub_desc' => esc_html__( 'Customize the look of single posts', 'beauty' ),
		'options'  => array(
			'enabled'  => array(
				'content' => array(
					'label'     => esc_html__( 'Post Content', 'beauty' ),
					'subfields' => array(),
				),
				'tags'    => array(
					'label'     => esc_html__( 'Tags', 'beauty' ),
					'subfields' => array(),
				),
				'author'  => array(
					'label'     => esc_html__( 'Author Box', 'beauty' ),
					'subfields' => array(
						array(
							'id'       => 'mts_related_posts_taxonomy',
							'type'     => 'switch',
							'title'    => esc_html__( 'Related Posts Taxonomy', 'beauty' ),
							'options'  => array(
								'tags'       => esc_html__( 'Tags', 'beauty' ),
								'categories' => esc_html__( 'Categories', 'beauty' ),
							),
							'class'    => 'green',
							'sub_desc' => esc_html__( 'Related Posts based on tags or categories.', 'beauty' ),
							'std'      => 'categories',
						),
					),
				),
				'related' => array(
					'label'     => esc_html__( 'Related Posts', 'beauty' ),
					'subfields' => array(
						array(
							'id'       => 'related_post_title',
							'type'     => 'text',
							'title'    => esc_html__( 'Related Posts Title', 'beauty' ),
							'sub_desc' => esc_html__( 'Enter the title text to show in the related posts section.', 'beauty' ),
							'std'      => 'Related Posts',

						),
						array(
							'id'       => 'mts_related_posts_taxonomy',
							'type'     => 'switch',
							'title'    => esc_html__( 'Related Posts Taxonomy', 'beauty' ),
							'options'  => array(
								'tags'       => esc_html__( 'Tags', 'beauty' ),
								'categories' => esc_html__( 'Categories', 'beauty' ),
							),
							'class'    => 'green',
							'sub_desc' => esc_html__( 'Related Posts based on tags or categories.', 'beauty' ),
							'std'      => 'categories',
						),
					),
				),
			),
			'disabled' => array(
				'subscribe' => array(
					'label'     => esc_html__( 'Subscribe Box', 'beauty' ),
					'subfields' => array(),
				),
			),
		),
	),

	array(
		'id'       => 'mts_single_headline_meta_info',
		'type'     => 'layout2',
		'title'    => esc_html__( 'Single Meta Info', 'beauty' ),
		'sub_desc' => esc_html__( 'Organize how you want the post meta info to appear on single page', 'beauty' ),
		'options'  => array(
			'enabled'  => array(
				'category' => array(
					'label'     => esc_html__( 'Categories', 'beauty' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_category_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'beauty' ),
						),
					),
				),
				'date'     => array(
					'label'     => esc_html__( 'Date', 'beauty' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_date_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'beauty' ),
						),
					),
				),
			),
			'disabled' => array(
				'author'  => array(
					'label'     => __( 'Author Name', 'beauty' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_author_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'beauty' ),
						),
					),
				),
				'comment' => array(
					'label'     => esc_html__( 'Comment Count', 'beauty' ),
					'subfields' => array(
						array(
							'id'    => 'mts_single_meta_info_comment_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'beauty' ),
						),
					),
				),
			),
		),
	),

	array(
		'id'       => 'single_meta_info_background',
		'type'     => 'color',
		'title'    => esc_html__( 'Single Meta Background Color', 'beauty' ),
		'sub_desc' => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'beauty' ),
	),

	array(
		'id'       => 'secondary_single_meta_info',
		'type'     => 'switch',
		'title'    => esc_html__( 'Show Secondary Meta Info', 'beauty' ),
		'sub_desc' => esc_html__( 'Enable/Disable the secondary meta info in the single post.', 'beauty' ),
		'std'      => '1',
	),

	array(
		'id'         => 'secondary_author_image',
		'type'       => 'multi_checkbox',
		'title'      => esc_html__( 'Secondary Author Image, Author Name', 'beauty' ),
		'sub_desc'   => esc_html__( 'Show or hide author image and author name.', 'beauty' ),
		'options'    => array(
			'author-image' => esc_html__( 'Author Image', 'beauty' ),
			'author-name'  => esc_html__( 'Author Name', 'beauty' ),
		),
		'std'        => array(
			'author-image',
			'author-name',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'secondary_single_meta_info',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'mts_secondary_single_headline_meta_info',
		'type'       => 'layout2',
		'title'      => esc_html__( 'Secondary Single Meta Info', 'beauty' ),
		'sub_desc'   => esc_html__( 'Organize how you want the post meta info to appear on single post, it will be shown below single featured image.', 'beauty' ),
		'options'    => array(
			'enabled'  => array(
				'category' => array(
					'label'     => esc_html__( 'Categories', 'beauty' ),
					'subfields' => array(
						array(
							'id'    => 'mts_secondary_single_meta_info_category_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'beauty' ),
						),
					),
				),
				'date'     => array(
					'label'     => esc_html__( 'Date', 'beauty' ),
					'subfields' => array(
						array(
							'id'    => 'mts_secondary_single_meta_info_date_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'beauty' ),
						),
					),
				),
			),
			'disabled' => array(
				'comment' => array(
					'label'     => esc_html__( 'Comment Count', 'beauty' ),
					'subfields' => array(
						array(
							'id'    => 'mts_secondary_single_meta_info_comment_icon',
							'type'  => 'icon_select',
							'title' => esc_html__( 'Select Icon', 'beauty' ),
						),
					),
				),
			),
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'secondary_single_meta_info',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'secondary_single_meta_info_background',
		'type'       => 'color',
		'title'      => esc_html__( 'Secondary Single Meta Background Color', 'beauty' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'beauty' ),
		'std'        => '#2d2628',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'secondary_single_meta_info',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'secondary_meta_info_author_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Secondary Meta Author Color', 'beauty' ),
		'sub_desc'   => esc_html__( 'The theme comes with unlimited color schemes for your theme\'s styling.', 'beauty' ),
		'std'        => '#ffffff',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'secondary_single_meta_info',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'secondary_single_meta_info_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Secondary Meta Info Padding', 'beauty' ),
		'sub_desc'   => esc_html__( 'Set secondary meta info padding from here.', 'beauty' ),
		'std'        => array(
			'top'    => '0',
			'right'  => '0',
			'bottom' => '25px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'secondary_single_meta_info',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'secondary_single_meta_info_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Secondary Meta Info Margin', 'beauty' ),
		'sub_desc'   => esc_html__( 'Set secondary meta info margin from here.', 'beauty' ),
		'std'        => array(
			'top'    => '-36px',
			'right'  => '0',
			'bottom' => '30px',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'secondary_single_meta_info',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'secondary_single_meta_info_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Secondary Meta Border', 'beauty' ),
		'sub_desc'   => esc_html__( 'Select border.', 'beauty' ),
		'std'        => array(
			'direction' => 'bottom',
			'size'      => '1',
			'style'     => 'solid',
			'color'     => '#e0dfdf',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'secondary_single_meta_info',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_breadcrumb',
		'type'     => 'switch',
		'title'    => esc_html__( 'Breadcrumbs', 'beauty' ),
		'sub_desc' => esc_html__( 'Breadcrumbs are a great way to make your site more user-friendly. You can enable them by checking this box.', 'beauty' ),
		'std'      => '0',
	),

	array(
		'id'         => 'breadcrumb_icon',
		'type'       => 'icon_select',
		'title'      => esc_html__( 'Icon', 'beauty' ),
		'sub_desc'   => esc_html__( 'Select divider icons from here.', 'beauty' ),
		'std'        => 'angle-right',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_breadcrumb',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_author_comment',
		'type'     => 'switch',
		'title'    => esc_html__( 'Highlight Author Comment', 'beauty' ),
		'sub_desc' => esc_html__( 'Use this button to highlight author comments.', 'beauty' ),
		'std'      => '1',
	),

	array(
		'id'       => 'mts_comment_date',
		'type'     => 'switch',
		'title'    => esc_html__( 'Date in Comments', 'beauty' ),
		'sub_desc' => esc_html__( 'Use this button to show the date for comments.', 'beauty' ),
		'std'      => '1',
	),
);
