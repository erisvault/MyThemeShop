<?php
/**
 * Typography tab
 *
 * @package Beauty
 */

$menus['typography-collection'] = array(
	'icon'       => 'fa-text-width',
	'title'      => esc_html__( 'Typography', 'beauty' ),
	'hide_title' => true,
);

$sections['typography-collection'] = array(

	array(
		'id'    => 'typography-collections',
		'type'  => 'typography_collections',
		'title' => esc_html__( 'Theme Typography', 'beauty' ),
		'desc'  => esc_html__( 'From here, you can control the fonts used on your site. You can choose from 17 standard font sets, or from the Google Fonts Library containing 800+ fonts.', 'beauty' ),
	),

	array(
		'id'    => 'beauty_logo',
		'type'  => 'typography',
		'title' => esc_html__( 'Logo Font', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'Logo',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '700',
			'font-size'     => '40px',
			'color'         => '#000000',
			'css-selectors' => '#logo a',
		),
	),

	array(
		'id'    => 'secondary_navigation_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Secondary Navigation', 'beauty' ),
		'std'   => array(
			'preview-text'   => 'Secondary Navigation Font',
			'preview-color'  => 'light',
			'font-family'    => 'Karla',
			'font-weight'    => '400',
			'font-size'      => '15px',
			'letter-spacing' => '0.5px',
			'color'          => '#000000',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '#secondary-navigation a, .header-search-icon',
		),
	),

	array(
		'id'    => 'home_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Archive Post Titles', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'Archive Article Title',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '22px',
			'line-height'   => '28px',
			'color'         => '#2d2628',
			'css-selectors' => '.latestPost .title a',
		),
	),

	array(
		'id'    => 'single_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Single Post Title', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'Single Article Title',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '60px',
			'line-height'   => '1',
			'color'         => '#2d2628',
			'css-selectors' => '.single-title',
		),
	),

	array(
		'id'    => 'content_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Content Font', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'Content Font',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '400',
			'font-size'     => '20px',
			'line-height'   => '2',
			'color'         => '#8e8084',
			'css-selectors' => 'body',
		),
	),

	array(
		'id'    => 'sidebar_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Widget Title', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '20px',
			'line-height'   => '24px',
			'color'         => '#2d2628',
			'css-selectors' => '#sidebar .widget h3.widget-title, .widget #wp-subscribe .title',
		),
	),

	array(
		'id'    => 'sidebar_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Font', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Font',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '400',
			'font-size'     => '14px',
			'line-height'   => '24px',
			'color'         => '#8e8084',
			'css-selectors' => '#sidebar .widget p, #sidebar .widget .post-excerpt',
		),
	),

	array(
		'id'    => 'sidebar_url',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Links', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Links',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '24px',
			'color'         => '#2d2628',
			'css-selectors' => '.sidebar .widget a, .sidebar .widget li, .widget #s',
		),
	),

	array(
		'id'    => 'sidebar_post_title',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Posts Title', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Posts Titles',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '20px',
			'color'         => '#2d2628',
			'css-selectors' => '.sidebar .post-title a, .sidebar .entry-title a, .sidebar .wpt_comment_meta a',
		),
	),

	array(
		'id'    => 'sidebar_large_post_title',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Large Posts Title', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'Sidebar Large Posts Titles',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '22px',
			'line-height'   => '28px',
			'color'         => '#2d2628',
			'css-selectors' => '.sidebar li.vertical-small .post-title a, .sidebar .widget .wpt_thumb_large + .entry-title a, .sidebar .widget .wpt_thumb_large + .wpt_comment_meta a, .sidebar .widget .review_thumb_large .entry-title a',
		),
	),

	array(
		'id'    => 'sidebar_postinfo_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Sidebar Meta font', 'beauty' ),
		'std'   => array(
			'preview-text'   => 'Sidebar Meta Font',
			'preview-color'  => 'dark',
			'font-family'    => 'Karla',
			'font-weight'    => '400',
			'font-size'      => '12px',
			'color'          => '#5a4047',
			'letter-spacing' => '1.7px',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.sidebar .widget .post-info, .sidebar .widget .post-info a, .sidebar .widget .wpt_widget_content .wpt-postmeta, .sidebar .wp_review_tab_widget_content .wp-review-tab-postmeta',
		),
	),

	array(
		'id'    => 'top_footer_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Widget Title', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'Footer Title Font',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '34px',
			'line-height'   => '40px',
			'color'         => '#2d2628',
			'css-selectors' => '.footer-widgets h3, #site-footer .widget #wp-subscribe .title, .brands-title',
		),
	),

	array(
		'id'    => 'top_footer_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer font', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'Footer Font',
			'preview-color' => 'light',
			'font-family'   => 'Karla',
			'font-weight'   => '400',
			'font-size'     => '16px',
			'line-height'   => '1.5',
			'color'         => '#8e8084',
			'css-selectors' => '.footer-widgets, footer .widget .wpt_excerpt, footer .advanced-recent-posts p, footer .popular-posts p, footer .category-posts p',
		),
	),

	array(
		'id'    => 'top_footer_link_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Link', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'Footer Links',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '18px',
			'line-height'   => '24px',
			'color'         => '#2d2628',
			'css-selectors' => '.f-widget a, .f-widget .wpt_widget_content a, .f-widget .wp_review_tab_widget_content a, .f-widget .widget #s',
		),
	),

	array(
		'id'    => 'top_footer_post_title',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Post Title', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'Footer Posts Title',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '18px',
			'line-height'   => '24px',
			'color'         => '#2d2628',
			'css-selectors' => '#site-footer .post-title a, #site-footer .entry-title a',
		),
	),

	array(
		'id'    => 'footer_large_post_title',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Large Posts Title', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'Footer Large Posts Titles',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '22px',
			'line-height'   => '28px',
			'color'         => '#2d2628',
			'css-selectors' => '#site-footer li.vertical-small .post-title a, #site-footer .widget .wpt_thumb_large + .entry-title a, #site-footer .widget .review_thumb_large .entry-title a, #site-footer .widget .wpt_thumb_large + .wpt_comment_meta a',
		),
	),

	array(
		'id'    => 'top_footer_meta_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Footer Meta font', 'beauty' ),
		'std'   => array(
			'preview-text'   => 'Footer Font',
			'preview-color'  => 'light',
			'font-family'    => 'Karla',
			'font-weight'    => '400',
			'font-size'      => '12px',
			'color'          => '#5a4047',
			'letter-spacing' => '1.7px',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => 'footer .widget .post-info, footer .widget .post-info a, footer .widget .wpt_widget_content .wpt-postmeta, footer .wp_review_tab_widget_content .wp-review-tab-postmeta',
		),
	),

	array(
		'id'    => 'copyrights_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Copyrights Section', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'Copyrights Font',
			'preview-color' => 'dark',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '18px',
			'line-height'   => '18px',
			'color'         => '#cac9c9',
			'css-selectors' => '#copyright-note, #copyright-note a',
		),
	),

	array(
		'id'    => 'h1_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H1 Heading in Content', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'H1 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '40px',
			'color'         => '#2d2628',
			'css-selectors' => 'h1',
		),
	),

	array(
		'id'    => 'h2_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H2 Heading in Content', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'H2 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '36px',
			'color'         => '#2d2628',
			'css-selectors' => 'h2',
		),
	),

	array(
		'id'    => 'h3_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H3 Heading in Content', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'H3 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '34px',
			'color'         => '#2d2628',
			'css-selectors' => 'h3',
		),
	),

	array(
		'id'    => 'h4_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H4 Heading in Content', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'H4 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '32px',
			'color'         => '#2d2628',
			'css-selectors' => 'h4',
		),
	),

	array(
		'id'    => 'h5_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H5 Heading in Content', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'H5 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '30px',
			'color'         => '#2d2628',
			'css-selectors' => 'h5',
		),
	),

	array(
		'id'    => 'h6_headline',
		'type'  => 'typography',
		'title' => esc_html__( 'H6 Heading in Content', 'beauty' ),
		'std'   => array(
			'preview-text'  => 'H6 Headline',
			'preview-color' => 'light',
			'font-family'   => 'Crimson Text',
			'font-weight'   => '400',
			'font-size'     => '28px',
			'color'         => '#2d2628',
			'css-selectors' => 'h6',
		),
	),

	array(
		'id'       => 'typography-subsets',
		'type'     => 'multi_checkbox',
		'title'    => esc_html__( 'Character sets', 'beauty' ),
		'sub_desc' => esc_html__( 'Choose the character sets you wish to include. Please note that not all sets are available for all fonts.', 'beauty' ),
		'options'  => array(
			'latin'        => esc_html__( 'Latin', 'beauty' ),
			'latin-ext'    => esc_html__( 'Latin Extended', 'beauty' ),
			'cyrillic'     => esc_html__( 'Cyrillic', 'beauty' ),
			'cyrillic-ext' => esc_html__( 'Cyrillic Extended', 'beauty' ),
			'greek'        => esc_html__( 'Greek', 'beauty' ),
			'greek-ext'    => esc_html__( 'Greek Extended', 'beauty' ),
			'vietnamese'   => esc_html__( 'Vietnamese', 'beauty' ),
			'khmer'        => esc_html__( 'Khmer', 'beauty' ),
			'devanagari'   => esc_html__( 'Devanagari', 'beauty' ),
		),
		'std'      => array( 'latin' ),
	),
);
