<?php
/**
 * The template for displaying all single posts.
 *
 * @package Beauty
 */

get_header(); ?>

	<div id="wrapper" class="<?php beauty_single_page_class(); ?>">

		<?php beauty_action( 'single_top' ); ?>

		<div class="container clearfix">

			<?php
			beauty_single_featured_image_effect();

			beauty_action( 'before_content' );

			beauty_single_sections();

			beauty_action( 'after_content' );

			get_sidebar();
			?>

		</div>

		<?php
		if ( 'full' === beauty_get_settings( 'related_posts_position' ) ) {
			beauty_related_posts();
		}
		$options = beauty_get_settings( 'mts_single_post_layout' );
		//print_r( $options );
		if ( 'subscribe-full' === beauty_get_settings( 'single_subscribe_position' ) && 'Subscribe Box' == $options['enabled']['subscribe'] ) {
			beauty()->single_sections->single_subscribe_box();
		}
		?>

<?php
get_footer();
