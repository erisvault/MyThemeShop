<?php
/*
Template Name: Latest Posts
*/
?>
<?php $mts_options = get_option('glamour'); ?>
<?php get_header(); ?>
<div id="page">
	<div class="article archive">
		<div id="content_box">
			<h1 class="postsby"><?php _e('Latest Posts','mythemeshop'); ?></h1>
			<div class="archive">
				<?php $temp = $wp_query; $wp_query= null; $wp_query = new WP_Query(); $wp_query->query('showposts=12'.'&paged='.$paged); ?>
				<?php while ($wp_query->have_posts()): $wp_query->the_post(); ?>
					<article class="latestPost excerpt  <?php echo (++$j % 4 == 0) ? 'last' : ''; ?>">
						<header>
							<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" id="featured-thumbnail">
								<?php if ( has_post_thumbnail() ) { ?> 
									<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('featured',array('title' => '')); echo '</div>'; ?>
								<?php } else { ?>
									<div class="featured-thumbnail">
										<img width="145" height="100" src="<?php echo get_template_directory_uri(); ?>/images/nothumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
									</div>
								<?php } ?>
							</a>                                               
						</header><!--.header-->
						<div class="post-container">
							<div class="post-content image-caption-format-1">
								<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" ><b><?php the_title(); ?></b></a>: <?php echo mts_excerpt(13);?>
							</div>
							<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('More','mythemeshop'); ?> +</a></div>
						</div> 
					</article><!--.post excerpt-->
				<?php endwhile;?>
			</div>
			<!--Start Pagination-->
			<?php $additional_loop = 0; mts_pagination($additional_loop['max_num_pages']); ?>           
			<!--End Pagination-->
		</div>
	</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>