var $ = jQuery.noConflict();
jQuery.fn.exists = function(callback) {
  var args = [].slice.call(arguments, 1);
  if (this.length) {
    callback.call(this, args);
  }
  return this;
};
/*
 * Superfish v1.5.0 - jQuery menu widget
 * Copyright (c) 2013 Joel Birch
 *
 * Dual licensed under the MIT and GPL licenses:
 * 	http://www.opensource.org/licenses/mit-license.php
 * 	http://www.gnu.org/licenses/gpl.html
 *
 * CHANGELOG: http://users.tpg.com.au/j_birch/plugins/superfish/changelog.txt
 */
!function(a){a.fn.superfish=function(b){var c=a.fn.superfish,d=c.c,e=a('<span class="'+d.arrowClass+'"> &#187;</span>'),f=function(){var b=a(this),c=h(b);clearTimeout(c.sfTimer),b.showSuperfishUl().siblings().hideSuperfishUl()},g=function(){var b=a(this),d=h(b),e=c.op;clearTimeout(d.sfTimer),d.sfTimer=setTimeout(function(){e.retainPath=a.inArray(b[0],e.$path)>-1,b.hideSuperfishUl(),e.$path.length&&b.parents("li."+e.hoverClass).length<1&&(e.onIdle.call(this),f.call(e.$path))},e.delay)},h=function(a){var b=a.parents("ul."+d.menuClass+":first")[0];return c.op=c.o[b.serial],b},i=function(a){a.addClass(d.anchorClass).append(e.clone())};return this.addClass(d.menuClass).each(function(){var e=this.serial=c.o.length,h=a.extend({},c.defaults,b);h.$path=a("li."+h.pathClass,this).slice(0,h.pathLevels).each(function(){a(this).addClass(h.hoverClass+" "+d.bcClass).filter("li:has(ul)").removeClass(h.pathClass)}),c.o[e]=c.op=h,a("li:has(ul)",this)[a.fn.hoverIntent&&!h.disableHI?"hoverIntent":"hover"](f,g).each(function(){h.autoArrows&&i(a(">a:first-child",this))}).not("."+d.bcClass).hideSuperfishUl();var j=a("a",this);j.each(function(a){var b=j.eq(a).parents("li");j.eq(a).focus(function(){f.call(b)}).blur(function(){g.call(b)})}),h.onInit.call(this)})};var b=a.fn.superfish;b.o=[],b.op={},b.c={bcClass:"sf-breadcrumb",menuClass:"sf-js-enabled",anchorClass:"sf-with-ul",arrowClass:"sf-sub-indicator"},b.defaults={hoverClass:"sfHover",pathClass:"overideThisToUse",pathLevels:1,delay:800,animation:{opacity:"show"},speed:"normal",autoArrows:!0,disableHI:!1,onInit:function(){},onBeforeShow:function(){},onShow:function(){},onHide:function(){},onIdle:function(){}},a.fn.extend({hideSuperfishUl:function(){var c=b.op,d=c.retainPath===!0?c.$path:"";c.retainPath=!1;var e=a("li."+c.hoverClass,this).add(this).not(d).removeClass(c.hoverClass).find(">ul").hide().css("visibility","hidden");return c.onHide.call(e),this},showSuperfishUl:function(){var a=b.op,c=this.addClass(a.hoverClass).find(">ul:hidden").css("visibility","visible");return a.onBeforeShow.call(c),c.animate(a.animation,a.speed,function(){a.onShow.call(c)}),this}})}(jQuery);
	
jQuery(document).ready(function() { 
	jQuery('#navigation ul.menu, #navigation ul#children, #navigation ul.sub-menu').superfish({ 
		delay:       100,								// 0.1 second delay on mouseout 
		animation:   {opacity:'show',height:'show'},	// fade-in and slide-down animation 
		dropShadows: false								// disable drop shadows 
	});
	
});

/*----------------------------------------------------
/* Scroll to top
/*--------------------------------------------------*/
jQuery(document).ready(function() {
    //START -- MOVE-TO-TOP ARROW
	//move-to-top arrow
	jQuery("body").prepend("<div id='move-to-top' class='animate '><i class='icon-chevron-up'></i></div>");
	var scrollDes = 'html,body';  
	/*Opera does a strange thing if we use 'html' and 'body' together so my solution is to do the UA sniffing thing*/
	if(navigator.userAgent.match(/opera/i)){
		scrollDes = 'html';
	}
	//show ,hide
	jQuery(window).scroll(function () {
		if (jQuery(this).scrollTop() > 160) {
			if(Modernizr.csstransitions) {
				jQuery('#move-to-top').addClass('filling').removeClass('hiding');
			}
			else {
				jQuery('#move-to-top').fadeIn();
			}
		} else {
			if(Modernizr.csstransitions) {				
				jQuery('#move-to-top').removeClass('filling').addClass('hiding');
			}else{
				jQuery('#move-to-top').fadeOut();				
			}
		}
	});
	// scroll to top when click 
	jQuery('#move-to-top').click(function () {
		jQuery(scrollDes).animate({ 
			scrollTop: 0
		},{
			duration :500
		});
	});
	//END -- MOVE-TO-TOP ARROW
});

/*----------------------------------------------------
/* Smooth Scrolling for Anchor Tag like #comments
/*--------------------------------------------------*/
$(function() {
  $('a[href*="#comments"]:not([href="#comments"])').click(function() {
    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') 
        || location.hostname == this.hostname) {

      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
      if (target.length) {
        $('html,body').animate({
          scrollTop: target.offset().top
        }, 1000);
        return false;
      }
    }
  });
});

/*----------------------------------------------------
/* Responsive Navigation
/*--------------------------------------------------*/
jQuery(function() {
	var pull 		= jQuery('#pull');
		menu 		= jQuery('nav > ul');
		menuHeight	= menu.height();

	jQuery(pull).on('click', function(e) {
		e.preventDefault();
		menu.slideToggle();
	});
});	

/*----------------------------------------------------
/* Tabbed Widget
/*--------------------------------------------------*/
jQuery(document).ready(function(){
	// UL = .tabs
	// Tab contents = .inside
	jQuery('.inside ul li:last-child').css('border-bottom','0px') // remove last border-bottom from list in tab conten
	jQuery('.tabs').each(function(){
		jQuery(this).children('li').children('a:first').addClass('selected'); // Add .selected class to first tab on load
	});
	jQuery('.inside > *').hide();
	jQuery('.inside > *:first-child').show();
	jQuery('.tabs li a').click(function(evt){ // Init Click funtion on Tabs
		var clicked_tab_ref = jQuery(this).attr('href'); // Strore Href value
		jQuery(this).parent().parent().children('li').children('a').removeClass('selected'); //Remove selected from all tabs
		jQuery(this).addClass('selected');
		jQuery(this).parent().parent().parent().children('.inside').children('*').hide();
		jQuery('.inside ' + clicked_tab_ref).fadeIn(500);
			evt.preventDefault();
	})
})

/*----------------------------------------------------
/* Scroll to top footer link script
/*--------------------------------------------------*/
jQuery(document).ready(function(){
    jQuery('a[href="#top"]').click(function(){
        jQuery('html, body').animate({scrollTop:0}, 'slow');
        return false;
    });
jQuery(".togglec").hide();
	jQuery(".togglet").click(function(){
	jQuery(this).toggleClass("toggleta").next(".togglec").slideToggle("normal");
	   return true;
	});
});

/*----------------------------------------------------
/* Social button scripts
/*---------------------------------------------------*/
jQuery(document).ready(function(){
	jQuery.fn.exists = function(callback) {
	  var args = [].slice.call(arguments, 1);
	  if (this.length) {
		callback.call(this, args);
	  }
	  return this;
	};
	(function(d, s) {
	  var js, fjs = d.getElementsByTagName(s)[0], load = function(url, id) {
		if (d.getElementById(id)) {return;}
		js = d.createElement(s); js.src = url; js.id = id;
		fjs.parentNode.insertBefore(js, fjs);
	  };
	jQuery('span.facebookbtn').exists(function() {
	  load('//connect.facebook.net/en_US/all.js#xfbml=1', 'fbjssdk');
	});
	jQuery('span.gplusbtn').exists(function() {
	  load('https://apis.google.com/js/plusone.js', 'gplus1js');
	});
	jQuery('span.twitterbtn').exists(function() {
	  load('//platform.twitter.com/widgets.js', 'tweetjs');
	});
	jQuery('span.linkedinbtn').exists(function() {
	  load('//platform.linkedin.com/in.js', 'linkedinjs');
	});
	jQuery('span.pinbtn').exists(function() {
	  load('//assets.pinterest.com/js/pinit.js', 'pinterestjs');
	});
	jQuery('span.stumblebtn').exists(function() {
	  load('//platform.stumbleupon.com/1/widgets.js', 'stumbleuponjs');
	});
	}(document, 'script'));
});

/*----------------------------------------------------
/* Social button scripts
/*---------------------------------------------------*/
jQuery(document).ready(function() {
jQuery('#catchersocial').exists(function() {
	function isScrolledTo(elem) {
		var docViewTop = jQuery(window).scrollTop(); //num of pixels hidden above current screen
		var docViewBottom = docViewTop + jQuery(window).height();

		var elemTop = jQuery(elem).offset().top; //num of pixels above the elem
		var elemBottom = elemTop + jQuery(elem).height();

		return ((elemTop <= docViewTop));
	}

	var catchersocial = jQuery('#catchersocial');
	var stickysocial = jQuery('#stickysocial');
	
	jQuery(window).scroll(function() {
		if(isScrolledTo(stickysocial)) {
			stickysocial.css('position','fixed');
			stickysocial.css('top','80px');
		} 
		var stopHeight = catchersocial.offset().top + catchersocial.height();
		if ( stopHeight > stickysocial.offset().top) {
			stickysocial.css('position','relative');
			stickysocial.css('top', 'auto');
		}
	});
});
});
