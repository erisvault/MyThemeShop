<!DOCTYPE html>
<?php $options = get_option('adorable'); ?>
<html class="no-js" <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<title><?php wp_title(''); ?></title>
	<?php mts_meta(); ?>
	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<?php wp_enqueue_script("jquery"); ?>
	<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
	<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<?php mts_head(); ?>
	<?php wp_head(); ?>
</head>

<?php flush(); ?>

<body id ="blog" <?php body_class('main'); ?>>
	<header class="main-header">
		<div class="container">
			<div id="header">
				<?php if( is_front_page() || is_home() || is_404() ) { ?>
						<h1 id="logo">
							<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
						</h1><!-- END #logo -->
				<?php } else { ?>
						<h2 id="logo">
							<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
						</h2><!-- END #logo -->
				<?php } ?>

				<?php widgetized_header(); ?>
			</div><!--#header-->  
			<div class="main-navigation">
				<nav id="navigation" >
					<?php if ( has_nav_menu( 'primary-menu' ) ) { ?>
						<?php wp_nav_menu( array( 'theme_location' => 'primary-menu', 'menu_class' => 'menu', 'container' => '' ) ); ?>
					<?php } else { ?>
						<ul class="menu">
							<?php wp_list_pages('title_li='); ?>
						</ul>
					<?php } ?>
				</nav>
			</div><!--.main-navigation-->
			<?php if (is_single() || is_page()) { ?>
				<div class="post-info-box">
					<?php if ($options['mts_breadcrumb'] == '1') {
						if( function_exists( 'rank_math' ) && rank_math()->breadcrumbs ) {
						    rank_math_the_breadcrumbs();
						  } else { ?>
						    <div class="breadcrumb" xmlns:v="http://rdf.data-vocabulary.org/#"><?php the_breadcrumb(); ?></div>
						<?php }
					} ?>
					
					<div class="post-info single-postmeta">
						<?php if($options['mts_headline_meta'] == '1') { ?>
							<time><?php the_time('F j, Y'); ?></time> |
							<span class="thecomments"><?php $numberOfComments = $wpdb->get_var("SELECT COUNT( comment_post_ID ) FROM $wpdb->comments WHERE comment_post_ID = '$post->ID' AND comment_type = '' GROUP BY 'comment_type' "); if ($numberOfComments == 0) { _e('0 comments','mythemeshop'); } else if ($numberOfComments != "" && $numberOfComments == 1) { echo $numberOfComments; _e(' comment','mythemeshop'); } else if ($numberOfComments > 1) { echo $numberOfComments; _e(' comments','mythemeshop'); } ?></span>
						<?php } ?>
					</div>
				</div>
			<?php } ?>
		</div><!--.container-->        
	</header>
<div class="main-container">