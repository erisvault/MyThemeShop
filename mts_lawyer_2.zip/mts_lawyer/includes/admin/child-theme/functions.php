<?php
/**
 * Lawyer Child Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Lawyer Child
 */

/**
 * Enqueue styles
 */
function lawyer_child_enqueue_scripts() {
	wp_enqueue_style( 'lawyer-child-theme-css', get_stylesheet_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'lawyer_child_enqueue_scripts', 15 );
