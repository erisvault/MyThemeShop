<?php
/**
 * HomePage Featured 3 Section
 *
 * @package Lawyer
 */

$menus['homepage']['child']['homepage-featured3'] = array(
	'title' => esc_html__( 'Featured 3', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the Featured 3 section.', 'lawyer' ),
);

$sections['homepage-featured3'] = array(

	array(
		'id'       => 'featured3_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Featured 3 Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'upload',
			'image_pattern' => 'nobg',
			'image_upload'  => get_template_directory_uri() . '/images/featured3-bg.jpg',
			'repeat'        => 'no-repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'featured3_icon',
		'type'     => 'icon_select',
		'title'    => esc_html__( 'Icon', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select an icon.', 'lawyer' ),
		'std'      => 'institution',
	),

	array(
		'id'       => 'featured3_title',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Title', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter title for featured3 section.', 'lawyer' ),
		'std'      => 'Legal Representation in Ligitation Case',
	),
	array(
		'id'    => 'featured3_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Title',
			'preview-color' => 'dark',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '48px',
			'line-height'   => '56px',
			'color'         => '#ffffff',
			'css-selectors' => '.featured3-section h2',
		),
	),

	array(
		'id'       => 'featured3_text',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter text for featured3 section.', 'lawyer' ),
		'std'      => 'Our lawyers will also represent you in civil litigation cases such as divorce, child and<br>spouse maintenance.',
	),
	array(
		'id'    => 'featured3_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Text',
			'preview-color' => 'dark',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '20px',
			'line-height'   => '35px',
			'color'         => '#ffffff',
			'css-selectors' => '.featured3-section p',
		),
	),

	array(
		'id'       => 'featured3_img1',
		'type'     => 'upload',
		'title'    => esc_html__( 'Image1', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select an image file. Recommended size: 445 X 198', 'lawyer' ),
		'return'   => 'url',
		'std'      => get_template_directory_uri() . '/images/featured3-1.jpg',
	),
	array(
		'id'       => 'featured3_img2',
		'type'     => 'upload',
		'title'    => esc_html__( 'Image2', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select an image file. Recommended size: 445 X 198', 'lawyer' ),
		'return'   => 'url',
		'std'      => get_template_directory_uri() . '/images/featured3-2.jpg',
	),

	array(
		'id'        => 'featured3_info',
		'type'      => 'group',
		'title'     => esc_html__( 'Text Info', 'lawyer' ),
		'sub_desc'  => esc_html__( 'Add info appearing on the featured3 section.', 'lawyer' ),
		'groupname' => esc_html__( 'Info', 'lawyer' ),
		'subfields' => array(
			array(
				'id'    => 'featured3_info_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'lawyer' ),
			),
			array(
				'id'    => 'featured3_info_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Select Icon', 'lawyer' ),
			),
			array(
				'id'    => 'featured3_info_small_text',
				'type'  => 'text',
				'title' => esc_html__( 'Small Text', 'lawyer' ),
			),
			array(
				'id'    => 'featured3_info_text',
				'type'  => 'text',
				'title' => esc_html__( 'Text', 'lawyer' ),
			),
		),
		'std'       => array(
			'time'    => array(
				'group_sort'                => '1',
				'featured3_info_title'      => 'Time',
				'featured3_info_icon'       => 'clock-o',
				'featured3_info_small_text' => 'Open on Mon. - Fri.',
				'featured3_info_text'       => '8:00 - 19:00',
			),
			'contact' => array(
				'group_sort'                => '2',
				'featured3_info_title'      => 'Contact',
				'featured3_info_icon'       => 'headphones',
				'featured3_info_small_text' => 'Call for Consultation',
				'featured3_info_text'       => '123.456.789',
			),
		),
	),

	array(
		'id'    => 'featured3_info_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Info Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Info Text',
			'preview-color' => 'dark',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '32px',
			'color'         => '#ffffff',
			'css-selectors' => '.featured3-section .info-text .big',
		),
	),
	array(
		'id'    => 'featured3_info_small_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Info Small Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Info Small Text',
			'preview-color'  => 'dark',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '12px',
			'color'          => '#ffffff',
			'additional-css' => 'text-transform: uppercase; opacity: 0.5;',
			'css-selectors'  => '.featured3-section .info-text .small',
		),
	),

	array(
		'id'       => 'featured3_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set featured3 section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '98px',
			'right'  => '0',
			'bottom' => '108px',
			'left'   => '0',
		),
	),

);
