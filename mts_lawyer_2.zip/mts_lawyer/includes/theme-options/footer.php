<?php
/**
 * Footer Tab
 *
 * @package Lawyer
 */

$menus['footer'] = array(
	'icon'  => 'fa-table',
	'title' => esc_html__( 'Footer', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of footer section.', 'lawyer' ),
);

$menus['footer']['child']['footer-general'] = array(
	'title' => esc_html__( 'General', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of footer section.', 'lawyer' ),
);

$mts_patterns = array(
	'nobg' => array( 'img' => $uri . 'bg-patterns/nobg.png' ),
);
for ( $i = 1; $i <= 29; $i++ ) {
	$mts_patterns[ 'hbg' . $i ] = array( 'img' => $uri . 'bg-patterns/hbg' . $i . '.png' );
}

$sections['footer-general'] = array(

	array(
		'id'       => 'mts_top_footer',
		'type'     => 'switch',
		'title'    => esc_html__( 'Footer', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enable or disable footer with this option.', 'lawyer' ),
		'std'      => '0',
	),

	array(
		'id'         => 'mts_top_footer_num',
		'type'       => 'button_set',
		'class'      => 'green',
		'title'      => esc_html__( 'Footer Layout', 'lawyer' ),
		'sub_desc'   => wp_kses( __( 'Choose the number of widget areas in the <strong>footer</strong>', 'lawyer' ), array( 'strong' => '' ) ),
		'options'    => array(
			'1' => esc_html__( '1 Widget', 'lawyer' ),
			'2' => esc_html__( '2 Widgets', 'lawyer' ),
			'3' => esc_html__( '3 Widgets', 'lawyer' ),
			'4' => esc_html__( '4 Widgets', 'lawyer' ),
		),
		'std'        => '4',
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'mts_top_footer',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'         => 'footer_sections_position',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Footer Sections Position', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Choose position of Footer Sections.', 'lawyer' ),
		'options'    => array(
			'top'    => esc_html__( 'Above', 'lawyer' ),
			'left'   => esc_html__( 'Left', 'lawyer' ),
			'bottom' => esc_html__( 'Below', 'lawyer' ),
			'right'  => esc_html__( 'Right', 'lawyer' ),
		),
		'std'        => 'bottom',
		'class'      => 'green',
		'dependency' => array(
			'relation' => 'or',
			array(
				'field'      => 'footer_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
			array(
				'field'      => 'footer_brands_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'mts_copyrights',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Copyrights Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'You can change or remove our link from footer and use your own custom text.', 'lawyer' ) . ( MTS_THEME_WHITE_LABEL ? '' : wp_kses( __( '(You can also use your affiliate link to <strong>earn 55% of sales</strong>. Ex: <a href="https://mythemeshop.com/go/aff/aff" target="_blank">https://mythemeshop.com/?ref=username</a>)', 'lawyer' ), array( 'strong' => '', 'a' => array( 'href' => array(), 'target' => array() ) ) ) ),
		// translators: Default value.
		'std'      => MTS_THEME_WHITE_LABEL ? null : sprintf( __( 'Theme by %s', 'lawyer' ), '<a href="https://mythemeshop.com/" rel="nofollow">MyThemeShop</a>' ),
	),

);
