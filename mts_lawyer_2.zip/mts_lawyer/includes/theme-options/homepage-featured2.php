<?php
/**
 * HomePage Featured 2 Section
 *
 * @package Lawyer
 */

$menus['homepage']['child']['homepage-featured2'] = array(
	'title' => esc_html__( 'Featured 2', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the Featured 2 section.', 'lawyer' ),
);

$sections['homepage-featured2'] = array(

	array(
		'id'       => 'featured2_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Featured 2 Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'upload',
			'image_pattern' => 'nobg',
			'image_upload'  => get_template_directory_uri() . '/images/featured2-bg.jpg',
			'repeat'        => 'no-repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'featured2_icon',
		'type'     => 'icon_select',
		'title'    => esc_html__( 'Icon', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select an icon.', 'lawyer' ),
		'std'      => 'shield',
	),

	array(
		'id'       => 'featured2_small_text',
		'type'     => 'text',
		'title'    => esc_html__( 'Small Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter small text here.', 'lawyer' ),
		'std'      => 'EST. 1982',
	),

	array(
		'id'       => 'featured2_nav_section',
		'type'     => 'switch',
		'title'    => esc_html__( 'Navigation Section', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enable or disable Navigation Section with this option.', 'lawyer' ),
		'std'      => '0',
	),
	array(
		'id'         => 'featured2_nav_border',
		'type'       => 'border',
		'title'      => esc_html__( 'Nav Border', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Select border', 'lawyer' ),
		'std'        => array(
			'color'     => '#6a717a',
			'direction' => 'top',
			'size'      => '1',
			'style'     => 'solid',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured2_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'featured2_nav_margin',
		'type'       => 'margin',
		'title'      => esc_html__( 'Nav Margin', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Set featured2 nav margin from here.', 'lawyer' ),
		'std'        => array(
			'top'    => '16px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured2_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),
	array(
		'id'         => 'featured2_nav_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Nav Padding', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Set featured2 nav padding from here.', 'lawyer' ),
		'std'        => array(
			'top'    => '31px',
			'right'  => '0',
			'bottom' => '0',
			'left'   => '0',
		),
		'dependency' => array(
			'relation' => 'and',
			array(
				'field'      => 'featured2_nav_section',
				'value'      => '1',
				'comparison' => '==',
			),
		),
	),

	array(
		'id'       => 'featured2_title',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Title', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter title for featured2 section.', 'lawyer' ),
		'std'      => 'Finest Defence Lawyers',
	),
	array(
		'id'    => 'featured2_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Title',
			'preview-color' => 'dark',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '64px',
			'line-height'   => '68px',
			'color'         => '#ffffff',
			'css-selectors' => '.featured2-section h2',
		),
	),

	array(
		'id'       => 'featured2_button_text1',
		'type'     => 'text',
		'title'    => esc_html__( 'Button1 Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button1 text.', 'lawyer' ),
		'std'      => 'Contact us now',
	),

	array(
		'id'       => 'featured2_button_url1',
		'type'     => 'text',
		'title'    => esc_html__( 'Button1 URL', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button1 URL.', 'lawyer' ),
		'std'      => '#',
	),

	array(
		'id'       => 'featured2_button_text2',
		'type'     => 'text',
		'title'    => esc_html__( 'Button2 Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button2 text.', 'lawyer' ),
		'std'      => 'See & Learn more',
	),

	array(
		'id'       => 'featured2_button_url2',
		'type'     => 'text',
		'title'    => esc_html__( 'Button2 URL', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter button2 URL.', 'lawyer' ),
		'std'      => '#',
	),

	array(
		'id'       => 'featured2_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set featured2 section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '128px',
			'right'  => '0',
			'bottom' => '128px',
			'left'   => '0',
		),
	),

);
