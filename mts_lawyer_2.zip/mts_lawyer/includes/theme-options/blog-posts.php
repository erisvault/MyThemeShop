<?php
/**
 * HomePage Posts
 *
 * @package Lawyer
 */

$features = lawyer_get_settings( 'mts_featured_categories' );
if ( empty( $features ) ) {
	return;
}
foreach ( $features as $feature ) :
	$title     = isset( $feature['mts_featured_title'] ) ? $feature['mts_featured_title'] : 'No Title';
	$unique_id = isset( $feature['unique_id'] ) ? $feature['unique_id'] : '';

	$menus['blog']['child'][ 'blog-' . $unique_id ] = array(
		'title' => $title,
		// translators: description.
		'desc'  => sprintf( wp_kses_post( __( 'From here, you can control the elements of %s', 'lawyer' ) ), $title ),
	);

	// Dependency check that back to top option is enable.
	$post_title_dependency = array(
		'relation' => 'and',
		array(
			'field'      => 'mts_featured_category_title_' . $unique_id,
			'value'      => '1',
			'comparison' => '==',
		),
	);

	$sections[ 'blog-' . $unique_id ] = array(

		/**
		 * Layout Default Settings
		 *
		 * @package Lawyer
		 */

		// Section Title.
		array(
			'id'    => 'mts_post_title_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Section Title', 'lawyer' ),
		),

		array(
			'id'       => 'mts_featured_category_title_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Show/Hide Title', 'lawyer' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide title of post container.', 'lawyer' ),
			'std'      => '0',
		),
		array(
			'id'         => 'mts_post_title_alignment_' . $unique_id,
			'type'       => 'button_set',
			'title'      => esc_html__( 'Section Title Alignment', 'lawyer' ),
			'sub_desc'   => esc_html__( 'Choose the section title alignment', 'lawyer' ),
			'options'    => array(
				'left'   => esc_html__( 'Left', 'lawyer' ),
				'center' => esc_html__( 'Center', 'lawyer' ),
				'right'  => esc_html__( 'Right', 'lawyer' ),
				'full'   => esc_html__( 'Full Width', 'lawyer' ),
			),
			'std'        => 'left',
			'dependency' => $post_title_dependency,
		),
		array(
			'id'         => 'mts_featured_category_title_background_' . $unique_id,
			'type'       => 'background',
			'title'      => esc_html__( 'Post Title Background Color', 'lawyer' ),
			'sub_desc'   => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
			'options'    => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'        => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
			'dependency' => $post_title_dependency,
		),
		array(
			'id'         => 'mts_featured_category_title_margin_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Margin', 'lawyer' ),
			'sub_desc'   => esc_html__( 'Set section title margin from here.', 'lawyer' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
			'dependency' => $post_title_dependency,
		),
		array(
			'id'         => 'mts_featured_category_title_padding_' . $unique_id,
			'type'       => 'margin',
			'title'      => esc_html__( 'Post Title Padding', 'lawyer' ),
			'sub_desc'   => esc_html__( 'Set section title padding from here.', 'lawyer' ),
			'std'        => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
			'dependency' => $post_title_dependency,
		),
		array(
			'id'         => 'post_title_border_' . $unique_id,
			'type'       => 'border',
			'title'      => esc_html__( 'Border', 'lawyer' ),
			'sub_desc'   => esc_html__( 'Select border', 'lawyer' ),
			'dependency' => $post_title_dependency,
		),

		array(
			'id'         => 'mts_featured_category_title_font_' . $unique_id,
			'type'       => 'typography',
			'title'      => esc_html__( 'Section Title Typography', 'lawyer' ),
			'std'        => array(
				'preview-text'   => 'Title Font',
				'preview-color'  => 'light',
				'font-family'    => 'Roboto Condensed',
				'font-weight'    => '700',
				'font-size'      => '26px',
				'color'          => '#000000',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.title-container.title-id-' . $unique_id . ' h3.featured-category-title',
			),
			'dependency' => $post_title_dependency,
		),

		// Meta info.
		array(
			'id'    => 'post_meta_info_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Meta Info', 'lawyer' ),
		),

		array(
			'id'       => 'mts_home_headline_meta_info' . $unique_id,
			'type'     => 'layout2',
			// translators: title.
			'title'    => sprintf( wp_kses_post( __( '%s Meta Info', 'lawyer' ) ), $title ),
			// translators: description.
			'sub_desc' => sprintf( wp_kses_post( __( 'Organize how you want the post meta info to appear on %s', 'lawyer' ) ), $title ),
			'options'  => array(
				'enabled'  => array(
					'author'   => array(
						'label'     => __( 'Author Name', 'lawyer' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_author_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'lawyer' ),
							),
						),
					),
					'category' => array(
						'label'     => esc_html__( 'Categories', 'lawyer' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_category_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'lawyer' ),
							),
						),
					),
					'date'     => array(
						'label'     => esc_html__( 'Date', 'lawyer' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_date_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'lawyer' ),
							),
						),
					),
				),
				'disabled' => array(
					'comment' => array(
						'label'     => esc_html__( 'Comment Count', 'lawyer' ),
						'subfields' => array(
							array(
								'id'    => 'mts_meta_info_comment_icon_' . $unique_id,
								'type'  => 'icon_select',
								'title' => esc_html__( 'Select Icon', 'lawyer' ),
							),
						),
					),
				),
			),
		),

		array(
			'id'       => 'mts_meta_info_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'lawyer' ),
			'sub_desc' => esc_html__( 'Post Meta Info margin.', 'lawyer' ),
			'std'      => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
				'left'   => '0',
			),
		),
		array(
			'id'       => 'mts_meta_info_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'lawyer' ),
			'sub_desc' => esc_html__( 'Post Meta Info padding.', 'lawyer' ),
			'std'      => array(
				'top'    => '0',
				'right'  => '0',
				'bottom' => '29px',
				'left'   => '0',
			),
		),

		array(
			'id'       => 'meta_info_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'lawyer' ),
			'sub_desc' => esc_html__( 'Select border.', 'lawyer' ),
			'std'      => array(
				'direction' => 'bottom',
				'size'      => '1',
				'style'     => 'solid',
				'color'     => '#e0e1e4',
			),
		),

		array(
			'id'    => 'meta_info_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Meta Info Typography', 'lawyer' ),
			'std'   => array(
				'preview-text'   => 'Post Meta Info Font',
				'preview-color'  => 'light',
				'font-family'    => 'Roboto',
				'font-weight'    => '700',
				'font-size'      => '13px',
				'letter-spacing' => '1px',
				'color'          => '#2d3849',
				'additional-css' => 'text-transform: uppercase;',
				'css-selectors'  => '.layout-' . $unique_id . ' .latestPost .post-info',
			),
		),
		// Post Container.
		array(
			'id'    => 'mts_post_heading_' . $unique_id,
			'type'  => 'heading',
			'title' => esc_html__( 'Post Container', 'lawyer' ),
		),

		array(
			'id'       => 'readmore_' . $unique_id,
			'type'     => 'switch',
			'title'    => esc_html__( 'Enable/Disable Read More', 'lawyer' ),
			'sub_desc' => esc_html__( 'Use this button to show or hide readmore.', 'lawyer' ),
			'std'      => '1',
		),

		array(
			'id'       => 'mts_featured_category_background_' . $unique_id,
			'type'     => 'background',
			'title'    => esc_html__( 'Post Background Color', 'lawyer' ),
			'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
			'options'  => array(
				'color'         => '',            // false to disable, not needed otherwise.
				'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
				'image_upload'  => '',            // false to disable, not needed otherwise.
				'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
				'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
				'position'      => array(),       // false to disable, array of options to override default ( optional ).
				'size'          => array(),       // false to disable, array of options to override default ( optional ).
				'gradient'      => '',            // false to disable, not needed otherwise.
				'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
			),
			'std'      => array(
				'color'         => '',
				'use'           => 'pattern',
				'image_pattern' => 'nobg',
				'image_upload'  => '',
				'repeat'        => 'repeat',
				'attachment'    => 'scroll',
				'position'      => 'left top',
				'size'          => 'cover',
				'gradient'      => array(
					'from'      => '#ffffff',
					'to'        => '#000000',
					'direction' => '0deg',
				),
				'parallax'      => '0',
			),
		),
		array(
			'id'       => 'post_border_' . $unique_id,
			'type'     => 'border',
			'title'    => esc_html__( 'Border', 'lawyer' ),
			'sub_desc' => esc_html__( 'Select border', 'lawyer' ),
		),
		array(
			'id'       => 'post_margin_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Margin', 'lawyer' ),
			'sub_desc' => esc_html__( 'Post margin.', 'lawyer' ),
			'left'     => false,
			'right'    => false,
			'std'      => array(
				'top'    => '56px',
				'bottom' => '35px',
			),
		),
		array(
			'id'       => 'post_padding_' . $unique_id,
			'type'     => 'margin',
			'title'    => esc_html__( 'Padding', 'lawyer' ),
			'sub_desc' => esc_html__( 'Post padding.', 'lawyer' ),
			'std'      => array(
				'left'   => '0',
				'top'    => '0',
				'right'  => '0',
				'bottom' => '0',
			),
		),

		array(
			'id'    => 'post_title_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Title Font', 'lawyer' ),
			'std'   => array(
				'preview-text'  => 'Post Title Font',
				'preview-color' => 'light',
				'font-family'   => 'Frank Ruhl Libre',
				'font-weight'   => '400',
				'font-size'     => '36px',
				'line-height'   => '46px',
				'color'         => '#2d3349',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .title a',
			),
		),

		array(
			'id'    => 'post_excerpt_font_' . $unique_id,
			'type'  => 'typography',
			'title' => esc_html__( 'Post Excerpt Font', 'lawyer' ),
			'std'   => array(
				'preview-text'  => 'Post Excerpt Font',
				'preview-color' => 'light',
				'font-family'   => 'Roboto',
				'font-weight'   => '400',
				'font-size'     => '15px',
				'line-height'   => '30px',
				'color'         => '#2d3849',
				'css-selectors' => '.layout-' . $unique_id . ' .latestPost .front-view-content',
			),
		),

	);
endforeach;
