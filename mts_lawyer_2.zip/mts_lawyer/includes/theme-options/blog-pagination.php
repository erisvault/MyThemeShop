<?php
/**
 * HomePage Pagination
 *
 * @package Lawyer
 */

$menus['blog']['child']['blog-pagination'] = array(
	'title' => esc_html__( 'Pagination', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of pagination.', 'lawyer' ),
);

// Dependency check - Default and Numbered pagination.
$default_pagination_dependency = array(
	'relation' => 'and',
	array(
		'field'      => 'mts_pagenavigation_type',
		'value'      => '2',
		'comparison' => '!=',
	),
);

// Dependency check the load more button.
$loadmore_button_dependency = array(
	'relation' => 'and',
	array(
		'field'      => 'mts_pagenavigation_type',
		'value'      => '2',
		'comparison' => '==',
	),
);

$sections['blog-pagination'] = array(

	array(
		'id'       => 'mts_pagenavigation_type',
		'type'     => 'radio',
		'title'    => esc_html__( 'Pagination Type', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select pagination type.', 'lawyer' ),
		'options'  => array(
			'0' => esc_html__( 'Default (Next / Previous)', 'lawyer' ),
			'1' => esc_html__( 'Numbered (1 2 3 4...)', 'lawyer' ),
			'2' => esc_html__( 'AJAX (Load More Button)', 'lawyer' ),
			'3' => esc_html__( 'AJAX (Auto Infinite Scroll)', 'lawyer' ),
		),
		'std'      => '1',
	),

	array(
		'id'         => 'load_more_alignment',
		'type'       => 'button_set',
		'title'      => esc_html__( 'Load More Alignment', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Choose the load more alignment from here.', 'lawyer' ),
		'options'    => array(
			'left'   => esc_html__( 'Left', 'lawyer' ),
			'center' => esc_html__( 'Center', 'lawyer' ),
			'right'  => esc_html__( 'Right', 'lawyer' ),
			'full'   => esc_html__( 'Full Width', 'lawyer' ),
		),
		'std'        => 'center',
		'dependency' => $loadmore_button_dependency,
	),

	array(
		'id'         => 'mts_pagenavigation_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination background color', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Select pagination background color.', 'lawyer' ),
		'std'        => '#ffffff',
		'dependency' => $default_pagination_dependency,
	),
	array(
		'id'         => 'load_more_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More background color', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Select background color for load more button.', 'lawyer' ),
		'std'        => lawyer_get_settings( 'primary_color_scheme' ),
		'dependency' => $loadmore_button_dependency,
	),
	array(
		'id'         => 'mts_pagenavigation_hover_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination background hover color', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Select pagination background hover color.', 'lawyer' ),
		'std'        => '#ffffff',
		'dependency' => $default_pagination_dependency,
	),
	array(
		'id'         => 'load_more_hover_bgcolor',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More background hover color', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Select background hover color for load more button.', 'lawyer' ),
		'std'        => '#2e2f36',
		'dependency' => $loadmore_button_dependency,
	),
	array(
		'id'         => 'mts_pagenavigation_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination color', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Select pagination color.', 'lawyer' ),
		'std'        => '#2d3349',
		'dependency' => $default_pagination_dependency,
	),
	array(
		'id'         => 'load_more_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More color', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Select color for load more button.', 'lawyer' ),
		'std'        => '#ffffff',
		'dependency' => $loadmore_button_dependency,
	),
	array(
		'id'         => 'mts_pagenavigation_hover_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Pagination hover color', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Select pagination hover color.', 'lawyer' ),
		'std'        => lawyer_get_settings( 'primary_color_scheme' ),
		'dependency' => $default_pagination_dependency,
	),
	array(
		'id'         => 'load_more_hover_color',
		'type'       => 'color',
		'title'      => esc_html__( 'Load More hover color', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Select hover color for load more button.', 'lawyer' ),
		'std'        => '#ffffff',
		'dependency' => $loadmore_button_dependency,
	),
	array(
		'id'       => 'mts_pagenavigation_margin',
		'type'     => 'margin',
		'title'    => esc_html__( 'Pagination Margin', 'lawyer' ),
		'sub_desc' => esc_html__( 'Update pagination margin from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '0',
			'right'  => '8px',
			'bottom' => '0',
			'left'   => '0',
		),
	),
	array(
		'id'         => 'mts_pagenavigation_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Pagination Padding', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Update pagination padding from here.', 'lawyer' ),
		'std'        => array(
			'top'    => '10px',
			'right'  => '12px',
			'bottom' => '7px',
			'left'   => '12px',
		),
		'dependency' => $default_pagination_dependency,
	),
	array(
		'id'         => 'load_more_padding',
		'type'       => 'margin',
		'title'      => esc_html__( 'Load More Padding', 'lawyer' ),
		'sub_desc'   => esc_html__( 'Update padding for load more button from here.', 'lawyer' ),
		'std'        => array(
			'top'    => '20px',
			'right'  => '30px',
			'bottom' => '17px',
			'left'   => '30px',
		),
		'dependency' => $loadmore_button_dependency,
	),
	array(
		'id'       => 'mts_pagenavigation_border_radius',
		'type'     => 'text',
		'class'    => 'small-text',
		'title'    => esc_html__( 'Pagination border radius', 'lawyer' ),
		'sub_desc' => esc_html__( 'Update pagination border radius in px.', 'lawyer' ),
		'std'      => '0',
		'args'     => array( 'type' => 'number' ),
	),
	array(
		'id'       => 'pagenavigation_border',
		'type'     => 'border',
		'title'    => esc_html__( 'Border', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select border', 'lawyer' ),
		'std'      => array(
			'color'     => '#e0e1e4',
			'direction' => 'top',
			'size'      => '1',
			'style'     => 'solid',
		),
	),
	array(
		'id'    => 'pagination_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Pagination', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Pagination',
			'preview-color'  => 'light',
			'font-family'    => 'Frank Ruhl Libre',
			'font-weight'    => '500',
			'font-size'      => '22px',
			'color'          => '#2d3349',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.pagination, #load-posts a',
		),
	),

);
