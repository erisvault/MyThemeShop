<?php
/**
 * HomePage Services Grid Section
 *
 * @package Lawyer
 */

$menus['homepage']['child']['homepage-services-grid'] = array(
	'title' => esc_html__( 'Services Grid', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the Services Grid section.', 'lawyer' ),
);

$sections['homepage-services-grid'] = array(

	array(
		'id'       => 'services_grid_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#ffffff',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'services_grid_icon',
		'type'     => 'icon_select',
		'title'    => esc_html__( 'Icon', 'lawyer' ),
		'sub_desc' => esc_html__( 'Select an icon.', 'lawyer' ),
		'std'      => 'institution',
	),

	array(
		'id'       => 'services_grid_title',
		'type'     => 'text',
		'title'    => esc_html__( 'Title', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter title here.', 'lawyer' ),
		'std'      => 'Toughest Defense Lawyers for Your Money',
	),
	array(
		'id'    => 'services_grid_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Title',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '48px',
			'line-height'   => '56px',
			'color'         => '#2d3349',
			'css-selectors' => '.services-grid-section h2',
		),
	),
	array(
		'id'       => 'services_grid_text',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter text here.', 'lawyer' ),
		'std'      => 'Our lawyers will also represent you in civil litigation cases such as divorce, child and<br>spouse maintenance.',
	),
	array(
		'id'    => 'services_grid_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Text',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '20px',
			'line-height'   => '35px',
			'color'         => '#2d3349',
			'css-selectors' => '.services-grid-section p',
		),
	),

	array(
		'id'        => 'services_group',
		'type'      => 'group',
		'title'     => esc_html__( 'Services Grid', 'lawyer' ),
		'sub_desc'  => esc_html__( 'Add services grid appearing on the Services Grid section.', 'lawyer' ),
		'groupname' => esc_html__( 'Services', 'lawyer' ),
		'subfields' => array(
			array(
				'id'    => 'services_group_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'lawyer' ),
			),
			array(
				'id'       => 'services_group_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Upload Image', 'lawyer' ),
				'sub_desc' => esc_html__( 'Select an image file. Recommended size: 255 X 275', 'lawyer' ),
			),
			array(
				'id'    => 'services_group_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Select Icon', 'lawyer' ),
			),
			array(
				'id'    => 'services_group_text',
				'type'  => 'text',
				'title' => esc_html__( 'Text', 'lawyer' ),
			),
			array(
				'id'    => 'services_group_url',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'lawyer' ),
			),
		),
		'std'       => array(
			'1' => array(
				'group_sort'           => '1',
				'services_group_title' => 'In the court of law',
				'services_group_image' => get_template_directory_uri() . '/images/services-grid1.jpg',
				'services_group_icon'  => 'book',
				'services_group_text'  => 'Criminal law',
				'services_group_url'   => '#',
			),
			'2' => array(
				'group_sort'           => '2',
				'services_group_title' => 'Medical Negligence',
				'services_group_image' => get_template_directory_uri() . '/images/services-grid2.jpg',
				'services_group_icon'  => 'book',
				'services_group_text'  => 'Medical Malpractice',
				'services_group_url'   => '#',
			),
			'3' => array(
				'group_sort'           => '3',
				'services_group_title' => 'Family law',
				'services_group_image' => get_template_directory_uri() . '/images/services-grid3.jpg',
				'services_group_icon'  => 'book',
				'services_group_text'  => 'Insurance law',
				'services_group_url'   => '#',
			),
			'4' => array(
				'group_sort'           => '4',
				'services_group_title' => 'Forclosure law',
				'services_group_image' => get_template_directory_uri() . '/images/services-grid4.jpg',
				'services_group_icon'  => 'book',
				'services_group_text'  => 'Real estate law',
				'services_group_url'   => '#',
			),
		),
	),

	array(
		'id'    => 'services_group_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Grid Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Grid Title',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '16px',
			'color'          => '#2d3349',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.services-grid-container h3',
		),
	),
	array(
		'id'    => 'services_group_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Grid Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Grid Text',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '400',
			'font-size'      => '12px',
			'line-height'    => '18px',
			'color'          => '#abadb3',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.services-grid-container p',
		),
	),

	array(
		'id'       => 'services_grid_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set services grid section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '124px',
			'right'  => '0',
			'bottom' => '94px',
			'left'   => '0',
		),
	),

);
