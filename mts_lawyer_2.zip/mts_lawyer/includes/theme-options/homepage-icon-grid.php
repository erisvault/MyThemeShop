<?php
/**
 * HomePage Icon Grid Section
 *
 * @package Lawyer
 */

$menus['homepage']['child']['homepage-icon-grid'] = array(
	'title' => esc_html__( 'Icon Grid', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the icon grid section.', 'lawyer' ),
);

$sections['homepage-icon-grid'] = array(

	array(
		'id'       => 'icon_grid_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Icon Grid Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '#f7f8f9',
			'use'           => 'pattern',
			'image_pattern' => 'nobg',
			'image_upload'  => '',
			'repeat'        => 'repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'        => 'icon_grid',
		'type'      => 'group',
		'title'     => esc_html__( 'Icon Grid', 'lawyer' ),
		'sub_desc'  => esc_html__( 'Add icon grid appearing on the homepage.', 'lawyer' ),
		'groupname' => esc_html__( 'Grid', 'lawyer' ),
		'subfields' => array(
			array(
				'id'    => 'icon_grid_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'lawyer' ),
			),
			array(
				'id'    => 'icon_grid_url',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'lawyer' ),
			),
			array(
				'id'    => 'icon_grid_icon',
				'type'  => 'icon_select',
				'title' => esc_html__( 'Select Icon', 'lawyer' ),
			),
			array(
				'id'    => 'icon_grid_text',
				'type'  => 'textarea',
				'title' => esc_html__( 'Text', 'lawyer' ),
			),
		),
		'std'       => array(
			'1' => array(
				'group_sort'      => '1',
				'icon_grid_title' => 'Bankrupcy',
				'icon_grid_url'   => '#',
				'icon_grid_icon'  => 'credit-card',
				'icon_grid_text'  => 'Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.',
			),
			'2' => array(
				'group_sort'      => '2',
				'icon_grid_title' => 'Traffic Ticket',
				'icon_grid_url'   => '#',
				'icon_grid_icon'  => 'car',
				'icon_grid_text'  => 'Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.',
			),
			'3' => array(
				'group_sort'      => '3',
				'icon_grid_title' => 'Injuries',
				'icon_grid_url'   => '#',
				'icon_grid_icon'  => 'wheelchair',
				'icon_grid_text'  => 'Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.',
			),
			'4' => array(
				'group_sort'      => '4',
				'icon_grid_title' => 'State Planning',
				'icon_grid_url'   => '#',
				'icon_grid_icon'  => 'bar-chart',
				'icon_grid_text'  => 'Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.',
			),
			'5' => array(
				'group_sort'      => '5',
				'icon_grid_title' => 'Car Accident',
				'icon_grid_url'   => '#',
				'icon_grid_icon'  => 'ambulance',
				'icon_grid_text'  => 'Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.',
			),
			'6' => array(
				'group_sort'      => '6',
				'icon_grid_title' => 'Capital Market',
				'icon_grid_url'   => '#',
				'icon_grid_icon'  => 'money',
				'icon_grid_text'  => 'Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.',
			),
		),
	),

	array(
		'id'       => 'icon_grid_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set icon grid section padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '75px',
			'right'  => '0',
			'bottom' => '75px',
			'left'   => '0',
		),
	),

	array(
		'id'    => 'icon_grid_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'   => 'Title',
			'preview-color'  => 'light',
			'font-family'    => 'Roboto',
			'font-weight'    => '700',
			'font-size'      => '16px',
			'color'          => '#2d3849',
			'additional-css' => 'text-transform: uppercase;',
			'css-selectors'  => '.icon-grid-section h3',
		),
	),
	array(
		'id'    => 'icon_grid_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Text',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '12px',
			'line-height'   => '18px',
			'color'         => '#2d3849',
			'css-selectors' => '.icon-grid-section p',
		),
	),

);
