<?php
/**
 * HomePage Featured On Section
 *
 * @package Lawyer
 */

$menus['homepage']['child']['homepage-featured-on'] = array(
	'title' => esc_html__( 'Featured On', 'lawyer' ),
	'desc'  => esc_html__( 'From here, you can control the elements of the Featured On section.', 'lawyer' ),
);

$sections['homepage-featured-on'] = array(

	array(
		'id'       => 'featured_on_background',
		'type'     => 'background',
		'title'    => esc_html__( 'Section Background', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set background color, pattern and image from here.', 'lawyer' ),
		'options'  => array(
			'color'         => '',            // false to disable, not needed otherwise.
			'image_pattern' => $mts_patterns, // false to disable, array of options otherwise ( required !!! ).
			'image_upload'  => '',            // false to disable, not needed otherwise.
			'repeat'        => array(),       // false to disable, array of options to override default ( optional ).
			'attachment'    => array(),       // false to disable, array of options to override default ( optional ).
			'position'      => array(),       // false to disable, array of options to override default ( optional ).
			'size'          => array(),       // false to disable, array of options to override default ( optional ).
			'gradient'      => '',            // false to disable, not needed otherwise.
			'parallax'      => array(),       // false to disable, array of options to override default ( optional ).
		),
		'std'      => array(
			'color'         => '',
			'use'           => 'upload',
			'image_pattern' => 'nobg',
			'image_upload'  => get_template_directory_uri() . '/images/featured-on-bg.jpg',
			'repeat'        => 'no-repeat',
			'attachment'    => 'scroll',
			'position'      => 'left top',
			'size'          => 'cover',
			'gradient'      => array(
				'from'      => '#ffffff',
				'to'        => '#000000',
				'direction' => '0deg',
			),
			'parallax'      => '0',
		),
	),

	array(
		'id'       => 'featured_on_title',
		'type'     => 'text',
		'title'    => esc_html__( 'Title', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter title here.', 'lawyer' ),
		'std'      => 'We are Regularly Featured in Press',
	),
	array(
		'id'    => 'featured_on_title_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Title Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Title',
			'preview-color' => 'light',
			'font-family'   => 'Frank Ruhl Libre',
			'font-weight'   => '400',
			'font-size'     => '48px',
			'line-height'   => '56px',
			'color'         => '#2d3349',
			'css-selectors' => '.featured-on-section h2',
		),
	),
	array(
		'id'       => 'featured_on_text',
		'type'     => 'textarea',
		'title'    => esc_html__( 'Text', 'lawyer' ),
		'sub_desc' => esc_html__( 'Enter text here.', 'lawyer' ),
		'std'      => 'Our lawyers will also represent you in civil litigation cases such as divorce, child and spouse maintenance.',
	),
	array(
		'id'    => 'featured_on_text_font',
		'type'  => 'typography',
		'title' => esc_html__( 'Text Font', 'lawyer' ),
		'std'   => array(
			'preview-text'  => 'Text',
			'preview-color' => 'light',
			'font-family'   => 'Roboto',
			'font-weight'   => '400',
			'font-size'     => '20px',
			'line-height'   => '35px',
			'color'         => '#2d3349',
			'css-selectors' => '.featured-on-section p',
		),
	),

	array(
		'id'        => 'featured_on_group',
		'type'      => 'group',
		'title'     => esc_html__( 'Brands', 'lawyer' ),
		'sub_desc'  => esc_html__( 'Add brand appearing on the Featured On section.', 'lawyer' ),
		'groupname' => esc_html__( 'Brand', 'lawyer' ),
		'subfields' => array(
			array(
				'id'    => 'featured_on_group_title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'lawyer' ),
			),
			array(
				'id'       => 'featured_on_group_image',
				'type'     => 'upload',
				'title'    => esc_html__( 'Upload Image', 'lawyer' ),
				'sub_desc' => esc_html__( 'Select an image file. Recommended size: 255 X 175', 'lawyer' ),
			),
			array(
				'id'    => 'featured_on_group_url',
				'type'  => 'text',
				'title' => esc_html__( 'URL', 'lawyer' ),
			),
		),
		'std'       => array(
			'1' => array(
				'group_sort'              => '1',
				'featured_on_group_title' => 'Logo1',
				'featured_on_group_image' => get_template_directory_uri() . '/images/featured-on1.png',
				'featured_on_group_url'   => '#',
			),
			'2' => array(
				'group_sort'              => '2',
				'featured_on_group_title' => 'Logo2',
				'featured_on_group_image' => get_template_directory_uri() . '/images/featured-on2.png',
				'featured_on_group_url'   => '#',
			),
			'3' => array(
				'group_sort'              => '3',
				'featured_on_group_title' => 'Logo3',
				'featured_on_group_image' => get_template_directory_uri() . '/images/featured-on3.png',
				'featured_on_group_url'   => '#',
			),
			'4' => array(
				'group_sort'              => '4',
				'featured_on_group_title' => 'Logo4',
				'featured_on_group_image' => get_template_directory_uri() . '/images/featured-on4.png',
				'featured_on_group_url'   => '#',
			),
		),
	),

	array(
		'id'       => 'featured_on_padding',
		'type'     => 'margin',
		'title'    => esc_html__( 'Padding', 'lawyer' ),
		'sub_desc' => esc_html__( 'Set padding from here.', 'lawyer' ),
		'std'      => array(
			'top'    => '97px',
			'right'  => '0',
			'bottom' => '59px',
			'left'   => '0',
		),
	),

);
