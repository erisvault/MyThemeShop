<?php
/**
 * Before footer detect ad blocker notice.
 *
 */

if ( lawyer_get_settings( 'detect_adblocker' ) && ( 'popup' === lawyer_get_settings( 'detect_adblocker_type' ) || 'floating' === lawyer_get_settings( 'detect_adblocker_type' ) ) ) { ?>
	<?php if ( 'popup' === lawyer_get_settings( 'detect_adblocker_type' ) ) { ?>
		<div class="blocker-overlay"></div>
	<?php } ?>
	<?php echo detect_adblocker_notice(); ?>
<?php } ?>
