<?php
/**
 * Homepage Section - Featured On
 *
 * @package Lawyer
 */

$title             = lawyer_get_settings( 'featured_on_title' );
$text              = lawyer_get_settings( 'featured_on_text' );
$featured_on_grids = lawyer_get_settings( 'featured_on_group' );

if ( empty( $title ) && empty( $text ) && empty( $featured_on_grids ) && ! is_array( $featured_on_grids ) ) {
	return;
}
?>

<section class="featured-on-section clearfix">

	<div class="container">

		<?php
		if ( ! empty( $title ) ) {
			printf( '<h2>%s</h2>', $title );
		}
		if ( ! empty( $text ) ) {
			printf( '<p>%s</p>', $text );
		}

		// Services grids.
		if ( ! empty( $featured_on_grids ) && is_array( $featured_on_grids ) ) {

			echo '<ul class="featured-on-container">';
			foreach ( $featured_on_grids as $featured_on_grid ) {
				printf(
					'<li><a href="%1$s"><img src="%2$s"></a></li>',
					$featured_on_grid['featured_on_group_url'],
					$featured_on_grid['featured_on_group_image']
				);
			}

			echo '</ul>';

		}
		?>

	</div><!-- .container -->

</section>
