<?php
/**
 * Homepage Section - Icon Grid
 *
 * @package Lawyer
 */

?>

<section class="icon-grid-section clearfix">

	<div class="container">

		<?php

		// Icon grids.
		$icon_grids = lawyer_get_settings( 'icon_grid' );
		if ( ! empty( $icon_grids ) && is_array( $icon_grids ) ) {

			if ( empty( $icon_grids ) ) {
				return;
			}

			echo '<ul class="icon-grid-container">';

			foreach ( $icon_grids as $icon_grid ) {
				printf(
					'<li><a href="%1$s"><div class="icon"><i class="fa fa-%2$s"></i></div><h3>%3$s</h3><p>%4$s</p><span class="fa fa-angle-right"></span></a></li>',
					$icon_grid['icon_grid_url'],
					$icon_grid['icon_grid_icon'],
					$icon_grid['icon_grid_title'],
					$icon_grid['icon_grid_text']
				);
			}

			echo '</ul>';

		}
		?>

	</div><!-- .container -->

</section>
