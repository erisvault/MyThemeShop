<?php
/**
 * Homepage Section - Featured 3
 *
 * @package Lawyer
 */

$icon       = lawyer_get_settings( 'featured3_icon' );
$title      = lawyer_get_settings( 'featured3_title' );
$text       = lawyer_get_settings( 'featured3_text' );
$img1       = lawyer_get_settings( 'featured3_img1' );
$img2       = lawyer_get_settings( 'featured3_img2' );
$info_items = lawyer_get_settings( 'featured3_info' );

if ( empty( $icon ) && empty( $title ) && empty( $text ) && empty( $img1 ) && empty( $img2 ) && empty( $info_items ) && ! is_array( $info_items ) ) {
	return;
}
?>

<section class="featured3-section clearfix">

	<div class="container">

		<?php
		if ( $icon ) {
			echo '<i class="icon fa fa-' . $icon . '"></i>';
		}
		if ( $title ) {
			echo '<h2>' . $title . '</h2>';
		}
		if ( $text ) {
			echo '<p>' . $text . '</p>';
		}
		if ( $img1 && $img2 ) {
			printf(
				'<div class="img-container"><img src="%1$s"><img src="%2$s"></div>',
				$img1,
				$img2
			);
		}
		// Info items.
		if ( $info_items && is_array( $info_items ) ) {

			echo '<ul class="info-text">';
			foreach ( $info_items as $info_item ) {
				printf(
					'<li><div class="icon"><i class="fa fa-%1$s"></i></div><div class="text-wrapper"><div class="small">%2$s</div><div class="big">%3$s</div></div></li>',
					$info_item['featured3_info_icon'],
					$info_item['featured3_info_small_text'],
					$info_item['featured3_info_text']
				);
			}

			echo '</ul>';

		}
		?>

	</div><!-- .container -->

</section>
