<?php
/**
 * Template Name: HomePage
 *
 * @package Lawyer
 */

get_header();

?>

<div id="wrapper" class="clearfix">

	<?php

	lawyer_homepage_sections();

	get_footer();
