<?php
// make sure to not include translations
$args['presets']['default'] = array(
	'title' => 'Default',
	'demo' => 'http://demo.mythemeshop.com/viral/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/default/thumb.jpg',
	'menus' => array( 'primary' => 'Top', 'secondary' => 'Menu' ), // menu location slug => Demo menu name
	'options' => array( 'show_on_front' => 'posts' ),
);

$args['presets']['photography'] = array(
	'title' => 'Photography',
	'demo' => 'http://demo.mythemeshop.com/viral-photography/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/photography/thumb.jpg',
	'menus' => array( 'primary' => 'Top', 'secondary' => 'Menu' ), // menu location slug => Demo menu name
	'options' => array( 'show_on_front' => 'posts' ),
);

$args['presets']['cat'] = array(
	'title' => 'Cat',
	'demo' => 'http://demo.mythemeshop.com/viral-cat/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/cat/thumb.jpg',
	'menus' => array( 'secondary' => 'Menu' ), // menu location slug => Demo menu name
	'options' => array( 'show_on_front' => 'posts' ),
);

$args['presets']['food'] = array(
	'title' => 'Food',
	'demo' => 'http://demo.mythemeshop.com/viral-food/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/food/thumb.jpg',
	'menus' => array( 'primary' => 'Menu' ), // menu location slug => Demo menu name
	'options' => array( 'show_on_front' => 'posts' ),
);

global $mts_presets;
$mts_presets = $args['presets'];
