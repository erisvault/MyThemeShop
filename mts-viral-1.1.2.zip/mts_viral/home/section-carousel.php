<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<div class="primary-slider-container clearfix loading">
	<div class="container clearfix">
		<div id="slider" class="primary-slider">
		<?php if ( empty( $mts_options['mts_custom_carousel'] ) ) {
			// prevent implode error
			if ( empty( $mts_options['mts_featured_carousel_cat'] ) || !is_array( $mts_options['mts_featured_carousel_cat'] ) ) {
				$mts_options['mts_featured_carousel_cat'] = array('0');
			}

			$slider_cat = implode( ",", $mts_options['mts_featured_carousel_cat'] );
			$slider_query = new WP_Query('cat='.$slider_cat.'&posts_per_page='.$mts_options['mts_featured_carousel_num']);
			while ( $slider_query->have_posts() ) : $slider_query->the_post();
			?>
				<div class="primary-slider-item"> 
					<a href="<?php echo esc_url( get_the_permalink() ); ?>">
						<?php the_post_thumbnail('viral-carousel',array('title' => '')); ?>
					</a> 
				</div>
			<?php endwhile; wp_reset_postdata();
		} else {
			foreach( $mts_options['mts_custom_carousel'] as $slide ) : ?>
				<?php if( $slide['mts_custom_carousel_url']) { ?>
				<a href="<?php echo esc_url( $slide['mts_custom_carousel_url'] ); ?>">
				<?php } ?>
				<div class="primary-slider-item">
					<?php echo wp_get_attachment_image( $slide['mts_custom_carousel_image'], 'viral-carousel', false, array('title' => '') ); ?>
				</div>
				<?php if( $slide['mts_custom_carousel_url']) { ?>
				</a>
				<?php } ?>
			<?php endforeach;
		} ?>
		</div><!-- .primary-slider -->
	</div>
</div><!-- .primary-slider-container -->