<?php
/**
 * The main template file.
 *
 * Used to display the homepage when home.php doesn't exist.
 */
$mts_options = get_option(MTS_THEME_NAME);
get_header(); ?>

<?php 
$layout = mts_get_posts_layout();
if( is_home() && !is_paged() && $mts_options['mts_featured_carousel'] && $mts_options['mts_carousel_position'] == 'top' ) {
	get_template_part('home/section', 'carousel');
} 
?>

<div id="page">
	<div class="article">
		<div id="content_box">
			<?php if ( !is_paged() ) {
				$featured_categories = array();
				if ( !empty( $mts_options['mts_featured_categories'] ) ) {
					foreach ( $mts_options['mts_featured_categories'] as $section ) {
						$category_id = $section['mts_featured_category'];
						$featured_categories[] = $category_id;
						$posts_num = $section['mts_featured_category_postsnum'];
						if ( 'latest' == $category_id ) { ?>
							<div class="featured-view-posts <?php echo $layout; ?> featured-view-posts-latest">
								<?php $j = 0; if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
									<article class="latestPost excerpt">
										<?php mts_archive_post( $layout ); ?>
									</article>
								<?php endwhile; endif; ++$j; ?>
							</div><!-- .featured-view-posts -->
							
							<?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
								<?php mts_pagination(); ?>
							<?php } ?>
							
						<?php } else { // if $category_id != 'latest': ?>
							<h3 class="featured-category-title"><a href="<?php echo esc_url( get_category_link( $category_id ) ); ?>" title="<?php echo esc_attr( get_cat_name( $category_id ) ); ?>"><?php echo esc_html( get_cat_name( $category_id ) ); ?></a></h3>
							<div class="featured-view-posts <?php echo $layout; ?>">
							<?php $j = 0; $cat_query = new WP_Query('cat='.$category_id.'&posts_per_page='.$posts_num);
							if ( $cat_query->have_posts() ) : while ( $cat_query->have_posts() ) : $cat_query->the_post(); ?>
								<article class="latestPost excerpt">
									<?php mts_archive_post( $layout ); ?>
								</article>
							<?php
							endwhile; endif; ++$j; wp_reset_postdata(); ?>
							</div><!-- .featured-view-posts -->
						<?php }
					}
				} ?>

			<?php } else { //Paged ?>
				<div class="featured-view-posts <?php echo $layout; ?> featured-view-posts-latest">
				<?php $j = 0; if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
					<article class="latestPost excerpt">
						<?php mts_archive_post( $layout ); ?>
					</article>
				<?php endwhile; endif; ++$j; ?>
				</div><!-- .featured-view-posts -->

				<?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
					<?php mts_pagination(); ?>
				<?php } ?>

			<?php } ?>
		</div>
	</div>
	<?php get_sidebar(); ?>
<?php get_footer(); ?>