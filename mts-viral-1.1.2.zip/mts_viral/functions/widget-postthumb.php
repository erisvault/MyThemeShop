<?php
/*-----------------------------------------------------------------------------------

	Plugin Name: MyThemeShop Recent Post Thumbs
	Version: 1.0
	
-----------------------------------------------------------------------------------*/
if( ! class_exists( 'mts_recent_postthumbs_widget' ) ){
	class mts_recent_postthumbs_widget extends WP_Widget {

		public function __construct() {
			parent::__construct(
		 		'mts_recent_postthumbs_widget',
				sprintf( __('%sRecent Post Thumbs', 'viral' ), MTS_THEME_WHITE_LABEL ? '' : 'MTS ' ),
				array( 'description' => __( 'Display the most recent posts from all categories', 'viral' ) )
			);
		}

	 	public function form( $instance ) {
			$defaults = array(
				'show_thumb2' => 1
			);
			$instance = wp_parse_args((array) $instance, $defaults);
			$qty = isset( $instance[ 'qty' ] ) ? esc_attr( $instance[ 'qty' ] ) : 6;
			?>

			<p>
				<label for="<?php echo $this->get_field_id( 'qty' ); ?>"><?php _e( 'Number of Posts to show', 'viral' ); ?></label>
				<input id="<?php echo $this->get_field_id( 'qty' ); ?>" name="<?php echo $this->get_field_name( 'qty' ); ?>" type="number" min="1" step="1" value="<?php echo esc_attr( $qty ); ?>" />
			</p>
		   
			<?php 
		}

		public function update( $new_instance, $old_instance ) {
			$instance = array();
			$instance['qty'] = intval( $new_instance['qty'] );
			return $instance;
		}

		public function widget( $args, $instance ) {
			extract( $args );
			$qty = (int) $instance['qty'];

			echo $before_widget;
			echo self::get_cat_posts( $qty );
			echo $after_widget;
		}

		public function get_cat_posts( $qty ) {

			$page_id = get_queried_object_id();
			
			$posts = new WP_Query( array(
				'orderby' => 'date',
				'order' => 'DESC',
				'posts_per_page' => $qty,
				'ignore_sticky_posts' => true,
				'no_found_rows' => true,
				'post_status' => 'publish',
			) ); ?>

			<div class="widget-prev-next">
				<?php previous_post_link('%link', '<i class="fa fa-angle-double-left"></i> '.__('Previous','viral')); ?>
				<?php next_post_link('%link', __('Next','viral').' <i class="fa fa-angle-double-right"></i>'); ?>
			</div>

			<?php echo '<ul class="mts-postthumb">';
			while ( $posts->have_posts() ) { $posts->the_post(); ?>
			<?php $post_id = get_the_ID(); ?>
				<li class="widget-postthumb">
					<div class="post-img">
						<a href="<?php echo esc_url( get_the_permalink() ); ?>" class="<?php echo ( $page_id == $post_id ) ? 'active' : ''; ?>" title="<?php echo esc_attr( get_the_title() ); ?>">
							<?php if ( has_post_thumbnail() ) { ?>
								<?php the_post_thumbnail( 'viral-postthumb', array( 'title' => '' ) ); ?>
							<?php } else { ?>
								<img class="wp-post-image" src="<?php echo get_template_directory_uri() . '/images/nothumb-viral-postthumb.png'; ?>" alt="<?php echo esc_attr( get_the_title() ); ?>"/>
							<?php } ?>
						</a>
					</div>
				</li>
			<?php }
			wp_reset_postdata();
			echo '</ul>'."\r\n";
		}

	}
}
// Register widget
add_action( 'widgets_init', 'register_mts_recent_postthumbs_widget' );
function register_mts_recent_postthumbs_widget() {
	register_widget( 'mts_recent_postthumbs_widget' );
}
